<?php 
class Logs_sys_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        if( !in_array($this->admin['level'], [
            1, 
            9
        ]) ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function nav()
    {
        global $cur_file;
        echo "<div class=\"app_nav\"> \t\t\n\t\t \n         <a class=\"btn btn-default\" href=\"" . $this->base . "/index\"><i class=\"icon-bug\"></i> System Logs</a> &nbsp;&nbsp; \t\t \t\t \n           - <a href='" . $this->base . "/LogsDel' class=\"btn btn-danger icon-trash\" OnClick=\"return confirm('Are you sure?');\">Delete logs</a>\n\t\t \n\t\t </div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        global $code;
        global $serial;
        global $mac;
        global $thelog;
        global $ip;
        global $order;
        global $qry;
        global $page;
        $intro->db->query('OPTIMIZE TABLE ' . PREFIX . '_logs;');
        echo "<div dir=ltr>\n";
        $this->nav();
        $page = intval($intro->input->get_post('page'));
        $code = $intro->db->escape($intro->input->get_post('code'));
        $serial = $intro->db->escape($intro->input->get_post('serial'));
        $mac = $intro->db->escape($intro->input->get_post('mac'));
        $thelog = $intro->db->escape($intro->input->get_post('thelog'));
        $ip = $intro->db->escape($intro->input->get_post('ip'));
        $qry = $intro->db->escape($intro->input->get_post('qry'));
        $action = $intro->db->escape($intro->input->get_post('action'));
        $admin_user = $intro->db->escape($intro->input->get_post('admin_user'));
        $params = '';
        if( $thelog != '' ) 
        {
            $qry .= (' AND the_log  LIKE \'%' . $thelog . '%\'');
            $params .= ('&thelog=' . $thelog);
        }
        if( $ip != '' ) 
        {
            $qry .= (' AND ip LIKE \'%' . $ip . '%\'');
            $params .= ('&ip=' . $ip);
        }
        if( $action != '' ) 
        {
            $qry .= (' AND action LIKE \'%' . $action . '%\'');
            $params .= ('&action=' . $action);
        }
        if( $admin_user != '' ) 
        {
            $qry .= (' AND admin_user LIKE \'%' . $admin_user . '%\'');
            $params .= ('&admin_user=' . $admin_user);
        }
        if( $qry != '' ) 
        {
            $qry = 'WHERE true ' . $qry;
        }
        if( $order == '' ) 
        {
            $order = 'id_desc';
        }
        $order = str_replace('_desc', ' desc', $order);
        $order = str_replace('_asc', ' asc', $order);
        $rows_per_page = '50';
        if( intval($page) == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT id,admin_user,dtime,app,ip,action,LEFT(the_log, 210) as the_log2 from ' . PREFIX . ('_logs_sys  ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $resultnumm = $intro->db->query('SELECT id from ' . PREFIX . ('_logs_sys  ' . $qry));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-bug"></i> System Logs (' . $totalrows . ')');
        echo "\n\t\t\n\t\t<form action=\"\" method=\"post\" class=''>\n\t\t\tReseller: " . $this->getAdminUser($admin_user) . "\n\t\t\tAction: " . $this->getActions($action) . ("\n\t\t\t<input type=\"text\" name=\"ip\" value=\"" . $ip . "\" size=\"30\" placeholder=\"IP\">\n\t\t\t<input type=\"text\" name=\"thelog\" value=\"" . $thelog . "\" size=\"30\" placeholder=\"Log text\">\n\t\t\t\n\t\t\t<input  name=\"name\" value=\"Search\" type=\"submit\">\n\t\t</form><hr>");
        echo "\n\t\n\t  <table class=\"table table-bordered table-hover table-condensed table-striped\">\n            <tr>\n\t\t\t\t<th>ID</th>\n\t\t\t\t<th>user</th>\n\t\t\t\t<th>Date</th>\n\t\t\t\t<th>App</th>\n\t\t\t\t<th>Action</th>\n\t\t\t\t<th>IP</th>\n\t\t\t\t<th> </th>\n\t\t\t\t<th>Log</th>\n\t    </tr>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            if( $i % 2 == 0 ) 
            {
                $BG = 'odd';
            }
            else
            {
                $BG = 'even';
            }
            $action = str_replace('login_fail', '<span class=\'label label-danger\'>login_fail</span>', $action);
            $action = str_replace('not_allowed_ip', '<span class=\'label label-danger\'>not_allowed_ip</span>', $action);
            $action = str_replace('suspended', '<span class=\'label label-warning\'>suspended</span>', $action);
            $action = str_replace('login_success', '<span class=\'label label-success\'>login_success</span>', $action);
            $action = str_replace('reset_codes', '<span class=\'label label-success\'>reset_codes</span>', $action);
            $action = str_replace('logout', '<span class=\'label label-primary\'>logout</span>', $action);
            $the_log = $the_log2;
            $the_log = str_replace('<!--', '[!]--', $the_log);
            $the_log = strip_tags($the_log);
            $the_log = htmlentities($the_log);
            $admin_user = htmlentities($admin_user);
            if( $country == '' ) 
            {
                $c = $intro->maxmind->get($ip)['country']['iso_code'];
                if( $c != '' ) 
                {
                    $flag = 'flag flag-' . strtolower($c);
                }
                else
                {
                    $flag = '';
                }
            }
            else
            {
                $flag = 'flag flag-' . strtolower($country);
            }
            echo "\n\t\t\t<tr>\n\t\t\t\t<td class=\"center\">" . $id . "</td>\n\t\t\t\t<td class=\"center\">" . $admin_user . "</td>\n\t\t\t\t<td class=\"center\">" . $dtime . "</th>\n\t\t\t\t<td class=\"center\">" . $app . "</th>\n\t\t\t\t<td class=\"center\">" . $action . "</th>\n\t\t\t\t<td class=\"center\"><a href='https://www.ip2location.com/demo/" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\n\t\t\t\t<td class=\"center\"><img src=\"" . admin_path . ('style/css/flags/blank.gif" class="' . $flag . '" title="' . $country . "\" /></th>\n\t\t\t\t<td><a class='AjaxModal' href='" . $this->base . '/View?id=' . $id . '&amp;NH=1\'>' . $the_log . "</a></th>     \n\t\t\t</tr>");
        }
        echo '</table>';
        $order = str_replace(' desc', '_desc', $order);
        $order = str_replace(' asc', '_asc', $order);
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?order=' . $order . $params, $totalrows, $rows_per_page, $page) . '</center>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function LogsDel()
    {
        global $intro;
        $intro->db->query('truncate ' . PREFIX . '_logs_sys; ');
        $intro->redirect($this->appname);
    }
    public function View()
    {
        global $intro;
        $id = intval($intro->input->get_post('id'));
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs_sys  where id=' . $id));
        $myrow = $intro->db->fetch_assoc($result);
        extract($myrow);
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22();
        echo "<ul>\n\t\t\t<li>ID : " . $id . "</li>\n\t\t\t<li>Reseller: " . $admin_user . "</li>\n\t\t\t<li>Date: " . $dtime . "</li>\n\t\t\t<li>APP: " . $app . "</li>\n\t\t\t<li>Action: " . $action . "</li>\n\t\t</ul>";
        if( $intro->input->get_post('html') != 'true' ) 
        {
            if( $action == 'capture' ) 
            {
                echo '<a href="' . $this->base . '/View?id=' . $id . '&amp;NH=1&amp;html=true">Encode HTML<a><br/>';
            }
            echo '<textarea style=\'width:99%;height:300px;\'>' . $the_log . '</textarea>';
        }
        else
        {
            echo $the_log;
        }
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function getActions($comp)
    {
        global $intro;
        global $array;
        $html = '<select name="action" class="chosen searchable">';
        $html .= '<option value="" selected="selected"> ALL </option>';
        $result = $intro->db->query('SELECT DISTINCT(`action`) from ' . PREFIX . '_logs_sys ORDER BY `action` ASC');
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            $act = $row['action'];
            $html .= ('<option value="' . $act . '" ' . (($comp == $act ? 'selected="selected"' : '')) . ('>' . $act . '</option>'));
        }
        return $html .= '</select>';
    }
    public function getAdminUser($comp)
    {
        global $intro;
        global $array;
        $html = '<select name="admin_user" class="chosen searchable">';
        $html .= '<option value="" selected="selected"> ALL </option>';
        $result = $intro->db->query('SELECT DISTINCT(`admin_user`) from ' . PREFIX . '_logs_sys ORDER BY `admin_user` ASC');
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            $admin_user = $row['admin_user'];
            $html .= ('<option value="' . $admin_user . '" ' . (($comp == $admin_user ? 'selected="selected"' : '')) . ('>' . $admin_user . '</option>'));
        }
        return $html .= '</select>';
    }
}
