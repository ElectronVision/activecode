<?php 
class Packages
{
    public $adminid = 0;
    public $period = 0;
    public $userid = 0;
    public $num = 0;
    public $cost = 0;
    public $ResellerCost = 0;
    public $FatherCost = 0;
    public $AdminGroup = 0;
    public $packages = [];
    public $error = '';
    public $admin = [];
    public $qry = '';
    public $OfficialOnly = false;
    public function __construct($admin)
    {
        $this->admin = $admin;
        $this->AdminGroup = $this->admin['member_group_id'];
    }
    public function getPackages()
    {
        global $intro;
        global $array;
        if( $this->OfficialOnly && $this->admin['level'] != 1 ) 
        {
            $this->qry = ' WHERE is_official=1';
        }
        $result = $intro->db->query('SELECT * from packages ' . $this->qry . ' order by is_official ASC ');
        while( $r = $intro->db->fetch_assoc($result) ) 
        {
            $id = $r['id'];
            if( strlen($this->admin['packages']) > 10 ) 
            {
                $json = json_decode($this->admin['packages'], true);
                if( isset($json[$id]['official_credits']) && floatval($json[$id]['official_credits']) > 0 ) 
                {
                    $r['official_credits'] = floatval($json[$id]['official_credits']);
                }
            }
            $groups = json_decode($r['groups'], true);
            foreach( $groups as $gid ) 
            {
                $this->packages[$gid][] = $r;
            }
        }
    }
    public function FormDropDown()
    {
        $this->getPackages();
        if( !isset($this->packages[$this->AdminGroup]) ) 
        {
            return 'Error: Wrong Package.';
        }
        $html = "<select name=\"package\" id=\"package\" class=\"searchable\">\n\t\t<option value='0'>Choose Package</option>";
        foreach( $this->packages[$this->AdminGroup] as $row ) 
        {
            extract($row);
            $html .= ('<option value="' . $id . '"  style="' . (($is_trial == 1 ? 'color:red;' : '')) . '">' . ($package_name . ' ') . (($is_official == 1 ? '[Credit: ' . $official_credits . ']' : '')) . '</option>');
        }
        return $html . '</select>';
    }
    public function set($name, $value)
    {
        $this->$name = $value;
    }
}
