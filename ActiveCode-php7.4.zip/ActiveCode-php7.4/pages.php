<?php 
define('_CHECK_X_ME', true);
require(dirname(__FILE__) . '/load2.php');
$sql = $db->query('select * from ' . PREFIX . '_options');
while( $row = $db->fetch_assoc($sql) ) 
{
    $op_name = trim($row['name']);
    $options[$op_name] = stripslashes($row['val']);
}
$page = $intro->input->get('page');
if( $page == 'm3u' ) 
{
    $user = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get('user'), '_');
    $pass = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get('pass'), '_');
    $sql = $intro->db->query('SELECT bouquet FROM users where ' . (' username=\'' . $user . '\' AND password=\'' . $pass . '\';'));
    $row = $intro->db->fetch_assoc($sql);
    if( !$row ) 
    {
        exit( 'L_' );
    }
    $bouquet = json_decode($row['bouquet'], true);
    if( count($bouquet) == 0 ) 
    {
        exit( 'B_' );
    }
    header('Content-Type: audio/mpegurl');
    header('Content-Disposition: attachment; filename=' . $user . '.m3u');
    echo "#EXTM3U\n";
    $sql = $intro->db->query('SELECT SQL_CACHE * FROM bouquets  WHERE id IN (' . implode(',', $bouquet) . ') order by view_order asc;');
    $i = 0;
    while( $row = $intro->db->fetch_assoc($sql) ) 
    {
        $i++;
        $bouquet_channels = @json_decode($row['bouquet_channels'], true);
        $ch_count = @count($bouquet_channels);
        $sql_ch = $intro->db->query('SELECT id, stream_display_name,stream_source,stream_icon    FROM streams  WHERE  id IN (' . implode(',', $bouquet_channels) . ');');
        while( $row = $intro->db->fetch_assoc($sql_ch) ) 
        {
            extract($row);
            $stream = str_replace([
                '{type}', 
                '{user}', 
                '{pass}', 
                '{ch}'
            ], [
                'live', 
                $user, 
                $pass, 
                $id
            ], trim($intro->option['iptv_host']));
            echo '#EXTINF:-1,' . $stream_display_name . "\n" . ($stream . "\n");
        }
    }
    exit();
}
echo "<!doctype html>\n<html>\n<head>\n<meta charset=\"utf-8\"/>\n</head>\n<body>\n";
if( $page == 'help' ) 
{
    echo stripslashes(nl2br($options['help']));
}
else if( $page == 'about' ) 
{
    echo stripslashes(nl2br($options['about']));
}
else
{
    echo 'error page not found.';
}
echo "</body>\n</html>";
