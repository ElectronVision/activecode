<?php 
$cssFiles = [
    './introtik.css', 
    './bootstrap.min.css', 
    './style.css', 
    '../js/chosen/chosen.min.css', 
    '../editable/css/bootstrap-editable.css', 
    '../js/jquery-ui.min.css', 
    '../js/sel/sel.css', 
    '../datatables/datatables.min.css', 
    './flags/flags.min.css', 
    '../bootstrap-toggle/css/bootstrap-toggle.css', 
    '../tagsinput/bootstrap-tagsinput.css'
];
$buffer = '';
foreach( $cssFiles as $cssFile ) 
{
    $buffer .= file_get_contents($cssFile);
}
$buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
$buffer = str_replace(': ', ':', $buffer);
$buffer = str_replace([
    "\r\n", 
    "\r", 
    "\n", 
    "\t", 
    '  ', 
    '    ', 
    '    '
], '', $buffer);
ob_start('ob_gzhandler');
header('Cache-Control: public');
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 86400) . ' GMT');
header('Content-type: text/css');
echo $buffer;
