<?php 
class Osd_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $qry_admin = '';
    public $qry_admin_code = '';
    public $qry_admin_where = '';
    public $qry_admin_where_code = '';
    public $admin = [];
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $adminid = intval($this->admin['adminid']);
        if( $this->admin['level'] != 1 ) 
        {
            $this->qry_admin = ' and member_id=' . $adminid;
            $this->qry_admin_where = ' where member_id=' . $adminid;
            $this->qry_admin_code = ' and adminid=' . $adminid;
            $this->qry_admin_where_code = ' where adminid=' . $adminid;
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function index()
    {
        global $intro;
        global $array;
        echo 'OSD Message. Error: you cannot access this file directly.';
    }
    public function code()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin_code . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if( $code == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this code:\n\t\t\t\t<li>The code may not found or is deleted.\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit();
        }
        if( $status == 0 ) 
        {
            $label = 'default';
        }
        else if( $status == 1 ) 
        {
            $label = 'success';
        }
        else if( $status == 2 ) 
        {
            $label = 'info';
        }
        else if( $status == 3 ) 
        {
            $label = 'danger';
        }
        else if( $status == 4 ) 
        {
            $label = 'default';
        }
        else if( $status == 5 ) 
        {
            $label = 'warning';
        }
        else
        {
            $label = 'danger';
        }
        $date_expire = ($date_expire != '' ? date('Y-m-d', $date_expire) : '-');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Send OSD Message to code: ' . $code, 'success');
        echo "<table class=\"table table-striped table-bordered\">\n\t\t\t<tr>\n\t\t\t\t<td class='info'>Fullname:</td>\n\t\t\t\t<td>" . $fullname . "</td>\n\t\t\t\t<td class='info'>Adminid:</td>\n\t\t\t\t<td>" . $array['admins'][$adminid] . ("</td>\n\t\t\t\t<td class='info'>TransID:</td>\n\t\t\t\t<td>" . $transid . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\t\t\n\t\t\t\t<td class='info'>Days:</td>\n\t\t\t\t<td>" . $days . "</td>\n\t\t\t\t<td class='info'>Date Expire</td>\n\t\t\t\t<td>" . $date_expire . "</td>\t\n\t\t\t\t<td class='info'>Status:</td>\n\t\t\t\t<td><span class='label label-" . $label . '\'>' . $intro->status[$status] . ' ') . (($code_replaced != '' ? '<br/>' . $code_replaced : '')) . ("</span></td>\n\t\t\t</tr>\n\t\t\t<tr>\t\t\t\t\n\t\t\t\t<td class='info'>MAC</td>\n\t\t\t\t<td>" . $mac . "</td>\n\t\t\t\t<td class='info'>Serial</td>\n\t\t\t\t<td>" . $serial . "</td>\n\t\t\t\t<td class='info'>Last Update</td>\n\t\t\t\t<td>" . $last_update . "</td>\n\t\t\t</tr>\n\t\t</table>");
        $stat = [
            '2' => 'مرسلة', 
            'تمت القراءة'
        ];
        if( $osd_stat == 1 ) 
        {
            $osd_stat = 'Yes! User has read the Message.';
        }
        else if( $osd_stat == 2 ) 
        {
            $osd_stat = 'User hasn\'t read the message yet.';
        }
        else
        {
            $osd_stat = 'Send New Message';
        }
        echo "\n\t\t<form name=\"frmSendOSD\"  id=\"frmSendOSD\" method=\"post\" action=\"" . $this->base . "/doCodeSend\">\n\t\t<div id='result'></div>\n\t\t<table class=\"table table-striped table-bordered\">\n\t\t<tr>\n\t\t\t<td>Mesaage: </td>\n\t\t\t<td><textarea name=\"OSD_message\" style=\"width:99%;height:150px\">" . $osd_msg . "</textarea></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td>Status:</td>\n\t\t\t<td>" . $osd_stat . "</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td> </td>\n\t\t\t<td> <input type=\"submit\" id=\"OsdSubmit\" value=\" Send \" class=\"btn btn-success\" OnClick=\"return confirm('Are you sure?')\" /> </td>\n\t\t</tr>\n\t\t\n\t\t</table>\n\t\t<input type=\"hidden\" name=\"code\" value=\"" . $code . "\" />\n\t\t<input type=\"hidden\" name=\"codeID\" value=\"" . $id . "\" />\n\t\t\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\n\t\t\$(document).ready(function(){\n\t\t\t\$(\"#frmSendOSD\").submit(function(event){\n\t\t\t\tevent.preventDefault();\n\n\t\t\t\t\$.ajax({\n\t\t\t\t\turl:'" . $this->base . "/doCodeSend?NH=1',\n\t\t\t\t\ttype:'POST',\n\t\t\t\t\tdata:\$(this).serialize(),\n\t\t\t\t\tsuccess:function(result){\n\t\t\t\t\t\t\$('#result').html(result);\n\t\t\t\t\t}\n\n\t\t\t\t});\n\t\t\t});\n\t\t});\n\t\t</script>";
    }
    public function doCodeSend()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('codeID'));
        $code = trim($intro->input->get_post('code'));
        $OSD_message = trim($intro->input->get_post('OSD_message'));
        $OSD_message = strip_tags($OSD_message);
        $OSD_message = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($OSD_message, '{ar}.\n ');
        $sql = $intro->db->query('UPDATE ' . PREFIX . ('_codes set osd_stat=2,osd_msg=\'' . $OSD_message . '\' where id=' . $id . ' ' . $this->qry_admin_code . ';'));
        echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Success:  Message Sent. ', 'success');
    }
    public function mag()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $fullname = '';
        $sql = $intro->db->query('SELECT * FROM mag_devices where mag_id=' . $id . ' ;');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $sql = $intro->db->query('SELECT * FROM users where id=' . $user_id . ' ' . $this->qry_admin . ';');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_users_data where userid=' . $user_id . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if( $username == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this MAG:\n\t\t\t\t<li>The code may not found or is deleted.\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit();
        }
        $exp_date = ($exp_date != '' ? date('Y-m-d H:i:s', $exp_date) : '-');
        $mac = base64_decode($mac);
        $adminid = $member_id;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Send OSD Message to code: ' . $mac, 'success');
        echo "<table class=\"table table-striped table-bordered\">\n\t\t\t<tr>\n\t\t\t\t<td class='info'>MAC</td>\n\t\t\t\t<td>" . $mac . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td class='info'>Fullname:</td>\n\t\t\t\t<td>" . $fullname . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\t\t\n\t\t\t\t<td class='info'>Expire:</td>\n\t\t\t\t<td>" . $exp_date . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\t\t\n\t\t\t\t<td class='info'>Reseller:</td>\n\t\t\t\t<td>" . $adminid . "</td>\n\t\t\t</tr>\n\t\t</table>";
        echo "\n\t\t<form name=\"frmSendOSD\"  id=\"frmSendOSD\" method=\"post\" action=\"" . $this->base . "/doMagSend\">\n\t\t<div id='result'></div>\n\t\t<table class=\"table table-striped table-bordered\">\n\t\t<tr>\n\t\t\t<td>Mesaage: </td>\n\t\t\t<td><textarea name=\"OSD_message\" style=\"width:99%;height:150px\"></textarea></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td></td>\n\t\t\t<td><label class=\"checkbox-inline\">\n\t\t\t\t<input type=\"checkbox\" value=\"\">\n\t\t\t\tUser must confirm the message?\n\t\t\t\t</label>\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td></td>\n\t\t\t<td> <label class=\"checkbox-inline\">\n\t\t\t\t<input type=\"checkbox\" value=\"\">\n\t\t\t\tReboot Device After Confirming (above option must be yes)\n\t\t\t\t</label></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td> </td>\n\t\t\t<td> <input type=\"submit\" id=\"OsdSubmit\" value=\" Send \" class=\"btn btn-success\" OnClick=\"return confirm('Are you sure?')\" /> </td>\n\t\t</tr>\n\t\t\n\t\t</table>\n\n\t\t<input type=\"hidden\" name=\"userid\" value=\"" . $id . "\" />\n\t\t\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\n\t\t\$(document).ready(function(){\n\t\t\t\$(\"#frmSendOSD\").submit(function(event){\n\t\t\t\tevent.preventDefault();\n\n\t\t\t\t\$.ajax({\n\t\t\t\t\turl:'" . $this->base . "/doMagSend/?NH=1',\n\t\t\t\t\ttype:'POST',\n\t\t\t\t\tdata:\$(this).serialize(),\n\t\t\t\t\tsuccess:function(result){\n\t\t\t\t\t\t\$('#result').html(result);\n\t\t\t\t\t}\n\n\t\t\t\t});\n\t\t\t});\n\t\t});\n\t\t</script>";
    }
    public function doMagSend()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('userid'));
        $OSD_message = trim($intro->input->get_post('OSD_message'));
        $OSD_message = strip_tags($OSD_message);
        $OSD_message = preg_replace('/[^a-zA-Z0-9-أ-ي. ]/ui', '', $OSD_message);
        echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Success:  Message Sent. ', 'success');
    }
}
