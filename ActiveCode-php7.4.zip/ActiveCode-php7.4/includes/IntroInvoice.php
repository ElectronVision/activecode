<?php 
class IntroInvoice
{
    public $adminid = 0;
    public $period = 0;
    public $userid = 0;
    public $num = 1;
    public $notes = '';
    public $all_data = '';
    public $reseller_name = '';
    public $code_trans = 0;
    public $inv_total_cost = 0;
    public $isPackage = false;
    public $package = 0;
    public function __construct()
    {
    }
    public function Save()
    {
        global $intro;
        global $array;
        $adminid = $this->adminid;
        $period = $this->period;
        $userid = $this->userid;
        $notes = $this->notes;
        $adm = $intro->auth->admin_data($adminid);
        $this->reseller_name = $adm['admin_name'];
        $father = intval($adm['father']);
        $level = intval($adm['level']);
        $date = date('Y-m-d H:i:s');
        if( $adminid == 0 ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Unknown Reseller ID.', 'danger');
            exit();
        }
        if( $period == 0 ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: please choose period.', 'danger');
            exit();
        }
        $p = new IntroPerms('CheckCost', $adm, $this->num, $period, $this->package);
        if( $p->error != '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232($p->error, 'danger');
            exit();
        }
        if( $this->isPackage ) 
        {
            if( $p->is_trial == 1 ) 
            {
                return null;
            }
            $data = [];
            $data['depit'] = $p->TotalCost;
            $data['amount'] = $p->TotalCost;
            $data['period'] = $period;
            $data['admin'] = $adminid;
            $data['userid'] = $userid;
            $data['all_data'] = $this->all_data;
            $data['pkg'] = $this->package;
            $data['code_trans'] = $this->code_trans;
            $data['type'] = 1;
            $data['dateadded'] = $date;
            $data['Notes'] = $this->notes;
            $intro->db->insert(PREFIX . '_trans', $data);
            _obf_0D2B32145C223B0E151F22302C132E2A0A0539333E3722($adminid, $p->TotalCost, '-');
            return $intro->db->insert_id();
        }
        $this->inv_total_cost = $p->TotalCost;
        if( $p->cost > 0 ) 
        {
            if( $level == 7 ) 
            {
                $data = [];
                $data['isSub'] = 1;
                $data['admin_father'] = $father;
                $data['depit'] = $p->TotalCost;
                $data['amount'] = $p->TotalCost;
                $data['period'] = $period;
                $data['admin'] = $adminid;
                $data['userid'] = $userid;
                $data['all_data'] = $this->all_data;
                $data['code_trans'] = $this->code_trans;
                $data['type'] = 1;
                $data['dateadded'] = $date;
                $data['Notes'] = $this->notes;
                $intro->db->insert(PREFIX . '_trans', $data);
                if( $intro->option['CreditSystem'] == 'restrict' ) 
                {
                    $bonus = $p->TotalCost - $p->FatherCost;
                    if( $bonus > 0 ) 
                    {
                        $data = [];
                        $data['admin'] = $father;
                        $data['dateadded'] = $date;
                        $data['Notes'] = 'Bonus from: ' . $this->notes;
                        $data['type'] = 2;
                        $data['method'] = 3;
                        $data['amount'] = $bonus;
                        $data['credit'] = $bonus;
                        $intro->db->insert(PREFIX . '_trans', $data);
                    }
                }
                else
                {
                    $data2 = [];
                    $data2['depit'] = $p->FatherCost;
                    $data2['amount'] = $p->FatherCost;
                    $data2['period'] = $period;
                    $data2['admin'] = $father;
                    $data2['userid'] = $userid;
                    $data2['all_data'] = $this->all_data;
                    $data2['code_trans'] = $this->code_trans;
                    $data2['type'] = 1;
                    $data2['dateadded'] = $date;
                    $data2['Notes'] = 'SubResel:' . $this->reseller_name . ': ' . $this->notes;
                    $intro->db->insert(PREFIX . '_trans', $data2);
                }
            }
            else
            {
                $data = [];
                $data['depit'] = $p->TotalCost;
                $data['amount'] = $p->TotalCost;
                $data['period'] = $period;
                $data['admin'] = $adminid;
                $data['userid'] = $userid;
                $data['all_data'] = $this->all_data;
                $data['code_trans'] = $this->code_trans;
                $data['type'] = 1;
                $data['dateadded'] = $date;
                $data['Notes'] = $this->notes;
                $intro->db->insert(PREFIX . '_trans', $data);
            }
            return $intro->db->insert_id();
        }
    }
    public function set($name, $value)
    {
        $this->$name = $value;
    }
}
