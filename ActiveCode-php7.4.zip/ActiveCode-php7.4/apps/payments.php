<?php 
echo "\t";
class Payments_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $goto = '';
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $qry_admin_father = '';
    public $qryWhereFather = '';
    public $admin = [];
    public $adminRow = [];
    public $method = [
        '1' => 'Topup', 
        '2' => 'Credit', 
        '3' => 'Bonus', 
        '4' => 'Transfer'
    ];
    public $qry_sub_for_dropdown = '';
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $adminid = intval($this->admin['adminid']);
        $this->adminRow = $intro->auth->admin_data($this->admin['adminid']);
        if( $this->admin['level'] != 1 ) 
        {
            $this->qry_admin = ' and admin=' . $adminid;
            $this->qry_admin_where = ' where admin=' . $adminid;
            $this->qry_sub_for_dropdown = '';
        }
        if( $this->admin['level'] == 6 ) 
        {
            $this->qry_admin_father = ' AND admin_father=\'' . $adminid . '\' ';
            $this->qryWhereFather = ' WHERE father=' . $adminid . ' ';
            $this->qry_sub = ' AND admin_father=\'' . $this->admin['adminid'] . '\' ';
            $this->qry_sub_for_dropdown = ' (adminid=\'' . $adminid . '\' OR father=' . $adminid . ' OR main_father=' . $adminid . ') ';
        }
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = ' and isSub=0 ';
            $this->qry_sub = ' AND isSub=1 ';
            $this->qryWhereFather = ' WHERE father=0 ';
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        global $options;
        $addnew = '';
        if( in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            $addnew .= ('<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index_sub') . (' p_view" href="' . $this->base . '/index_sub"><icon class="icon-list"> Sub-Resel Payments</icon></a>  '));
            $addnew .= ('<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add&amp;goto=' . $this->goto . '"><icon class="icon-plus-squared"> Addd New</icon></a>  '));
            $addnew .= ('<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Transfer') . (' p_add" href="' . $this->base . '/Transfer"><icon class="icon-exchange">Transfer Credit</icon></a>  '));
        }
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\">Payments</icon></a> \r\n\t\t\t" . $addnew . "\t \r\n\t\t<!--<a class=\"btn btn-success\" href=\"" . $this->base . "/SendMoney\"><icon class=\"icon-mail\">Send Money</icon></a> -->\t\t \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        global $sess_admin;
        $qry = $queryadmin = $params = '';
        $get_active = $intro->input->get_post('active');
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $admin = intval($intro->input->get_post('admin'));
        $Notes = trim($intro->input->get_post('Notes'));
        $date1 = trim($intro->input->get_post('date1'));
        $date2 = trim($intro->input->get_post('date2'));
        $admin = intval($intro->input->get_post('admin'));
        $method = intval($intro->input->get_post('method'));
        $depit = $intro->input->get_post('depit');
        $depit = ($depit != '' ? floatval($depit) : '');
        $Notes = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($Notes, ' ');
        $date1 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date1, '-');
        $date2 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date2, '-');
        $this->nav();
        $rows_per_page = '30';
        if( $admin != 0 ) 
        {
            $qry .= (' AND admin=' . $admin . ' ');
            $params .= ('&admin=' . $admin);
            $rows_per_page = '500';
        }
        if( $method != 0 ) 
        {
            $qry .= (' AND method=' . $method . ' ');
            $params .= ('&method=' . $method);
            $rows_per_page = '500';
        }
        if( $date1 != '' && $date2 != '' ) 
        {
            $qry .= (' AND dateadded BETWEEN \'' . $date1 . ' 00:00:00\' AND \'' . $date2 . ' 23:59:59\' ');
            $params .= ('&date1=' . $date1 . '&date2=' . $date2);
            $rows_per_page = '5000';
        }
        if( $Notes != '' ) 
        {
            $qry .= (' and Notes LIKE \'%' . $Notes . '%\' ');
            $params .= ('&Notes=' . $Notes);
        }
        if( $order == '' ) 
        {
            $order = 'trans_id:desc';
        }
        $order = str_replace(':', ' ', $order);
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . '_trans ' . (' where type=2 ' . $qry . ' ' . $this->qry_admin . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT trans_id from ' . PREFIX . '_trans ' . (' where type=2 ' . $qry . ' ' . $this->qry_admin));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Payments/Credits (' . $totalrows . ')</legend>', 'success');
        if( $date1 == '' ) 
        {
            $date1 = date('Y-01-01');
        }
        if( $date2 == '' ) 
        {
            $date2 = date('Y-m-d');
        }
        echo "<form action=\"\" method=\"GET\" class=\"form-inline\">\r\n\t\t<table class='table' style='max-width:800px;'>\r\n\t\t<tr>";
        if( in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            $qry = '';
            if( $this->qry_sub_for_dropdown != '' ) 
            {
                $qry = ' WHERE ';
            }
            echo "<td>Reseller:</td>\r\n\t\t\t\t<td>" . form_resellers('admin', $admin, 'All Resellers', ' ' . $qry . ' ' . $this->qry_sub_for_dropdown) . '</td>';
        }
        echo "\r\n\t\t\t<td>Date:</td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"text\" name=\"date1\" value=\"" . $date1 . "\" class=\"date_picker\" placeholder='From' class='form-control form-inline' style='width:100px;'>\r\n\t\t\t\t<input type=\"text\" name=\"date2\" value=\"" . $date2 . "\" class=\"date_picker\" placeholder='To' class='form-control form-inline' style='width:100px;'>\r\n\t\t\t</td>\r\n\t\t\t<td></td>\r\n\t\t\t<td></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Type:</td>\r\n\t\t\t<td>" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('method', $this->method, $method, 'All') . ("</td>\r\n\t\t\t<td></td>\r\n\t\t\t<td></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Notes:</td>\r\n\t\t\t<td><input type=\"text\" name=\"Notes\" value=\"" . $Notes . "\" placeholder='Notes' class='form-control'></td>\r\n\t\t\t<td></td>\r\n\t\t\t<td><input type=\"submit\" value=\" View \" class='btn btn-default'></td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</form>");
        echo "\r\n\r\n\t\t<table class=\"table table-striped table-bordered\" id=\"table_trans\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('trans_id', 'index', $params) . "</th>\r\n\t\t\t<th> " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('method', 'index', $params) . "</th>\r\n\t\t\t<th>Date " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('dateadded', 'index', $params) . "</th>\r\n\t\t\t<th>Reseller  " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('adminid', 'index', $params) . " </th>\r\n\t\t\t<th>Amount " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('credit', 'index', $params) . " </th>\r\n\t\t\t<th>Notes " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('Notes', 'index', $params) . " </th>\r\n\t\t\t<th>Options</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = $tot_credit = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $credit = floatval($credit);
            $depit = floatval($depit);
            if( $this->admin['adminid'] == 1 ) 
            {
                $delbtn = '<a class="btn btn-danger btn-xs p_del intro_ui_del" href="' . $this->base . '/Del?trans_id=' . $trans_id . '" OnClick="return false;" title="' . $intro->lang['del'] . '"><i class="icon-cancel-circled2"></i></a>';
            }
            else
            {
                $delbtn = '';
            }
            $tot_credit += $credit;
            if( $method == 2 ) 
            {
                $credit = $depit * -1;
            }
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\">" . $trans_id . "</td>\r\n\t\t\t\t<td class=\"center\">") . $intro->pay_method[$method] . "</td>\r\n\t\t\t\t<td class=\"center\">" . $dateadded . "</td>\r\n\t\t\t\t<td class=\"center\">" . $array['admins'][$admin] . "</td>\r\n\t\t\t\t<td class='c'>" . number_format($credit) . ("</td>\r\n\t\t\t\t<td>" . $Notes . "</td>\r\n\t\t\t\t<td class=\"center\"> ");
            if( $this->admin['level'] == 1 && $method == 1 ) 
            {
                echo '<a class="btn btn-info btn-xs p_edit" href="' . $this->base . '/Form?t=edit&trans_id=' . $trans_id . '" title="' . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t" . $delbtn);
            }
            echo "</td>\r\n\t\t\t</tr>";
        }
        echo '</tbody>';
        if( $admin != 0 ) 
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td>Total:</td>\r\n\t\t\t\t<th class='c'>" . number_format($tot_credit) . "</th>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t</tr>";
        }
        echo '</table>';
        $order = str_replace(' ', ':', $order);
        _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?' . $params . '&order=' . $order, $totalrows, $rows_per_page, $page) . '</center>');
    }
    public function index_sub()
    {
        global $intro;
        global $array;
        global $sess_admin;
        $qry = $queryadmin = $params = '';
        $get_active = $intro->input->get_post('active');
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $admin = intval($intro->input->get_post('admin'));
        $this->goto = 'index_sub';
        $this->nav();
        $rows_per_page = '30';
        if( $admin != 0 ) 
        {
            $qry .= (' AND admin=' . $admin . ' ');
            $params .= ('&admin=' . $admin);
            $rows_per_page = '500';
        }
        if( $order == '' ) 
        {
            $order = 'trans_id:desc';
        }
        $order = str_replace(':', ' ', $order);
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . '_trans ' . (' where type=2 ' . $this->qry_sub . ' ' . $qry . '  order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT trans_id from ' . PREFIX . '_trans ' . (' where type=2 ' . $this->qry_sub . ' ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        if( $this->admin['level'] == 1 ) 
        {
            $sub_resel_qry = '';
        }
        else if( $this->admin['level'] == 1 ) 
        {
            $sub_resel_qry = 'WHERE father=\'' . $this->admin['adminid'] . '\'';
        }
        else
        {
            $sub_resel_qry = 'WHERE father=\'' . $this->admin['adminid'] . '\'';
        }
        echo "\r\n\t\t<fieldset><legend><i class=\"icon-list\"></i> Sub-Resellers Payments (" . $totalrows . ')</legend>';
        echo "<form action=\"\" method=\"GET\">\r\n\t\t\t" . form_resellers('admin', $admin, 'All Resellers', $sub_resel_qry) . " \r\n\t\t\t<input type=\"submit\" class=\"btn btn-success\" value=\" Search! \" class='btn btn-default'>\r\n\t\t\t</form>";
        echo "\r\n\r\n\t\t<table class=\"table table-striped table-bordered\" id=\"table_trans\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('trans_id', 'index') . "</th>\r\n\t\t\t<th> " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('method', 'index') . "</th>\r\n\t\t\t<th>Date " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('dateadded', 'index') . '</th>';
        if( $this->admin['level'] == 1 ) 
        {
            echo '<th>Father  ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('admin_father', 'index') . ' </th>';
        }
        echo "\r\n\t\t\t<th>Reseller  " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('admin', 'index') . " </th>\r\n\t\t\t<th>Amount " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('depit', 'index') . " </th>\r\n\t\t\t<th>Notes " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('depit', 'index') . " </th>\r\n\t\t\t<th>Options</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = $tot_credit = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $tot_credit += $credit;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\">" . $trans_id . "</td>\r\n\t\t\t\t<td class=\"center\">") . $intro->pay_method[$method] . "</td>\r\n\t\t\t\t<td class=\"center\">" . $dateadded . '</td>';
            if( $this->admin['level'] == 1 ) 
            {
                echo '<td>' . $array['admins'][$admin_father] . '</td>';
            }
            echo "\r\n\t\t\t\t<td class=\"center\">" . $array['admins'][$admin] . "</td>\r\n\t\t\t\t<td class='c'>" . number_format($credit) . ("</td>\r\n\t\t\t\t<td>" . $Notes . "</td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info btn-xs p_edit\" href=\"" . $this->base . '/Form?t=edit&trans_id=' . $trans_id . '&amp;goto=' . $this->goto . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a> \r\n\t\t\t\t\t<a class=\"btn btn-danger btn-xs p_del intro_ui_del\" href=\"" . $this->base . '/Del?trans_id=' . $trans_id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a> \r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo '</tbody>';
        if( $admin != 0 ) 
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t" . (($this->admin['level'] == 1 ? '<td></td>' : '')) . "\r\n\t\t\t\t<td class='text-right'>Total:</td>\r\n\t\t\t\t<th class='c'>" . number_format($tot_credit) . "</th>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t</tr>";
        }
        echo '</table>';
        $order = str_replace(' ', ':', $order);
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index_sub?' . $params . '&order=' . $order, $totalrows, $rows_per_page, $page) . '</center>';
        echo '</fieldset>';
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $amount;
        global $array;
        global $userid;
        global $depit;
        global $credit;
        global $admin;
        global $dateadded;
        global $adminid;
        global $period;
        global $Notes;
        if( $_GET != null ) 
        {
            @extract($_GET);
        }
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        if( !in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $goto = trim($intro->input->get_post('goto'));
        $trans_id = intval($intro->input->get_post('trans_id'));
        $t = ($t == '' ?: $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM ' . PREFIX . '_trans ' . (' where trans_id=\'' . $trans_id . '\' and type=2 AND method=1 ' . $this->qry_admin_father . ';'));
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = ' Edit <b> ' . $trans_id . ' </b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $btn['copy'] = '';
            $date = $dateadded;
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add Payment';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = 'Add New';
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
            $btn['copy'] = '';
            $date = date('Y-m-d H:i:s');
            if( $intro->input->get_post('adminid') != '' ) 
            {
                $admin = $intro->input->get_post('adminid');
            }
        }
        $cur_bal = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($this->admin['adminid']);
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'success');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<table class='table table-bordered table-hover'>\r\n\t\t<tr>\r\n\t\t\t<td>Reseller : </td>\r\n\t\t\t<td>";
        if( $t == 'add' ) 
        {
            echo _obf_0D311A13371B215B013B112303362D1032353D2E344022('adminid', 'Choose Reseller', 'solus_admin', $admin, 'adminid', 'admin_name', $this->qryWhereFather);
            echo $this->error('adminid') . ' ';
        }
        else
        {
            echo (isset($array['admins'][$admin]) ? $array['admins'][$admin] : 'Error: Unknown');
        }
        echo "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Date Added  : </td>\r\n\t\t\t<td><input dir=\"ltr\" type=\"text\" name=\"dateadded\" value=\"" . date('Y-m-d H:i:s') . ('" size="30"> ' . $this->error('dateadded') . "</td>\r\n\t\t</tr>");
        if( $this->admin['level'] == 6 ) 
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Your Current Balance : </td>\r\n\t\t\t\t<td><strong>" . $cur_bal . "<strong></td>\r\n\t\t\t</tr>";
        }
        echo "\r\n\t\t<tr>\r\n\t\t\t<td>Amount : </td>\r\n\t\t\t<td><input dir=\"ltr\" type=\"text\" name=\"amount\" " . (($this->admin['level'] == 6 ? 'max=\'' . $cur_bal . '\'' : '')) . (' value="' . $amount . "\" size=\"30\" required=\"\">\r\n\t\t\t" . $this->error('amount') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Notes  : </td>\r\n\t\t\t<td><textarea cols=35 rows= 5 name='Notes'>" . $Notes . '</textarea> ' . $this->error('Notes') . "</td>\r\n\t\t</tr>");
        if( $t == 'edit' ) 
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Edit Reason  : </td>\r\n\t\t\t\t<td>\r\n\t\t\t\t\t<input class=\"form-control\" type=\"text\" name=\"edit_reason\" value=\"\" required=''>\r\n\t\t\t\t\tPlease tell why you edit this payment?\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"trans_id\"  value=\"" . $trans_id . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"xAmount\"  value=\"" . $amount . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"xAdmin\"  value=\"" . $admin . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"goto\"  value=\"" . $goto . "\">\r\n\t\t\t\t<button class=\"btn btn-success\" type=\"submit\"><span class=\"" . $btn['img_icon'] . '"> ' . $btn['name'] . " </span></button>\r\n\t\t\t\t\r\n\t\t\t</td>\r\n\t\t</tr>";
        if( $t == 'edit' ) 
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Added By: </td>\r\n\t\t\t\t<td> " . $array['admins'][$admin_add] . (' On ' . $time_add . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Last edit By: </td>\r\n\t\t\t\t<td> ") . $array['admins'][$admin_edit] . (' On ' . $time_edit . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Edit Reason: </td>\r\n\t\t\t\t<td>" . $edit_reason . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Edit History: </td>\r\n\t\t\t\t<td>" . $edit_log . "</td>\r\n\t\t\t</tr>");
        }
        echo "\r\n\t\t</table>\r\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        global $array;
        $userid = intval($intro->input->post('userid'));
        $adminid = intval($intro->input->post('adminid'));
        $amount = floatval($intro->input->post('amount'));
        $dateadded = trim($intro->input->post('dateadded'));
        $Notes = trim($intro->input->post('Notes'));
        $time = date('Y-m-d H:i:s');
        $admin_bal = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($this->admin['adminid']);
        $target_adm_balance = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($adminid);
        if( $adminid == 0 || $amount <= 0 && $this->admin['level'] != 1 || $this->admin['level'] == 6 && $admin_bal < $amount || $this->admin['level'] != 1 && $this->adminRow['member_group_id'] > 0 && $admin_bal < $amount ) 
        {
            if( $adminid == 0 ) 
            {
                $error['adminid'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $amount <= 0 && $this->admin['level'] != 1 ) 
            {
                $error['amount'] = '<span class=error>Error Amount must be > 0. You can\'t use negative number less than Zero.</span>';
            }
            if( $this->admin['level'] == 6 && $admin_bal < $amount ) 
            {
                $error['amount'] = '<span class=error>You can\'t add amount greater than your balance. You can put <b>' . $admin_bal . '</b> or less.</span>';
            }
            if( $this->admin['level'] != 1 && $this->adminRow['member_group_id'] > 0 && $admin_bal < $amount ) 
            {
                $error['amount'] = '<span class=error>You can\'t add amount greater than your balance. You can put <b>' . $admin_bal . '</b> or less.</span>';
            }
            $this->Form('add');
            exit();
        }
        $data = [];
        $data['userid'] = $userid;
        $data['admin'] = $adminid;
        $data['dateadded'] = $intro->input->post('dateadded');
        $data['Notes'] = $intro->input->post('Notes');
        $data['type'] = 2;
        $data['amount'] = $amount;
        $data['credit'] = $amount;
        $data['method'] = 1;
        $data['admin_add'] = $this->admin['adminid'];
        if( $this->admin['level'] == 6 ) 
        {
            $data['admin_father'] = $this->admin['adminid'];
            $data['isSub'] = 1;
        }
        $data['admin_edit'] = 0;
        $data['time_add'] = $time;
        $intro->db->insert(PREFIX . '_trans', $data);
        _obf_0D2B32145C223B0E151F22302C132E2A0A0539333E3722($adminid, $amount, '+');
        if( $this->admin['level'] == 6 && $intro->option['CreditSystem'] == 'restrict' || $this->admin['level'] != 1 && $this->adminRow['member_group_id'] > 0 ) 
        {
            $data = [];
            $data['admin'] = $this->admin['adminid'];
            $data['dateadded'] = date('Y-m-d H:i:s');
            $data['Notes'] = 'Credit to Reseller: ' . $array['admins'][$adminid];
            $data['type'] = 2;
            $data['method'] = 2;
            $data['amount'] = $amount;
            $data['depit'] = $amount;
            $intro->db->insert(PREFIX . '_trans', $data);
            _obf_0D2B32145C223B0E151F22302C132E2A0A0539333E3722($this->admin['adminid'], $amount, '-');
        }
        $intro->redirect($this->appname, $intro->input->post('goto'));
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $time = date('Y-m-d H:i:s');
        $trans_id = intval($intro->input->post('trans_id'));
        $period = $intro->input->post('period');
        $amount = floatval($intro->input->post('amount'));
        $edit_reason = trim($intro->input->post('edit_reason'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_trans where trans_id=\'' . $trans_id . '\';'));
        $row = $intro->db->fetch_assoc($sql);
        $data = [];
        $data['userid'] = intval($intro->input->post('userid'));
        $data['dateadded'] = $intro->input->post('dateadded');
        $data['Notes'] = $intro->input->post('Notes');
        $data['type'] = 2;
        $data['amount'] = $amount;
        $data['credit'] = $amount;
        $data['admin_edit'] = $this->admin['adminid'];
        $data['time_edit'] = $time;
        $data['edit_reason'] = $edit_reason;
        $edit_log = '';
        $xAmount = floatval($intro->input->post('xAmount'));
        $xAdmin = intval($intro->input->post('xAdmin'));
        if( $xAmount != $amount ) 
        {
            $edit_log .= ('<li>' . $time . ' Amount from (' . $xAmount . ') to (' . $amount . ') ' . $edit_reason . "</li>\n");
        }
        if( $xAdmin != $data['admin'] ) 
        {
            $edit_log .= ('<li>' . $time . ' Amount from (' . $xAdmin . ') to (' . $data['admin'] . ') ' . $edit_reason . "</li>\n");
        }
        if( $edit_log != '' ) 
        {
            $db_edit_log = $row['edit_log'];
            $data['edit_log'] = $db_edit_log . " \n " . $edit_log;
        }
        if( $this->admin['level'] == 1 ) 
        {
            $intro->db->update(PREFIX . '_trans', $data, 'trans_id=' . $trans_id . ';');
            _obf_0D1A103E0E3F192D062A303301251B141F191A0D390432($row['adminid']);
        }
        $intro->redirect($this->appname, $intro->input->post('goto'));
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $trans_id = intval($intro->input->get_post('trans_id'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_trans where trans_id=\'' . $trans_id . '\';'));
        $row = $intro->db->fetch_assoc($sql);
        if( $row['isSub'] == 1 && $row['admin_father'] == $this->admin['adminid'] ) 
        {
        }
        var_dump($this->qry_admin_father);
        exit();
        if( !in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_trans WHERE trans_id=' . $trans_id . ' ' . $this->qry_admin_father));
        $intro->redirect($this->appname);
    }
    public function Transfer($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $amount;
        global $array;
        global $user;
        global $Notes;
        $trans_id = intval($intro->input->get_post('trans_id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        $balance = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($this->admin['adminid']);
        _obf_0D29240218250E143407102A213F0D2D3907013C1A3F22();
        _obf_0D1C142634050E01362131030D39111708241D3E3B1932();
        $qry = '';
        if( $this->qry_sub_for_dropdown != '' ) 
        {
            $qry = ' WHERE ' . $this->qry_sub_for_dropdown;
        }
        $action = 'doTransfer';
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-main"></i> Transfer Credit to another Reseller ', 'primary');
        echo "\r\n\t\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $action . "\" enctype=\"multipart/form-data\">\r\n\t\t\t<table class=\"table table-bordered table-hover table-stripped\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Your Balance: </td>\r\n\t\t\t\t<td>" . $balance . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>From Reseller: *</td>\r\n\t\t\t\t<td>" . form_resellers('from', $intro->input->post('from'), 'From', $qry, 'view_bal') . (' ' . $this->error('from') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reseller Credit:</td>\r\n\t\t\t\t<td id='credit'></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Credit : *</td>\r\n\t\t\t\t<td><input dir=\"ltr\" type=\"text\" name=\"amount\" value=\"" . $intro->input->post('amount') . '" required=\'\' size="30">' . $this->error('amount') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>To Reseller: *</td>\r\n\t\t\t\t<td>") . form_resellers('to', $intro->input->post('to'), 'To', $qry, 'view_bal') . (' ' . $this->error('to') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Notes  : (optional)</td>\r\n\t\t\t\t<td><textarea cols=35 rows= 5 name='Notes'>" . $intro->input->post('Notes') . '</textarea> ' . $this->error('Notes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td><button type=\"submit\" class='btn btn-success'><span class=\"icon-exchange\"> Transfer Credit  </span></button></td>\r\n\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$('documnet').ready(function(){\r\n\r\n\r\n\t\t\t\$(\"select[name='from']\").change(function() {\r\n\t\t\t \r\n\t\t\t\t\$('#credit').load('" . $this->base . "/getCredit?NH=1&_x=' + \$(this).val() , function(data) {\r\n\t\t\t\t  \r\n\t\t\t\t});\r\n\r\n\t\t\t});\r\n\r\n\t\t});\r\n\t\t</script>";
    }
    public function getCredit()
    {
        global $intro;
        global $error;
        $id = intval($intro->input->get_post('_x'));
        $qry = '';
        if( $this->qry_sub_for_dropdown != '' ) 
        {
            $qry = ' AND ' . $this->qry_sub_for_dropdown;
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adminid=\'' . $id . '\' ' . $qry));
        $row = $intro->db->fetch_assoc($sql);
        if( $row ) 
        {
            extract($row);
            $bal = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($id);
            if( $bal > 0 ) 
            {
                $cr = '<span class=\'badge badge-success\'>' . $bal . '</span>';
            }
            else
            {
                $cr = '<span class=\'badge badge-danger\'>' . $bal . '</span>';
            }
            echo 'Name: ' . $admin_name . ' Credit: ' . $cr;
        }
        else
        {
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222($this->appname, 'credit_transfer', 'Try to add credit to: ' . $id . '. and he is not in his panel.');
        }
    }
    public function doTransfer()
    {
        global $intro;
        global $error;
        $from = intval($intro->input->post('from'));
        $to = intval($intro->input->post('to'));
        $amount = floatval($intro->input->post('amount'));
        $Notes = trim($intro->input->post('Notes'));
        if( $from == 0 || $to == 0 || $from == $to || $amount <= 0 ) 
        {
            if( $from == 0 ) 
            {
                $error['from'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $to == 0 ) 
            {
                $error['to'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $from == $to ) 
            {
                $error['from'] = '<span class=error>Error: you can\'t send to the same reseller!!!.</span>';
            }
            if( $amount <= 0 ) 
            {
                $error['amount'] = '<span class=error>Error: credit must be more than Zero 0</span>';
            }
            $this->Transfer();
            exit();
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adminid=' . $from . ';'));
        $row_from = $intro->db->fetch_assoc($sql);
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adminid=' . $to . ';'));
        $row_to = $intro->db->fetch_assoc($sql);
        $balance_from = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($from);
        if( $balance_from < $amount ) 
        {
            if( $balance_from < $amount ) 
            {
                $error['from'] = '<span class=error>Error: The amount is greater than reseller\'s balance. You can only Transfer (' . $balance_from . ') credit.</span>';
            }
            $this->Transfer();
            exit();
        }
        $date = date('Y-m-d H:i:s');
        $data = [];
        $data['admin'] = $from;
        $data['dateadded'] = $date;
        $data['Notes'] = 'Transfer to [' . $to . '] ' . (($Notes != '' ? ' | Notes: ' . $Notes : ''));
        $data['type'] = 2;
        $data['method'] = 4;
        $data['amount'] = $amount * -1;
        $data['credit'] = $amount * -1;
        $intro->db->insert(PREFIX . '_trans', $data);
        $data['admin'] = $to;
        $data['Notes'] = 'From [' . $from . '] ' . (($Notes != '' ? ' | Notes: ' . $Notes : ''));
        $data['type'] = 2;
        $data['amount'] = $amount;
        $data['credit'] = $amount;
        $intro->db->insert(PREFIX . '_trans', $data);
        $intro->redirect($this->appname);
    }
}
