<?php
class Codes_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $admin = array();
    public $adminRow = array();
    public $inputBy = array('Code', 'MAC', 'Serial');
    public $free = array(101, 103, 107, 110);
    public $output = array('ts' => ' MPEGTS (.ts)', 'm3u8' => 'HLS (.m3u8)');
    public $time = null;
    public $PaypassLargeNumber = false;
    public $array_mac_type = array('Normal', 'Double MACs (2 MACs for code)', 'Disable MAC Check', 'Disable MAC & Serial (for Bad Android Boxes)');
    public $array_mac_type_txt = array('<sup><a title="Normal">N</a></sup>', '<sup><a title="Double MACs (2 MACs for code)">2M</a></sup>', '<sup><a title="Disable MAC Check">DM</a></sup>', '<sup><a title="Disable MAC & Serial (for Bad Android Boxes)">DMS</a></sup>');
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $array;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $this->adminRow = $intro->auth->admin_data(intval($this->admin['adminid']));
        $adminid = intval($this->admin['adminid']);
        if ($this->admin['level'] == 1) {
            $this->qry_admin = '';
            $this->qry_admin_where = '';
        } else {
            $this->qry_admin = ' and adminid=' . $adminid;
            $this->qry_admin_where = ' where adminid=' . $adminid;
            if ($this->adminRow['level'] == 6) {
                $this->qry_admin = ' and ( adminid=' . $adminid . ' OR adminid IN (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adminid . ' OR main_father=' . $adminid . '))');
                $this->qry_admin_where = ' where adminid=' . $adminid . ' OR adminid IN (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adminid . ' OR main_father=' . $adminid . ')');
            }
        }
        $this->time = time();
        $this->free = $array['free'];
    }
    public function error($index = '')
    {
        global $error;
        return isset($error[$index]) ? $error[$index] : '';
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        $sql_all = $intro->db->query('SELECT id from ' . PREFIX . ('_codes ' . $this->qry_admin_where . ';'));
        $all = $intro->db->returned_rows;
        $sql_new = $intro->db->query('SELECT id from ' . PREFIX . ('_codes where status=0 ' . $this->qry_admin . ';'));
        $new = $intro->db->returned_rows;
        $sql_used = $intro->db->query('SELECT id from ' . PREFIX . ('_codes where status=1 ' . $this->qry_admin . ';'));
        $used = $intro->db->returned_rows;
        $sql1 = $intro->db->query('SELECT id from ' . PREFIX . ('_codes where status=2 ' . $this->qry_admin . ';'));
        $sus = $intro->db->returned_rows;
        $sql2 = $intro->db->query('SELECT id from ' . PREFIX . ('_codes where status=3 ' . $this->qry_admin . ';'));
        $del = $intro->db->returned_rows;
        $sql2 = $intro->db->query('SELECT id from ' . PREFIX . ('_codes where status=4 ' . $this->qry_admin . ';'));
        $expired = $intro->db->returned_rows;
        $sql3 = $intro->db->query('SELECT id from ' . PREFIX . ('_codes where is_mag=1 ' . $this->qry_admin . ';'));
        $mag = $intro->db->returned_rows;
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . '/index"><icon class="icon-list"> ') . $intro->lang['codes_appname'] . '</icon> (' . money($all) . ")</a>  \r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add"><icon class="icon-plus-squared"> ') . $intro->lang['codes_add'] . '</icon></a> ';
        if ($this->admin['level'] == 1) {
            echo ' <a class="btn btn-success" href="' . $intro->app_url('free_code', 'index') . '"><icon class="icon-list"> Free Codes</icon></a> ';
        }
        echo "\r\n\t\t</div>";
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-default\" href=\"" . $this->base . '/index?status=0">New (' . money($new) . (")</a> \r\n\t\t<a class=\"btn btn-success\" href=\"" . $this->base . '/index?status=1">Active (') . money($used) . (")</a> \r\n\t\t<a class=\"btn btn-info\" href=\"" . $this->base . '/index?status=2">Suspended (') . money($sus) . (")</a> \r\n\t\t<a class=\"btn btn-danger\" href=\"" . $this->base . '/index?status=3">Deleted (') . money($del) . (")</a>\r\n\t\t<a class=\"btn btn-warning\" href=\"" . $this->base . '/index?status=4">Expired (') . money($expired) . (")</a>\r\n\t\t<a class=\"btn btn-success\" href=\"" . $this->base . '/index?is_mag=1">MAG (') . money($mag) . ")</a>\r\n\t\t</div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        global $options;
        $qry = $params = '';
        $status = trim($intro->input->get_post('status'));
        $view = trim($intro->input->get_post('view'));
        $params .= '&status=' . $status;
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $code = trim($intro->input->get_post('code'));
        $fullname = trim($intro->input->get_post('fullname'));
        $mac = trim($intro->input->get_post('mac'));
        $serial = trim($intro->input->get_post('serial'));
        $inputBy = trim($intro->input->get_post('inputBy'));
        $period = intval($intro->input->get_post('period'));
        $adminid = intval($intro->input->get_post('adminid'));
        $transid = trim($intro->input->get_post('transid'));
        $mobile = trim($intro->input->get_post('mobile'));
        $notes = trim($intro->input->get_post('notes'));
        $username = trim($intro->input->get_post('username'));
        $is_mag = trim($intro->input->get_post('is_mag'));
        $this->nav();
        if ($status != '') {
            $qry = ' AND status=' . intval($status);
            $params .= '&code=' . $code;
        }
        $xcode = $code;
        if ($code != '') {
            $qry .= ' AND code  LIKE \'' . str_replace('*', '%', $code) . '\' ';
            $params .= '&code=' . $code;
        }
        if ($username != '') {
            $qry .= ' AND username  LIKE \'' . str_replace('*', '%', $username) . '\' ';
            $params .= '&username=' . $username;
        }
        if ($serial != '') {
            $qry .= ' AND serial  LIKE \'' . str_replace('*', '%', $serial) . '\' ';
            $params .= '&serial=' . $serial;
        }
        if ($mac != '') {
            $qry .= ' AND mac  LIKE \'' . str_replace('*', '%', $mac) . '\' ';
            $params .= '&mac=' . $mac;
        }
        if ($fullname != '') {
            $qry .= ' AND fullname  LIKE \'%' . $fullname . '%\' ';
            $params .= '&fullname=' . $fullname;
        }
        if ($inputBy != '') {
            $qry .= ' AND inputBy=\'' . $inputBy . '\' ';
            $params .= '&inputBy=' . $inputBy;
        }
        if ($transid != '') {
            $qry .= ' AND transid=\'' . $transid . '\' ';
            $params .= '&transid=' . $transid;
        }
        if ($notes != '') {
            $qry .= ' AND notes=\'' . $notes . '\' ';
            $params .= '&notes=' . $notes;
        }
        if ($mobile != '') {
            $qry .= ' AND mobile=\'' . $mobile . '\' ';
            $params .= '&mobile=' . $mobile;
        }
        if ($adminid != '') {
            $qry .= ' AND adminid=' . $adminid . ' ';
            $params .= '&adminid=' . $adminid;
        }
        if ($period != 0) {
            $qry .= ' AND period=' . $period . ' ';
            $params .= '&period=' . $period;
        }
        if ($view == 'expired') {
            $qry = ' AND date_expire <= \'' . $this->time . '\' AND status!=0';
            $params .= '&view=expired';
        }
        if ($is_mag != '') {
            $qry .= ' AND is_mag=' . intval($is_mag);
            $params .= '&is_mag=' . $is_mag;
        }
        if ($this->admin['level'] == 9 && strlen($code) > 3) {
            $this->qry_admin = '';
            $this->qry_admin_where = '';
            if ($code != '') {
                $qry .= ' AND code  LIKE \'%' . $code . '%\' ';
            }
        }
        if ($order == '') {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 50;
        if ($page == 0) {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $qry_online = ',IF(status=1,(select online.activity_id from user_activity_now online, users  where online.user_id=users.id AND users.username=codes.code ORDER BY activity_id DESC LIMIT 1),\'\') as activity_id';
        $concat = 'stream_id,\'|\',user_agent,\'|\',user_ip,\'|\',container,\'|\',geoip_country_code,\'|\',isp';
        $qry_online = ',IF(status=1,(select CONCAT(' . $concat . ') as online from user_activity_now online ' . ' where online.user_id=codes.userid ORDER BY activity_id DESC LIMIT 1),\'\') as online';
        $result = $intro->db->query('SELECT *' . $qry_online . ' from ' . PREFIX . '_codes codes ' . (' where true ' . $this->qry_admin . ' ' . $qry . ' order by ' . $order . ' limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from ' . PREFIX . '_codes ' . (' where true ' . $this->qry_admin . ' ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        $intro->db->query('UPDATE ' . PREFIX . ('_codes set status=4 WHERE status!=4 AND status!=0 AND date_expire!=0 AND date_expire!=\'\' AND date_expire <= \'' . $this->time . '\''));
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Found Codes (' . money($totalrows) . ')', 'primary');
        echo "\r\n\t\t<form action=\"\" method=\"GET\">\r\n\t\t\t<table class=\"table table-bordered table-condensed\">\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Code:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"code\" value=\"" . $code . "\" size=\"20\" placeholder='code : Use * for wildcards.' autofocus></td>\r\n\t\t\t\t\t<td>Fullname:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"fullname\" value=\"" . $fullname . "\" size=\"15\" placeholder=Fullname></td>\r\n\t\t\t\t\t<td>Input:</td>\r\n\t\t\t\t\t<td>" . _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811('inputBy', $this->inputBy, $inputBy, 'All', '') . "</td>\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Days: </td>\r\n\t\t\t\t\t<td>" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', _obf_0D322A5B141A102E2824032B03230A35140306272F2F11(), $period, 'ALL Months') . "</td>\r\n\t\t\t\t\t<td>Rseller:</td>";
        if (in_array($this->admin['level'], [1, 6])) {
            $qry_father = '';
            if ($this->admin['level'] == 6) {
                $fath = intval($this->admin['adminid']);
                $qry_father = 'WHERE adminid=' . $fath . ' OR father=' . $fath . ' ';
            }
            echo "\r\n\t\t\t\t\t\t<td>" . form_resellers('adminid', $adminid, 'All Resellers', $qry_father) . '</td>';
        } else {
            echo '<td>' . $this->admin['admin_name'] . '</td>';
        }
        echo "\r\n\t\t\t\t\t<td>TransID</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"transid\" value=\"" . $transid . "\" size=\"15\" placeholder=TransID></td>\r\n\t\t\t\t\t\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>MAC:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"mac\" value=\"" . $mac . "\" size=\"15\" placeholder='MAC (use * for wildcards)'></td>\r\n\t\t\t\t\t<td>Serial:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"serial\" value=\"" . $serial . "\" size=\"15\" placeholder='Serial (use * for wildcards)'></td>\r\n\t\t\t\t\t<td>Username:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"username\" value=\"" . $username . "\" size=\"15\" placeholder='Username (use * for wildcards)'></td>\r\n\t\t\t\t\t\r\n\t\t\t\t\t<!--<td>Status:</td>\r\n\t\t\t\t\t<td>" . _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811('status', $intro->status, -1) . ("</td>-->\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Mobile:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"mobile\" value=\"" . $mobile . "\" size=\"20\" placeholder='Mobile'></td>\r\n\t\t\t\t\t<td>Notes:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"notes\" value=\"" . $notes . "\" size=\"20\" placeholder=Notes></td>\r\n\t\t\t\t\t<td><input type=\"submit\" class=\"btn btn-success\" value=\" Search! \" class='btn btn-default'></td>\r\n\t\t\t\t\t<td></td>\r\n\t\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t\t<input type=\"hidden\" name=\"status\" value=\"" . $status . "\">\r\n\t\t</form>");
        echo "\r\n\t\t" . ($intro->input->get('msg') == 'renew_success' ? _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Code [' . $code . '] Renew Success!', 'success') : '') . "\r\n\t\t" . ($intro->input->get('msg') == 'renew_fail' ? _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Failed: ' . $intro->input->get('fail'), 'danger') : '') . "\r\n\t\t<table class=\"table table-striped table-bordered table-condensed\" id=\"table_codes\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['codes_fullname'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('fullname', 'index') . " </th>\r\n\t\t\t<th> </th>\r\n\t\t\t<th>" . $intro->lang['codes_code'] . '  </th>';
        if ($username != '') {
            echo '<th>Username</th>';
        }
        echo "\r\n\t\t\t<th>" . $intro->lang['codes_days'] . " </th>\r\n\t\t\t<th>Rseller  </th>\r\n\t\t\t<th>" . $intro->lang['codes_transid'] . " </th>\r\n\t\t\t<th>" . $intro->lang['codes_status'] . "  </th>\r\n\t\t\t<th>MAC </th>\r\n\t\t\t<th>Serial</th>\r\n\t\t\t<th>Start</th>\r\n\t\t\t<th>Expire</th>\r\n\t\t\t<th>Input</th>\r\n\t\t\t<th>Options</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        $mac = $serial = $activity_id = '';
        while ($myrow = $intro->db->fetch_assoc($result)) {
            @extract($myrow);
            $i++;
            $code_replaced = $myrow['code_replaced'];
            if ($status == 0 || $status == 111) {
                $label = 'default';
            } else {
                if ($status == 1) {
                    $label = 'success';
                } else {
                    if ($status == 2) {
                        $label = 'info';
                    } else {
                        if ($status == 3) {
                            $label = 'danger';
                        } else {
                            if ($status == 4) {
                                $label = 'warning';
                            } else {
                                if ($status == 5) {
                                    $label = 'danger';
                                } else {
                                    $label = 'danger';
                                }
                            }
                        }
                    }
                }
            }
            $date_expire = $date_expire != '' ? @date('Y-m-d', $date_expire) : '-';
            $date_start = $date_start != '' && $date_start != 0 ? @date('Y-m-d', $date_start) : '-';
            if ($online != '') {
                $online = '<a class="AjaxModal" href="' . $intro->app_url('online', 'index') . ('/?id=' . $userid . '&for=code"><icon class="icon-globe" style=\'color:green;\' title="' . $online . '"></icon></a>');
            } else {
                $online = '<a class="AjaxModal" href="' . $intro->app_url('online', 'was') . ('/?id=' . $userid . '&for=code"><icon class="icon-globe" style=\'color:gray;\' title="offline"></icon></a>');
            }
            $linethrough = $status == 4 ? 'style=\'text-decoration: line-through;\'' : '';
            echo "\r\n\t\t\t<tr id=\"tr_" . $id . '" ' . (in_array($period, $this->free) ? 'style=\'color:#ff2626\'' : '') . ' ' . ($status == 4 ? 'style=\'color:#d90000;\'' : '') . (">\r\n\t\t\t\t<td class='c'>" . $id . "</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='c'>" . $online . "</td>\r\n\t\t\t\t<td class='c' " . $linethrough . '>' . $code . '</td>');
            if ($intro->input->get_post('username') != '') {
                echo '<td>' . $username . '</td>';
            }
            echo '<td class=\'c\' ' . $linethrough . '>' . ($pkg > 0 ? $intro->packages[$pkg] : period($period, $free_days)) . "</td>\r\n\t\t\t\t<td class='c'>" . $array['admins'][$adminid] . "</td>\r\n\t\t\t\t<td class='c'>" . ($transid > 0 ? '<a href="' . $intro->app_url('trans', 'index') . ('?id=' . $transid . '">' . $transid . '</a>') : '-') . ("</td>\r\n\t\t\t\t<td  class='c' id=\"status_" . $id . "\">\r\n\t\t\t\t\t<span class='label label-" . $label . "'>\r\n\t\t\t\t\t\t" . $intro->status[$status] . " \r\n\t\t\t\t\t\t") . ($code_replaced != '' ? '<br/>' . $code_replaced : '') . ("\r\n\t\t\t\t\t</span>\r\n\t\t\t\t</td>\r\n\t\t\t\t<td class='c' id=\"mac_" . $id . "\">\r\n\t\t\t\t\t<a title='Model: " . $model . '\'>' . $mac . '</a>') . ($status != 0 ? $this->array_mac_type_txt[$mac_type] : '') . "\r\n\t\t\t\t\t" . ($mac2 != '' ? '<br/>' . $mac2 : '') . ("\r\n\t\t\t\t</td>\r\n\t\t\t\t<td class='c' id=\"sn_" . $id . '">' . $serial . "</td>\r\n\t\t\t\t<td class='c'><span class=\"editExpireDate\" data-type=\"text\" data-pk=\"" . $id . '" data-name="date_start">' . $date_start . "</span></td>\r\n\t\t\t\t<td class='c' id='expire_" . $id . '\' ' . $linethrough . '><span class="editExpireDate" data-type="text" data-pk="' . $id . '" data-name="date_expire">' . $date_expire . "</span></td>\r\n\t\t\t\t<td class='c'>") . $this->inputBy[$inputBy] . "</td>\r\n\t\t\t\t<td class='c'>";
            echo "\r\n\t\t\t\t\t<div class=\"btn-group\">\r\n                        <button class=\"btn btn-primary btn-xs dropdown-toggle\" href=\"#\" data-toggle=\"dropdown\">\r\n                        <span class='icon-cog'></span> <span class=\"caret\"></span>\r\n                        </button>\r\n                        <ul class=\"dropdown-menu stay-open pull-right\" role=\"menu\" style=\"padding: 15px; min-width: 200px;\">";
            if (isset($options['opt_stop_code']) && $options['opt_stop_code'] == 'yes' && $status == 1 && $date_start == date('Y-m-d')) {
                echo '<li><a class="AjaxConfirm" href="' . $this->base . '/Store?id=' . $id . '&NH=1&sus=off" OnClick="return false;"  title="Store code and don\'t count expire days."><span class="btn btn-default btn-xs icon-pause"></span> Store/Freez </a></li>';
            }
            if ($status == 2) {
                echo '<li><a class="AjaxConfirm" href="' . $this->base . '/Suspend?id=' . $id . '&NH=1&sus=off" OnClick="return false;"  title="Unsuspend Code"><span class="btn btn-success btn-xs icon-ok"></span> Unsuspend Code </a></li>';
            }
            if ($status > 0) {
                echo '<li><a class="AjaxModal" href="' . $intro->app_url('renew', 'RenewCode') . ('/?id=' . $id . '" title="Renew Code تجديد"><span class="btn btn-success btn-xs icon-cw"></span> Renew Code</a></li>');
            }
            if ($status == 1 && isset($options['opt_activation_count']) && $options['opt_activation_count'] == 'yes') {
                echo '<li><a class="AjaxModal" href="' . $this->base . '/ResetActivation?id=' . $id . '&NH=1" OnClick="return false;"  title="Reset Activation Limit"><span class="btn btn-success btn-xs icon-ok"></span> Reset Activation Limit </a></li>';
            }
            if ($status == 1) {
                if ($this->admin['level'] == 1 || $this->adminRow['can_m3u'] == 1) {
                    echo '<li><a class="p_edit AjaxModal" href="' . $this->base . '/m3u/?id=' . $id . "\" title=\"Download m3u\">\r\n\t\t\t\t\t\t\t\t\t<span class=\"btn btn-success btn-xs icon-download\"></span> m3u </a></li>";
                }
                echo '<li><a class="p_edit AjaxConfirm" href="' . $this->base . '/ResetCode?id=' . $id . '" OnClick="return false;" title="Reset Mac & Serial"><span class="btn btn-warning btn-xs icon-cw"></span> Reset MAC & SN</a></li>';
                if ($is_mag == 0 && $inputBy == 0 && $mac != 'reset_me' && $serial != 'reset_me' && $this->adminRow['can_set_pass'] == 1) {
                    echo '<li><a class="p_edit AjaxModal" href="' . $this->base . '/MacOptions?id=' . $id . '" OnClick="return false;" title="MAC & Serial Options"><span class="btn btn-danger btn-xs icon-barcode"></span> MAC/SN options</a></li>';
                }
                echo '<li><a class="p_view" href="' . $this->base . '/Debug?id=' . $id . '" title="Debug Code"><span class="btn btn-primary btn-xs icon-bug"></span> Watch Logs</a></li>';
            }
            echo '<li><a class="p_edit" href="' . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="Edit and Update Code Info"><span class="btn btn-info btn-xs icon-edit"></span> Edit </a></li>';
            if ($status == 1) {
                echo '<li><a class="p_edit AjaxConfirm" href="' . $this->base . '/Suspend?id=' . $id . '&NH=1&sus=on" OnClick="return false;" title="Suspend Code and Kik User"><span class="btn btn-info btn-xs icon-off"></span> Suspend </a></li>';
            }
            if ($this->admin['level'] == 1 || intval($this->admin['can_delete']) == 1) {
                echo '<li><a class="p_del AjaxModal" href="' . $this->base . '/DelForm?id=' . $id . '" title="' . $intro->lang['del'] . '"><span class="btn btn-danger btn-xs icon-trash"></span> Delete</a></li>';
            }
            echo "\r\n\t\t\t\t\t\t\t<li class=\"divider\"></li>";
            if ($status == 1) {
                echo '<li><a class="p_view AjaxModal" href="' . $intro->app_url('osd', 'code') . ('?id=' . $id . '" title="OSD Message"><span class="btn btn-default btn-xs icon-desktop"></span> Send OSD Msg</a></li>');
            }
            echo "\r\n                        </ul>\r\n\t\t\t\t\t</div>";
        }
        echo "</tbody>\r\n\t\t\t</table>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?' . $params, $totalrows, $rows_per_page, $page) . '</div>');
        echo "\t\t<script>\r\n\t\t\$(document).ready(function() {\r\n\t\t\t\r\n\t\t\t";
        if ($this->admin['level'] == 1 || $this->admin['level'] == 9) {
            echo "\t\t\t\t\$.fn.editable.defaults.mode = 'pop';     \r\n\t\t\t\t\$('.editExpireDate').editable({\r\n\t\t\t\t\turl: '";
            echo $this->base;
            echo "/EditCodeDate?NH=1',\r\n\t\t\t\t\tsuccess: function(response) {\r\n\t\t\t\t\t\tif(response != \"success\" && response != \"\")\r\n\t\t\t\t\t\t\talert(response);\r\n\t\t\t\t\t}\r\n\t\t\t\t});\r\n\t\t\t";
        }
        echo "\t\t});\r\n\t\t</script>\r\n\t\t";
    }
    public function ResetActivation()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if ($code == '') {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this code:\r\n\t\t\t\t<li>The code may not found or is deleted.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit;
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Reset activation limit for code: ' . $code, 'success');
        echo "\r\n\t\t<form name=\"frmRESET_LIMIT\" id=\"frmRESET_LIMIT\" method=\"post\" action=\"" . $this->base . "/doSaveMacOpts\">\r\n\t\t\r\n\t\t<table class=\"table table-striped table-bordered\">\r\n\t\t<!--<tr>\r\n\t\t\t<td>Activation Limit: </td>\r\n\t\t\t<td>" . $act_limit . "</td>\r\n\t\t</tr>-->\r\n\t\t<tr>\r\n\t\t\t<td>Number of Activation times: </td>\r\n\t\t\t<td>" . $act_count . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Warning: </td>\r\n\t\t\t<td>This will change the code, you will get new code with same expire date.</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> </td>\r\n\t\t\t<td> <input type=\"submit\" id=\"btn_Submit_RESET_LIMIT\" value=\" Yes, I agree to reset limit and change the code. \" class=\"btn btn-success\" OnClick=\"return confirm('Are you sure? this action cannot be undone.');\"/> \r\n\t\t\t\t<span id='spanSpin' class='icon-spin5'></span> \r\n\t\t\t\t<span id='result'></span></td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t<input type=\"hidden\" name=\"code\" value=\"" . $code . "\" />\r\n\t\t<input type=\"hidden\" name=\"codeID\" value=\"" . $id . "\" />\r\n\t\t\r\n\t\t</form>";
        echo '<a href="' . $this->base . '/CodeChange" class="btn btn-default icon-exchange"> Change Codes History </a> ';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$(document).ready(function(){\r\n\t\t\t\$(\"#frmRESET_LIMIT\").submit(function(event){\r\n\t\t\t\tevent.preventDefault();\r\n\r\n\t\t\t\t\$('#spanSpin').addClass('animate-spin');\r\n\t\t\t\t\r\n\t\t\t\t\$.ajax({\r\n\t\t\t\t\turl:'" . $this->base . "/doResetActivation?NH=1',\r\n\t\t\t\t\ttype:'POST',\r\n\t\t\t\t\tdata:\$(this).serialize(),\r\n\t\t\t\t\tsuccess:function(result){\r\n\t\t\t\t\t\t\$('#result').html(result);\r\n\t\t\t\t\t\t\$('#spanSpin').removeClass('animate-spin');\r\n\t\t\t\t\t}\r\n\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t});\r\n\t\t</script>";
    }
    public function doResetActivation()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('codeID'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        if ($row['code'] == '') {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this code:\r\n\t\t\t\t<li>The code may not found or is deleted.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit;
        }
        if (intval($row['userid']) == 0) {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: the code is not found in Xtream database.\r\n\t\t\t\t<li>Please contact your system admin.", 'danger');
            exit;
        }
        $old_code = $row['code'];
        $old_length = strlen($old_code);
        $old_length = $old_length < 10 ? 10 : $old_length;
        $new_code = $this->random_number($old_length);
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where code=\'' . $new_code . '\';'));
        if (0 >= $intro->db->returned_rows) {
            $intro->db->insert(PREFIX . "_codes_change", ["code_id" => $id, "old_code" => $old_code, "new_code" => $new_code, "reseller" => $this->admin["adminid"], "dtime" => date("Y-m-d H:i:s")]);
            $intro->db->query("UPDATE " . PREFIX . "_codes set code='" . $new_code . "',act_count=0 where id=" . $id . " " . $this->qry_admin);
            $intro->db->query("UPDATE `users` set username='" . $new_code . "' where id=" . intval($row["userid"]));
            echo "Success. Activation Limit has been reset.";
            echo "<h3>\r\n\t\tNew code is: " . $new_code . "\r\n\t\t</h3>";
        }
    }
    public function MacOptions()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if ($code == '') {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this code:\r\n\t\t\t\t<li>The code may not found or is deleted.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit;
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('MAC/SN Options for Code: ' . $code, 'success');
        echo "\r\n\t\t<form name=\"frmMacOpts\" id=\"frmMacOpts\" method=\"post\" action=\"" . $this->base . "/doSaveMacOpts\">\r\n\t\t\r\n\t\t<table class=\"table table-striped table-bordered\">\r\n\t\t<tr>\r\n\t\t\t<td>MAC Type: </td>\r\n\t\t\t<td>" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('mac_type', $this->array_mac_type, $mac_type, 0, 0) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> </td>\r\n\t\t\t<td> <input type=\"submit\" id=\"btn_Submit_MAC_Opts\" value=\" Save \" class=\"btn btn-success\" /> \r\n\t\t\t\t<span id='MacOptSpin' class='icon-spin5'></span> \r\n\t\t\t\t<span id='result'></span></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t</table>\r\n\t\t<input type=\"hidden\" name=\"code\" value=\"" . $code . "\" />\r\n\t\t<input type=\"hidden\" name=\"codeID\" value=\"" . $id . "\" />\r\n\t\t\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$(document).ready(function(){\r\n\t\t\t\$(\"#frmMacOpts\").submit(function(event){\r\n\t\t\t\tevent.preventDefault();\r\n\r\n\t\t\t\t\$('#MacOptSpin').addClass('animate-spin');\r\n\t\t\t\t\r\n\t\t\t\t\$.ajax({\r\n\t\t\t\t\turl:'" . $this->base . "/doSaveMacOpts?NH=1',\r\n\t\t\t\t\ttype:'POST',\r\n\t\t\t\t\tdata:\$(this).serialize(),\r\n\t\t\t\t\tsuccess:function(result){\r\n\t\t\t\t\t\t\$('#result').html(result);\r\n\t\t\t\t\t\t\$('#MacOptSpin').removeClass('animate-spin');\r\n\t\t\t\t\t}\r\n\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t});\r\n\t\t</script>";
    }
    public function doSaveMacOpts()
    {
        global $intro;
        $data = [];
        $id = intval($intro->input->get_post('codeID'));
        $code = trim($intro->input->get_post('code'));
        $mac_type = intval($intro->input->get_post('mac_type'));
        $data['mac_type'] = $mac_type;
        $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id);
        echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232(' Success!. You set value to : ' . $this->array_mac_type[$mac_type], 'success');
        echo "<script>\r\n\t\t\$(function () {\r\n\t\t   setTimeout(function()\r\n\t\t   {\r\n\t\t\t\t\$('#m3u-modal').modal('hide');\r\n\t\t   }, 1000);\r\n\t\t   \r\n\t\t   \$('#mac_" . $id . '\').load(\'' . $this->base . '/getMacData?NH=1&id=' . $id . "');\r\n\t\t   \r\n\t\t});</script>";
    }
    public function getMacData()
    {
        global $intro;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT status,mac,mac2,mac_type FROM ' . PREFIX . ('_codes where id=' . $id));
        $row = $intro->db->fetch_assoc($sql);
        extract($row);
        echo (string) $mac . ($status != 0 ? $this->array_mac_type_txt[$mac_type] : '') . "\r\n\t\t\t\t\t" . ($mac2 != '' ? '<br/>' . $mac2 : '');
    }
    public function EditCodeDate()
    {
        global $intro;
        $data = $dataU = [];
        $id = intval($intro->input->get_post('pk'));
        $name = trim($intro->input->get_post('name'));
        $value = trim($intro->input->get_post('value'));
        if (!IntroDate::validateDate($value, 'Y-m-d')) {
            exit('Wrong Date Format: use yyyy-mm-dd');
        }
        $value = strtotime($value);
        $data[$name] = $value;
        if ($this->admin['level'] == 1 || $this->admin['level'] == 9) {
            if ($name == 'date_expire') {
                $sql = $intro->db->query('SELECT userid,status,code,inputBy,username  FROM ' . PREFIX . ('_codes where id=' . $id));
                $row = $intro->db->fetch_assoc($sql);
                if ($row['status'] == 1) {
                    $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id);
                } else {
                    exit('Error: user not active.');
                }
                $userid = intval($row['userid']);
                $inputBy = intval($row['inputBy']);
                if ($userid != 0) {
                    $where = ' id=' . intval($userid);
                } else {
                    if ($inputBy == 0) {
                        $where = ' username=\'' . $code . '\' ';
                    } else {
                        $where = ' username=\'' . $username . '\' ';
                    }
                }
                $intro->db->query_fast('UPDATE users SET `exp_date`=\'' . $value . '\' WHERE ' . $where . ';');
                $af = $intro->db->affected_rows;
                exit('success (' . $af . ')');
            } else {
                $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id);
                exit('success');
            }
        }
    }
    public function m3u()
    {
        global $intro;
        global $array;
        global $options;
        $id = intval($intro->input->get_post('id'));
        if ($this->admin['level'] != 1) {
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if ($code == '') {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this code:\r\n\t\t\t\t<li>The code may not found or is deleted.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit;
        }
        $userid = intval($row['userid']);
        $sql2 = $intro->db->query('SELECT username,password,bouquet FROM users WHERE id=' . $userid . '; ');
        $row2 = $intro->db->fetch_assoc($sql2);
        $user = trim($row2['username']);
        $pass = trim($row2['password']);
        $bouquet = $row2['bouquet'];
        $url = _obf_0D3F5B5B312E2F352234142C1C1F3C1B0C06231A292732('m3u');
        if ($this->adminRow['host'] != '') {
            $url['host'] = $this->adminRow['host'];
        }
        $host = $url['scheme'] . '://' . $url['host'] . ':' . $url['port'] . str_replace('//', '/', '/' . $url['path']);
        $sql = $intro->db->query('SELECT * from devices order by device_name asc;');
        $data = 'Host: ' . $url['host'] . ':' . $url['port'] . "\n";
        $data .= 'Username: ' . $user . "\n";
        $data .= 'Password: ' . $pass . "\n";
        $maa = 1;
        $m3u8 = $host . ('?username=' . $user . '&password=' . $pass . '&type=m3u&output=ts');
        $m3u8_opt = $host . ('?username=' . $user . '&password=' . $pass . '&type=m3u_plus&output=ts');
        echo '<textarea class=\'AutoCopy form-control\' style=\'height:100px;font-size:16px;\' spellcheck="false" data-gramm="false">' . $data . '</textarea>';
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('M3U');
        echo '<textarea class=\'AutoCopy form-control\' style=\'height:60px;font-size:16px;\' spellcheck="false" data-gramm="false">' . $m3u8 . '</textarea>';
        echo 'M3U With Options:<br/><textarea class=\'AutoCopy form-control\' style=\'height:60px;font-size:16px;\' spellcheck="false" data-gramm="false">' . $m3u8_opt . '</textarea>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo '<br/><ul class="list-group">';
        while ($row = $intro->db->fetch_assoc($sql)) {
            $device_name = $row['device_name'];
            $device_key = $row['device_key'];
            $device_id = $row['device_id'];
            $link = $host . ('?username=' . $user . '&password=' . $pass . '&type=' . $device_key . '&output=mpegts');
            echo '<li data-id="' . $device_id . '" class="m3uSelector list-group-item ' . ($device_name == 'm3u' ? 'list-group-item-info' : '') . ('"><a href="' . $link . "\" OnClick='return false;'>\r\n\t\t\t\t" . $device_name . " \r\n\t\t\t\t</a>\r\n\t\t\t\t<div id='div_m3uinput_" . $device_id . "' style='display:none'>\r\n\t\t\t\t<input id='m3uinput_" . $device_id . '\' type=\'text\' class=\'form-control\' value=\'' . $link . "' />\r\n\t\t\t\t</div>\r\n\t\t\t</li>");
        }
        echo '</ul>';
    }
    public function Store()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $span_sus = '<span class="label label-default">Store</span>';
        $qq = $code = '';
        if (intval($this->admin['level']) == 1 || intval($this->admin['level']) == 9) {
            $qq = '';
        } else {
            $qq = ' and adminid=' . intval($this->admin['adminid']);
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $qq . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $code = $row['code'];
        $username = $row['username'];
        $sql = $intro->db->query('UPDATE ' . PREFIX . ('_codes SET status=111 WHERE id=' . $id . ' ' . $qq . ';'));
        $arr = ['status_' . $id => $span_sus];
        header('Content-Type: application/json');
        echo json_encode($arr);
    }
    public function Suspend()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sus = trim($intro->input->get_post('sus'));
        if ($sus == 'on') {
            $status = 2;
            $enabled = 0;
            $span_sus = '<span class="label label-info">Suspended</span>';
        } else {
            if ($sus == 'off') {
                $status = 1;
                $enabled = 1;
                $span_sus = '<span class="label label-success">Active</span>';
            } else {
                exit('Opps!!!');
            }
        }
        $qq = $code = '';
        if (intval($this->admin['level']) == 1 || intval($this->admin['level']) == 9) {
            $qq = '';
        } else {
            $qq = ' and adminid=' . intval($this->admin['adminid']);
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $qq . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $code = $row['code'];
        $username = $row['username'];
        $sql = $intro->db->query('UPDATE ' . PREFIX . ('_codes SET status=' . $status . ' WHERE id=' . $id . ' ' . $qq . ';'));
        if ($username != '') {
            $intro->db->query('UPDATE users SET enabled=' . $enabled . ' WHERE username=\'' . $username . '\'; ');
        } else {
            $intro->db->query('UPDATE users SET enabled=' . $enabled . ' WHERE username=\'' . $code . '\'; ');
            $arr = ['status_' . $id => $span_sus];
            header('Content-Type: application/json');
            echo json_encode($arr);
        }
    }
    public function DelForm()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        if (!is_array($row)) {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Code is not found or deleted. OR you are not authorized to delete this code.', 'danger');
            exit;
        }
        @extract($row);
        if ($status == 0) {
            $label = 'default';
        } else {
            if ($status == 1) {
                $label = 'success';
            } else {
                if ($status == 2) {
                    $label = 'info';
                } else {
                    if ($status == 3) {
                        $label = 'danger';
                    } else {
                        if ($status == 4) {
                            $label = 'default';
                        } else {
                            if ($status == 5) {
                                $label = 'warning';
                            } else {
                                $label = 'danger';
                            }
                        }
                    }
                }
            }
        }
        $date_expire = $date_expire != '' ? date('Y-m-d', $date_expire) : '-';
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Delete: ' . $code, 'danger');
        echo "<table class=\"table table-striped table-bordered\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='info'>Fullname:</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='info'>Adminid:</td>\r\n\t\t\t\t<td>" . $adminid . "</td>\r\n\t\t\t\t<td class='info'>TransID:</td>\r\n\t\t\t\t<td>" . $transid . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\r\n\t\t\t\t<td class='info'>Days:</td>\r\n\t\t\t\t<td>" . $days . "</td>\r\n\t\t\t\t<td class='info'>Date Expire</td>\r\n\t\t\t\t<td>" . $date_expire . "</td>\t\r\n\t\t\t\t<td class='info'>Status:</td>\r\n\t\t\t\t<td><span class='label label-" . $label . '\'>' . $intro->status[$status] . ' ' . ($code_replaced != '' ? '<br/>' . $code_replaced : '') . ("</span></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\t\t\r\n\t\t\t\t<td class='info'>MAC</td>\r\n\t\t\t\t<td>" . $mac . "</td>\r\n\t\t\t\t<td class='info'>Serial</td>\r\n\t\t\t\t<td>" . $serial . "</td>\r\n\t\t\t\t<td class='info'>Last Update</td>\r\n\t\t\t\t<td>" . $last_update . "</td>\r\n\t\t\t</tr>\r\n\t\t</table>");
        echo "<div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\">\r\n\t\t\t\t  \r\n\t\t\t\t  <a class=\"btn btn-danger p_del\" id=\"delete\" href=\"" . $this->base . '/Del?id=' . $id . '&code=' . $code . "&NH=1&db=1\">\r\n\t\t\t\t\t<i class=\"icon-cancel-circled2\"></i> Delete Code From database\r\n\t\t\t\t  </a>\r\n\t\t\t\t  \r\n\t\t\t\t  <a class=\"btn btn-warning\" id=\"suspend\" href=\"" . $this->base . '/Del?id=' . $id . '&code=' . $code . "&NH=1\">\r\n\t\t\t\t\t<i class=\"icon-cancel-circled2\"></i> Mark as Delete and Dsiable in Extream.\r\n\t\t\t\t  </a>\r\n\t\t\t\t  \r\n\t\t\t\t\r\n\t\t\t</div>\r\n\t\t\t\t\r\n\t\t\t\t<span id=\"spin\" class='icon-spin5'></span>";
        echo '<div id=\'result\'>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$('documnet').ready(function(){\r\n\t\t\t\$('#delete').click(function(e){\r\n\t\t\t\te.preventDefaults;\r\n\t\t\t\t\r\n\t\t\t\tif(!confirm('Are you sure?')) return false;\r\n\t\t\t\t\r\n\t\t\t\t\$('#spin').addClass('animate-spin');\r\n\t\t\t\t\$.get( \$(this).attr('href'), function( data ) {\r\n\t\t\t\t\t\$( \"#result\" ).html( data );\r\n\t\t\t\t\t\$('#spin').removeClass('animate-spin');\r\n\t\t\t\t});\r\n\t\t\t\treturn false;\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$('#suspend').click(function(e){\r\n\t\t\t\te.preventDefaults;\r\n\t\t\t\t\r\n\t\t\t\tif(!confirm('Are you sure?')) return false;\r\n\t\t\t\t\r\n\t\t\t\t\$('#spin').addClass('animate-spin');\r\n\t\t\t\t\$.get( \$(this).attr('href'), function( data ) {\r\n\t\t\t\t\t\$( \"#result\" ).html( data );\r\n\t\t\t\t\t\$('#spin').removeClass('animate-spin');\r\n\t\t\t\t});\r\n\t\t\t\treturn false;\r\n\t\t\t});\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function Debug()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $file = trim($intro->input->get_post('file'));
        if ($this->admin['level'] == 9) {
            $this->qry_admin = '';
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if ($status == 0) {
            $label = 'default';
        } else {
            if ($status == 1) {
                $label = 'success';
            } else {
                if ($status == 2) {
                    $label = 'info';
                } else {
                    if ($status == 3) {
                        $label = 'danger';
                    } else {
                        if ($status == 4) {
                            $label = 'default';
                        } else {
                            if ($status == 5) {
                                $label = 'warning';
                            } else {
                                $label = 'danger';
                            }
                        }
                    }
                }
            }
        }
        $date_expire = $date_expire != '' ? date('Y-m-d', $date_expire) : '-';
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Debug code: ' . $code);
        echo "<table class=\"table table-striped table-bordered\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='info'>Fullname:</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='info'>Adminid:</td>\r\n\t\t\t\t<td>" . $adminid . "</td>\r\n\t\t\t\t<td class='info'>TransID:</td>\r\n\t\t\t\t<td>" . $transid . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\r\n\t\t\t\t<td class='info'>Days:</td>\r\n\t\t\t\t<td>" . $days . "</td>\r\n\t\t\t\t<td class='info'>Date Expire</td>\r\n\t\t\t\t<td>" . $date_expire . "</td>\t\r\n\t\t\t\t<td class='info'>Status:</td>\r\n\t\t\t\t<td><span class='label label-" . $label . '\'>' . $intro->status[$status] . ' ' . ($code_replaced != '' ? '<br/>' . $code_replaced : '') . ("</span></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\t\t\r\n\t\t\t\t<td class='info'>MAC</td>\r\n\t\t\t\t<td>" . $mac . "</td>\r\n\t\t\t\t<td class='info'>Serial</td>\r\n\t\t\t\t<td>" . $serial . "</td>\r\n\t\t\t\t<td class='info'>Last Update</td>\r\n\t\t\t\t<td>" . $last_update . "</td>\r\n\t\t\t</tr>\r\n\t\t</table>");
        echo "<div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\">\r\n\t\t\t\t  <button id='refresh_bug' type=\"button\" class=\"btn btn-primary\">Refresh Logs</button>\r\n\t\t\t\t</div><span id=\"spin\" class='icon-spin5'></span>";
        $this->getBug($code, $mac, $serial, $inputBy, $userid);
        echo '</div>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$('documnet').ready(function(){\r\n\t\t\t\$('#refresh_bug').click(function(){\r\n\t\t\t\t\$('#spin').addClass('animate-spin');\r\n\t\t\t\t\$.get( \"" . $this->base . '/getBug?NH=1&code=' . $code . '&inputBy=' . $inputBy . '&sn=' . $serial . '&mac=' . $mac . '&userid=' . $userid . "\", function( data ) {\r\n\t\t\t\t\t\$( \"#result\" ).html( data );\r\n\t\t\t\t\t\$('#spin').removeClass('animate-spin');\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function getBug($code = '', $mac = '', $sn = '', $inputBy = 0, $userid = 0)
    {
        global $intro;
        global $array;
        if ($code == '') {
            $code = trim($intro->input->get_post('code'));
        }
        if ($mac == '') {
            $mac = trim($intro->input->get_post('mac'));
        }
        if ($sn == '') {
            $sn = trim($intro->input->get_post('sn'));
        }
        if ($inputBy == 0) {
            $inputBy = intval($intro->input->get_post('inputBy'));
        }
        if ($userid == 0) {
            $userid = intval($intro->input->get_post('userid'));
        }
        if ($inputBy == 0) {
            $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs where code=\'' . $code . '\' order by id desc'));
        }
        if ($inputBy == 1) {
            $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs where mac=\'' . $mac . '\' order by id desc'));
        }
        if ($inputBy == 2) {
            $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs where serial=\'' . $sn . '\' order by id desc'));
        }
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Logs (' . $totalrows . ')');
        echo "\r\n\t\tB = Block IP\r\n\t\t<table class=\"table table-bordered table-hover\">\r\n            <tr>\r\n\t\t\t\t<th>ID</th>\r\n\t\t\t\t<th>Ver</th>\r\n\t\t\t\t<th>Resel</th>\r\n\t\t\t\t<th>Date</th>\r\n\t\t\t\t<th>Code</th>\r\n\t\t\t\t<th>Serial</th>\r\n\t\t\t\t<th>Mac</th>\r\n\t\t\t\t<th>IP</th>\r\n\t\t\t\t<th>Log</th>\r\n\t\t\t\t<th>UserAgent</th>\r\n\t    </tr>";
        $i = 0;
        while ($myrow = $intro->db->fetch_assoc($result)) {
            @extract($myrow);
            $i++;
            if ($i % 2 == 0) {
                $BG = 'odd';
            } else {
                $BG = 'even';
            }
            $dtime = date('Y-m-d H:i:s', $dtime);
            $thelog = str_replace('+', '<br/>', $thelog);
            $thelog = str_replace('@Wrong Code', '<span class=\'label label-danger\'>@Wrong Code</span>', $thelog);
            $thelog = str_replace('ReActivation', '<span class=\'label label-default\'>ReActivation</span>', $thelog);
            $thelog = str_replace('Success', '<span class=\'label label-success\'>Success</span>', $thelog);
            echo '<tr class="' . $BG . "\">\r\n\t\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t\t<td class=\"center\">" . $ver . "</td>\r\n\t\t\t\t\t<td class=\"center\">" . $array['admins'][$adminid] . "</td>\r\n                     <td class=\"center\">" . $dtime . "</th>\r\n                     <td class=\"center\">" . $code . "</th>\r\n                     <td class=\"center\">" . $serial . "</th>\r\n                     <td class=\"center\">" . $mac . "</th>\r\n                     <td class=\"center\"><a href='http://ipinfo.io/" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\r\n                     <td>" . $thelog . "</th>     \r\n                     <td>" . $uagent . "</th>     \r\n\t\t </tr>";
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        $sql = $intro->db->query('SELECT * FROM `client_logs` where user_id=' . $userid . ' ' . ' group by client_status order by id desc LIMIT 50');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<span class=\'icon-list\'></span>Xtream Clients Logs Userid: ' . $userid, 'primary');
        echo "\r\n\t\t<table class=\"table table-condensed table-bordered table-hover\">\r\n\t\t\t<tr>\r\n\t\t\t\t<th>ID</th>\r\n\t\t\t\t<th>Stream</th>\r\n\t\t\t\t\r\n\t\t\t\t<th>Status</th>\r\n\t\t\t\t<th>Query</th>\r\n\t\t\t\t<th>Agent</th>\r\n\t\t\t\t<th>IP</th>\r\n\t\t\t\t<th>Date</th>\r\n\t\t\t\t<th>Count</th>\r\n\t\t\t</tr>";
        $i = 0;
        while ($row = $intro->db->fetch_assoc($sql)) {
            @extract($row);
            $i++;
            echo "<tr>\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $stream_id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $client_status . "</th>\r\n\t\t\t\t<td class=\"center\">" . $query_string . "</th>\r\n\t\t\t\t<td class=\"center\">" . $user_agent . "</th>\r\n\t\t\t\t<td class=\"center\"><a href='https://cmyip.com/search-ip.php?ip=" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\r\n\t\t\t\t<td class=\"center\">" . @date('Y-m-d H:i:s', $date) . ("</th>\r\n\t\t\t\t<td>" . $cnt . "</th>     \r\n\t\t\t\t\t\r\n\t\t\t</tr>");
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function ResetCode()
    {
        global $intro;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT is_mag,mac,serial,inputBy FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $is_mag = intval($row['is_mag']);
        $inputBy = intval($row['inputBy']);
        $mac = trim($row['mac']);
        $serial = trim($row['serial']);
        if ($is_mag == 0) {
            $data = [];
            if ($inputBy == 0) {
                $data['mac'] = 'reset_me';
                $mac = $data['mac'];
                $data['mac2'] = '';
                $data['serial'] = 'reset_me';
                $serial = $data['serial'];
            } elseif ($inputBy == 1) {
                $data['serial'] = 'reset_me';
                $serial = $data['serial'];
            } elseif ($inputBy == 2) {
                $data['mac'] = 'reset_me';
                $mac = $data['mac'];
            }
            $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id . ' AND is_mag=0');
        }
        if ($is_mag == 1) {
            $data = [];
            $data['mac2'] = '';
            $data['serial'] = 'reset_me';
            $serial = $data['serial'];
            $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id . ' AND inputBy=0 AND is_mag=1');
        }
        $arr = ['mac_' . $id => $mac, 'sn_' . $id => $serial];
        header('Content-Type: application/json');
        echo json_encode($arr);
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $period;
        global $fullname;
        global $code;
        global $days;
        global $adminid;
        global $transid;
        global $status;
        global $last_update;
        global $num;
        global $bouquets;
        global $forced_country;
        global $allowed_uagent;
        global $mobile;
        global $notes;
        global $free_days;
        global $length;
        global $islam_pkg;
        global $options;
        global $container;
        global $output;
        global $groupID;
        if ($error || $_POST != null) {
            @extract($_POST);
        }
        $IF = intval($intro->input->get_post('IF'));
        $id = intval($intro->input->get_post('id'));
        $page = intval($intro->input->get_post('page'));
        $t = $t == '' ? $intro->input->get_post('t') : $t;
        $btn = [];
        if ($IF != 1) {
            $this->nav();
        }
        if ($t == 'edit') {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $qry = '';
            $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            if ($userid > 0) {
                $sql2 = $intro->db->query('SELECT * FROM users where id=\'' . $userid . '\';');
                $row2 = $intro->db->fetch_assoc($sql2);
                $username = $row2['username'];
            }
            if ($code == '') {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this code:\r\n\t\t\t\t\t<li>The code may not found or is deleted.\r\n\t\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
                exit;
            }
            $btn['legend_name'] = $intro->lang['codes_edit'] . (' <b>' . $id . '</b>');
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $bouquets = explode(',', $bouquets);
            if ($allowed_uagent != '') {
                $tmp_ua = json_decode($allowed_uagent, true);
                $allowed_uagent = implode(',', $tmp_ua);
            }
        } elseif ($t == 'add') {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            new IntroPerms('CheckBalance', $this->adminRow);
            $btn['legend_name'] = $intro->lang['codes_add'];
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
            $num = $num == '' ? 1 : $num;
            $length = $length == '' ? 12 : $length;
            if ($this->adminRow['num_free'] == 0) {
            }
            $output = $output == '' ? 'ts' : $output;
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ') . "\r\n\t\t" . _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911() . ("\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<table class=\"table table-bordered\">\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['codes_fullname'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"fullname\" value=\"" . $fullname . '" class="form-control" required=\'\'> ' . $this->error('fullname') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Mobile :</td>\r\n\t\t\t<td><input  type=\"text\" name=\"mobile\" value=\"" . $mobile . '" class="form-control"> ' . $this->error('mobile') . "</td>\r\n\t\t</tr>");
        $numLimit = '';
        if ($this->admin['level'] != 1) {
            $numLimit = 'max="999"';
        }
        if ($this->admin['level'] == 1 || $t == 'add') {
            if ($this->adminRow['member_group_id'] == 0) {
                echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>" . $intro->lang['codes_days'] . " :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td><div class=\"form-inline\">\r\n\t\t\t\t\t\t" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', _obf_0D322A5B141A102E2824032B03230A35140306272F2F11(), $period) . (' ' . $this->error('period'));
                if ($this->admin['level'] == 1) {
                    echo '<span id="span_free_days" style="display:none">Free Extra Days: <input  type="number" name="free_days" value="' . $free_days . '" ' . ($t == 'add' ? 'min="1"' : '') . ' class="form-control" size="10"></span>';
                } elseif (strlen($this->adminRow['extra_free_days']) >= 2) {
                    echo extra_free_days($this->adminRow['extra_free_days'], $free_days);
                }
                echo "\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
            }
            if ($t == 'add') {
                echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td><span style='color:#ff0000'>Numbers of codes :  *</span>\r\n\t\t\t\t\t<br/><span dir=rtl>the number of codes you want to generate.</span>\r\n\t\t\t\t\t</td>\r\n\t\t\t\t<td>\r\n\t\t\t\t\t<div class=\"form-inline\">\r\n\t\t\t\t\t\t<input  type=\"number\" name=\"num\"  min=\"1\" " . $numLimit . ' value="' . $num . '" class="form-control" size="10"> ' . $this->error('num') . " \r\n\t\t\t\t\t\tCode Length: <input  type=\"number\" name=\"length\" min=\"10\" max='16' step='2' value=\"" . $length . '" class="form-control" size="5" required=\'\'>' . $this->error('length') . ' ';
                if ($this->PaypassLargeNumber) {
                    echo "<div style='background:#006619;color:#fff'>\r\n\t\t\t\t\t\t\t<input type='checkbox' name='PaypassLargeNumber' value='yes'> Ok I know Add all (" . $num . ") codes.\r\n\t\t\t\t\t\t\t</div>";
                }
                echo "\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
            }
        }
        if ($t == 'edit') {
            echo "\r\n\t\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td>" . $intro->lang['codes_code'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td><input  type=\"text\" name=\"code\" value=\"" . $code . '" size="30"> ' . $this->error('code') . " \r\n\t\t\t\t\t") . ($this->admin['can_change'] == 1 && $t == 'edit' && $inputBy == 0 ? '<small>You can change code.</small>' : '[You cannot change code because it\'s activated by MAC/SN]') . ("</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Username :</td>\r\n\t\t\t\t<td><input  type=\"text\" name=\"username\" value=\"" . $username . '" size="30"> ' . $this->error('username') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>MAC :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td><input  type=\"text\" name=\"mac\" value=\"" . $mac . '" size="30"> ' . $this->error('mac') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>SERIAL :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td><input  type=\"text\" name=\"serial\" value=\"" . $serial . '" size="30"> ' . $this->error('serial') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>") . $intro->lang['codes_status'] . " : </td>\r\n\t\t\t\t<td>" . _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811('status', $intro->status, $status) . (' ' . $this->error('status') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>") . $intro->lang['codes_last_update'] . (" : </td>\r\n\t\t\t\t<td>" . $last_update . "</td>\r\n\t\t\t</tr>");
        }
        if ($this->admin['level'] == 1 && $t == 'edit' && $status == 1) {
            if ($date_start != '' && $date_start != 0) {
                $date_start = date('Y-m-d H:i:s', $date_start);
            }
            $date_expire = date('Y-m-d H:i:s', $date_expire);
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Start Date : </td>\r\n\t\t\t\t<td><input type=\"text\" name=\"date_start\" value=\"" . $date_start . "\" size=\"25\"></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>End Date : </td>\r\n\t\t\t\t<td><input type=\"text\" name=\"date_expire\" value=\"" . $date_expire . "\" size=\"25\"></td>\r\n\t\t\t</tr>";
        }
        if ($this->admin['level'] == 1 || $this->adminRow['member_group_id'] == 0) {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Output  : </td>\r\n\t\t\t\t<td>" . _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811('output', $this->output, $output) . "</td>\r\n\t\t\t</tr>";
        }
        if ($this->adminRow['member_group_id'] == 0 || $t == 'edit') {
            if ($this->adminRow['member_group_id'] > 0) {
                $intro->member_group_id = $this->adminRow['member_group_id'];
                $intro->code_pkg = $pkg;
            }
            echo "<tr>\r\n\t\t\t\t<td>Bouquets:  <span style='color:#ff0000'>*</span>\r\n\t\t\t\t\t<div style=\"float:right;\">\r\n\t\t\t\t\t\t   <input type=\"checkbox\" id=\"checkAll\"/> <b>Check All</b>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\r\n\t\t\t\t<td> " . $this->error('bouquets') . ' ' . bouquets($bouquets) . "</td>\r\n\t\t\t</tr>";
        } elseif ($t == 'add') {
            $pkg = new Packages($this->adminRow);
            echo "\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Package: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t\t<td>";
            echo $pkg->FormDropDown();
            echo "\r\n\t\t\t\t\t</td>\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Bouquets:  <span style='color:#ff0000'>*</span>\r\n\t\t\t\t\t\t<div style=\"float:right;\">\r\n\t\t\t\t\t\t\t   <input type=\"checkbox\" id=\"checkAll\"/> <b>Check All</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</td>\r\n\t\t\t\t\t<td> " . $this->error('bouquets') . " <div id='bouquets_result'></div></td>\r\n\t\t\t\t</tr>";
        }
        if ($this->admin['level'] == 1 || $this->adminRow['can_set_country'] == 1) {
            echo "<tr>\r\n\t\t\t\t\t<td>Override General Country Restriction:  </td>\r\n\t\t\t\t\t<td> " . forced_country($forced_country) . "</td>\r\n\t\t\t\t</tr>";
        }
        if (in_array($this->admin['level'], [1, 6])) {
            $qry_father = '';
            if ($this->admin['level'] == 6) {
                $fath = intval($this->admin['adminid']);
                $qry_father = 'WHERE adminid=' . $fath . ' OR father=' . $fath . ' ';
                if ($t == 'add') {
                    $adminid = $fath;
                }
            }
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Allowed User Agent :</td>\r\n\t\t\t\t<td>\r\n\t\t\t\t\t<div class=\"form-inline\">\r\n\t\t\t\t\t\t<input class=\"form-control\" type=\"text\" name=\"allowed_uagent\" value=\"" . $allowed_uagent . '" size="30"> ' . $this->error('allowed_uagent') . " <i>(Allowed User Agents to use this account [Default all allowed])</i>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>" . $intro->lang['codes_adminid'] . " :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td>" . _obf_0D312C22263726180408322D1B0C363E320C351C1B0B32($adminid, $qry_father) . (' ' . $this->error('adminid') . "</td>\r\n\t\t\t</tr>");
        }
        if ($this->admin['level'] == 1 && $t == 'edit') {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Xtream UserID : </td>\r\n\t\t\t\t<td><input type=\"text\" name=\"userid\" value=\"" . $userid . "\" size=\"10\" readonly></td>\r\n\t\t\t</tr>";
        }
        if (isset($options['opt_islamic_pkg']) && $options['opt_islamic_pkg'] == 'yes') {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>  </td>\r\n\t\t\t\t<td><input type=\"checkbox\" name=\"islam_pkg\" value=\"1\" " . ($islam_pkg == 1 ? 'checked' : '') . ">\r\n\t\t\t\t\tIslamic Package</td>\r\n\t\t\t</tr>";
        }
        if ($this->admin['level'] == 1) {
            echo "\r\n\t\t<tr>\r\n\t\t\t<td>Group: </td>\r\n\t\t\t<td>" . _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811('groupID', $intro->groups, $groupID, $txt = '', $val = 0) . "</td>\r\n\t\t</tr>";
        }
        echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Notes :</td>\r\n\t\t\t\t<td><textarea name=\"notes\" class=\"form-control\" style='width:100%;height:70px;'>" . $notes . '</textarea> ' . $this->error('notes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Cost :</td>\r\n\t\t\t\t<td><div id='ResultCost'></div></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"center\" colspan=\"2\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"IF\"  value=\"" . $IF . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"old_status\"  value=\"" . $status . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"page\"  value=\"" . $page . "\">\r\n\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success\" value=\"" . $btn['action'] . '"><i class="' . $btn['img_icon'] . '"> ' . $btn['name'] . " </i></button>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t</table>\r\n\t\t</form>";
        echo "<script>\r\n\t\t\$(document).ready(function(){\r\n\r\n\t\t\t\$(\"select[name='package']\").change(function () {\r\n\t\t\t\t\r\n\t\t\t\tvar package = \$(this).val();\r\n\t\t\t\t\r\n\t\t\t\t\$.post(\"" . $intro->app_url('renew', 'getBouquets') . "/?NH=1\", \r\n\t\t\t\t\t{package:package}, function(data,status,xhr){\t\r\n\t\t\t\t\t\$(\"#bouquets_result\").html(data);\r\n\t\t\t\t\t/*\$(\"#checkAll\").trigger('click');*/\r\n\t\t\t\t\t\$(\"#UsersBouquets\").find(':checkbox').prop('checked', true);\r\n\t\t\t\t});\r\n\t\t\t\r\n\t\t\t\t\r\n\t\t\t});\r\n\t\t\t\$(\"#checkAll\").change(function () {\r\n\t\t\t\t\$(\"input:checkbox\").prop('checked', \$(this).prop(\"checked\"));\r\n\t\t\t});\r\n\t\t\tvar CalcCost = function (){\r\n\t\t\t\t\r\n\t\t\t\tvar period = parseInt(\$(\"select[name=period]\").val()) || 0;\r\n\t\t\t\tvar admin = parseInt(\$(\"select[name=adminid]\").val()) || 0;\r\n\t\t\t\tvar num = parseInt(\$(\"input[name=num]\").val()) || 0;\r\n\t\t\t\t\r\n\t\t\t\t\$.post(\"" . $intro->app_url('renew', 'calcCost') . "/?NH=1\", {period:period,resel:admin,num:num}, function(data,status,xhr){\t\r\n\t\t\t\t\t\$(\"#ResultCost\").html(data);\r\n\t\t\t\t});\r\n\t\t\t}\r\n\t\t\t\$(\"select[name=period]\").change(function () {\r\n\t\t\t\t\r\n\t\t\t\tvar groupName = \$(this).val();\r\n\t\t\t\t\r\n\t\t\t\tif(groupName < 100 && groupName >= 1){\r\n\t\t\t\t\t\$('#span_free_days').show();\r\n\t\t\t\t\t\r\n\t\t\t\t}else{\r\n\t\t\t\t\t\$('#span_free_days').hide();\r\n\t\t\t\t}\r\n\t\t\t\tCalcCost;\r\n\t\t\t});\r\n\t\t\t\$(\"select[name=adminid],select[name=period]\").change(CalcCost);\r\n\t\t\t\$(\"input[name='num']\").keyup(CalcCost).blur(CalcCost).change(CalcCost);\r\n\t\t\t\r\n\t\t});";
        if ($period >= 1 && $period < 100) {
            echo "\$('#span_free_days').show();\n";
        } else {
            echo "\$('#span_free_days').hide();\n";
        }
        echo "\r\n\t\t</script>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        global $array;
        $fullname = trim($intro->input->post('fullname'));
        $mobile = trim($intro->input->post('mobile'));
        $notes = trim($intro->input->post('notes'));
        $days = intval($intro->input->post('days'));
        $period = intval($intro->input->post('period'));
        $adminid = intval($intro->input->post('adminid'));
        $num = intval($intro->input->post('num'));
        $num = intval($intro->input->post('num'));
        $free_days = intval($intro->input->post('free_days'));
        $bouquets = $intro->input->post('bouquets');
        $forced_country = trim($intro->input->post('forced_country'));
        $allowed_uagent = trim($intro->input->post('allowed_uagent'));
        $length = intval($intro->input->post('length'));
        $islam_pkg = intval($intro->input->post('islam_pkg'));
        $package = intval($intro->input->post('package'));
        if ($fullname == '' || $num == 0 || !in_array($length, [10, 12, 14, 16]) || $period == 0 && $package == 0 || $bouquets == null || $this->adminRow['num_free'] == 0 && in_array($period, $array['free']) && $package == 0) {
            if ($fullname == '') {
                $error['fullname'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if ($num == 0) {
                $error['num'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if ($period == 0 && $package == 0) {
                $error['period'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if ($this->adminRow['num_free'] == 0 && in_array($period, $array['free']) && $package == 0) {
                $error['period'] = '<span class=error>Error: you can\'t Add free Codes at this time. Please contact admin.</span>';
            }
            if ($bouquets == null) {
                $error['bouquets'] = '<span class=error>Please choose at least one Bouquets/PACKAGE</span>';
            }
            if (!in_array($length, [10, 12, 14, 16])) {
                $error['length'] = '<span class=error>Length must be 10 or 12 or 14 or 16</span>';
            }
            $this->Form('add');
            exit;
        }
        if (in_array($period, $array['free']) && $this->adminRow['num_free'] != -1 && $this->adminRow['num_free'] < $num) {
            $error['num'] = '<span class=error>Error: you can only add (' . $this->adminRow['num_free'] . ') free codes.</span>';
            $this->Form('add');
            exit;
        }
        if ($num >= 1001 && $intro->input->post('PaypassLargeNumber') != 'yes') {
            $error['num'] = "<h3><span class='label label-danger'>Warning You are trying \r\n\t\t\t\tto ADD (" . $num . ') codes!!! please contact admin.</span></h3>';
            if ($this->admin['level'] == 1) {
                $this->PaypassLargeNumber = true;
            }
            $this->Form('add');
            exit;
        }
        if ($adminid == 0) {
            $adminid = intval($this->admin['adminid']);
        }
        if (in_array($period, $array['free'])) {
            $dd = $period - 100;
            $days = $dd;
        } else {
            $days = $period * 30;
        }
        $totalinvoices = 0;
        if ($this->admin['level'] != 1 && !in_array($period, $array['free']) || $package > 0) {
            $p = new IntroPerms('CheckCost', $this->adminRow, $num, $period, $package);
            if ($p->error != '') {
                _obf_0D103C08311F24242D2F281F0B3E28333032320A031011($p->error, 'danger');
                $this->Form('add');
                exit;
            }
        }
        if ($package > 0) {
            $pkg = _obf_0D0E122A21280A14271F3B1D1727291E290A0A2A092E11($package);
        }
        if ($num > 1) {
            $tData = ['trans_name' => $fullname, 'trans_codes' => $num, 'trans_period' => $period, 'trans_free_days' => $free_days, 'trans_date' => time(), 'trans_codes_length' => $length, 'adminid' => $adminid];
            $intro->db->insert(PREFIX . '_codes_trans', $tData);
            $transid = $intro->db->insert_id();
            $inv_note = 'Add ' . $num . ' codes(s)';
        } else {
            $transid = 0;
            $inv_note = 'Add codes: {code}';
        }
        $inv_all_data = '';
        $success = 0;
        for ($i = 1; $i <= $num; $i++) {
            $data = [];
            $data['fullname'] = $fullname;
            $data['code'] = $this->random_number($length);
            $data['days'] = $days;
            if ($package > 0) {
                $data['period'] = $package;
                $data['pkg'] = $package;
                $data['is_free'] = $pkg['is_trial'];
            } else {
                $data['period'] = $period;
                $data['is_free'] = in_array($period, $array['free']) ? 1 : 0;
            }
            $data['free_days'] = $free_days;
            $data['adminid'] = $adminid;
            $data['transid'] = $transid;
            $data['status'] = 0;
            $data['last_update'] = '';
            $data['bouquets'] = implode(',', $bouquets);
            $data['forced_country'] = $forced_country;
            $data['allowed_uagent'] = $this->allowed_uagent($allowed_uagent, 'save');
            $data['inputBy'] = 0;
            $data['mobile'] = $mobile;
            $data['notes'] = $notes;
            $data['islam_pkg'] = $islam_pkg;
            $data['output'] = trim($intro->input->post('output'));
            $data['groupID'] = intval($intro->input->post('groupID'));
            $intro->db->insert(PREFIX . '_codes', $data);
            if ($intro->db->insert_id() > 0) {
                $success++;
            }
            $inv_all_data .= $data['code'] . "\n";
        }
        if ($package == 0) {
            if (!in_array($period, $array['free'])) {
                $inv = new IntroInvoice();
                $inv->set('adminid', $adminid);
                $inv->set('period', $period);
                $inv->set('num', $num);
                $inv->set('code_trans', $transid);
                $inv->set('all_data', $inv_all_data);
                $inv->set('userid', 0);
                $inv->set('notes', str_replace('{code}', $data['code'], $inv_note) . ' Days:' . $array['period'][$period]);
                $inv->Save();
            }
        } else {
            $inv = new IntroInvoice();
            $inv->set('isPackage', true);
            $inv->set('adminid', $adminid);
            $inv->set('package', $package);
            $inv->set('period', $package);
            $inv->set('num', $num);
            $inv->set('code_trans', $transid);
            $inv->set('all_data', $inv_all_data);
            $inv->set('userid', 0);
            $inv->set('notes', str_replace('{code}', $data['code'], $inv_note) . ' Days:' . $pkg['inv_notes']);
            $inv->Save();
        }
        if (in_array($period, $array['free']) && $this->adminRow['num_free'] > 0 && $success > 0) {
            $intro->db->query('UPDATE ' . PREFIX . ('_admin SET num_free=num_free-' . $success . ' WHERE num_free>0 AND adminid=' . $adminid . ';'));
            if ($this->adminRow['father'] > 0) {
                $intro->db->query('UPDATE ' . PREFIX . ('_admin SET num_free=num_free-' . $success . ' WHERE num_free>0 AND adminid=' . $this->adminRow['father'] . ';'));
            }
            $intro->db->query('UPDATE ' . PREFIX . '_admin SET num_free=0 WHERE num_free<-1;');
        }
        $intro->redirect($this->appname);
    }
    public function random_number($length)
    {
        $random = substr(number_format(time() * rand(), 0, '', ''), 0, $length);
        return $random;
    }
    public function allowed_uagent($allowed_uagent, $for = 'save')
    {
        if ($for == 'save') {
            if ($allowed_uagent != '') {
                $ex = explode(',', $allowed_uagent);
                $agnet = json_encode($ex);
                return $agnet;
            } else {
                return '';
            }
        }
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        global $error;
        $id = intval($intro->input->get_post('id'));
        $allowed_uagent = trim($intro->input->get_post('allowed_uagent'));
        $sql = $intro->db->query('SELECT code,username,status,inputBy FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $old_code = $row['code'];
        $data = [];
        $code = trim($intro->input->post('code'));
        if ($this->admin['level'] == 1) {
            $data['status'] = trim($intro->input->post('status'));
            $data['period'] = intval($intro->input->post('period'));
            $data['free_days'] = intval($intro->input->post('free_days'));
            $data['adminid'] = intval($intro->input->post('adminid'));
            $data['allowed_uagent'] = $this->allowed_uagent($allowed_uagent, 'save');
        }
        if ($row['inputBy'] == 0 && ($this->admin['can_change'] == 1 || $this->admin['level'] == 1 || $this->admin['level'] == 9)) {
            if (strlen($code) < 10 || !is_numeric($code)) {
                $error['code'] = '<span class=\'label label-danger\'>Code must be number and 10 digits or greater.</span>';
                $_POST['id'] = $id;
                $this->Form('edit');
                exit;
            }
            if ($old_code != $code) {
                $sql = $intro->db->query('SELECT code FROM ' . PREFIX . ('_codes where code=\'' . $code . '\' AND code!=\'' . $code . '\';'));
                if ($intro->db->returned_rows > 0) {
                    $error['code'] = '<span class=\'label label-danger\'>Sorry code: ' . $code . ' already used.</span>';
                    $_POST['id'] = $id;
                    $this->Form('edit');
                    exit;
                }
            }
            $data['code'] = $code;
        }
        $bouquets = $intro->input->post('bouquets');
        $data['bouquets'] = implode(',', $bouquets);
        $data['fullname'] = $intro->input->post('fullname');
        $data['mac'] = trim($intro->input->post('mac'));
        $data['serial'] = trim($intro->input->post('serial'));
        $data['forced_country'] = trim($intro->input->post('forced_country'));
        $data['mobile'] = trim($intro->input->post('mobile'));
        $data['notes'] = trim($intro->input->post('notes'));
        $data['islam_pkg'] = intval($intro->input->post('islam_pkg'));
        $data['output'] = trim($intro->input->post('output'));
        $data['groupID'] = intval($intro->input->post('groupID'));
        $id = intval($intro->input->post('id'));
        $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id . ' ' . $this->qry_admin);
        $dataU = [];
        $dataU['bouquet'] = '[' . implode(',', $bouquets) . ']';
        $dataU['forced_country'] = $data['forced_country'];
        if ($old_code != $code) {
            $dataU['username'] = $code;
            $code = $old_code;
        }
        if ($this->admin['level'] == 1) {
            $dataU['allowed_ua'] = $this->allowed_uagent($allowed_uagent, 'save');
        }
        if (intval($row['status']) != 0) {
            if ($row['inputBy'] == 0) {
                $intro->db->update('users', $dataU, 'username=\'' . $code . '\'');
            }
            if ($row['inputBy'] == 1 || $row['inputBy'] == 2) {
                $intro->db->update('users', $dataU, 'username=\'' . $row['username'] . '\'');
            }
        }
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $db = intval($intro->input->get_post('db'));
        $code = trim($intro->input->get_post('code'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('SELECT id,username,userid FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $username = $row['username'];
        $userid = intval($row['userid']);
        if (intval($row['id']) == 0) {
            echo '<h1>Not authorized!</h1>';
        }
        if ($this->admin['level'] == 1 || $this->admin['can_delete'] == 1) {
            if ($db == 1) {
                $intro->db->query('delete from ' . PREFIX . ('_codes WHERE id=' . $id . ' '));
                $intro->db->query('delete from users WHERE id=' . $userid . ' ');
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Code deleted form database forever!', 'success');
                echo "<script>\r\n\t\t\t\t\t\$(function () {\r\n\t\t\t\t\t   setTimeout(function()\r\n\t\t\t\t\t   {\r\n\t\t\t\t\t\t\t\$('#m3u-modal').modal('hide');\r\n\t\t\t\t\t\t\t\$('#tr_" . $id . "').fadeOut();\r\n\t\t\t\t\t   }, 1000);\r\n\t\t\t\t\t   \r\n\t\t\t\t\t});</script>";
            } else {
                $sql = $intro->db->query('UPDATE ' . PREFIX . ('_codes SET status=3 WHERE id=' . $id . ' '));
                $sql = $intro->db->query('UPDATE users SET enabled=0 WHERE username=\'' . ($username != '' ? $username : $code) . '\'; ');
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Marked as Delete OK.', 'success');
                echo "<script>\r\n\t\t\t\t\$(function () {\r\n\t\t\t\t   setTimeout(function()\r\n\t\t\t\t   {\r\n\t\t\t\t\t\t\$('#m3u-modal').modal('hide');\r\n\t\t\t\t\t\t\$('#tr_" . $id . "').fadeOut();\r\n\t\t\t\t   }, 1000);\r\n\t\t\t\t   \r\n\t\t\t\t});</script>";
            }
        } else {
            echo '<h1>Not authorized!</h1>';
        }
    }
    public function allMacSn($type)
    {
        global $intro;
        $type = intval($type);
        $html = '<select name="allMacSnCodes" id="allMacSnCodes">';
        $html .= '<option value=""> New - Or chose from existing ... </option>';
        $sql = $intro->db->query('SELECT DISTINCT(code) FROM ' . PREFIX . ('_codes where inputBy=' . $type . ';'));
        while ($row = $intro->db->fetch_assoc($sql)) {
            $html .= '<option value="' . $row['code'] . '">' . $row['code'] . '</option>';
        }
        return $html . '</select>';
    }
    public function FormSerialMac()
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $bonus_days;
        global $forced_country;
        global $bouquets;
        global $allowed_uagent;
        if ($_GET != null) {
            @extract($_GET);
        }
        if ($error || $_POST != null) {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = trim($intro->input->get_post('t'));
        if ($t == 'serial') {
            $btn['legend_name'] = 'Add Codes By Serials';
            $btn['name'] = 'Add Serials';
            $input_type = 2;
            $txtadd = '<span class=\'big green\'>Serials</span>';
        } elseif ($t == 'mac') {
            $btn['legend_name'] = 'Add Codes By MACs';
            $btn['name'] = 'Add MACs';
            $input_type = 1;
            $txtadd = '<span class=\'big green\'>MACs</span>';
        }
        $this->nav();
        $_SESSION['_token'] = uniqid();
        $btn['legend_img'] = 'icon-plus-squared';
        $btn['img'] = 'add_16.png';
        $btn['action'] = 'doAddSerialMac';
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22(' <icon class="' . $btn['legend_img'] . '"></icon> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t\t\r\n\t\t\t<form class=\"form-inline\" method=\"POST\" name=\"form_add\"  action=\"" . $this->base . "/doAddSerialMac\" enctype=\"multipart/form-data\">\r\n\t\t\t" . _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911() . ("\r\n\t\t\t<table align=\"center\" border=\"1\" width=\"100%\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\" class=\"table table-striped table-hover table-bordered\">\r\n\t\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t <td>\r\n\t\t\t\t\tPaste  " . $txtadd . " <br/>\r\n\t\t\t\t\teach one in single line <font color=red>*</font><br/>\r\n\t\t\t\t\t" . $this->error('all_data') . "\r\n\t\t\t\t </td>\r\n\t\t\t\t <td><textarea class=\"form-control\" dir=ltr name=\"all_data\" cols=\"60\" rows=\"10\">") . $intro->input->post('all_data') . ("</textarea> </td>\r\n\t\t\t </tr>\r\n\t\t\t<tr>\r\n\t\t\t\t <td>Master Code " . $txtadd . " :  <font color=red>*</font></td>\r\n\t\t\t\t <td class='danger'><input class=\"form-control big\" type=\"text\" name=\"code_for_all\" value=\"") . $intro->input->get_post('code_for_all') . "\" size=\"30\" maxlength=\"16\" style='font-size:18px'/> \r\n\t\t\t\t " . $this->allMacSn($input_type) . (':  by ' . $txtadd . "  \r\n\t\t\t\t \r\n\t\t\t\t  (this code will be used by end users.)\r\n\t\t\t\t \r\n\t\t\t\t " . $this->error('code_for_all') . "</td>\r\n\t\t\t</tr>\r\n\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Username Prefix: <font color=red>*</font> </td>\r\n\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"username_prefix\" value=\"") . $intro->input->post('username_prefix') . ("\" size=\"20\" maxlength=\"15\" />\r\n\t\t\t\t<br> username prefix like: userxx, loremuser, mystbmodle any valid username \r\n\t\t\t\t<br> if you type: userxx it will be:  userxx0001 to userxx0100 \r\n\t\t\t\t" . $this->error('username_prefix') . "</td>\r\n\t\t\t</tr>");
        if ($this->admin['level'] == 1) {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reseller :  <span style='color:#ff0000'>*</span> " . $this->error('adminid') . "</td>\r\n\t\t\t\t<td>" . form_resellers('adminid', $intro->input->post('adminid')) . " </td>\r\n\t\t\t</tr>";
        }
        if ($this->adminRow['member_group_id'] == 0) {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>" . $intro->lang['codes_days'] . (' :  <span style=\'color:#ff0000\'>*</span> ' . $this->error('period') . "</td>\r\n\t\t\t\t<td>\r\n\t\t\t\t\t") . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', _obf_0D322A5B141A102E2824032B03230A35140306272F2F11(), $intro->input->post('period')) . "  \r\n\t\t\t\t\t<span id=\"span_free_days\" style=\"display:none\">Free Extra Days: <input  type=\"number\" name=\"free_days\" value=\"" . $intro->input->post('free_days') . "\" min=\"1\" class=\"form-control\" size=\"10\"></span>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "\r\n\t\t\t<tr>\r\n                 <td>Trans Name : " . $this->error('tname') . "</td>\r\n                 <td><input class=\"form-control\" type=\"text\" class=big name=\"tname\" value=\"" . $intro->input->post('tname') . '" size="40" placeholder="give these ' . strip_tags($txtadd) . (" a refrence name.\">\r\n\t\t\t\t\ttype refrence name for these " . $txtadd . " like: codes for ali/hassan me ... </td>\r\n             </tr>");
        if ($this->adminRow['member_group_id'] > 0) {
            $pkg = new Packages($this->adminRow);
            $intro->member_group_id = $this->adminRow['member_group_id'];
            $intro->code_pkg = $pkg;
            echo "\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Package: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t\t<td>";
            echo $pkg->FormDropDown();
            echo ' ' . $this->error('period') . "\r\n\t\t\t\t\t</td>\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Bouquets:  <span style='color:#ff0000'>*</span>\r\n\t\t\t\t\t\t<div style=\"float:right;\">\r\n\t\t\t\t\t\t\t   <input type=\"checkbox\" id=\"checkAll\"/> <b>Check All</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</td>\r\n\t\t\t\t\t<td> " . $this->error('bouquets') . " <div id='bouquets_result'></div></td>\r\n\t\t\t\t</tr>";
        } else {
            echo "<tr>\r\n\t\t\t\t<td>Bouquets:  <span style='color:#ff0000'>*</span>\r\n\t\t\t\t\r\n\t\t\t\t<div style=\"float:right;\">\r\n\t\t\t\t\t\t   <input type=\"checkbox\" id=\"checkAll\"/> <b>Check All</b>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\r\n\t\t\t\t<td> " . $this->error('bouquets') . ' ' . bouquets($bouquets) . " </td>\r\n\t\t\t</tr>";
        }
        echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Override General Country Restriction:  </td>\r\n\t\t\t\t<td> " . forced_country($forced_country) . (" </td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Allowed User Agent :</td>\r\n\t\t\t\t<td><input  type=\"text\" name=\"allowed_uagent\" value=\"" . $allowed_uagent . '" size="30"> ' . $this->error('allowed_uagent') . " <i>(Allowed User Agents to use this account [Default all allowed])</i></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td>\r\n\t\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"input_type\"  value=\"" . $input_type . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"_token\"  value=\"" . $_SESSION['_token'] . "\">\r\n\t\t\t\t\t<button class=\"btn btn-success btn-lg\" type=\"submit\" name=\"app_action\" value=\"doAddSerialMac\" title=\"" . $btn['name'] . "\">\r\n\t\t\t\t\t " . $btn['name'] . " \r\n\t\t\t\t\t</button>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$(document).ready(function(){\r\n\t\t\t\r\n\t\t\t\$(\"select[name='package']\").change(function () {\r\n\t\t\t\t\r\n\t\t\t\tvar package = \$(this).val();\r\n\t\t\t\t\r\n\t\t\t\t\$.post(\"" . $intro->app_url('renew', 'getBouquets') . "/?NH=1\", \r\n\t\t\t\t\t{package:package}, function(data,status,xhr){\t\r\n\t\t\t\t\t\$(\"#bouquets_result\").html(data);\r\n\t\t\t\t\t\r\n\t\t\t\t\t\$(\"#UsersBouquets\").find(':checkbox').prop('checked', true);\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$(\"#checkAll\").change(function () {\r\n\t\t\t\t\$(\"input:checkbox\").prop('checked', \$(this).prop(\"checked\"));\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$(\"select[name=allMacSnCodes]\").change(function () {\r\n\t\t\t\t\r\n\t\t\t\tvar code4all = \$(this).val();\r\n\t\t\t\t\$(\"input[name='code_for_all']\").val(code4all);\r\n\t\t\t\t\r\n\t\t\t});\r\n\t\t\t\$(\"select[name=period]\").change(function () {\r\n\t\t\t\t\r\n\t\t\t\tvar groupName = \$(this).val();\r\n\t\t\t\t\r\n\t\t\t\tif(groupName < 100 && groupName >= 1){\r\n\t\t\t\t\t\$('#span_free_days').show();\r\n\t\t\t\t\t\r\n\t\t\t\t}else{\r\n\t\t\t\t\t\$('#span_free_days').hide();\r\n\t\t\t\t}\r\n\t\t\t});\r\n\t\t\t";
        if (intval($intro->input->post('period')) >= 1 && intval($intro->input->post('period')) < 100) {
            echo "\$('#span_free_days').show();\n";
        } else {
            echo "\$('#span_free_days').hide();\n";
        }
        echo "\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function doAddSerialMac()
    {
        global $intro;
        global $error;
        global $array;
        @set_time_limit(0);
        @ignore_user_abort(true);
        $all_data = trim($_POST['all_data']);
        $code_for_all = trim($_POST['code_for_all']);
        $username_prefix = trim($_POST['username_prefix']);
        $adminid = intval($intro->input->post('adminid'));
        $period = intval($intro->input->post('period'));
        $free_days = intval($intro->input->post('free_days'));
        $bonus_days = intval($intro->input->post('bonus_days'));
        $t = trim($intro->input->post('t'));
        $input_type = intval($intro->input->post('input_type'));
        $bouquets = $intro->input->post('bouquets');
        $forced_country = trim($intro->input->post('forced_country'));
        $tname = trim($intro->input->post('tname'));
        $allowed_uagent = trim($intro->input->post('allowed_uagent'));
        $package = intval($intro->input->post('package'));
        $all_data = explode("\n", $all_data);
        $num_codes = count($all_data);
        if ($bouquets == null || $all_data == '' || $code_for_all == '' || $username_prefix == '' || $period == 0 && $package == 0 || $this->admin['level'] == 1 && $adminid == 0) {
            if ($bouquets == null) {
                $error['bouquets'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if ($all_data == '') {
                $error['all_data'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if ($code_for_all == '') {
                $error['code_for_all'] = '<br/><span class=error>' . $intro->lang['required'] . '</span>';
            }
            if ($username_prefix == '') {
                $error['username_prefix'] = '<br/><span class=error>' . $intro->lang['required'] . '</span>';
            }
            if ($period == 0 && $package == 0) {
                $error['period'] = '<span class=error>' . $intro->lang['required'] . ' And don\'t use Free.</span>';
            }
            if ($this->admin['level'] == 1 && $adminid == 0) {
                $error['adminid'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Error: please fill in required fields.', 'danger');
            $this->FormSerialMac();
            exit;
        }
        if (preg_match('/[^A-Za-z0-9]/', $username_prefix)) {
            $error['username_prefix'] = '<span class=error>Error: Only English Letters with numbers is Allowed.</span>';
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Error: please fill in required fields.', 'danger');
            $this->FormSerialMac();
            exit;
        }
        $dupSql = 0;
        if ($t == 'serial') {
            $dbField = 'serial';
            $inputBy = 2;
            $dupSql = 1;
        }
        if ($t == 'mac') {
            $dbField = 'mac';
            $inputBy = 1;
            $dupSql = 2;
        }
        $sql = $intro->db->query_fast('select id from ' . PREFIX . '_codes where ' . (' code=\'' . $code_for_all . '\' AND inputBy=' . $dupSql . ' LIMIT 1;'));
        if (mysqli_num_rows($sql) == 1) {
            $error['code_for_all'] = '<br/><span class=error>Error: you can\'t use the code <b>' . $code_for_all . "</b> \r\n\t\t\t\tfor both MACs and Serials. Don't use the same code for both MAC & Serial. You must use diffrent codes. </span>";
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Error: please fill in required fields.', 'danger');
            $this->FormSerialMac();
            exit;
        }
        $sqlM = $intro->db->query('SELECT master_code from ' . PREFIX . '_codes_master ' . (' WHERE master_code=\'' . $code_for_all . '\' AND master_by=' . $inputBy . ';'));
        if (mysqli_num_rows($sqlM) == 0) {
            $intro->db->insert(PREFIX . '_codes_master', ['master_code' => $code_for_all, 'master_by' => $inputBy], true);
        }
        $days = $period * 30;
        if (in_array($period, $array['free'])) {
            $dd = $period - 100;
            $days = $dd;
        } else {
            $days = $period * 30;
        }
        if ($this->admin['level'] != 1) {
            $adminid = $this->admin['adminid'];
        }
        if ($package > 0) {
            $pkg = _obf_0D0E122A21280A14271F3B1D1727291E290A0A2A092E11($package);
        }
        $totalinvoices = 0;
        if ($this->admin['level'] != 1 && !in_array($period, $array['free']) || $package > 0) {
            $p = new IntroPerms('CheckCost', $this->adminRow, $num_codes, $period, $package);
            if ($p->error != '') {
                _obf_0D103C08311F24242D2F281F0B3E28333032320A031011($p->error, 'danger');
                $this->FormSerialMac('add');
                exit;
            }
        }
        $tData = ['trans_name' => $tname, 'trans_codes' => 0, 'trans_period' => $period, 'trans_free_days' => $free_days, 'trans_date' => time(), 'trans_codes_length' => 0, 'adminid' => $adminid];
        if ($num_codes > 1) {
            $intro->db->insert(PREFIX . '_codes_trans', $tData);
            $transid = intval($intro->db->insert_id());
            if (intval($transid) == 0) {
                exit('unknown transID, cannot insert trans.');
            }
        } else {
            $transid = 0;
        }
        $trans_id = $transid;
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22(' Result ');
        $num = 0;
        $allInvData = '';
        for ($i = 0; $i < $num_codes; $i++) {
            $the_data = preg_replace("/[\n\r]/", '', $all_data[$i]);
            $the_data = trim($the_data);
            if ($the_data == '') {
            } else {
                $sql = $intro->db->query_fast('select ' . $dbField . ' from ' . PREFIX . '_codes where ' . (' inputBy=' . $inputBy . ' AND code=\'' . $code_for_all . '\' AND ' . $dbField . '=\'' . $the_data . '\';'));
                if (mysqli_num_rows($sql) == 0) {
                    $num++;
                    $username = $username_prefix . uniqid();
                    $allInvData .= $the_data . "\n";
                    $data = [];
                    $data['fullname'] = $tname;
                    $data[$dbField] = $the_data;
                    $data['code'] = $code_for_all;
                    $data['username'] = $username;
                    $data['days'] = $days;
                    $data['free_days'] = $free_days;
                    if ($package > 0) {
                        $data['period'] = $package;
                        $data['pkg'] = $package;
                        $data['is_free'] = $pkg['is_trial'];
                    } else {
                        $data['period'] = $period;
                        $data['is_free'] = in_array($period, $array['free']) ? 1 : 0;
                    }
                    $data['adminid'] = $adminid;
                    $data['transid'] = $transid;
                    $data['status'] = 0;
                    $data['last_update'] = '';
                    $data['bouquets'] = implode(',', $bouquets);
                    $data['forced_country'] = $forced_country;
                    $data['inputBy'] = $input_type;
                    $data['allowed_uagent'] = $allowed_uagent;
                    $intro->db->insert(PREFIX . '_codes', $data, true);
                    $code_id = $intro->db->insert_id();
                    $username = $username_prefix . '_' . $code_id;
                    $intro->db->query_fast('UPDATE ' . PREFIX . ('_codes set username=\'' . $username . '\' where id=' . $code_id));
                    echo '<li><span style=\'color:green\'> #[' . $num . '] user[' . $username . '] - ' . $the_data . ' : Added Ok</span> <br>';
                } else {
                    echo '<li><span style=\'color:red\'>- ' . $the_data . ':  Already Exisit on code: ' . $code_for_all . ' .</span><br>';
                }
            }
        }
        if ($package == 0) {
            if (!in_array($period, $array['free'])) {
                $inv = new IntroInvoice();
                $inv->set('adminid', $adminid);
                $inv->set('period', $period);
                $inv->set('num', $num);
                $inv->set('code_trans', $transid);
                $inv->set('all_data', $allInvData);
                $inv->set('userid', 0);
                $inv->set('notes', 'Add ' . $num . ' ' . $t . ' on code: ' . $code_for_all);
                $inv->Save();
            }
        } else {
            $inv = new IntroInvoice();
            $inv->set('isPackage', true);
            $inv->set('adminid', $adminid);
            $inv->set('package', $package);
            $inv->set('period', $package);
            $inv->set('num', $num);
            $inv->set('code_trans', $transid);
            $inv->set('all_data', $allInvData);
            $inv->set('userid', 0);
            $inv->set('notes', 'Add ' . $num . ' ' . $t . ' on code: ' . $code_for_all);
            $inv->Save();
        }
        echo '<h3>Total Success Records: ' . $num . ' </h3>';
        echo '<h3>Total Cost: ' . $inv->inv_total_cost . '</h3>';
        $intro->db->query('UPDATE ' . PREFIX . ('_codes_trans set trans_codes=' . $num . ' where trans_id=' . $trans_id . ';'));
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function Report()
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22(' <icon class="icon-list-alt"></icon> Report ', 'info');
        echo "<style>td,th{text-align:center;}</style>\r\n\t\t\t<table align=\"center\" border=\"1\" width=\"100%\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\" class=\"table table-striped table-hover table-bordered\">\r\n\t\t\t<thead>\r\n\t\t\t<tr>\r\n\t\t\t\t <th>Period</th>\r\n\t\t\t\t <th>New</th>\r\n\t\t\t\t <th>Active</th>\r\n\t\t\t\t <th>Suspended</th>\r\n\t\t\t\t <th>Deleted</th>\r\n\t\t\t\t <th>Expired</th>\r\n\t\t\t\t <th>Sub Total</th>\r\n\t\t\t </tr>\r\n\t\t\t </thead>\r\n\t\t\t <tbody>";
        $tot = [];
        $tot['tot_row'] = 0;
        $tot['row'] = $tot['tot_row'];
        $tot['tot4'] = $tot['row'];
        $tot['tot3'] = $tot['tot4'];
        $tot['tot2'] = $tot['tot3'];
        $tot['tot1'] = $tot['tot2'];
        $tot['tot0'] = $tot['tot1'];
        foreach ($array['period'] as $key => $val) {
            $period = intval($key);
            if (in_array($period, $array['free'])) {
                $pp = $period - 100 . ' Free Day(s)';
            } else {
                $pp = $period . ' Month(s)';
            }
            $sql = $intro->db->query_fast('SELECT(SELECT count(id) FROM ' . PREFIX . ('_codes WHERE `period`=' . $period . ' AND `status`=0 ' . $this->qry_admin . ') as tot0') . ',(SELECT count(id) FROM ' . PREFIX . ('_codes WHERE `period`=' . $period . ' AND `status`=1 ' . $this->qry_admin . ') as tot1') . ',(SELECT count(id) FROM ' . PREFIX . ('_codes WHERE `period`=' . $period . ' AND `status`=2 ' . $this->qry_admin . ') as tot2') . ',(SELECT count(id) FROM ' . PREFIX . ('_codes WHERE `period`=' . $period . ' AND `status`=3 ' . $this->qry_admin . ') as tot3') . ',(SELECT count(id) FROM ' . PREFIX . ('_codes WHERE `period`=' . $period . ' AND `status`=4 ' . $this->qry_admin . ') as tot4'));
            $row = $intro->db->fetch_assoc($sql);
            extract($row);
            $tot['row'] = $tot0 + $tot1 + $tot2 + $tot3 + $tot4;
            $tot['tot_row'] += $tot['row'];
            echo "\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t <td>" . $pp . "</td>\r\n\t\t\t\t\t <td>" . money($tot0) . "</td>\r\n\t\t\t\t\t <td>" . money($tot1) . "</td>\r\n\t\t\t\t\t <td>" . money($tot2) . "</td>\r\n\t\t\t\t\t <td>" . money($tot3) . "</td>\r\n\t\t\t\t\t <td>" . money($tot4) . "</td>\r\n\t\t\t\t\t <th>" . money($tot['row']) . "</th>\r\n\t\t\t\t </tr>";
            $tot['tot0'] += $tot0;
            $tot['tot1'] += $tot1;
            $tot['tot2'] += $tot2;
            $tot['tot3'] += $tot3;
            $tot['tot4'] += $tot4;
        }
        echo "\r\n\t\t\t </tbody>\t\r\n\t\t\t <tfooter>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t <th> Total: </td>\r\n\t\t\t\t\t <th>" . money($tot['tot0']) . "</th>\r\n\t\t\t\t\t <th>" . money($tot['tot1']) . "</th>\r\n\t\t\t\t\t <th>" . money($tot['tot2']) . "</th>\r\n\t\t\t\t\t <th>" . money($tot['tot3']) . "</th>\r\n\t\t\t\t\t <th>" . money($tot['tot4']) . "</th>\r\n\t\t\t\t\t <td style='color:#fff;background:#ff0000'>" . money($tot['tot_row']) . "</td>\r\n\t\t\t\t </tr>\r\n\t\t\t </tfooter>\r\n\t\t\t </table>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function export_mac()
    {
        global $intro;
        echo '<textarea style=\'width:100%;height:400px;\'>';
        $sql = $intro->db->query_fast('select DISTINCT(mac) from ' . PREFIX . '_codes order by id asc;');
        while ($row = $intro->db->fetch_assoc($sql)) {
            echo $row['mac'] . "\n";
        }
        echo '</textarea>';
    }
    public function master()
    {
        global $intro;
        $sql = $intro->db->query('SELECT DISTINCT(code) FROM ' . PREFIX . '_codes where inputBy=1;');
        while ($row = $intro->db->fetch_assoc($sql)) {
            $data = [];
            $data['master_code'] = trim($row['code']);
            $data['master_by'] = 1;
            $intro->db->insert(PREFIX . '_codes_master', $data, true);
            echo '<li>1 = ' . trim($row['code']) . '<li>';
        }
        $sql = $intro->db->query('SELECT DISTINCT(code) FROM ' . PREFIX . '_codes where inputBy=2;');
        while ($row = $intro->db->fetch_assoc($sql)) {
            $data = [];
            $data['master_code'] = trim($row['code']);
            $data['master_by'] = 2;
            $intro->db->insert(PREFIX . '_codes_master', $data, true);
            echo '<li>2 = ' . trim($row['code']) . '<li>';
        }
    }
    public function CodeChange()
    {
        global $intro;
        global $array;
        $qry = $params = '';
        $page = intval($intro->input->get_post('page'));
        $code = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('code'));
        $order = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('order'), ':');
        $this->nav();
        if ($code != '') {
            $qry .= ' AND ( old_code  LIKE \'%' . $code . '%\' OR new_code  LIKE \'%' . $code . '%\')';
            $params .= '&code=' . $code;
        }
        if ($this->admin['level'] == 1) {
            $this->qry_admin = '';
        } else {
            $adm = intval($this->admin['adminid']);
            $this->qry_admin = ' AND ( reseller=' . $adm . ' OR reseller IN (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adm . ' OR main_father=' . $adm . '))');
        }
        if ($order == '') {
            $order = 'id_desc';
        }
        $order = str_replace('_desc', ' desc', $order);
        $order = str_replace('_asc', ' asc', $order);
        $rows_per_page = '50';
        if ($page == 0) {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_codes_change WHERE true  ' . $this->qry_admin . ' ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $resultnumm = $intro->db->query('SELECT id from ' . PREFIX . ('_codes_change WHERE true  ' . $this->qry_admin . ' ' . $qry));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<span class=\'icon-exchange\'></span> Change Codes History (' . $totalrows . ')', 'primary');
        echo "<fieldset>\r\n\t\t<form action=\"\" method=\"post\" class=''>\r\n\t\t\t<input type=\"text\" name=\"code\" value=\"" . $code . "\" size=\"30\" placeholder=\"Code\">\t\r\n\t\t\t<input  name=\"name\" value=\"Search\" type=\"submit\">\r\n\t\t</form>\r\n\t\t</fieldset>";
        echo "\r\n\t\t<table class=\"table table-condensed table-bordered table-hover\">\r\n            <tr>\r\n\t\t\t\t<th>ID</th>\r\n\t\t\t\t<th>Code ID</th>\r\n\t\t\t\t\r\n\t\t\t\t<th>Date</th>\r\n\t\t\t\t<th>Ago</th>\r\n\t\t\t\t<th>Resel</th>\r\n\t\t\t\t\r\n\t\t\t\t<th>Old Code</th>\r\n\t\t\t\t<th>New Code</th>\r\n\t    </tr>";
        $i = 0;
        while ($myrow = $intro->db->fetch_assoc($result)) {
            @extract($myrow);
            $i++;
            $old_code = str_replace((string) $code, '<span style=\'background:#ffff00;\'>' . $code . '</span>', $old_code);
            $new_code = str_replace((string) $code, '<span style=\'background:#ffff00;\'>' . $code . '</span>', $new_code);
            echo "<tr>\r\n\t\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t\t<td class=\"center\">" . $code_id . "</td>\r\n\t\t\t\t\t\r\n\t\t\t\t\t<td class=\"center\">" . $dtime . "</td>\r\n\t\t\t\t\t<td class=\"center\">" . _obf_0D10361F073B102D294032060E21400727331210083132(strtotime($dtime)) . ("</td>\r\n\t\t\t\t\t<td class=\"center\">" . $array['admins'][$reseller] . "</td>\r\n                     <td class=\"center\">" . $old_code . "</td>\r\n                     <td class=\"center\">" . $new_code . "</td>   \r\n\t\t </tr>");
        }
        echo '</table>';
        $order = str_replace(' desc', '_desc', $order);
        $order = str_replace(' asc', '_asc', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411(_obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/CodeChange?order=' . $order . $params, $totalrows, $rows_per_page, $page));
    }
}