<?php 
class Pages_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        if( !in_array($this->admin['level'], [
            1, 
            9
        ]) ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\"> Pages </icon></a> \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        $sql = $intro->db->query('select * from ' . PREFIX . '_options');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $op_name = trim($row['name']);
            $options[$op_name] = trim($row['val']);
        }
        $btn['legend_name'] = 'Edit';
        $btn['legend_icon'] = 'icon-edit';
        $btn['name'] = ' Save ';
        $btn['img_icon'] = 'icon-floppy';
        $btn['action'] = 'doEdit';
        echo "\r\n\t\t<div class=\"forms\">\t\r\n\t\t\t<fieldset>\r\n\t\t\t\t<legend>\r\n\t\t\t\t\t<i class=\"" . $btn['legend_icon'] . "\"></i> Edit Pages\r\n\t\t\t\t</legend>\r\n\t\t\t<div>Note: HTML is allowed</div><br/>\r\n\t\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t\t<table cellspacing=\"2\" style=\"margin:auto;width:95%\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td> About Page</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td><textarea style='width:100%;height:250px' name=\"about\">" . stripslashes($options['about']) . "</textarea>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td> Help Page</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td><textarea style='width:100%;height:250px'name=\"help\">" . stripslashes($options['help']) . ("</textarea>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td colspan=\"2\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success\" name=\"app_action\" value=\"doEdit\"><i class=\"icon-floppy\"> </i> " . $btn['name'] . "</button>\t\t\t\t\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t\t</form>\r\n\t\t\t</fieldset>\r\n\t\t</div>");
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $about = addslashes($intro->input->post('about'));
        $help = addslashes($intro->input->post('help'));
        $intro->db->update(PREFIX . '_options', ['val' => $about], 'name=\'about\'');
        $intro->db->update(PREFIX . '_options', ['val' => $help], 'name=\'help\'');
        $intro->redirect($this->appname);
    }
}
