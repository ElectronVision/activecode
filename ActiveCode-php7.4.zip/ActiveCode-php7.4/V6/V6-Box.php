<?php 
include('./API-V6.php');
exit();