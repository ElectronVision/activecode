function launch_toast() {
    var x = document.getElementById("toast")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}

$(document).ready(function() {
	$('.DataTables').DataTable();

	$(".searchable").addClass('chosen').chosen({search_contains: true});
	
	$( "#UsersBouquets>tbody" ).sortable();
	
});	
function IntroFilterInput(inputID,divID) {
				
  var input, filter, ul, li, a, i;
  input = document.getElementById(inputID);
  filter = input.value.toUpperCase();
  div = document.getElementById(divID);
  a = div.getElementsByTagName("li");
  for (i = 0; i < a.length; i++) {
	  
	txtValue = a[i].textContent || a[i].innerText;
	if (txtValue.toUpperCase().indexOf(filter) > -1) {
	  a[i].style.display = "";
	} else {
	  a[i].style.display = "none";
	}
  }
} 
$(document).on('click', '.AjaxModal', function(e){
	e.preventDefault();
	
	var spinner = "<center><span class='icon-spin5 animate-spin' style='font-size:30px;color:blue'></span></center>";
	$("#m3u-modal .modal-body").html(spinner);
	$("#m3u-modal .modal-body").load( $(this).attr('href') + "&NH=1" );
	$("#m3u-modal").modal("show");
	
	return false;

});	
$(document).on('click', '#btnAddMagStb', function(e){
	e.preventDefault();
	
	var newStb = $("#inputAddMagStb").val();
	if(newStb.length < 5) return;
	$("#allowed_stb_types").prepend("<option value='"+newStb+"' selected='selected'>"+newStb+"</option>").trigger('chosen:updated');
	$("#inputAddMagStb").val('');
	alert('Add Success');

});	

$(document).on('click', '.AjaxConfirm', function(e){
	var link = this;
	var link_tr = $(this).closest('tr');
	e.preventDefault();
	$.confirm({
		text: "Are you sure you?",
		title: "Confirmation required",
		confirm: function(button) {
			$.get( link.href +'&NH=1', function( data ) {						
				
				$.each(data, function(key, value) {
					  $("#"+key).html(value);
				});
			});
			return false;
		},
		cancel: function(button) {
		},
		confirmButton: "Yes",
		cancelButton: "Cancel",
		post: true,
		confirmButtonClass: "btn-danger",
		cancelButtonClass: "btn-default",
		dialogClass: "modal-dialog modal-lg"
	});
});	

function jsdel(url) {
    var answer = confirm("Are you sure you want to delete? this action cannot be re done.")
     if (answer){
         window.location = ""+ url +"";
     }
}

function intro_getRowNumber(a) {
    return parseInt(a.split(/row_/)[1])
}

/* count checked boxed by intro.ps*/
function countChecked() {
	//we have 2 ways using .length,  use the shortest one
	// $("[type='checkbox']:checked").length;
	$("#checked_count").html($("input:checked").length);
}

$(document).ready(function () {
	
	$('body').on('hidden.bs.modal', '.modal', function () {
		$(this).removeData('bs.modal');
	});
	/*
	$('.DataTable').dataTable({
		"pageLength": 50,
		"bSort": false,
		"bPaginate": false
	});		*/
	
	$(".numOnly").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) ||
             // Allow: Ctrl+C
            (e.keyCode == 67 && e.ctrlKey === true) ||
             // Allow: Ctrl+X
            (e.keyCode == 88 && e.ctrlKey === true) ||
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
	
	

    $(".mask_date").mask("9999-99-99");
    $(".mask_time").mask("99:99:99");
	
	/*$( ".timepicker" ).timepicker();*/
	
	$( ".date_picker" ).datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat: 'yy-mm-dd'
	});
   
	
});	
/******************************
UI delete
******************************/

$(document).ready(function() {
	$("#dialog-box").dialog({
		autoOpen: false,
		modal: true
	});

	$(".intro_ui_del").click(function(e) {
		var currentElem = $(this);
		$("#dialog-box").dialog({
		  buttons : {
			" Delete " : function() {
			  $(this).dialog("close");
			  $.get( currentElem.attr('href') +"&NH=1" , function( data ) { /*alert( data );*/ });
			  currentElem.closest('tr').fadeOut();
			},
			" Cancel " : function() {
			  $(this).dialog("close");
			}
		  }
		});

		$("#dialog-box").dialog("open");
		e.preventDefault();
		return false;
	});
	
	$(".global_ajax").click(function(e) {
		var currentElem = $(this);			
		$("#"+ currentElem.attr('data-id') ).html("<img src='"+admin_folder+"/images/loading.gif' />");			
		$.get(currentElem.attr('href'), function(data) {
			$("#"+ currentElem.attr('data-id') ).html(data);
		});			
	});
	
	$(".intro_ui_del2").click(function(e) {
		var currentElem = $(this);
		$("#dialog-box").dialog({
		  buttons : {
			" Unfeatured " : function() {
			  $(this).dialog("close");
			  $.get( currentElem.attr('href') +"&NH=1" , function( data ) { /*alert( data );*/ });
			  currentElem.closest('tr').fadeOut();
			},
			" Cancel " : function() {
			  $(this).dialog("close");
			}
		  }
		});

		$("#dialog-box").dialog("open");
		e.preventDefault();
		return false;
	});
	
	$(".confirmReset").on("click", function(e) {
		var link = this;

		e.preventDefault();

		$.confirm({
			text: "Are you sure you want Reset Code?",
			title: "Confirmation required",
			confirm: function(button) {
				
				$.get( link.href +'&NH=1', function( data ) {						
				  alert( data);
				});
				return false;
			},
			cancel: function(button) {
				// nothing to do
			},
			confirmButton: "Yes",
			cancelButton: "Cancel",
			post: true,
			confirmButtonClass: "btn-danger",
			cancelButtonClass: "btn-default",
			dialogClass: "modal-dialog modal-lg" // Bootstrap classes for large modal
		});
	});/*confirmReset*/
	
	
		
});

