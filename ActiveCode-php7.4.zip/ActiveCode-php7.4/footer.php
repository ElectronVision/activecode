<?php 
echo "\n\t<div class=\"clear\"></div>\n\t</div><!-- End Contents -->\n\t<div class=\"clear\"></div>\n\t<div id=\"footer\">\n\t\t<br/>\n\t\t<br/>\n\t\n\t\t<hr/>\n\t\t<div class=\"row text-center\">\n\t\t";
global $intro;
if( isset($intro->option['hide_introtech_copy']) && $intro->option['hide_introtech_copy'] == 1 ) 
{
    if( isset($intro->option['copyright']) && $intro->option['copyright'] != '' ) 
    {
        echo $intro->option['copyright'];
    }
}
else
{
    echo "\n\t\t\t\t<h5 class='center'><a href='http://intro.ps/' target=_blank>" . _intro_ver . '</a></h5>';
}
echo ' Mem: <span class=\'label-success\'> ' . _obf_0D223F350731381A3F101E2F0B0536222129393F132201() . '</span>';
echo "\t\t</div>\n\t</div>\n</div><!-- End MainContainer -->\n";
global $intro;
if( $intro->option['debug'] == 1 ) 
{
    $intro->db->show_debug_console();
}
