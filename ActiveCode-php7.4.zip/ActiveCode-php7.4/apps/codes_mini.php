<?php 
class Codes_mini_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $admin = [];
    public $adminRow = [];
    public $inputBy = [
        'Code', 
        'MAC', 
        'Serial'
    ];
    public $free = [
        101, 
        103, 
        107, 
        110
    ];
    public $time = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $array;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $this->adminRow = $intro->auth->admin_data(intval($this->admin['adminid']));
        if( $this->admin['level'] == 1 || $this->admin['level'] == 5 ) 
        {
            $this->qry_admin = '';
            $this->qry_admin_where = '';
        }
        $this->time = time();
        $this->free = $array['free'];
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\">\r\n\t\t\t<icon class=\"icon-list\"> ") . $intro->lang['codes_appname'] . "</icon>\r\n\t\t</a> \r\n\t\t\r\n\t\t</div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = $params = '';
        $status = trim($intro->input->get_post('status'));
        $view = trim($intro->input->get_post('view'));
        $params .= ('&status=' . $status);
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $code = trim($intro->input->get_post('code'));
        $fullname = trim($intro->input->get_post('fullname'));
        $mac = trim($intro->input->get_post('mac'));
        $serial = trim($intro->input->get_post('serial'));
        $inputBy = trim($intro->input->get_post('inputBy'));
        $period = intval($intro->input->get_post('period'));
        $adminid = intval($intro->input->get_post('adminid'));
        $transid = trim($intro->input->get_post('transid'));
        $mobile = trim($intro->input->get_post('mobile'));
        $notes = trim($intro->input->get_post('notes'));
        $username = trim($intro->input->get_post('username'));
        $this->nav();
        if( $status != '' ) 
        {
            $qry = ' AND status=' . intval($status);
            $params .= ('&code=' . $code);
        }
        $xcode = $code;
        if( $code != '' ) 
        {
            $qry .= (' AND code  LIKE \'%' . $code . '%\' ');
            $params .= ('&code=' . $code);
        }
        if( $username != '' ) 
        {
            $qry .= (' AND username  LIKE \'' . str_replace('*', '%', $username) . '\' ');
            $params .= ('&username=' . $username);
        }
        if( $serial != '' ) 
        {
            $qry .= (' AND serial  LIKE \'%' . $serial . '%\' ');
            $params .= ('&serial=' . $serial);
        }
        if( $mac != '' ) 
        {
            $qry .= (' AND mac  LIKE \'%' . $mac . '%\' ');
            $params .= ('&mac=' . $mac);
        }
        if( $fullname != '' ) 
        {
            $qry .= (' AND fullname  LIKE \'%' . $fullname . '%\' ');
            $params .= ('&fullname=' . $fullname);
        }
        if( $inputBy != '' ) 
        {
            $qry .= (' AND inputBy=\'' . $inputBy . '\' ');
            $params .= ('&inputBy=' . $inputBy);
        }
        if( $transid != '' ) 
        {
            $qry .= (' AND transid=\'' . $transid . '\' ');
            $params .= ('&transid=' . $transid);
        }
        if( $notes != '' ) 
        {
            $qry .= (' AND notes=\'' . $notes . '\' ');
            $params .= ('&notes=' . $notes);
        }
        if( $mobile != '' ) 
        {
            $qry .= (' AND mobile=\'' . $mobile . '\' ');
            $params .= ('&mobile=' . $mobile);
        }
        if( $adminid != '' ) 
        {
            $qry .= (' AND adminid=' . $adminid . ' ');
            $params .= ('&adminid=' . $adminid);
        }
        if( $view == 'expired' ) 
        {
            $qry = ' AND date_expire <= \'' . $this->time . '\' AND status!=0';
            $params .= '&view=expired';
        }
        if( $order == '' ) 
        {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 50;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $qry_online = ',IF(status=1,(select online.activity_id from user_activity_now online, users  where online.user_id=users.id AND users.username=codes.code ORDER BY activity_id DESC LIMIT 1),\'\') as activity_id';
        $result = $intro->db->query('SELECT *' . $qry_online . ' from ' . PREFIX . '_codes codes ' . (' where true ' . $this->qry_admin . ' ' . $qry . ' order by ' . $order . ' limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from ' . PREFIX . '_codes ' . (' where true ' . $this->qry_admin . ' ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo "\r\n\t\t<fieldset>\r\n\t\t<legend><i class=\"icon-search\"></i>Search</legend>\r\n\t\t<form action=\"\" method=\"GET\">\r\n\t\t\t<table class=\"table table-bordered table-condensed\">\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Code:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"code\" value=\"" . $code . "\" size=\"20\" placeholder='code' autofocus></td>\r\n\t\t\t\t\t<td>Fullname:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"fullname\" value=\"" . $fullname . "\" size=\"15\" placeholder=Fullname></td>\r\n\t\t\t\t\t<td>Input:</td>\r\n\t\t\t\t\t<td>" . _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811('inputBy', $this->inputBy, $inputBy, 'All', '') . "</td>\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Days: </td>\r\n\t\t\t\t\t<td>" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', _obf_0D322A5B141A102E2824032B03230A35140306272F2F11(), $period, 'ALL Months') . "</td>\r\n\t\t\t\t\t<td>Rseller:</td>\r\n\t\t\t\t\t<td>" . form_resellers('adminid', $adminid, 'All Resellers') . ("</td>\r\n\t\t\t\t\t<td>TransID</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"transid\" value=\"" . $transid . "\" size=\"15\" placeholder=TransID></td>\r\n\t\t\t\t\t\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>MAC:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"mac\" value=\"" . $mac . "\" size=\"15\" placeholder=MAC></td>\r\n\t\t\t\t\t<td>Serial:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"serial\" value=\"" . $serial . "\" size=\"15\" placeholder=Serial></td>\r\n\t\t\t\t\t<td>Username:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"username\" value=\"" . $username . "\" size=\"15\" placeholder='Username (use * for wildcards)'></td>\r\n\t\t\t\t\t\r\n\t\t\t\t\t<!--<td>Status:</td>\r\n\t\t\t\t\t<td>") . _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811('status', $intro->status, -1) . ("</td>-->\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>Mobile:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"mobile\" value=\"" . $mobile . "\" size=\"20\" placeholder='Mobile'></td>\r\n\t\t\t\t\t<td>Notes:</td>\r\n\t\t\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"notes\" value=\"" . $notes . "\" size=\"20\" placeholder=Notes></td>\r\n\t\t\t\t\t<td><input type=\"submit\" class=\"btn btn-success\" value=\" Search! \" class='btn btn-default'></td>\r\n\t\t\t\t\t<td></td>\r\n\t\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t\t<input type=\"hidden\" name=\"status\" value=\"" . $status . "\">\r\n\t\t</form>\r\n\t\t</fieldset>");
        if( $qry == '' ) 
        {
            exit( '' );
        }
        echo "\r\n\t\t<fieldset><legend><i class=\"icon-list\"></i> " . $intro->lang['codes_cur'] . (' (' . $totalrows . ")</legend>\r\n\t\t") . (($intro->input->get('msg') == 'renew_success' ? _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Code [' . $code . '] Renew Success!', 'success') : '')) . "\r\n\t\t" . (($intro->input->get('msg') == 'renew_fail' ? _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Failed: ' . $intro->input->get('fail'), 'danger') : '')) . "\r\n\t\t<table class=\"DataTable table-striped table-bordered table-condensed\" id=\"table_codes\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['codes_fullname'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('fullname', 'index') . " </th>\r\n\t\t\t<th> </th>\r\n\t\t\t<th>" . $intro->lang['codes_code'] . '  </th>';
        if( $username != '' ) 
        {
            echo '<th>Username</th>';
        }
        echo "\r\n\t\t\t<th>" . $intro->lang['codes_days'] . " </th>\r\n\t\t\t<th>Rseller  </th>\r\n\t\t\t<th>" . $intro->lang['codes_transid'] . " </th>\r\n\t\t\t<th>" . $intro->lang['codes_status'] . "  </th>\r\n\t\t\t<th>MAC </th>\r\n\t\t\t<th>Serial</th>\r\n\t\t\t<th>Start</th>\r\n\t\t\t<th>Expire</th>\r\n\t\t\t<th>Input</th>\r\n\t\t\t<th>Options</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        $mac = $serial = $activity_id = '';
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $code_replaced = $myrow['code_replaced'];
            if( $status == 0 ) 
            {
                $label = 'default';
            }
            else if( $status == 1 ) 
            {
                $label = 'success';
            }
            else if( $status == 2 ) 
            {
                $label = 'info';
            }
            else if( $status == 3 ) 
            {
                $label = 'danger';
            }
            else if( $status == 4 ) 
            {
                $label = 'default';
            }
            else if( $status == 5 ) 
            {
                $label = 'warning';
            }
            else
            {
                $label = 'danger';
            }
            $date_expire = ($date_expire != '' ? @date('Y-m-d', $date_expire) : '-');
            $date_start = ($date_start != '' && $date_start != 0 ? @date('Y-m-d', $date_start) : '-');
            if( $activity_id != '' ) 
            {
                $online = '<icon class="icon-globe" style=\'color:green;\'></icon>';
            }
            else
            {
                $online = '<icon class="icon-globe" style=\'color:red;\'></icon>';
            }
            if( in_array($period, $array['free']) ) 
            {
                $pp = ($period - 100) . ' Free Day(s)';
            }
            else
            {
                $pp = $period . ' Month(s)';
                if( $free_days > 0 ) 
                {
                    $pp = $period . 'M + ' . $free_days . 'D';
                }
            }
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='c'>" . $id . "</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='c'>" . $online . "</td>\r\n\t\t\t\t<td class='c'>" . $code . '</td>';
            if( $intro->input->get_post('username') != '' ) 
            {
                echo '<td>' . $username . '</td>';
            }
            echo '<td class=\'c\'>' . $pp . "</td>\r\n\t\t\t\t<td class='c'>" . $array['admins'][$adminid] . ("</td>\r\n\t\t\t\t<td class='c'>" . $transid . "</td>\r\n\t\t\t\t<td  class='c' id=\"status_" . $id . "\">\r\n\t\t\t\t\t<span class='label label-" . $label . "'>\r\n\t\t\t\t\t\t" . $intro->status[$status] . " \r\n\t\t\t\t\t\t") . (($code_replaced != '' ? '<br/>' . $code_replaced : '')) . ("\r\n\t\t\t\t\t</span>\r\n\t\t\t\t</td>\r\n\t\t\t\t<td class='c' id=\"mac_" . $id . '">' . $mac . "</td>\r\n\t\t\t\t<td class='c' id=\"sn_" . $id . '">' . $serial . "</td>\r\n\t\t\t\t<td class='c'><span class=\"editExpireDate\" data-type=\"text\" data-pk=\"" . $id . '" data-name="date_start">' . $date_start . "</span></td>\r\n\t\t\t\t<td class='c'><span class=\"editExpireDate\" data-type=\"text\" data-pk=\"" . $id . '" data-name="date_expire">' . $date_expire . "</span></td>\r\n\t\t\t\t<td class='c'>") . $this->inputBy[$inputBy] . "</td>\r\n\t\t\t\t<td class='c'>";
            echo "\r\n\t\t\t\t\t<div class=\"btn-group\">\r\n                        <button class=\"btn btn-primary btn-xs dropdown-toggle\" href=\"#\" data-toggle=\"dropdown\">\r\n                        <span class='icon-cog'></span> <span class=\"caret\"></span>\r\n                        </button>\r\n                        <ul class=\"dropdown-menu stay-open pull-right\" role=\"menu\" style=\"padding: 15px; min-width: 200px;\">";
            if( $status == 2 ) 
            {
                echo '<li><a class="confirmSuspend_and_Reset" href="' . $this->base . '/Suspend?id=' . $id . '&NH=1&sus=off" OnClick="return false;"  title="Unsuspend Code"><span class="btn btn-success btn-xs icon-ok"></span> Unsuspend Code </a></li>';
            }
            if( $status == 1 ) 
            {
                echo '<li><a class="p_edit confirmSuspend_and_Reset" href="' . $this->base . '/Suspend?id=' . $id . '&NH=1&sus=on" OnClick="return false;" title="Suspend Code and Kik User"><span class="btn btn-info btn-xs icon-off"></span> Suspend </a></li>';
                echo "\r\n\t\t\t\t\t\t\t\t<li><a class=\"p_edit confirmSuspend_and_Reset\" href=\"" . $this->base . '/ResetCode?id=' . $id . '" OnClick="return false;" title="Reset Mac & Serial"><span class="btn btn-warning btn-xs icon-cw"></span> Reset MAC & SN</a></li>';
            }
            if( $this->admin['level'] == 8 ) 
            {
                echo '<li><a class="p_view" href="' . $this->base . '/Debug?id=' . $id . '" title="Debug Code"><span class="btn btn-primary btn-xs icon-bug"></span> Watch Logs</a></li>';
            }
            if( $this->admin['level'] == 8 && $status > 0 ) 
            {
                echo '<li><a class="" href="' . $this->base . '/RenewCode?id=' . $id . '" title="Renew Code تجديد"><span class="btn btn-success btn-xs icon-cw"></span> Renew Code</a></li>';
            }
            echo "\r\n                        </ul>\r\n\t\t\t\t\t</div>";
        }
        echo "</tbody>\r\n\t\t\t</table>";
        $order = str_replace(' ', ':', $order);
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?' . $params, $totalrows, $rows_per_page, $page) . '</center>';
        echo '</fieldset>';
        if( $this->admin['level'] == 1 ) 
        {
            echo "\t\t\t\t\$.fn.editable.defaults.mode = 'pop';     \r\n\t\t\t\t\$('.editExpireDate').editable({\r\n\t\t\t\t\turl: '";
            echo $this->base;
            echo "/EditCodeDate?NH=1',\r\n\t\t\t\t\tsuccess: function(response) {\r\n\t\t\t\t\t\tif(response != \"success\" && response != \"\")\r\n\t\t\t\t\t\t\talert(response);\r\n\t\t\t\t\t}\r\n\t\t\t\t});\r\n\t\t\t";
        }
        echo "\t\t\t\r\n\t\t});\r\n\t\t</script>\r\n\t\t<style>\r\n\t\t.modal-body {\r\n\t\t\tmax-height: calc(100vh - 150px);\r\n\t\t\toverflow-y: auto;\r\n\t\t}\r\n\t\t</style>\r\n\t\t";
    }
    public function EditCodeDate()
    {
        global $intro;
        $data = $dataU = [];
        $id = intval($intro->input->get_post('pk'));
        $name = trim($intro->input->get_post('name'));
        $value = trim($intro->input->get_post('value'));
        if( !IntroDate::validateDate($value, 'Y-m-d') ) 
        {
            exit( 'Error: Wrong Date Format: use yyyy-mm-dd' );
        }
        $value = strtotime($value);
        $data[$name] = $value;
        if( $this->admin['level'] == 1 || $this->admin['level'] == 5 ) 
        {
            if( $name == 'date_expire' ) 
            {
                $sql = $intro->db->query('SELECT userid,status,code,inputBy,username  FROM ' . PREFIX . ('_codes where id=' . $id));
                $row = $intro->db->fetch_assoc($sql);
                if( $row['status'] == 1 ) 
                {
                    $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id);
                }
                else
                {
                    exit( 'Error: user not active.' );
                }
                if( $row['inputBy'] == 0 ) 
                {
                    $intro->db->query_fast('UPDATE users SET `exp_date`=\'' . $value . '\' WHERE username=\'' . $row['code'] . '\';');
                    exit( 'success' );
                }
                if( $row['inputBy'] == 1 || $row['inputBy'] == 2 ) 
                {
                    $intro->db->query_fast('UPDATE users SET `exp_date`=\'' . $value . '\' WHERE username=\'' . $row['username'] . '\';');
                    exit( 'success' );
                }
            }
            else
            {
                $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id);
                exit( 'success' );
            }
        }
        else
        {
            exit( 'error: you don\'t have permissions ' );
        }
    }
    public function Suspend()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sus = trim($intro->input->get_post('sus'));
        if( $sus == 'on' ) 
        {
            $status = 2;
            $enabled = 0;
            $span_sus = '<span class="label label-info">Suspended</span>';
        }
        else if( $sus == 'off' ) 
        {
            $status = 1;
            $enabled = 1;
            $span_sus = '<span class="label label-success">Active</span>';
        }
        else
        {
            exit( 'Opps!!!' );
        }
        if( $this->admin['level'] != 1 && $this->admin['level'] != 5 ) 
        {
            exit( 'Opps!!! No permissions.' );
        }
        $qq = $code = '';
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $qq . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $code = $row['code'];
        $username = $row['username'];
        $sql = $intro->db->query('UPDATE ' . PREFIX . ('_codes SET status=' . $status . ' WHERE id=' . $id . ' ' . $qq . ';'));
        if( $username != '' ) 
        {
            $intro->db->query('UPDATE users SET enabled=' . $enabled . ' WHERE username=\'' . $username . '\'; ');
        }
        else
        {
            $intro->db->query('UPDATE users SET enabled=' . $enabled . ' WHERE username=\'' . $code . '\'; ');
            $arr = ['status_' . $id => $span_sus];
            header('Content-Type: application/json');
            echo json_encode($arr);
        }
    }
    public function ResetCode()
    {
        global $intro;
        $id = intval($intro->input->get_post('id'));
        $data = [];
        $data['mac'] = 'reset_me';
        $data['serial'] = 'reset_me';
        $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id . ' AND inputBy=0');
        $arr = [
            'mac_' . $id => $data['mac'], 
            'sn_' . $id => $data['serial']
        ];
        header('Content-Type: application/json');
        echo json_encode($arr);
    }
    public function Debug()
    {
        global $intro;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $file = trim($intro->input->get_post('file'));
        if( $this->admin['level'] == 9 || $this->admin['level'] == 5 ) 
        {
            $this->qry_admin = '';
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if( $status == 0 ) 
        {
            $label = 'default';
        }
        else if( $status == 1 ) 
        {
            $label = 'success';
        }
        else if( $status == 2 ) 
        {
            $label = 'info';
        }
        else if( $status == 3 ) 
        {
            $label = 'danger';
        }
        else if( $status == 4 ) 
        {
            $label = 'default';
        }
        else if( $status == 5 ) 
        {
            $label = 'warning';
        }
        else
        {
            $label = 'danger';
        }
        $date_expire = ($date_expire != '' ? date('Y-m-d', $date_expire) : '-');
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Debug code: ' . $code);
        echo "<table class=\"table table-striped table-bordered\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='info'>Fullname:</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='info'>Adminid:</td>\r\n\t\t\t\t<td>" . $adminid . "</td>\r\n\t\t\t\t<td class='info'>TransID:</td>\r\n\t\t\t\t<td>" . $transid . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\r\n\t\t\t\t<td class='info'>Days:</td>\r\n\t\t\t\t<td>" . $days . "</td>\r\n\t\t\t\t<td class='info'>Date Expire</td>\r\n\t\t\t\t<td>" . $date_expire . "</td>\t\r\n\t\t\t\t<td class='info'>Status:</td>\r\n\t\t\t\t<td><span class='label label-" . $label . '\'>' . $intro->status[$status] . ' ' . (($code_replaced != '' ? '<br/>' . $code_replaced : '')) . ("</span></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\t\t\r\n\t\t\t\t<td class='info'>MAC</td>\r\n\t\t\t\t<td>" . $mac . "</td>\r\n\t\t\t\t<td class='info'>Serial</td>\r\n\t\t\t\t<td>" . $serial . "</td>\r\n\t\t\t\t<td class='info'>Last Update</td>\r\n\t\t\t\t<td>" . $last_update . "</td>\r\n\t\t\t</tr>\r\n\t\t</table>");
        echo "<div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\">\r\n\t\t\t\t  <button id='refresh_bug' type=\"button\" class=\"btn btn-primary\">Refresh Logs</button>\r\n\t\t\t\t</div><span id=\"spin\" class='icon-spin5'></span>";
        $this->getBug($code, $mac, $serial, $inputBy, $userid);
        echo '</div>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$('documnet').ready(function(){\r\n\t\t\t\$('#refresh_bug').click(function(){\r\n\t\t\t\t\$('#spin').addClass('animate-spin');\r\n\t\t\t\t\$.get( \"" . $this->base . '/getBug?NH=1&code=' . $code . '&inputBy=' . $inputBy . '&sn=' . $serial . '&mac=' . $mac . '&userid=' . $userid . "\", function( data ) {\r\n\t\t\t\t\t\$( \"#result\" ).html( data );\r\n\t\t\t\t\t\$('#spin').removeClass('animate-spin');\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function getBug($code = '', $mac = '', $sn = '', $inputBy = 0, $userid = 0)
    {
        global $intro;
        global $array;
        if( $code == '' ) 
        {
            $code = trim($intro->input->get_post('code'));
        }
        if( $mac == '' ) 
        {
            $mac = trim($intro->input->get_post('mac'));
        }
        if( $sn == '' ) 
        {
            $sn = trim($intro->input->get_post('sn'));
        }
        if( $inputBy == 0 ) 
        {
            $inputBy = intval($intro->input->get_post('inputBy'));
        }
        if( $userid == 0 ) 
        {
            $userid = intval($intro->input->get_post('userid'));
        }
        if( $inputBy == 0 ) 
        {
            $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs where code=\'' . $code . '\' order by id desc'));
        }
        if( $inputBy == 1 ) 
        {
            $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs where mac=\'' . $mac . '\' order by id desc'));
        }
        if( $inputBy == 2 ) 
        {
            $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs where serial=\'' . $sn . '\' order by id desc'));
        }
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Logs (' . $totalrows . ')');
        echo "\r\n\t\tB = Block IP\r\n\t\t<table dir=ltr border=\"1\" align=\"center\" width=\"100%\" cellspacing=\"1\" bordercolor=\"#808080\" style=\"border-collapse: collapse\">\r\n            <tr>\r\n\t\t\t\t<th>ID</th>\r\n\t\t\t\t<th>Ver</th>\r\n\t\t\t\t<th>Resel</th>\r\n\t\t\t\t<th>Date</th>\r\n\t\t\t\t<th>Code</th>\r\n\t\t\t\t<th>Serial</th>\r\n\t\t\t\t<th>Mac</th>\r\n\t\t\t\t<th>IP</th>\r\n\t\t\t\t<th>Log</th>\r\n\t\t\t\t<th>UserAgent</th>\r\n\t    </tr>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            if( $i % 2 == 0 ) 
            {
                $BG = 'odd';
            }
            else
            {
                $BG = 'even';
            }
            $dtime = date('Y-m-d H:i:s', $dtime);
            $thelog = str_replace('+', '<br/>', $thelog);
            $thelog = str_replace('@Wrong Code', '<span class=\'label label-danger\'>@Wrong Code</span>', $thelog);
            $thelog = str_replace('ReActivation', '<span class=\'label label-default\'>ReActivation</span>', $thelog);
            $thelog = str_replace('Success', '<span class=\'label label-success\'>Success</span>', $thelog);
            echo '<tr class="' . $BG . "\">\r\n\t\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t\t<td class=\"center\">" . $ver . "</td>\r\n\t\t\t\t\t<td class=\"center\">" . $array['admins'][$adminid] . "</td>\r\n                     <td class=\"center\">" . $dtime . "</th>\r\n                     <td class=\"center\">" . $code . "</th>\r\n                     <td class=\"center\">" . $serial . "</th>\r\n                     <td class=\"center\">" . $mac . "</th>\r\n                     <td class=\"center\"><a href='http://ipinfo.io/" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\r\n                     <td>" . $thelog . "</th>     \r\n                     <td>" . $uagent . "</th>     \r\n\t\t </tr>";
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        $sql = $intro->db->query('SELECT * FROM `client_logs` where user_id=' . $userid . ' ' . ' group by client_status order by id desc LIMIT 50');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<span class=\'icon-list\'></span>Xtream Clients Logs Userid: ' . $userid, 'primary');
        echo "\r\n\t\t<table class=\"table table-condensed table-bordered table-hover\">\r\n\t\t\t<tr>\r\n\t\t\t\t<th>ID</th>\r\n\t\t\t\t<th>Stream</th>\r\n\t\t\t\t\r\n\t\t\t\t<th>Status</th>\r\n\t\t\t\t<th>Query</th>\r\n\t\t\t\t<th>Agent</th>\r\n\t\t\t\t<th>IP</th>\r\n\t\t\t\t<th>Date</th>\r\n\t\t\t\t<th>Count</th>\r\n\t\t\t</tr>";
        $i = 0;
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            $i++;
            echo "<tr>\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $stream_id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $client_status . "</th>\r\n\t\t\t\t<td class=\"center\">" . $query_string . "</th>\r\n\t\t\t\t<td class=\"center\">" . $user_agent . "</th>\r\n\t\t\t\t<td class=\"center\"><a href='https://cmyip.com/search-ip.php?ip=" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\r\n\t\t\t\t<td class=\"center\">" . @date('Y-m-d H:i:s', $date) . ("</th>\r\n\t\t\t\t<td>" . $cnt . "</th>     \r\n\t\t\t\t\t\r\n\t\t\t</tr>");
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function RenewCode()
    {
        global $intro;
        global $array;
        global $config;
        include_once('codes.php');
        $c = new Codes_AppAdmin($intro->app, $config['base_url'] . 'index.php/' . $intro->app, null);
        $c->qry_admin = '';
        $c->RenewCode();
    }
    public function doRenew()
    {
        global $intro;
        global $error;
        global $array;
        include_once('codes.php');
        $c = new Codes_AppAdmin($intro->app, $config['base_url'] . 'index.php/' . $intro->app, null);
        $c->qry_admin = '';
        $c->doRenew();
    }
    public function calcCost($adminid = 0, $period = 0)
    {
        global $intro;
        global $array;
        if( $adminid == 0 ) 
        {
            $adminid = intval($intro->input->get('resel'));
        }
        if( $period == 0 ) 
        {
            $period = intval($intro->input->get('period'));
        }
        if( in_array($period, $array['free']) ) 
        {
            echo '0';
        }
        $adm = $intro->auth->admin_data($adminid);
        $cost = floatval($adm['cost_' . $period]);
        if( $cost <= 0 ) 
        {
            exit( 'Contact admin to set you cost for (' . $period . ') Months.' );
        }
        $bal = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($adminid);
        if( $bal < $cost ) 
        {
            exit( 'Insufficient balance. Your balance is: ' . $bal . '.' );
        }
        echo $cost;
    }
    public function calc()
    {
        global $intro;
        $cur_date = trim($intro->input->get_post('cur_date'));
        $period = trim($intro->input->get_post('period'));
        if( in_array($period, $this->free) ) 
        {
            if( $this->admin['level'] != 1 ) 
            {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Sorry: you can\'t renew Free Days. It\'s not allowed.', 'danger');
                exit();
            }
            $days = $period - 100;
            $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($cur_date, 'day', $days, 'Y-m-d');
            echo (string)$new_end;
        }
        else
        {
            $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($cur_date, 'month', $period, 'Y-m-d');
            echo (string)$new_end;
        }
    }
    public function getEndDate($date_expire, $period)
    {
        $rem = _obf_0D0B35352F210E3915162B31313632322D080512342E01(date('Y-m-d'), $date_expire);
        if( $rem > 0 ) 
        {
            $this->cur_date = $date_expire;
        }
        else
        {
            $this->cur_date = date('Y-m-d');
        }
        if( in_array($period, $this->free) ) 
        {
            $days = $period - 100;
            $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($this->cur_date, 'day', $days, 'Y-m-d');
            return $new_end;
        }
        $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($this->cur_date, 'month', $period, 'Y-m-d');
        return $new_end;
    }
}
