<?php 
if( isset($intro->option['hide_introtech_copy']) && $intro->option['hide_introtech_copy'] == 1 ) 
{
    $copyright = '';
}
else
{
    $copyright = _intro_ver;
}
echo "<!DOCTYPE html>\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n\r\n<head>\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n<meta content=\"text/html; charset=utf-8\" http-equiv=\"Content-Type\" />\r\n<meta charset=\"utf-8\" />\r\n<title>";
echo $intro->option['site_name'];
echo ' | ';
echo $copyright;
echo "</title>\r\n<link rel=\"stylesheet\" href=\"style/css/bootstrap.min.css\">\t\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"style/css/login.css\">\r\n<style>\r\nbody {\r\n\t\tbackground: url(style/img/loginbg.jpg) no-repeat center center fixed;\r\n\t\t-webkit-background-size: cover;\r\n\t\t-moz-background-size: cover;\r\n\t\t-o-background-size: cover;\r\n\t\tbackground-size: cover;\r\n\t}\r\n</style>\r\n</head>\r\n\r\n<body>\r\n\r\n\r\n<div class=\"container\">\r\n\t<div class=\"row\">\r\n\t\t<div class=\"col-sm-6 col-md-4 col-md-offset-4\">\r\n\t\t\t<h1 class=\"text-center login-title\">Login in</h1>\r\n\t\t\t<div class=\"account-wall\">\r\n\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t<div class=\"col-sm-12 col-md-12 text-center\">\r\n\t\t\t\t\t";
if( isset($intro->option['hide_login_logo']) && $intro->option['hide_login_logo'] == 1 ) 
{
    echo '<h3 style=\'color:#4d4cff\'>Login to LYNX IPTV Panel</h3>';
}
else
{
    echo '<img src="style/img/logo.png" alt="" style="max-width:450px;">';
}
echo "\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<form class=\"form-signin\" method=\"POST\">\r\n\t\t\t\t\t<input type=\"text\" name=\"";
echo $name1;
echo '" value="';
echo $username;
echo "\" class=\"form-control\" placeholder=\"Username\" required autofocus>\r\n\t\t\t\t\t<input type=\"password\" name=\"";
echo $name2;
echo '" value="';
echo $password;
echo "\" class=\"form-control\" placeholder=\"Password\" required>\r\n\t\t\t\t\t<div style=\"width:500px;margin:auto;color:red;font-weight:bold;\">";
echo (isset($this->error['msg']) ? $this->error['msg'] : '');
echo "</div>\r\n\t\t\t\t\t<button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Login</button>\r\n\t\t\t\t\t<label class=\"checkbox pull-left\">\r\n\t\t\t\t\t\t<input type=\"checkbox\" value=\"remember-me\"> Remember me\r\n\t\t\t\t\t</label>\r\n\t\t\t\t\t<a href=\"#\" class=\"pull-right need-help\">Forgot password? </a><span class=\"clearfix\"></span>\r\n\t\t\t\t\t<input type=\"hidden\" name=\"maa\" value=\"do_login\" />\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t\t\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n";
if( isset($intro->option['hide_introtech_copy']) && $intro->option['hide_introtech_copy'] == 1 ) 
{
    if( isset($intro->option['copyright']) && $intro->option['copyright'] != '' ) 
    {
        echo "\r\n\t\t\t<div class=\"row text-center\"><br/>\r\n\t\t\t\t" . $intro->option['copyright'] . "\r\n\t\t\t</div>";
    }
}
else
{
    echo "<center>\r\n\t<h5 class='center'><a href='http://intro.ps/' target=_blank>" . _intro_ver . "</a></h5>\r\n\t</center>";
}
