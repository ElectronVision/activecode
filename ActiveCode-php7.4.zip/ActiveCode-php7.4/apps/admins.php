<?php 
define('_ADMIN_NAME_TITLE', 'Resellers');
define('_ADMIN_ADD', 'Add Reseller');
define('_ADMIN_EDIT', 'Edit Reseller');
define('_ADMIN_CURRENT', 'Resellers');
define('_ADMIN_ADMIN_NAME', 'Name');
define('_ADMIN_ADM_USERNAME', $intro->lang['username']);
define('_ADMIN_ADM_PASSWORD', 'Password');
define('_ADMIN_EMAIL', 'Email');
define('_ADMIN_FULLNAME', $intro->lang['fullname_admin']);
define('_ADMIN_REGDATE', $intro->lang['users_reg_date']);
define('_ADMIN_IPADDRESS', $intro->lang['IP']);
define('_ADMIN_LASTLOGIN', $intro->lang['last_visit']);
class Admins_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $canSubResel = 0;
    public $qry_admin = '';
    public $qry_where_father = '';
    public $groups = [];
    public $adminRow = [];
    public $level = [
        '1' => 'Admin', 
        '2' => 'Super Reseller', 
        '3' => 'Reseller', 
        '4' => 'Reset Codes Only', 
        '6' => 'Reseller With Sub-Resel', 
        '7' => 'Sub-Reselller'
    ];
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $options;
        $this->admin = $intro->auth->sess_admin();
        if( isset($options['opt_ReselExtraOpts']) && $options['opt_ReselExtraOpts'] == 'yes' ) 
        {
            $level = [
                '5' => 'Reset,Expire,Suspend', 
                '8' => 'Reset,Expire,Suspend, Streams, Logs, Bouquets', 
                '9' => 'Admin No bulk,inv,pay,code list'
            ];
            $this->level += $level;
        }
        if( !in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        if( $this->admin['level'] == 6 ) 
        {
            $this->qry_admin = ' AND (adminid=\'' . $this->admin['adminid'] . '\' OR father=' . intval($this->admin['adminid']) . ')';
            $this->qry_where_father = ' AND father=' . intval($this->admin['adminid']);
            $this->adminRow = $intro->auth->admin_data($this->admin['adminid']);
        }
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = ' AND father=0';
            $this->qry_where_father = '';
        }
        $this->getGroups();
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function getGroups()
    {
        global $intro;
        $this->groups[0] = 'All';
        $sql = $intro->db->query('SELECT * from ' . PREFIX . '_admin_groups order by g_name ASC');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            extract($row);
            $this->groups[$g_id] = $g_name;
        }
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        global $policy;
        $adminid = $sess_admin['adminid'];
        $base = $this->appname;
        $policy = policy($adminid, $base . '.php');
        echo $policy;
        echo "<div class=\"app_nav\">\n\t\t <a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . (' icon-users" href="' . $this->base . '/index"> ') . _ADMIN_NAME_TITLE . "</a> \n\t\t <a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' icon-plus" href="' . $this->base . '/Form?t=add"> ') . _ADMIN_ADD . '</a> ';
        if( $this->admin['level'] == 1 ) 
        {
            echo '<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Groups') . (' icon-list" href="' . $this->base . '/Groups?t=add"> Groups </a> ');
            echo '<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('ImportRegUsers') . (' icon-upload" href="' . $this->base . '/ImportRegUsers"> Import Reseller </a> ');
            echo '<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('copyusers') . (' icon-upload" href="' . $this->base . '/copyusers"> Copy users  </a> ');
        }
        echo "\n\t\t</div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        global $options;
        $this->nav();
        $qry = $params = '';
        $user = $intro->db->escape(trim($intro->input->get_post('user')));
        $resel_name = $intro->db->escape(trim($intro->input->get_post('resel_name')));
        $father = intval($intro->input->get_post('father'));
        if( $father != 0 ) 
        {
            $qry .= (' AND father=' . $father . ' ');
        }
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = '';
        }
        if( $user != '' ) 
        {
            $qry .= (' AND adm_username  LIKE \'' . str_replace('*', '%', $user) . '\' ');
        }
        if( $resel_name != '' ) 
        {
            $qry .= (' AND admin_name  LIKE \'' . str_replace('*', '%', $resel_name) . '\' ');
        }
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = '';
            if( $qry == '' ) 
            {
                $qry = 'AND father=0';
            }
        }
        $order = trim($intro->input->get('order'));
        $page = trim($intro->input->get('page'));
        if( !isset($order) || $order == '' ) 
        {
            $order = 'adminid_asc';
        }
        $order = str_replace('_desc', ' desc', $order);
        $order = str_replace('_asc', ' asc', $order);
        $rows_per_page = 200;
        if( !isset($page) || $page == '' ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT *,(SELECT COUNT(*) FROM ' . PREFIX . '_admin tbl_sub WHERE tbl_sub.father=adm.adminid  ) as totSub ' . ',(SELECT SUM(credit-depit) FROM ' . PREFIX . '_trans where admin=adm.adminid) as balance ' . ' FROM ' . PREFIX . ('_admin adm WHERE true ' . $this->qry_admin . ' ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $resultnumm = $intro->db->query('SELECT adminid FROM ' . PREFIX . ('_admin WHERE true ' . $this->qry_admin . ' ' . $qry));
        $totrows = mysqli_num_rows($result);
        $totalrows = mysqli_num_rows($resultnumm);
        echo _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22(_ADMIN_CURRENT . (' (' . $totalrows . ')'), 'info');
        echo '<form action="' . $this->base . "/index\" method=\"post\">\n\t\t<input type=\"text\" name=\"resel_name\" value=\"" . $resel_name . "\" placeholder=\"Name\" size=\"15\">\n\t\t<input type=\"text\" name=\"user\" value=\"" . $user . "\" placeholder=\"Username\" size=\"15\">\n\t\t<input type=\"hidden\" name=\"maa\" value=\"Main\"> user * for search\n\t\t<input value=\" Search \" type=\"submit\">\n\t\t</form>";
        echo "<table class=\"XDataTable table table-hover table-bordered table-condensed\">\n\t\t<thead>\n\t\t<tr>\n\t\t\t<th class=\"center\"><b>ID</b></th>\n\t\t\t<th><b>Level</b> </th> ";
        if( $qry != '' ) 
        {
            echo '<th>Father</th>';
        }
        echo "<th>Name</th> \n\t\t\t<th>Username</th>  \n\t\t\t<th><b>Group</b></th>  \n\t\t\t<!--<th><b>Codes</b> </th>\n\t\t\t<th><b>Users</b> </th>-->\n\t\t\t<th><b>LastLogin</b> </th>\n\t\t\t<th><b>ip</b></th> \n\t\t\t<th><b>Free</b></th>\n\t\t\t<th><b>Balance </b> </th>";
        if( $this->admin['level'] == 1 && isset($options['opt_activation_count']) && $options['opt_activation_count'] == 'yes' ) 
        {
            echo '<th><b>Act Count</b></th>';
        }
        echo "\n\t\t\t<th class=\"center\"><b>Options</b></th>\n\t\t</tr>\n\t\t</thead>\n\t\t<tbody>";
        $i = 0;
        $this->level[0] = 'error please edit';
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            extract($myrow);
            $i++;
            $sub_a = '';
            if( $totSub > 0 && $this->admin['level'] == 1 ) 
            {
                $sub_a = '<a href="' . $this->base . '/index?father=' . $adminid . '"><span class="badge badge-success">' . $totSub . '</span></a>';
            }
            echo "\n\t\t\t<tr>\n\t\t\t\t<td class=\"c\">" . $adminid . "</td>\n\t\t\t\t<td id=\"suspend_" . $adminid . "\">\n\t\t\t\t" . (($suspend == 1 ? '<span class="label label-info">Suspended</span>' : '')) . ' ' . ((isset($this->level[$level]) ? $this->level[$level] : 'ERR')) . "\n\t\t\t\t</th>";
            if( $qry != '' ) 
            {
                echo '<td>' . ((isset($array['admins'][$father]) ? $array['admins'][$father] : '-')) . '</td>';
            }
            echo '<td>' . $admin_name . ' ' . $sub_a . "</th>\n\t\t\t\t<td>" . $adm_username . "</th>\t\t\t\t\t\t\n\t\t\t\t<td class=\"c\">" . $this->groups[$group_id] . '</th>' . '<td class="c">' . _obf_0D10361F073B102D294032060E21400727331210083132(strtotime($lastlogin)) . ("</th>\t\t\t\t\t\t\n\t\t\t\t<td class=\"c\">" . $ipaddress . "</th>\t\t\t\t\t\t\n\t\t\t\t<td class=\"c\">" . $num_free . "</th>\t\t\t\t\t\t\n\t\t\t\t<td class=\"c\">") . number_format($balance) . '</th>';
            if( $this->admin['level'] == 1 && isset($options['opt_activation_count']) && $options['opt_activation_count'] == 'yes' ) 
            {
                echo '<td class="c"><span class="editInPlace" data-type="text" data-pk="' . $adminid . '" data-name="act_count">' . $act_count . '</span></td>';
            }
            echo '<td class="center">';
            echo '<li><a class="p_view" href="' . $this->base . '/Report?the_adminid=' . $adminid . '" title="Report"><span class="btn btn-primary btn-xs icon-list"></span> Report </a>';
            if( $suspend == 0 ) 
            {
                echo '<li><a class="p_edit" href="' . $this->base . '/Suspend?id=' . $adminid . '&action=sus" title="Suspend Reseller"><span class="btn btn-info btn-xs icon-off"></span> Suspend </a></li>';
            }
            if( $suspend == 1 ) 
            {
                echo '<li><a class="" href="' . $this->base . '/Suspend?id=' . $adminid . '&action=unsus" title="Unsuspend Reseller"><span class="btn btn-success btn-xs icon-ok"></span> Unsuspend </a></li>';
            }
            if( $this->admin['level'] != 9 && $level == 1 || $this->admin['level'] == 1 || $this->admin['level'] == 6 ) 
            {
                echo '<li><a class="p_edit" href="' . $this->base . '/Form?t=edit&amp;the_adminid=' . $adminid . '" title="' . $intro->lang['edit'] . '"><span class="btn btn-info btn-xs icon-edit"></span> Edit </a></li>';
            }
            if( $level != 1 && $this->admin['level'] == 1 ) 
            {
                echo '<li><a class="p_del Xintro_ui_delX" href="' . $this->base . '/Del?the_adminid=' . $adminid . '"  title="' . $intro->lang['del'] . '"><span class="btn btn-danger btn-xs icon-trash"></span> Delete </a></li>';
            }
            echo "\n                        </ul>\n\t\t\t\t\t</div>";
        }
        echo "\n\t\t\t</tbody>\n\t\t\t</table>";
        $order = str_replace(' desc', '_desc', $order);
        $order = str_replace(' asc', '_asc', $order);
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?order=' . $order . $params, $totalrows, $rows_per_page, $page) . '</center>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\n\t\t \$(document).ready(function() {\n\t\t\t \n\t\t\t\$.fn.editable.defaults.mode = 'pop';     \n\t\t\t\$('.editInPlace').editable({\n\t\t\t\turl: '" . $this->base . "/EditInPlace?NH=1',\n\t\t\t\tsuccess: function(response) {\n\t\t\t\t}\n\t\t\t});\n\t\t\t\n\t\t\t \$(\".confirmSuspend_and_Reset\").on(\"click\", function(e) {\n\t\t\t\tvar link = this;\n\t\t\t\tvar link_tr = \$(this).closest('tr');\n\t\t\t\te.preventDefault();\n\t\t\t\t\$.confirm({\n\t\t\t\t\ttext: \"Are you sure you?\",\n\t\t\t\t\ttitle: \"Confirmation required\",\n\t\t\t\t\tconfirm: function(button) {\n\t\t\t\t\t\t\$.get( link.href +'&NH=1', function( data ) {\t\t\t\t\t\t\n\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\$.each(data, function(key, value) {\n\t\t\t\t\t\t\t\t  \$(\"#\"+key).html(value);\n\t\t\t\t\t\t\t});\n\t\t\t\t\t\t});\n\t\t\t\t\t\treturn false;\n\t\t\t\t\t},\n\t\t\t\t\tcancel: function(button) {\n\t\t\t\t\t},\n\t\t\t\t\tconfirmButton: \"Yes\",\n\t\t\t\t\tcancelButton: \"Cancel\",\n\t\t\t\t\tpost: true,\n\t\t\t\t\tconfirmButtonClass: \"btn-danger\",\n\t\t\t\t\tcancelButtonClass: \"btn-default\",\n\t\t\t\t\tdialogClass: \"modal-dialog modal-lg\"\n\t\t\t\t});\n\t\t\t});\n\t\t });\n\t\t </script>";
    }
    public function EditInPlace()
    {
        global $intro;
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $data = [];
        $id = intval($intro->input->get_post('pk'));
        $name = trim($intro->input->get_post('name'));
        $value = trim($intro->input->get_post('value'));
        $data[$name] = $value;
        if( $this->admin['level'] == 1 ) 
        {
            $intro->db->update('' . PREFIX . '_admin', $data, 'adminid=' . $id);
        }
    }
    public function Suspend()
    {
        global $intro;
        global $array;
        $the_adminid = intval($intro->input->get_post('id'));
        $action = trim($intro->input->get_post('action'));
        $adm = $intro->auth->adminid();
        $name = $array['admins'][$the_adminid];
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        if( $the_adminid == $this->admin['adminid'] ) 
        {
            $this->nav();
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h3>Sorry: you can\'t suspend your account.</h3>', 'danger');
            exit();
        }
        $this->nav();
        if( $action == 'sus' ) 
        {
            $txt = 'Suspend';
            $btn1 = 'warning';
            $btn2 = 'warning';
            $btn3 = 'danger';
            $panel = 'warning';
            $on_off = 'on';
        }
        else if( $action == 'unsus' ) 
        {
            $txt = 'Unsuspend';
            $btn1 = 'success';
            $btn2 = 'success';
            $btn3 = 'info';
            $panel = 'success';
            $on_off = 'off';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22($txt . ' Reseller: ' . $name, $panel);
        $tot = 0;
        $tot += ($num_users = $intro->db->dcount('id', 'users', 'member_id=' . $the_adminid . ' AND is_mag=0 AND is_e2=0'));
        $tot += ($num_mag = $intro->db->dcount('id', 'users', 'member_id=' . $the_adminid . ' AND is_mag=1'));
        $tot += ($num_e2 = $intro->db->dcount('id', 'users', 'member_id=' . $the_adminid . ' AND is_e2=1'));
        $tot += ($num_resel = $intro->db->dcount('adminid', '' . PREFIX . '_admin', 'father=' . $the_adminid));
        $tot += ($num_codes = $intro->db->dcount('id', '' . PREFIX . '_codes', 'adminid=' . $the_adminid));
        echo "\n\t\t<div class='row'>\n\t\t\t<div class='col-md-6'>\n\t\t\t\t<ul class=\"list-group\">";
        if( $this->admin['level'] == 1 ) 
        {
            echo '<li class="list-group-item">Found Sub Rellers <span class="badge">' . $num_resel . '</span></li>';
        }
        echo '<li class="list-group-item">Found Users <span class="badge">' . $num_users . "</span></li>\n\t\t\t\t  <li class=\"list-group-item\">Found MAG Devices <span class=\"badge\">" . $num_mag . "</span></li>\n\t\t\t\t  <li class=\"list-group-item\">Found Enigma2 Devices <span class=\"badge\">" . $num_e2 . "</span></li>\n\t\t\t\t \n\t\t\t\t  <li class=\"list-group-item\">Found Codes <span class=\"badge\">" . $num_codes . "</span></li>\n\t\t\t\t</ul>\n\t\t\t</div>\n\t\t</div>";
        if( $tot > 0 ) 
        {
            echo '<a href="' . $this->base . '/doSuspend?id=' . $the_adminid . '&amp;action=resel_only&sus=' . $on_off . '" class=\'btn btn-' . $btn1 . "' \n\t\t\t\t\tOnClick=\"return confirm('Are you Sure?');\">\n\t\t\t\t\t" . $txt . ' Only: (' . $name . ') ! </a> ';
            echo '<a href="' . $this->base . '/doSuspend?id=' . $the_adminid . '&amp;action=resel_and_sub&sus=' . $on_off . '" class=\'btn btn-' . $btn1 . "' \n\t\t\t\t\tOnClick=\"return confirm('Are you Sure?');\">\n\t\t\t\t\t" . $txt . ' (' . $name . ') and his Sub-Resellers! </a> ';
            echo '<a href="' . $this->base . '/doSuspend?id=' . $the_adminid . '&amp;action=all&sus=' . $on_off . '" class=\'btn btn-' . $btn1 . "' \n\t\t\t\t\tOnClick=\"return confirm('Are you Sure?');\">\n\t\t\t\t\t" . $txt . ' reseller (' . $name . ') and All his accounts !!!.</a>';
        }
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doSuspend()
    {
        global $intro;
        global $array;
        $adminid = intval($intro->input->get_post('id'));
        $sus = trim($intro->input->get_post('sus'));
        $action = trim($intro->input->get_post('action'));
        $name = $array['admins'][$adminid];
        $un = '';
        if( $sus == 'on' ) 
        {
            $suspend = 1;
            $admin_enabled = 0;
            $span_sus = '<span class="label label-info">Suspended</span>';
        }
        else if( $sus == 'off' ) 
        {
            $suspend = 0;
            $admin_enabled = 1;
            $span_sus = '<span class="label label-success">Active</span>';
            $un = 'Un';
        }
        else
        {
            exit( 'Opps!!!' );
        }
        $qry = '';
        if( $action == 'resel_only' ) 
        {
            if( $this->admin['level'] == 6 ) 
            {
                $qry = ' and father=' . intval($this->admin['adminid']);
            }
            $sql = $intro->db->query('UPDATE ' . PREFIX . ('_admin SET suspend=' . $suspend . ' WHERE adminid=' . $adminid . ' AND level!=1 ' . $qry . ';'));
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Reseller: ' . $name . ' <b>' . $un . 'suspended!</b>');
        }
        else if( $action == 'resel_and_sub' || $action == 'all' ) 
        {
            if( $this->admin['level'] == 6 ) 
            {
                $qry = ' and father=' . intval($this->admin['adminid']);
            }
            $sql = $intro->db->query('UPDATE ' . PREFIX . ('_admin SET suspend=' . $suspend . ' WHERE adminid=' . $adminid . ' AND level!=1 ' . $qry . ';'));
            if( $this->admin['level'] == 1 ) 
            {
                $sql = $intro->db->query('UPDATE ' . PREFIX . ('_admin SET suspend=' . $suspend . '  WHERE father=' . $adminid . ' AND level!=1;'));
            }
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Reseller: ' . $name . ' <b>' . $un . 'suspended</b> along with his Sub-Resellers.!');
        }
        if( $action == 'all' ) 
        {
            if( $this->admin['level'] == 1 ) 
            {
                $sql = $intro->db->query('UPDATE `users` SET admin_enabled=' . $admin_enabled . '  WHERE member_id=' . $adminid . ' ' . ' OR member_id in (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adminid . ' AND level!=1);'));
            }
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Reseller: ' . $name . ' <b>' . $un . 'suspended</b> along with his Sub-Resellers and all accounts.!');
        }
        $intro->redirect($this->appname);
    }
    public function Groups()
    {
        global $intro;
        global $array;
        $this->nav();
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $search_txt = trim($intro->input->get_post('search_txt'));
        $qry = '';
        if( $search_txt != '' ) 
        {
            $qry = ' where fullname  LIKE \'%' . $search_txt . '%\' or adm_username like \'%' . $search_txt . '%\'';
        }
        $text = _ADMIN_CURRENT;
        $order = trim($intro->input->get('order'));
        $page = trim($intro->input->get('page'));
        if( !isset($order) || $order == '' ) 
        {
            $order = 'g_id_asc';
        }
        $order = str_replace('_desc', ' desc', $order);
        $order = str_replace('_asc', ' asc', $order);
        $rows_per_page = 50;
        if( !isset($page) || $page == '' ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_admin_groups ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $resultnumm = $intro->db->query('SELECT g_id from ' . PREFIX . ('_admin_groups ' . $qry));
        $totrows = mysqli_num_rows($result);
        $totalrows = mysqli_num_rows($resultnumm);
        echo "\n\t\t<fieldset><legend> Add new Group</legend>\n\t\t\t<form action=\"" . $this->base . "/doAddGroup\" id=\"frmAddGroup\" method=\"post\">\n\t\t\t\tGoup Name: <input type=\"text\" name=\"g_name\" value=\"\" size=\"20\">\n\t\t\t\t<input name=\"name\" value=\" Add \" type=\"submit\">\n\t\t\t</form>\n\t\t</fieldset>";
        echo '<fieldset><legend> ' . $text . ' (' . $totalrows . ')</legend>';
        echo "\n\t\t<form action=\"" . $this->base . "/index\" method=\"post\">\n\t\t\t<input type=\"text\" name=\"search_txt\" value=\"" . $search_txt . "\" size=\"20\" placeholder=\"Goup Name\">\n\t\t\t<input type=\"hidden\" name=\"maa\" value=\"Main\">\n\t\t\t<input name=\"name\" value=\" Search \" type=\"submit\">\n\t\t</form>";
        echo "<script>\n\t\t\$(document).ready(function(){\n\t\t\t\n\t\t\t\$(\"#frmAddGroup\").submit( function(e) {   \n\t\t\t\te.preventDefault();\n\t\t\t\t\n\t\t\t\t\$.post('" . $this->base . "/doAddGroup?NH=1',\$(this).serialize(),function(data){\n\n\t\t\t\t\talert(data);\n\t\t\t\t\tlocation.reload();\n\t\t\t\t});\n\t\t\t\treturn false;   \n\t\t\t});\n\t\t});\n\t\t</script>";
        echo "<table class=\"DataTable table table-bordered table-condensed\">\n\t\t<thead>\n\t\t\t<tr>\n\t\t\t\t<th class=\"center\"><b>ID</b> \n\t\t\t\t<th><b>Group Name</b></th>\n\t\t\t\t<th class=\"center\"><b>Options</b></th>\n\t\t\t</tr>\n\t\t</thead>\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            extract($myrow);
            $i++;
            echo "\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\n\t\t\t\t<td class=\"c\">" . $g_id . "</td>\n\t\t\t\t<td><span class=\"editableGroup\" data-type=\"text\" data-pk=\"" . $g_id . '" data-name="g_name">') . $g_name . ("</span></th>\n\n\t\t\t\t<td class=\"center\"> \n\t\t\t\t\n\t\t\t\t<!--\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?g_id=' . $g_id . '"  title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\n\t\t\t\t-->\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t</tbody>\n\t\t</table>";
        $order = str_replace(' desc', '_desc', $order);
        $order = str_replace(' asc', '_asc', $order);
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?search_txt=' . $search_txt . '&order=' . $order, $totalrows, $rows_per_page, $page) . '</center>';
        echo '</fieldset>';
        echo "<script>\n\t\t\$.fn.editable.defaults.mode = 'inline';     \n\t\t\$('.editableGroup').editable({\n\t\t\turl: '" . $this->base . "/EditInPlaceGroup?NH=1',\n\t\t\tsuccess: function(response) {\n\t\t\talert(response);\n\t\t\t}\n\t\t});\n\t\t</script>";
    }
    public function EditInPlaceGroup()
    {
        global $intro;
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $id = intval($intro->input->get_post('pk'));
        $name = trim($intro->input->get_post('name'));
        $value = trim($intro->input->get_post('value'));
        $data = [];
        $data[$name] = $value;
        $intro->db->update(PREFIX . '_admin_groups', $data, 'g_id=' . $id);
    }
    public function level($comp)
    {
        global $intro;
        if( $intro->input->post('level') != '' ) 
        {
            $comp = $intro->input->post('level');
        }
        $html = "\n\t\t<select name=\"level\" id=\"level\">";
        $html .= '<option value="0" selected="selected">Choose level</option>';
        foreach( $this->level as $key => $val ) 
        {
            $html .= ('<option value="' . $key . '" ' . (($comp == $key ? 'selected="selected"' : '')) . ('>' . $val . '</option>'));
        }
        $html .= "\n\t\t</select>";
        return $html;
    }
    public function Form()
    {
        global $intro;
        global $t;
        global $error;
        global $admin_typ;
        global $policy;
        global $adminid;
        global $array;
        global $options;
        global $admin_name;
        global $adm_username;
        global $adm_password;
        global $email;
        global $cost_1;
        global $cost_3;
        global $cost_6;
        global $cost_12;
        global $cost_24;
        global $cost_36;
        global $fullname;
        global $site;
        global $country;
        global $city;
        global $tel;
        global $regdate;
        global $ipaddress;
        global $lastlogin;
        global $level;
        global $resel_bouquets;
        global $can_add_free;
        global $can_delete;
        global $can_change;
        global $can_add_free_1;
        global $can_add_free_3;
        global $can_add_free_7;
        global $can_add_free_10;
        global $cost_1_enabled;
        global $cost_3_enabled;
        global $cost_6_enabled;
        global $cost_12_enabled;
        global $cost_24_enabled;
        global $cost_36_enabled;
        global $group_id;
        global $can_add_mac;
        global $can_add_sn;
        global $num_free;
        global $can_m3u;
        global $can_add_sub;
        global $father;
        global $postpaid;
        global $no_invoice;
        global $can_add_mag;
        global $can_add_users;
        global $msg_welcome;
        global $logo;
        global $brand;
        global $act_count;
        global $notes;
        global $host;
        global $extra_free_days;
        global $allowed_ips;
        global $can_add_codes;
        global $manage_streams;
        global $manage_vod;
        $subQry = $qry = '';
        $stb_groups = [];
        $t = stripslashes($intro->input->get_post('t'));
        $the_adminid = intval($intro->input->get_post('the_adminid'));
        $adminid = intval($intro->input->get_post('adminid'));
        $this->nav();
        if( $t == 'edit' ) 
        {
            $qry = '';
            if( !in_array($this->admin['level'], [
                1, 
                6
            ]) ) 
            {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h3>Danger! you tried to edit admin.</h3>', 'danger');
                exit();
            }
            if( $this->admin['level'] == 6 ) 
            {
                $qry = ' AND father=' . $this->admin['adminid'];
            }
            $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_admin where adminid=\'' . $the_adminid . '\' ' . $qry));
            $row = $intro->db->fetch_assoc($sql);
            if( is_array($row) ) 
            {
                extract($row);
            }
            if( !$row ) 
            {
                exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: you can\'t edit this admin.', 'danger') );
            }
            if( $this->admin['level'] != 1 && $this->admin['adminid'] == $the_adminid ) 
            {
                exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: you can\'t edit your account, please contact admin.', 'danger') );
            }
            $info_text = 'Edit Reseller ID: <b>' . $adminid . '</b>';
            $info_icon = $this->img_path . '/icons/edit_24.png';
            $action = 'doEdit';
            $btn_submit = ' Save ';
            $class = 'p_edit';
            $the_adminid = intval($row['adminid']);
            $resel_bouquets = explode(',', $resel_bouquets);
            $subQry = ' AND adminid!=' . $the_adminid . ' ';
        }
        else if( $t == 'add' ) 
        {
            if( isset($_POST) && $_POST != null ) 
            {
                extract($_POST);
            }
            $info_text = 'Add New Reseller';
            $info_icon = ' ';
            $action = 'doAdd';
            $btn_submit = ' Save ';
            $class = 'p_add';
            $act_count = ($act_count == '' ? 0 : $act_count);
            if( $this->admin['level'] == 6 ) 
            {
                $FATHER = $intro->auth->admin_data();
                $cost_1 = ($cost_1 == '' ? $FATHER['cost_1'] : $cost_1);
                $cost_3 = ($cost_3 == '' ? $FATHER['cost_3'] : $cost_3);
                $cost_6 = ($cost_6 == '' ? $FATHER['cost_6'] : $cost_6);
                $cost_12 = ($cost_12 == '' ? $FATHER['cost_12'] : $cost_12);
                $cost_24 = ($cost_24 == '' ? $FATHER['cost_24'] : $cost_24);
                $cost_36 = ($cost_36 == '' ? $FATHER['cost_36'] : $cost_36);
                $cost_1_enabled = ($cost_1_enabled == '' ? $FATHER['cost_1_enabled'] : $cost_1_enabled);
                $cost_3_enabled = ($cost_3_enabled == '' ? $FATHER['cost_3_enabled'] : $cost_3_enabled);
                $cost_6_enabled = ($cost_6_enabled == '' ? $FATHER['cost_6_enabled'] : $cost_6_enabled);
                $cost_12_enabled = ($cost_12_enabled == '' ? $FATHER['cost_12_enabled'] : $cost_12_enabled);
                $cost_24_enabled = ($cost_24_enabled == '' ? $FATHER['cost_24_enabled'] : $cost_24_enabled);
                $cost_36_enabled = ($cost_36_enabled == '' ? $FATHER['cost_36_enabled'] : $cost_36_enabled);
            }
        }
        if( is_array($error) && count($error) > 0 ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Please fix the flowing errors', 'danger');
            echo '<ul>';
            foreach( $error as $k => $v ) 
            {
                echo '<li> ' . $v . ' </li>';
            }
            echo '</ul>';
        }
        echo '<fieldset><legend>' . $info_text . '</legend>';
        echo '<form method="POST" name="form_add"  action="' . $this->base . '/' . $action . "\" enctype=\"multipart/form-data\">\n\t\t <table align=\"center\" border=\"1\" width=\"100%\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\" class=\"table table-striped table-hover table-bordered\">";
        if( $this->admin['level'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Father: </td>\n\t\t\t\t<td>" . form_resellers('father', $father, 'None', 'WHERE father=0 ' . $subQry) . "</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>" . _ADMIN_ADMIN_NAME . (" : <font color=red>*</font></td>\n\t\t\t\t<td><input type=\"text\" name=\"admin_name\" value=\"" . $admin_name . '" size="30"> ') . $this->error('admin_name') . "</td>\n\t\t\t</tr>\n\n\t\t\t<tr>\n\t\t\t\t<td>" . _ADMIN_ADM_USERNAME . (" : <font color=red>*</font></td>\n\t\t\t\t<td><input type=\"text\" name=\"adm_username\" value=\"" . $adm_username . '" size="30">') . $this->error('adm_username') . "\n\t\t\t\t<br>Allowed characters: a-z A-Z 0-9 AND the sign - (don't use spaces)\n\t\t\t\t</td>\n\t\t\t</tr>\n\n\t\t\t<tr>\n\t\t\t\t<td>" . _ADMIN_ADM_PASSWORD . (" : <font color=red>*</font></td>\n\t\t\t\t<td><input type=\"password\" name=\"adm_password\" size=\"30\"> " . $intro->lang['users_type_pass_to_changeit'] . ' ') . $this->error('adm_password') . "</td>\n\t\t\t</tr>\n\n\t\t\t<tr>\n\t\t\t\t<td>" . _ADMIN_EMAIL . (" : </td>\n\t\t\t\t<td><input type=\"text\" name=\"email\" value=\"" . $email . '" size="30"> ') . $this->error('email') . "</td>\n\t\t\t</tr>";
        if( $this->admin['level'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Level: </td>\n\t\t\t\t<td>" . $this->level($level) . ' ' . $this->error('level') . "</td>\n\t\t\t</tr>";
            echo "\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Logo & Brandname :</th>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Logo: </td>\n\t\t\t\t<td><input type=\"file\" name=\"logo\" value=\"\">";
            if( $t == 'edit' && $logo != '' ) 
            {
                echo '<img src="data:image/png;base64,' . base64_encode(stripslashes($logo)) . '" style="max-height:100px;">';
                echo '<div><input type=\'checkbox\' name=\'remove_logo\' value=\'1\'> Remove Logo </div>';
            }
            echo "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Brand Name: </td>\n\t\t\t\t<td><input type=\"text\" name=\"brand\" value=\"" . $brand . "\" size=\"40\"></td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Host (DNS): </td>\n\t\t\t\t<td><input type=\"text\" name=\"host\" value=\"" . $host . "\" size=\"40\"> like: example.com, don't put: http</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Service :</th>\n\t\t\t</tr>";
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_codes'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Add Codes : </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_codes', $can_add_codes, 1, 'Yes', 'No', 'primary') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_users'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Add Users : </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_users', $can_add_users, 1, 'Yes', 'No', 'primary') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_mag'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Add MAG : </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_mag', $can_add_mag, 1, 'Yes', 'No', 'primary') . "</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Service Price :</th>\n\t\t\t</tr>\t\n\t\t\t<tr>\n\t\t\t\t<td>Total free Codes/Users/MAG : </td>\n\t\t\t\t<td><input type=\"text\" name=\"num_free\" value=\"" . $num_free . "\" size=\"10\"> \n\t\t\t\t\t " . (($this->admin['level'] == 1 ? '-1 = Unlimited' : ' MAX = ' . $this->adminRow['num_free'])) . ' ' . $this->error('num_free') . "\n\t\t\t\t\t<div id=\"num_free_err_msg\" class=\"label label-danger\"></div></td>\n\t\t\t</tr>";
        if( $this->admin['level'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Extra free days : </td>\n\t\t\t\t<td> <input type=\"text\" name=\"extra_free_days\" value=\"" . $extra_free_days . "\" size=\"30\"> Example: 30,90,180 etc.. </td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['postpaid'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Postpaid : </td>\n\t\t\t\t<td> " . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('postpaid', $postpaid, 1, 'Yes', 'No', 'primary') . " (Reseller will pay later. He can add codes/users with Zero balance.)</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 ) 
        {
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_free_1'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 1 days : </td>\n\t\t\t\t<td> " . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_free_1', $can_add_free_1, 1, 'Yes', 'No', 'primary') . " </td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_free_3'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 3 days : </td>\n\t\t\t\t<td> " . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_free_3', $can_add_free_3, 1, 'Yes', 'No', 'primary') . " </td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_free_7'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 7 days : </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_free_7', $can_add_free_7, 1, 'Yes', 'No', 'primary') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_free_10'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 10 days : </td>\n\t\t\t\t<td> " . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_free_10', $can_add_free_10, 1, 'Yes', 'No', 'primary') . " </td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['cost_1_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> 1 Month | Cost: </td>\n\t\t\t\t<td>\n\t\t\t\t\t<input type=\"text\" name=\"cost_1\" value=\"" . $cost_1 . '" size="15"> ' . $this->error('cost_1') . "\n\t\t\t\t\t" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('cost_1_enabled', $cost_1_enabled, 1, 'Enabled ', 'Disabled', 'info') . "\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['cost_3_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>3 Months | Cost: </td>\n\t\t\t\t<td>\n\t\t\t\t\t<input type=\"text\" name=\"cost_3\" value=\"" . $cost_3 . '" size="15"> ' . $this->error('cost_3') . "\n\t\t\t\t\t" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('cost_3_enabled', $cost_3_enabled, 1, 'Enabled ', 'Disabled', 'info') . "\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['cost_6_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>6 Months |  Cost: </td>\n\t\t\t\t<td>\n\t\t\t\t\t<input type=\"text\" name=\"cost_6\" value=\"" . $cost_6 . '" size="15"> ' . $this->error('cost_6') . "\n\t\t\t\t\t" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('cost_6_enabled', $cost_6_enabled, 1, 'Enabled ', 'Disabled', 'info') . "\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['cost_12_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>12 Months | Cost: </td>\n\t\t\t\t<td>\n\t\t\t\t\t<input type=\"text\" name=\"cost_12\" value=\"" . $cost_12 . '" size="15"> ' . $this->error('cost_12') . "\n\t\t\t\t\t" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('cost_12_enabled', $cost_12_enabled, 1, 'Enabled ', 'Disabled', 'info') . "\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['cost_24_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>2 Years | Cost: </td>\n\t\t\t\t<td>\n\t\t\t\t\t<input type=\"text\" name=\"cost_24\" value=\"" . $cost_24 . '" size="15"> ' . $this->error('cost_24') . "\n\t\t\t\t\t" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('cost_24_enabled', $cost_24_enabled, 1, 'Enabled ', 'Disabled', 'info') . "\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['cost_36_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>3 Years | Cost: </td>\n\t\t\t\t<td>\n\t\t\t\t\t<input type=\"text\" name=\"cost_36\" value=\"" . $cost_36 . '" size="15"> ' . $this->error('cost_36') . "\n\t\t\t\t\t" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('cost_36_enabled', $cost_36_enabled, 1, 'Enabled ', 'Disabled', 'info') . "\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Other Options:</th>\n\t\t\t</tr>";
        if( $this->admin['level'] == 1 && isset($options['opt_activation_count']) && $options['opt_activation_count'] == 'yes' ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Code Activation Count: </td>\n\t\t\t\t<td> <input type=\"text\" name=\"act_count\" value=\"" . $act_count . "\" size=\"5\">\n\t\t\t\t\t<i>Te number of times the code can be activated. enter 0 for unlimited.</i></td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_m3u'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Download <span class='label label-success icon-download'>m3u</span> file <strong>(for Codes only)</strong>: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_m3u', $can_m3u, 1, 'Yes ', 'No', 'success') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_mac'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Add Codes By MAC <span class='icon-maxcdn'></span>: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_mac', $can_add_mac, 1, 'Yes ', 'No', '') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_sn'] == 1 ) 
        {
            echo "\t\n\t\t\t<tr>\n\t\t\t\t<td>Add Codes By Serial <span class='icon-barcode'></span>: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_sn', $can_add_sn, 1, 'Yes ', 'No', '') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_add_free'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allow <span class='label label-primary icon-plus'>add</span> Free Codes/Users/MAG: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_free', $can_add_free, 1, 'Yes ', 'No', 'primary') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_delete'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allow <span class='label label-danger icon-trash'>Delete</span> Codes/Users/MAG + Invoices: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_delete', $can_delete, 1, 'Yes ', 'No', 'danger') . "</td>\n\t\t\t</tr>";
        }
        if( $this->admin['level'] == 1 || $this->admin['level'] == 6 && $this->adminRow['can_change'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allow <span class='label label-info icon-edit'>Change/Edit</span> Codes/Users/MAG: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_change', $can_change, 1, 'Yes ', 'No', 'info') . "</td>\n\t\t\t</tr>";
        }
        $all = '';
        if( $this->admin['level'] == 1 ) 
        {
            $all = 'all';
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>Packages (Bouquets): \n\t\t\t\t\t<div style=\"float:right;\">\n\t\t\t\t\t\t   <input type=\"checkbox\" id=\"checkAll\"/> <b>Check All</b>\n\t\t\t\t\t</div>\n\t\t\t\t</td>\n\t\t\t\t<td id=\"tdBouquets\">" . bouquets($resel_bouquets, $all) . ' ' . $this->error('resel_bouquets') . "</td>\n\t\t\t</tr>";
        if( $this->admin['level'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Group: </td>\n\t\t\t\t<td>" . $this->selGroup($group_id) . "</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allowed IPs :</td>\n\t\t\t\t<td>\n\t\t\t\tIf you put here the IPs of reseller, he will only allowed to login from these IPs. <br>\n\t\t\t\tEnter each IP in a separate line. \n\t\t\t\t<textarea name=\"allowed_ips\" class=\"form-control\" style='width:100%;height:70px;'>" . $allowed_ips . "</textarea></td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Message to Reseller:\n\t\t\t\t\t<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\"></script>\n\t\t\t\t\t<link href=\"https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css\" rel=\"stylesheet\">\n\t\t\t\t\t<script src=\"https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js\"></script>\n\t\t\t\t</td>\n\t\t\t\t<td><textarea id='msg_welcome' name=\"msg_welcome\" class=\"form-control\" style='width:100%;height:80px;'>" . $msg_welcome . "</textarea>\n\t\t\t\t\t<script>\n\t\t\t\t\t  \$('#msg_welcome').summernote({\n\t\t\t\t\t\tplaceholder: 'type here a message to reseller',\n\t\t\t\t\t\ttabsize: 2,\n\t\t\t\t\t\theight: 100,\n\t\t\t\t\t\ttoolbar: [\n\t\t\t\t\t\t\t['style', ['style','bold', 'italic', 'underline', 'clear']],\t\t\t\t\t\t\n\t\t\t\t\t\t\t['fontsize', ['fontsize']],\n\t\t\t\t\t\t\t['color', ['color']],\n\t\t\t\t\t\t\t['para', ['ul', 'ol', 'paragraph']],\n\t\t\t\t\t\t\t['height', ['height']],\n\t\t\t\t\t\t\t['insert', ['link']],\n\t\t\t\t\t\t\t['view', ['fullscreen', 'codeview']]\n\t\t\t\t\t\t  ]\n\t\t\t\t\t  });\n\t\t\t\t\t</script>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Notes :</td>\n\t\t\t\t<td><textarea name=\"notes\" class=\"form-control\" style='width:100%;height:80px;'>" . $notes . "</textarea></td>\n\t\t\t</tr>";
        if( $this->admin['level'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Manage Movies/Series/Streams</th>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Manage Movies/Series: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('manage_vod', $manage_vod, 1, 'Yes ', 'No', 'info') . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Manage Streams: </td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('manage_streams', $manage_streams, 1, 'Yes ', 'No', 'info') . "</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t<td class=\"center\" colspan=\"2\">\n\t\t\t\t<input type=\"hidden\" name=\"old_group_id\"  value=\"" . $group_id . "\">\n\t\t\t\t<input type=\"hidden\" name=\"maa\"  value=\"" . $action . "\">\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\n\t\t\t\t<input type=\"hidden\" name=\"the_adminid\"  value=\"" . $the_adminid . "\">\n\t\t\t\t<input class=" . $class . ' id=\'btnAddEditAdmin\' type="submit" value=" ' . $btn_submit . " \" name=\"B1\">\t\t\t\t\n\t\t\t</td>\n\t\t</tr>\n\t\t</table>\n\t\t</form>\n\t\t</fieldset>\n\t\t<br/><br/><br/>";
        echo "<script>\n\t\t\$(document).ready(function(){\n\t\t\t\n\t\t\t\$(\"#checkAll\").change(function () {\n\t\t\t\t\$(\"#tdBouquets input:checkbox\").prop('checked', \$(this).prop(\"checked\"));\n\t\t\t});";
        if( $this->admin['level'] == 6 ) 
        {
            echo "\n\t\t\t\t\$(\"input[name='num_free']\").focusout(function() {\n\t\t\t\t\t\n\t\t\t\t\tvar userInput = \$(\"input[name='num_free']\").val();\n\t\t\t\t\t\$.getJSON( \"" . $this->base . "/checkNumFree?NH=1\", { val: userInput}).done( function( json ) {\n\t\t\t\t\t\t\n\t\t\t\t\t\tif(json.status == 100){\n\t\t\t\t\t\t\t \$('#num_free_err_msg').html('');\n\t\t\t\t\t\t\t \$('#btnAddEditAdmin').removeAttr('disabled');\n\t\t\t\t\t\t}else{\n\t\t\t\t\t\t\t\$('#num_free_err_msg').html(json.msg);\n\t\t\t\t\t\t\t\$('#btnAddEditAdmin').prop('disabled', true);\n\t\t\t\t\t\t}\n\t\t\t\t\t\t\n\t\t\t\t\t});\n\t\t\t\t});";
        }
        echo "\n\t\t\t\n\t\t});\n\t\t</script>";
    }
    public function checkNumFree()
    {
        global $intro;
        $val = intval($intro->input->get_post('val'));
        $num_free = $this->adminRow['num_free'];
        $ar = [];
        if( $num_free == 0 ) 
        {
            $ar['status'] = 200;
            $ar['msg'] = 'Error: your don\'t have free codes.';
        }
        else if( $num_free < $val ) 
        {
            $ar['status'] = 200;
            $ar['msg'] = 'Error: your max free codes are ' . $num_free . '.';
        }
        else
        {
            $ar['status'] = 100;
            $ar['msg'] = '';
        }
        header('Content-type: application/json; charset=utf-8');
        echo json_encode($ar);
    }
    public function stb_groups($stb_groups = [])
    {
        global $intro;
        $html = "<select name=\"stb_groups[]\" id=\"stb_groups\" style=\"width:250px;\" size=\"6\" multiple>\n";
        $sql = $intro->db->query('SELECT * from ' . PREFIX . '_stb_groups order by stb_gname ASC');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            extract($row);
            $html .= ('<option value="' . $stb_gid . '" ' . ((is_array($stb_groups) && in_array($stb_gid, $stb_groups) ? 'selected=\'selected\'' : '')) . ('>' . $stb_gname . "</options>\n"));
        }
        $html .= "</select>\n";
        return $html;
    }
    public function selGroup($comp = 0)
    {
        global $intro;
        $html = "<select name=\"group_id\" id=\"group_id\" style=\"width:250px;\">\n\n\t\t<option value=\"0\" selected='selected'>All</options>\n";
        $sql = $intro->db->query('SELECT * from ' . PREFIX . '_admin_groups order by g_name ASC');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            extract($row);
            $html .= ('<option value="' . $g_id . '" ' . (($comp == $g_id ? 'selected=\'selected\'' : '')) . ('>' . $g_name . "</options>\n"));
        }
        $html .= "</select>\n";
        return $html;
    }
    public function yes_no($name, $val)
    {
        $html = " <label class=\"radio-inline\">\n\t\t<input type=\"radio\" name=\"" . $name . '" value="1" ' . (($val == 1 ? 'checked' : '')) . '>Yes</label>';
        $html .= (" <label class=\"radio-inline\">\n\t\t<input type=\"radio\" name=\"" . $name . '" value="0" ' . (($val == 0 ? 'checked' : '')) . '>No</label>');
        return $html;
    }
    public function doAddGroup()
    {
        global $intro;
        $g_name = trim($intro->input->post('g_name'));
        if( $g_name == '' ) 
        {
            exit( '<span class="label label-danger">Required!</label>' );
        }
        $data = [];
        $data['g_name'] = $g_name;
        $intro->db->insert(PREFIX . '_admin_groups', $data);
        echo 'Success!';
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $options;
        $adm = $sess_admin['adminid'];
        $app = $this->appname;
        policy($adm, $app . '.php', 'add');
        $admin_name = trim($intro->input->post('admin_name'));
        $adm_username = trim($intro->input->post('adm_username'));
        $adm_password = trim($intro->input->post('adm_password'));
        $email = trim($intro->input->post('email'));
        $cost_1 = floatval($intro->input->post('cost_1'));
        $cost_3 = floatval($intro->input->post('cost_3'));
        $cost_6 = floatval($intro->input->post('cost_6'));
        $cost_12 = floatval($intro->input->post('cost_12'));
        $cost_24 = floatval($intro->input->post('cost_24'));
        $cost_36 = floatval($intro->input->post('cost_36'));
        $level = intval($intro->input->post('level'));
        $group_id = intval($intro->input->post('group_id'));
        $can_delete = intval($intro->input->post('can_delete'));
        $can_change = intval($intro->input->post('can_change'));
        $can_add_free = intval($intro->input->post('can_add_free'));
        $can_add_mac = intval($intro->input->post('can_add_mac'));
        $can_add_sn = intval($intro->input->post('can_add_sn'));
        $num_free = intval($intro->input->post('num_free'));
        $can_m3u = intval($intro->input->post('can_m3u'));
        $can_add_users = intval($intro->input->post('can_add_users'));
        $can_add_mag = intval($intro->input->post('can_add_mag'));
        $resel_bouquets = $intro->input->post('bouquets');
        $regdate = date('Y-m-d H:i:s');
        if( $level == 0 && $this->admin['level'] == 1 || $admin_name == '' || $adm_username == '' || $adm_password == '' || $resel_bouquets == null ) 
        {
            if( $level == 0 && $this->admin['level'] == 1 ) 
            {
                $error['level'] = '<font class=error>' . $intro->lang['required'] . '</font>';
            }
            if( $admin_name == '' ) 
            {
                $error['admin_name'] = '<font class=error>' . $intro->lang['required'] . '</font>';
            }
            if( $adm_username == '' ) 
            {
                $error['adm_username'] = '<font class=error>' . $intro->lang['required'] . '</font>';
            }
            if( $adm_password == '' ) 
            {
                $error['adm_password'] = '<font class=error>' . $intro->lang['required'] . '</font>';
            }
            if( $resel_bouquets == null ) 
            {
                $error['resel_bouquets'] = '<span class=error>Please choose at least one Bouquets/PACKAGE</span>';
            }
            $t = 'add';
            $this->Form();
            exit();
        }
        $data = [];
        if( $this->admin['level'] == 1 ) 
        {
            $data['father'] = intval($intro->input->post('father'));
        }
        $data['admin_name'] = $admin_name;
        $data['adm_username'] = $adm_username;
        $data['adm_password'] = $intro->pwd($adm_password);
        $data['email'] = $email;
        $data['regdate'] = $regdate;
        $data['level'] = $level;
        $data['cost_1'] = $cost_1;
        $data['cost_3'] = $cost_3;
        $data['cost_6'] = $cost_6;
        $data['cost_12'] = $cost_12;
        $data['cost_36'] = $cost_36;
        $data['can_add_free'] = $can_add_free;
        $data['resel_bouquets'] = implode(',', $resel_bouquets);
        $data['can_delete'] = $can_delete;
        $data['can_change'] = $can_change;
        $data['group_id'] = $group_id;
        $data['can_add_mac'] = $can_add_mac;
        $data['can_add_sn'] = $can_add_sn;
        $data['can_m3u'] = $can_m3u;
        $data['can_add_codes'] = intval($intro->input->post('can_add_codes'));
        $data['can_add_users'] = $can_add_users;
        $data['can_add_mag'] = $can_add_mag;
        $data['host'] = trim($intro->input->post('host'));
        $data['postpaid'] = intval($intro->input->post('postpaid'));
        $data['can_add_free_1'] = intval($intro->input->post('can_add_free_1'));
        $data['can_add_free_3'] = intval($intro->input->post('can_add_free_3'));
        $data['can_add_free_7'] = intval($intro->input->post('can_add_free_7'));
        $data['can_add_free_10'] = intval($intro->input->post('can_add_free_10'));
        $data['cost_1_enabled'] = intval($intro->input->post('cost_1_enabled'));
        $data['cost_3_enabled'] = intval($intro->input->post('cost_3_enabled'));
        $data['cost_6_enabled'] = intval($intro->input->post('cost_6_enabled'));
        $data['cost_12_enabled'] = intval($intro->input->post('cost_12_enabled'));
        $data['cost_24_enabled'] = intval($intro->input->post('cost_24_enabled'));
        $data['cost_36_enabled'] = intval($intro->input->post('cost_36_enabled'));
        $data['num_free'] = intval($intro->input->post('num_free'));
        $data['act_count'] = intval($intro->input->post('act_count'));
        $data['notes'] = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->post('notes'), '{ar}\n ');
        $data['allowed_ips'] = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->post('allowed_ips'), '.\n');
        $data['msg_welcome'] = strip_tags($intro->input->post('msg_welcome'), '<h1><h2><h3><h4><p><a><b><i><span><div>');
        if( $this->admin['level'] == 6 ) 
        {
            $FATHER = $intro->auth->admin_data();
            if( $FATHER['cost_1_enabled'] == 1 && $cost_1 < $FATHER['cost_1'] || $FATHER['cost_3_enabled'] == 1 && $cost_3 < $FATHER['cost_3'] || $FATHER['cost_6_enabled'] == 1 && $cost_6 < $FATHER['cost_6'] || $FATHER['cost_12_enabled'] == 1 && $cost_12 < $FATHER['cost_12'] || $FATHER['cost_24_enabled'] == 1 && $cost_24 < $FATHER['cost_24'] || $FATHER['cost_36_enabled'] == 1 && $cost_36 < $FATHER['cost_36'] ) 
            {
                if( $data['cost_1_enabled'] == 1 && $cost_1 < $FATHER['cost_1'] ) 
                {
                    $error['cost_1'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_1'] . '</font>';
                }
                if( $data['cost_3_enabled'] == 1 && $cost_3 < $FATHER['cost_3'] ) 
                {
                    $error['cost_3'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_3'] . '</font>';
                }
                if( $data['cost_6_enabled'] == 1 && $cost_6 < $FATHER['cost_6'] ) 
                {
                    $error['cost_6'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_6'] . '</font>';
                }
                if( $data['cost_12_enabled'] == 1 && $cost_12 < $FATHER['cost_12'] ) 
                {
                    $error['cost_12'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_12'] . '</font>';
                }
                if( $data['cost_24_enabled'] == 1 && $cost_24 < $FATHER['cost_24'] ) 
                {
                    $error['cost_24'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_24'] . '</font>';
                }
                if( $data['cost_36_enabled'] == 1 && $cost_36 < $FATHER['cost_36'] ) 
                {
                    $error['cost_36'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_36'] . '</font>';
                }
                $t = 'add';
                $this->Form();
                exit();
            }
            $data['group_id'] = intval($FATHER['group_id']);
            $data['act_count'] = intval($FATHER['act_count']);
            $data['level'] = 7;
            $data['father'] = intval($FATHER['adminid']);
        }
        if( $this->admin['level'] == 1 ) 
        {
            $data['no_invoice'] = intval($intro->input->post('no_invoice'));
            $data['extra_free_days'] = trim($intro->input->post('extra_free_days'));
            $data['manage_streams'] = intval($intro->input->post('manage_streams'));
            $data['manage_vod'] = intval($intro->input->post('manage_vod'));
        }
        $intro->db->insert(PREFIX . '_admin', $data);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $sess_admin;
        global $error;
        global $options;
        $stb_groups = $intro->input->post('stb_groups');
        policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
        $admin_name = trim($intro->input->post('admin_name'));
        $adm_username = trim($intro->input->post('adm_username'));
        $adm_password = $intro->input->post('adm_password');
        $email = trim($intro->input->post('email'));
        $the_adminid = intval($intro->input->post('the_adminid'));
        $isadmin = intval($intro->input->post('isadmin'));
        $level = intval($intro->input->post('level'));
        $can_delete = intval($intro->input->post('can_delete'));
        $can_change = intval($intro->input->post('can_change'));
        $group_id = intval($intro->input->post('group_id'));
        $cost_1 = floatval($intro->input->post('cost_1'));
        $cost_3 = floatval($intro->input->post('cost_3'));
        $cost_6 = floatval($intro->input->post('cost_6'));
        $cost_12 = floatval($intro->input->post('cost_12'));
        $cost_24 = floatval($intro->input->post('cost_24'));
        $cost_36 = floatval($intro->input->post('cost_36'));
        $resel_bouquets = $intro->input->post('bouquets');
        $can_add_free = intval($intro->input->post('can_add_free'));
        $can_add_mac = intval($intro->input->post('can_add_mac'));
        $can_add_sn = intval($intro->input->post('can_add_sn'));
        $can_m3u = intval($intro->input->post('can_m3u'));
        $can_add_users = intval($intro->input->post('can_add_users'));
        $can_add_mag = intval($intro->input->post('can_add_mag'));
        $adminid = $the_adminid;
        if( $resel_bouquets == '' ) 
        {
            $resel_bouquets = [];
        }
        $data = [];
        if( $this->admin['level'] == 1 && $the_adminid != 1 ) 
        {
            $data['father'] = intval($intro->input->post('father'));
        }
        $result = $intro->db->query('SELECT * FROM ' . PREFIX . ('_admin where adminid=' . $the_adminid));
        $row_admin = $intro->db->fetch_assoc($result);
        $data['level'] = $level;
        $data['admin_name'] = $admin_name;
        $data['adm_username'] = $adm_username;
        $data['email'] = $email;
        $data['cost_1'] = $cost_1;
        $data['cost_3'] = $cost_3;
        $data['cost_6'] = $cost_6;
        $data['cost_12'] = $cost_12;
        $data['cost_24'] = $cost_24;
        $data['cost_36'] = $cost_36;
        $data['can_add_free'] = $can_add_free;
        $data['resel_bouquets'] = implode(',', $resel_bouquets);
        $data['can_delete'] = $can_delete;
        $data['can_change'] = $can_change;
        $data['group_id'] = $group_id;
        $data['can_add_mac'] = $can_add_mac;
        $data['can_add_sn'] = $can_add_sn;
        $data['can_m3u'] = $can_m3u;
        $data['can_add_codes'] = intval($intro->input->post('can_add_codes'));
        $data['can_add_users'] = $can_add_users;
        $data['can_add_mag'] = $can_add_mag;
        if( $stb_groups && is_array($stb_groups) && count($stb_groups) >= 1 && isset($stb_groups[0]) && $stb_groups[0] >= 1 ) 
        {
            $data['stb_groups'] = json_encode($stb_groups, JSON_FORCE_OBJECT);
        }
        else
        {
            $data['stb_groups'] = '';
        }
        $data['postpaid'] = intval($intro->input->post('postpaid'));
        $data['can_add_free_1'] = intval($intro->input->post('can_add_free_1'));
        $data['can_add_free_3'] = intval($intro->input->post('can_add_free_3'));
        $data['can_add_free_7'] = intval($intro->input->post('can_add_free_7'));
        $data['can_add_free_10'] = intval($intro->input->post('can_add_free_10'));
        $data['cost_1_enabled'] = intval($intro->input->post('cost_1_enabled'));
        $data['cost_3_enabled'] = intval($intro->input->post('cost_3_enabled'));
        $data['cost_6_enabled'] = intval($intro->input->post('cost_6_enabled'));
        $data['cost_12_enabled'] = intval($intro->input->post('cost_12_enabled'));
        $data['cost_24_enabled'] = intval($intro->input->post('cost_24_enabled'));
        $data['cost_36_enabled'] = intval($intro->input->post('cost_36_enabled'));
        $data['num_free'] = intval($intro->input->post('num_free'));
        if( $adm_password != '' ) 
        {
            $data['adm_password'] = $intro->pwd($adm_password);
        }
        if( $adminid == 1 ) 
        {
            $data['level'] = 1;
            $data['can_add_free'] = 1;
            $data['can_delete'] = 1;
            $data['can_change'] = 1;
            $data['can_add_users'] = 1;
            $data['can_add_mag'] = 1;
        }
        if( $this->admin['level'] == 6 ) 
        {
            $FATHER = $intro->auth->admin_data();
            $data['group_id'] = intval($FATHER['group_id']);
            $data['act_count'] = intval($FATHER['act_count']);
            $data['host'] = $FATHER['host'];
            $data['level'] = 7;
            if( $FATHER['cost_1_enabled'] == 1 && $cost_1 < $FATHER['cost_1'] || $FATHER['cost_3_enabled'] == 1 && $cost_3 < $FATHER['cost_3'] || $FATHER['cost_6_enabled'] == 1 && $cost_6 < $FATHER['cost_6'] || $FATHER['cost_12_enabled'] == 1 && $cost_12 < $FATHER['cost_12'] || $FATHER['cost_24_enabled'] == 1 && $cost_24 < $FATHER['cost_24'] || $FATHER['cost_36_enabled'] == 1 && $cost_36 < $FATHER['cost_36'] ) 
            {
                if( $data['cost_1_enabled'] == 1 && $cost_1 < $FATHER['cost_1'] ) 
                {
                    $error['cost_1'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_1'] . '</font>';
                }
                if( $data['cost_3_enabled'] == 1 && $cost_3 < $FATHER['cost_3'] ) 
                {
                    $error['cost_3'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_3'] . '</font>';
                }
                if( $data['cost_6_enabled'] == 1 && $cost_6 < $FATHER['cost_6'] ) 
                {
                    $error['cost_6'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_6'] . '</font>';
                }
                if( $data['cost_12_enabled'] == 1 && $cost_12 < $FATHER['cost_12'] ) 
                {
                    $error['cost_12'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_12'] . '</font>';
                }
                if( $data['cost_24_enabled'] == 1 && $cost_24 < $FATHER['cost_24'] ) 
                {
                    $error['cost_24'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_24'] . '</font>';
                }
                if( $data['cost_36_enabled'] == 1 && $cost_36 < $FATHER['cost_36'] ) 
                {
                    $error['cost_36'] = '<font class=error>Error: Amount must be greater than cost. Your cost is: ' . $FATHER['cost_36'] . '</font>';
                }
                $t = 'edit';
                $this->Form('edit');
                exit();
            }
        }
        if( $this->admin['level'] == 1 ) 
        {
            if( is_uploaded_file($_FILES['logo']['tmp_name']) ) 
            {
                $logo = addslashes(file_get_contents($_FILES['logo']['tmp_name']));
                $data['logo'] = $logo;
            }
            $data['brand'] = trim($intro->input->post('brand'));
            $data['host'] = trim($intro->input->post('host'));
            $data['act_count'] = intval($intro->input->post('act_count'));
            if( $level == 6 ) 
            {
                $dataS = [];
                $dataS['can_add_codes'] = $data['can_add_codes'];
                $dataS['can_add_users'] = $data['can_add_users'];
                $dataS['can_add_mag'] = $data['can_add_mag'];
                $dataS['can_add_free_1'] = $data['can_add_free_1'];
                $dataS['can_add_free_3'] = $data['can_add_free_3'];
                $dataS['can_add_free_7'] = $data['can_add_free_7'];
                $dataS['can_add_free_10'] = $data['can_add_free_10'];
                $dataS['cost_1_enabled'] = $data['cost_1_enabled'];
                $dataS['cost_3_enabled'] = $data['cost_1_enabled'];
                $dataS['cost_6_enabled'] = $data['cost_6_enabled'];
                $dataS['cost_12_enabled'] = $data['cost_12_enabled'];
                $dataS['cost_24_enabled'] = $data['cost_24_enabled'];
                $dataS['cost_36_enabled'] = $data['cost_36_enabled'];
                $dataS['can_m3u'] = $data['can_m3u'];
                $dataS['can_add_mac'] = $data['can_add_mac'];
                $dataS['can_add_sn'] = $data['can_add_sn'];
                $dataS['can_add_free'] = $data['can_add_free'];
                $dataS['can_delete'] = $data['can_delete'];
                $dataS['can_change'] = $data['can_change'];
                $dataS['resel_bouquets'] = $data['resel_bouquets'];
                $dataS['host'] = $data['host'];
                $dataS['act_count'] = $data['act_count'];
                $dataS['brand'] = $data['brand'];
                $dataS['logo'] = (isset($data['logo']) ? $data['logo'] : '');
                $intro->db->update(PREFIX . '_admin', $dataS, 'father=\'' . $adminid . '\'');
            }
        }
        if( intval($intro->input->post('remove_logo')) == 1 ) 
        {
            $data['logo'] = '';
            $intro->db->update(PREFIX . '_admin', ['logo' => ''], 'father=\'' . $adminid . '\'');
        }
        if( $group_id != intval($intro->input->post('old_group_id')) ) 
        {
            $intro->db->query('UPDATE ' . PREFIX . ('_codes SET groupID=' . $group_id . ' WHERE adminid=\'' . $adminid . '\' '));
        }
        if( $this->admin['level'] == 6 && $this->admin['adminid'] == $adminid ) 
        {
            unset($data['admin_name']);
            unset($data['adm_username']);
        }
        if( $this->admin['level'] == 1 ) 
        {
            $data['extra_free_days'] = trim($intro->input->post('extra_free_days'));
            $data['manage_streams'] = intval($intro->input->post('manage_streams'));
            $data['manage_vod'] = intval($intro->input->post('manage_vod'));
        }
        if( $this->admin['level'] != 1 ) 
        {
            unset($data['father']);
        }
        $data['notes'] = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->post('notes'), '{ar}\n ');
        $data['allowed_ips'] = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->post('allowed_ips'), '.\n');
        $data['msg_welcome'] = strip_tags($intro->input->post('msg_welcome'), '<h1><h2><h3><h4><p><a><b><i><span><div>');
        $intro->db->update(PREFIX . '_admin', $data, 'adminid=\'' . $adminid . '\' ' . $this->qry_where_father);
        unset($row_admin['regdate']);
        unset($row_admin['lastlogin']);
        unset($row_admin['user_agent']);
        unset($row_admin['ipaddress']);
        $new = array_diff($row_admin, $data);
        $ar = [];
        foreach( $new as $key => $val ) 
        {
            $ar[$key] = [
                'before' => (isset($row_admin[$key]) ? $row_admin[$key] : ''), 
                'after' => (isset($data[$key]) ? $data[$key] : '')
            ];
        }
        _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222($this->appname, 'edit_resel', 'ReselID=' . $adminid . '|name=' . $admin_name . '|user=' . $adm_username . ' <hr>' . json_encode($ar));
        $intro->redirect($this->appname);
    }
    public function DelCodesPay()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $the_adminid = intval($intro->input->get_post('the_adminid'));
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        if( $the_adminid == $this->admin['adminid'] ) 
        {
            $this->nav();
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h3>Sorry: you can\'t delete your account.</h3>', 'danger');
            exit();
        }
        $intro->db->query('DELETE FROM ' . PREFIX . ('_trans where admin=' . $the_adminid . ';'));
        $intro->db->query('DELETE FROM ' . PREFIX . ('_codes where adminid=' . $the_adminid . ';'));
        $intro->db->query('DELETE FROM ' . PREFIX . ('_codes_trans where adminid=' . $the_adminid . ';'));
        $intro->redirect($this->appname, 'Del', '?the_adminid=' . $the_adminid);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $the_adminid = intval($intro->input->get_post('the_adminid'));
        $del = trim($intro->input->get_post('del'));
        $adm = $sess_admin['adminid'];
        $name = $array['admins'][$the_adminid];
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        if( $the_adminid == $this->admin['adminid'] ) 
        {
            $this->nav();
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h3>Sorry: you can\'t delete your account.</h3>', 'danger');
            exit();
        }
        if( $del == 'ok' ) 
        {
            if( $adm == 1 ) 
            {
                $intro->db->query('DELETE FROM ' . PREFIX . ('_trans where admin=' . $the_adminid . ';'));
                $intro->db->query('DELETE FROM ' . PREFIX . ('_codes where adminid=' . $the_adminid . ';'));
                $intro->db->query('DELETE FROM ' . PREFIX . ('_codes_trans where adminid=' . $the_adminid . ';'));
            }
            $intro->db->query('DELETE FROM ' . PREFIX . ('_admin WHERE adminid=\'' . $the_adminid . '\' and adminid !=1 '));
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('<h3>The reseller (' . $name . ') has been deleted successfully.</h3>', 'success');
            $intro->redirect($this->appname);
            exit();
        }
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Delete Reseller: ' . $name, 'danger');
        $tot = 0;
        $tot += ($num_users = $intro->db->dcount('id', 'users', 'member_id=' . $the_adminid . ' AND is_mag=0 AND is_e2=0'));
        $tot += ($num_mag = $intro->db->dcount('id', 'users', 'member_id=' . $the_adminid . ' AND is_mag=1'));
        $tot += ($num_e2 = $intro->db->dcount('id', 'users', 'member_id=' . $the_adminid . ' AND is_e2=1'));
        $tot += ($num_resel = $intro->db->dcount('adminid', '' . PREFIX . '_admin', 'father=' . $the_adminid));
        $tot += ($num_codes = $intro->db->dcount('id', '' . PREFIX . '_codes', 'adminid=' . $the_adminid));
        $tot += ($num_inv = $intro->db->dcount('*', '' . PREFIX . '_trans', 'admin=' . $the_adminid));
        $tot += ($num_cod_tranz = $intro->db->dcount('*', '' . PREFIX . '_codes_trans', 'adminid=' . $the_adminid));
        $delBTN = '';
        if( $num_resel == 0 ) 
        {
            $delBTN = '<a href="' . $this->base . '/DelCodesPay?the_adminid=' . $the_adminid . "\" class='btn btn-danger btn-lg' \n\t\t\tOnClick=\"return confirm('Are you Sure?');\">\n\t\t\tClick here to Delete Codes, Trans, Payment, Invoices</a>";
        }
        echo "\n\t\t<div class='row'>\n\t\t\t<div class='col-md-6'>\n\t\t\t\t<ul class=\"list-group\">\n\t\t\t\t   <li class=\"list-group-item\">Found Sub Rellers <span class=\"badge\">" . $num_resel . "</span></li>\n\t\t\t\t  <li class=\"list-group-item\">Found Users <span class=\"badge\">" . $num_users . "</span></li>\n\t\t\t\t  <li class=\"list-group-item\">Found MAG Devices <span class=\"badge\">" . $num_mag . "</span></li>\n\t\t\t\t  <li class=\"list-group-item\">Found Enigma2 Devices <span class=\"badge\">" . $num_e2 . "</span></li>\n\t\t\t\t \n\t\t\t\t  <li class=\"list-group-item\">Found Codes <span class=\"badge\">" . $num_codes . "</span></li>\n\t\t\t\t  <li class=\"list-group-item\">Found Code Trans <span class=\"badge\">" . $num_cod_tranz . "</span></li>\n\t\t\t\t  <li class=\"list-group-item\">Found Invoices/Payments <span class=\"badge\">" . $num_inv . "</span></li>\n\t\t\t\t</ul>\n\t\t\t</div>\n\t\t</div>";
        if( $tot == 0 ) 
        {
            echo '<a href="' . $this->base . '/Del?the_adminid=' . $the_adminid . "&amp;del=ok\" class='btn btn-danger btn-lg' \n\t\t\t\t\tOnClick=\"return confirm('Are you Sure?');\">\n\t\t\t\t\tYes Delete: " . $name . '</a>';
        }
        else
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("<h3>Sorry: you can't delete this reseller. <br/>\n\t\t\tPlease first delete the found records.<br/>" . $delBTN . '</h3>', 'danger');
        }
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function FixActCount()
    {
        global $intro;
        global $array;
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . '_admin where level=6');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            echo '<li>' . $adm_username . ' ';
            $intro->db->query('UPDATE ' . PREFIX . ('_admin SET act_count=' . $act_count . ' ') . (' WHERE father=' . $adminid . ' AND level=7;'));
            echo '(' . $intro->db->affected_rows . ')';
        }
    }
    public function bq()
    {
        global $intro;
        global $array;
        if( isset($intro->option['BouquetsOrder']) && $intro->option['BouquetsOrder'] != '' ) 
        {
            $order = str_replace(':', ' ', $intro->option['BouquetsOrder']);
        }
        else
        {
            $order = 'id ASC';
        }
        $ar = [];
        $sql = $intro->db->query('SELECT id FROM bouquets WHERE bouquet_status=1 order by ' . $order);
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            $ar[] = $id;
        }
        return implode(',', $ar);
    }
    public function ImportRegUsers()
    {
        global $intro;
        global $array;
        $this->nav();
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $resel_bouquets = $this->bq();
        if( $intro->input->get('save') == 'yes' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h3>Update Success. Please don\'t refresh page.</h3>', 'success');
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Import Registered Users form Xtream Code panel', 'info');
        echo '<a class="btn btn-danger icon-upload" href="' . $this->base . '/ImportRegUsers/?save=yes" OnClick="return confirm(\'Danger! Danger! Danger! Dont click this button. You will change all resellers users.\');"> Update All New Resellers </a> ';
        echo "<table class='table table-bordered table-hover table-condensed'>\n\t\t<tr>\n\t\t\t<th>ID</th>\n\t\t\t<th>username</th>\n\t\t\t<th>email</th>\n\t\t\t<th>XC Balance</th>\n\t\t\t<th>Sub accounts</th>\n\t\t\n\t\t\t<th>Total Users</th>\n\t\t</tr>";
        $sql = $intro->db->query('SELECT *  ,(select count(id) from users where member_id=reg.id) AS tot_member_users  ,(select count(id) from users where created_by=reg.id) AS tot_createdby_users  FROM reg_users reg where owner_id=0 order by id ASC');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            $father = $id;
            $data = [];
            $data['adminid'] = $id;
            $data['father'] = 0;
            $data['admin_name'] = $username;
            $data['adm_username'] = $username;
            $data['adm_password'] = $intro->pwd(uniqid() . time());
            $data['email'] = $email;
            $data['regdate'] = date('Y-m-d H:i:s', $date_registered);
            $data['level'] = 3;
            $data['num_free'] = 0;
            $data['act_count'] = 0;
            $data['resel_bouquets'] = $resel_bouquets;
            $data['can_add_codes'] = 1;
            $data['can_add_users'] = 1;
            $data['can_add_mag'] = 1;
            if( $intro->input->get('save') == 'yes' ) 
            {
                $insert = $intro->db->insert(PREFIX . '_admin', $data, true);
            }
            echo "<tr>\n\t\t\t\t<td>" . $id . "</td>\n\t\t\t\t<td>" . $username . "</td>\n\t\t\t\t<td>" . $email . "</td>\n\t\t\t\t<td class='center'>" . $credits . '</td>';
            echo '<td>';
            $sql2 = $intro->db->query('SELECT *  ,(select count(id) from users where created_by=reg.id) AS tot_users2  ,(select count(id) from users where member_id=reg.id) AS tot_users_memb ' . (' FROM reg_users reg where owner_id=' . $id . ' order by id ASC'));
            if( $intro->db->returned_rows > 0 ) 
            {
                echo "<table border=1 style='width:100%'>\n\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t<th>ID</th>\n\t\t\t\t\t\t\t<th>username</th>\n\t\t\t\t\t\t\t<th>email</th>\n\t\t\t\t\t\t\t<th>XC Balance</th>\n\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t<th>users</th>\n\t\t\t\t\t\t</tr>";
                while( $row2 = $intro->db->fetch_assoc($sql2) ) 
                {
                    @extract($row2);
                    $tot_users2 = intval($tot_users2);
                    $tot_users_memb = intval($tot_users_memb);
                    echo "\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td class='c'>" . $id . "</td>\n\t\t\t\t\t\t<td class='c'>" . $username . "</td>\n\t\t\t\t\t\t<td class='c'>" . $email . "</td>\n\t\t\t\t\t\t<td class='center'>" . $credits . "</td>\n\t\t\t\t\t\t<td class='c'>" . $tot_users2 . ' ' . (($tot_users_memb != $tot_users2 ? '|' . $tot_users_memb : '')) . "</td>\n\t\t\t\t\t</tr>";
                    if( $intro->input->get('save') == 'yes' ) 
                    {
                        $data = [];
                        $data['adminid'] = $id;
                        $data['father'] = $father;
                        $data['admin_name'] = $username;
                        $data['adm_username'] = $username;
                        $data['adm_password'] = $intro->pwd(uniqid());
                        $data['email'] = $email;
                        $data['regdate'] = date('Y-m-d H:i:s', $date_registered);
                        $data['level'] = 7;
                        $data['num_free'] = 0;
                        $data['act_count'] = 0;
                        $data['resel_bouquets'] = $resel_bouquets;
                        $data['can_add_codes'] = 1;
                        $data['can_add_users'] = 1;
                        $data['can_add_mag'] = 0;
                        $intro->db->insert(PREFIX . '_admin', $data, true);
                    }
                }
                echo '</table>';
                if( $intro->input->get('save') == 'yes' ) 
                {
                    $intro->db->query('update ' . PREFIX . ('_admin SET level=6 WHERE adminid=' . $father));
                }
            }
            echo '</td>';
            $tot_member_users = intval($tot_member_users);
            $tot_createdby_users = intval($tot_createdby_users);
            echo '<td class=\'c\'>' . $tot_member_users . ' ' . (($tot_createdby_users != $tot_member_users ? '|' . $tot_createdby_users : '')) . "</td>\n\t\t\t</tr>";
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doImportRegUsers()
    {
        global $intro;
        global $array;
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $resel_bouquets = $this->bq();
        $sql = $intro->db->query('SELECT *  ,(select count(id) from users where member_id=reg.id) AS tot_member_users  ,(select count(id) from users where created_by=reg.id) AS tot_createdby_users  FROM reg_users reg where owner_id=0 AND username not in (select adm_username from ' . PREFIX . '_admin) order by id ASC');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            $data = [];
            $data['father'] = 0;
            $data['admin_name'] = $username;
            $data['adm_username'] = $username;
            $data['adm_password'] = $intro->pwd('12345x69995');
            $data['email'] = $email;
            $data['regdate'] = date('Y-m-d H:i:s', $date_registered);
            $data['level'] = 3;
            $data['num_free'] = 0;
            $data['act_count'] = 0;
            $data['resel_bouquets'] = $resel_bouquets;
            $data['can_add_codes'] = 1;
            $data['can_add_users'] = 1;
            $data['can_add_mag'] = 1;
            $intro->db->insert(PREFIX . '_admin', $data);
            $adminid = $intro->db->insert_id();
            if( $adminid > 0 && $id > 0 ) 
            {
                $intro->db->query('UPDATE `users` SET  created_by=' . $adminid . ' WHERE created_by=' . $id . ';');
                $intro->db->query('UPDATE `users` SET  member_id=' . $adminid . ' WHERE member_id=' . $id . ';');
            }
            $father = $adminid;
            $sql2 = $intro->db->query('SELECT *  ,(select count(id) from users where created_by=reg.id) AS tot_users2  ,(select count(id) from users where member_id=reg.id) AS tot_users_memb ' . (' FROM reg_users reg where owner_id=' . $id . ' AND username not in (select adm_username from ') . PREFIX . '_admin) order by id ASC');
            if( $intro->db->returned_rows > 0 ) 
            {
                while( $row2 = $intro->db->fetch_assoc($sql2) ) 
                {
                    @extract($row2);
                    $sub_resel_id = intval($row2['id']);
                    $tot_users2 = intval($tot_users2);
                    $tot_users_memb = intval($tot_users_memb);
                    $data = [];
                    $data['father'] = $father;
                    $data['admin_name'] = $username;
                    $data['adm_username'] = $username;
                    $data['adm_password'] = $intro->pwd('12345x69995');
                    $data['email'] = $email;
                    $data['regdate'] = date('Y-m-d H:i:s', $date_registered);
                    $data['level'] = 7;
                    $data['num_free'] = 0;
                    $data['act_count'] = 0;
                    $data['resel_bouquets'] = $resel_bouquets;
                    $data['can_add_codes'] = 1;
                    $data['can_add_users'] = 1;
                    $data['can_add_mag'] = 0;
                    $intro->db->insert(PREFIX . '_admin', $data);
                    $adminid_sub = $intro->db->insert_id();
                    if( $adminid_sub > 0 && $sub_resel_id > 0 ) 
                    {
                        $intro->db->query('UPDATE `users` SET created_by=' . $adminid_sub . ' WHERE created_by=' . $sub_resel_id . ';');
                        $intro->db->query('UPDATE `users` SET member_id=' . $adminid_sub . ' WHERE member_id=' . $sub_resel_id . ';');
                    }
                }
                $intro->db->query('update ' . PREFIX . ('_admin SET level=6 WHERE adminid=' . $father));
            }
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<h1>Import success. don\'t refresh page.</h1>');
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function no_invoice()
    {
        global $intro;
        global $array;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('no_invoice');
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . '_admin where no_invoice=1');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            echo '<li>father=' . $father . ' | ' . $adm_username . ' ';
        }
        $intro->db->query('update ' . PREFIX . '_admin set no_invoice=0');
        echo 'AFF=(' . $intro->db->affected_rows . ')';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function Report()
    {
        global $intro;
        global $array;
        $the_adminid = intval($intro->input->get_post('the_adminid'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_admin where adminid=\'' . $the_adminid . '\''));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        echo '<h2 style=\'background:#fff;border-radius:10px;padding:2px\'>' . $admin_name . "</h2>\n\t\t<div class=\"row\">\n\t\t\t<div class=\"col-md-6\">" . $this->balance($the_adminid) . ' ' . $this->codesByInput($the_adminid) . "</div>\n\t\t\t<div class=\"col-md-6\">" . $this->codes($the_adminid) . "</div>\n\t\t\t<div class=\"col-md-6\">" . $this->users($the_adminid) . "</div>\n\t\t</div>";
        echo "<script>\n\t\t\$(document).ready(function(){\n\n\t\t\$(\"#checkAll\").change(function () {\n\t\t\$(\"input:checkbox\").prop('checked', \$(this).prop(\"checked\"));\n\t\t});\n\n\t\t});\n\t\t</script>";
    }
    public function users($adminid)
    {
        global $intro;
        return 'Users report will come here Soon...';
    }
    public function balance($adminid)
    {
        global $intro;
        $sql = $intro->db->query('SELECT sum(credit-depit) as bal,sum(credit) as tot_cr,sum(depit) as tot_de FROM ' . PREFIX . ('_trans where admin=' . $adminid . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $cr = number_format($row['tot_cr']);
        $de = number_format(floatval($row['tot_de']));
        $bal = number_format(floatval($row['bal']));
        $html = _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Balance');
        $html .= ("<table class=\"table\">\n\t\t\t<tr>\n\t\t\t\t<td class='danger text-center'>Invoices : </td>\n\t\t\t\t<td  class='text-center'>" . $de . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td class='success text-center'>Payments : </td>\n\t\t\t\t<td class='text-center'>" . $cr . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td  class='success text-center'>Balance : </td>\n\t\t\t\t<td  class='text-center' style='background:#" . (($bal > 0 ? '006619' : 'ff0000')) . (';color:#ffff00\'>' . $bal . "</td>\n\t\t\t</tr>\n\t\t</table>"));
        $html .= _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        return $html;
    }
    public function codes($adminid)
    {
        global $intro;
        $html = _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Codes');
        $html .= '<table class="table">';
        $sql = $intro->db->query('SELECT period,count(*) as tot FROM ' . PREFIX . '_codes ' . (' where adminid=' . $adminid . ' GROUP BY period ORDER BY period ASC;'));
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $tot = $row['tot'];
            $period = $row['period'];
            $html .= ("\n\t\t\t\t<tr>\n\t\t\t\t\t<td class='success'>" . period($period) . ("</td>\n\t\t\t\t\t<td class='text-center'>" . $tot . "</td>\n\t\t\t\t</tr>"));
        }
        $html .= '</table>';
        $html .= _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        return $html;
    }
    public function codesByInput($adminid)
    {
        global $intro;
        $html = _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Codes By Type');
        $html .= '<table class="table">';
        $tt = [
            'Code', 
            'MAC', 
            'Serial'
        ];
        $sql = $intro->db->query('SELECT period,inputBy,count(*) as tot FROM ' . PREFIX . '_codes ' . (' where adminid=' . $adminid . ' GROUP BY period,inputBy ORDER BY period ASC;'));
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $tot = $row['tot'];
            $period = $row['period'];
            $inputBy = $row['inputBy'];
            $html .= ("\n\t\t\t\t<tr>\n\t\t\t\t\t<td class=success>" . period($period) . "</td>\n\t\t\t\t\t<td class='success'>" . $tt[$inputBy] . ("</td>\n\t\t\t\t\t<td class='text-center'>" . $tot . "</td>\n\t\t\t\t</tr>"));
        }
        $html .= '</table>';
        $html .= _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        return $html;
    }
    public function update()
    {
        global $intro;
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $field = trim($intro->input->get_post('field'));
        $val = intval($intro->input->get_post('val'));
        $data = [];
        $data[$field] = $val;
        if( $field == 'can_add_codes' ) 
        {
            $intro->db->update('' . PREFIX . '_admin', $data);
        }
        echo 'Done';
    }
    public function qry()
    {
        global $intro;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22(' Qry ', 'info');
        echo '<form action="' . $this->base . "/doQry\" method=\"post\">\n\t\t<input type=\"text\" name=\"qry\" value=\"\" placeholder=\"Name\" size=\"100\">\n\t\t<br>\n\t\t<input value=\" Submit Query \" type=\"submit\">\n\t\t</form>";
    }
    public function doQry()
    {
        global $intro;
        $html = _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('fix admind+1000');
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22(' Qry ', 'info');
        $qry = trim($intro->input->post('qry'));
        $sql = $intro->db->query((string)$qry);
        echo '<h1> ' . $qry . ' </h1>';
        echo '<h1>aff=' . $intro->db->affected_rows . '</h1>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function fix_id()
    {
        global $intro;
        $html = _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('fix admind+1000');
        if( $this->admin['level'] != 1 ) 
        {
            exit( 'error: no perms' );
        }
        $sql = $intro->db->query('UPDATE ' . PREFIX . '_admin SET adminid=adminid+1000;');
        $sql = $intro->db->query('UPDATE ' . PREFIX . '_admin SET father=father+1000 WHERE father>0;');
        $sql = $intro->db->query('UPDATE ' . PREFIX . '_codes SET adminid=adminid+1000;');
        $sql = $intro->db->query('UPDATE ' . PREFIX . '_codes_trans SET adminid=adminid+1000;');
        $sql = $intro->db->query('UPDATE ' . PREFIX . '_trans SET admin=admin+1000;');
        echo 'Done';
    }
    public function copyusers()
    {
        global $intro;
        global $t;
        global $error;
        global $admin_typ;
        global $policy;
        global $adminid;
        global $array;
        global $options;
        global $sucsess;
        $sucsess = trim($intro->input->get('sucsess'));
        $this->nav();
        echo '<fieldset><legend>Copy Users </legend>';
        echo '<form method="POST" name="form_add"  action="' . $this->base . "/docopy\" enctype=\"multipart/form-data\">\n\t\t\t<center><font color=green size=5>" . $sucsess . "</font></center>\n\t\t\t<table align=\"center\" border=\"1\" width=\"100%\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\" class=\"table table-striped table-hover table-bordered\">\n\t\t\t<tr>\n\t\t\t\t<td>Copy users from XC</td>\n\t\t\t\t<td><center>To</center></td>\n\t\t\t\t<td>Active Code Resellers</td>\n\t\t\t</tr>\t\n\t\t\t<tr>\n\t\t\t\t<td>" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('old', 'XC Members', 'reg_users', 0, 'id', 'username') . (' ' . $this->error('old') . "</td>\n\t\t\t\t<td></td>\n\t\t\t\t<td>") . _obf_0D311A13371B215B013B112303362D1032353D2E344022('new', 'Active Code resellers', 'solus_admin', 0, 'adminid', 'adm_username') . (' ' . $this->error('new') . "</td>\n\t\t\t</tr>\t\n\t\t\t<tr>\n\t\t\t\t<td></td>\n\t\t\t\t<td></td>\n\t\t\t\t<td><input type=\"hidden\" name=\"app_name\"  value=\"" . $this->base . "/docopy\">\n\t\t\t\t\t<button class=\"btn btn-success\" type=\"submit\" name=\"app_action\" value=\"docopy\">\n\t\t\t\t\t<i class=\"icon-plus-squared\"></i> Save\n\t\t\t\t\t</button>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t</table>\n\t\t\t</form>");
    }
    public function docopy()
    {
        global $intro;
        global $error;
        $old = intval($intro->input->post('old'));
        $new = intval($intro->input->post('new'));
        if( $old == 0 || $new == 0 ) 
        {
            if( $old == 0 ) 
            {
                $error['old'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $new == 0 ) 
            {
                $error['new'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->copyusers();
            exit();
        }
        $intro->db->query('update users set member_id=\'' . $new . '\' where member_id=\'' . $old . '\' ');
        $sucsess = 'Copy Successed';
        $intro->redirect($this->appname, 'copyusers', '?sucsess=' . $sucsess);
    }
}
