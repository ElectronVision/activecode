<?php 
class IntroDate
{
    public static function check_datetime($x)
    {
        return date('Y-m-d', strtotime($x)) == $x;
    }
    public static function validateDate($date, $format = 'Y-m-d H:i:s')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }
    public static function isDate($value)
    {
        if( !$value ) 
        {
            return false;
        }
        try
        {
            new DateTime($value);
            return true;
        }
        catch( Exception $e ) 
        {
            return false;
        }
    }
}
