<?php 
class Free_code_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        if( $this->admin['level'] != 1 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . '/index"><icon class="icon-list"></icon>') . $intro->lang['free_code_appname'] . "</a> \r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add"><icon class="icon-plus-squared"></icon>') . $intro->lang['free_code_add'] . "</a>  \t\t \t\t \r\n\t\t</div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = $forced_country = '';
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $intro->country[''] = 'Don\'t override';
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry = ' where code  LIKE \'%' . $search_txt . '%\' ';
        }
        if( $order == '' ) 
        {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 30;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_free_code ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from ' . PREFIX . ('_free_code ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> ' . $intro->lang['free_code_cur'] . (' (' . $totalrows . ')'), 'info');
        echo "\r\n\t\t\r\n\t\t<fieldset>\r\n\t\t\t<form action=\"\" method=\"post\">\r\n\t\t\t\t<input type=\"text\" name=\"search_txt\" value=\"" . $search_txt . '" placeholder="' . $intro->lang['search_form'] . "\" size=\"20\">\r\n\t\t\t\t<input name=\"name\" value=\"" . $intro->lang['search'] . "\" type=\"submit\">\r\n\t\t\t</form>\r\n\t\t</fieldset>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th> </th>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . "</th>\r\n\t\t\t<th>" . $intro->lang['free_code_code'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('code', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['free_code_days'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('days', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['free_code_code_total'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('code_total', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['free_code_code_used'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('code_used', 'index') . " </th>\r\n\t\t\t<th>Country Restriction</th>\r\n\t\t\t<th>Status</th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\"><input type=\"checkbox\" value=\"" . $id . "\" name=\"selected_fld[]\"></td>\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td>" . $code . "</td>\r\n\t\t\t\t<td>" . $days . "</td>\r\n\t\t\t\t<td>" . $code_total . "</td>\r\n\t\t\t\t<td>" . $code_used . ' <a class="btn btn-success" href="' . $this->base . '/ListCodes?code=' . $code . "\" title=\"View\"><i class=\"icon-search\"></i></a></td>\r\n\t\t\t\t<td>") . $intro->country[$forced_country] . "</td>\r\n\t\t\t\t<td>" . (($status == 1 ? '<span class=\'label label-success\'>Runing</span>' : '<span class=\'label label-danger\'>Stopped</span>')) . ("</td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del\" href=\"" . $this->base . '/DelConfirm?id=' . $id . '&code=' . $code . '" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>\r\n\t\t</div>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?search_txt=' . $search_txt . '&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</center>';
        echo '</fieldset>';
    }
    public function ListCodes()
    {
        global $intro;
        global $array;
        $intro->country[0] = '-';
        $intro->country[''] = '-';
        $qry = $forced_country = '';
        $page = intval($intro->input->get_post('page'));
        $this->nav();
        $rows_per_page = 30;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_codes_free where true ' . $qry . ' order by id desc  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from ' . PREFIX . ('_codes_free where true ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo "\r\n\t\t<fieldset><legend><i class=\"icon-list\"></i> Free Codes (" . $totalrows . ")</legend>\r\n\t\t\r\n\t\t<table class=\"DataTable table-striped table-bordered\" id=\"table_codes\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . "</th>\r\n\t\t\t<th>" . $intro->lang['codes_code'] . "  </th>\r\n\t\t\t<th> Username</th>\r\n\t\t\t<th>" . $intro->lang['codes_days'] . " </th>\r\n\t\t\t<th>" . $intro->lang['codes_status'] . "  </th>\r\n\t\t\t<th>MAC </th>\r\n\t\t\t<th>Serial</th>\r\n\t\t\t<th>Expire</th>\r\n\t\t\t<th>Country Restriction</th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        $mac = $serial = '';
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            if( $status == 0 ) 
            {
                $label = 'default';
            }
            else if( $status == 1 ) 
            {
                $label = 'success';
            }
            else if( $status == 2 ) 
            {
                $label = 'info';
            }
            else if( $status == 3 ) 
            {
                $label = 'danger';
            }
            else if( $status == 4 ) 
            {
                $label = 'default';
            }
            else if( $status == 5 ) 
            {
                $label = 'warning';
            }
            else
            {
                $label = 'danger';
            }
            $date_expire = ($date_expire != '' ? date('Y-m-d H:i', $date_expire) : '-');
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td>" . $code . "</td>\r\n\t\t\t\t<td>" . $user . "</td>\r\n\t\t\t\t<td>" . $days . "</td>\r\n\t\t\t\t<td>" . $status . "</td>\r\n\t\t\t\t<td>" . $mac . "</td>\r\n\t\t\t\t<td>" . $serial . "</td>\r\n\t\t\t\t<td>" . $date_expire . "</td>\r\n\t\t\t\t<td>") . $intro->country[$forced_country] . ("</td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/DelFreeCode?id=' . $id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t\t</table>";
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/' . 'ListCodes', $totalrows, $rows_per_page, $page) . '</center>';
        echo '</fieldset>';
    }
    public function multiDel()
    {
        global $intro;
        global $error;
        global $sess_admin;
        $selected_fld = $_POST['selected_fld'];
        $count = count($selected_fld);
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        for( $i = 0; $i < $count; $i++ ) 
        {
            $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_free_code WHERE id=\'' . $selected_fld[$i] . '\' '));
        }
        $intro->redirect($this->appname);
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $code;
        global $days;
        global $code_total;
        global $status;
        global $code_used;
        global $forced_country;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $IF = intval($intro->input->get_post('IF'));
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        if( $IF != 1 ) 
        {
            $this->nav();
        }
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_free_code where id=\'' . $id . '\''));
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = $intro->lang['free_code_edit'] . (' <b>' . $id . '</b>');
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = $intro->lang['free_code_add'];
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['free_code_code'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"code\" value=\"" . $code . '" size="30"> ' . $this->error('code') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['free_code_days'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"days\" value=\"" . $days . '" size="30"> ' . $this->error('days') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['free_code_code_total'] . (" : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"code_total\" value=\"" . $code_total . '" size="30"> ' . $this->error('code_total') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Override General Country Restriction:  </td>\r\n\t\t\t<td> ") . forced_country($forced_country) . (" </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Status : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"status\" value=\"" . $status . "\" size=\"5\"> 1 = Running , 0 = Stopped</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"IF\"  value=\"" . $IF . "\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</div>\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $code = trim($intro->input->post('code'));
        $forced_country = trim($intro->input->post('forced_country'));
        $days = intval($intro->input->post('days'));
        $code_total = intval($intro->input->post('code_total'));
        $code_used = intval($intro->input->post('code_used'));
        if( $code == '' || $days == 0 ) 
        {
            if( $code == '' ) 
            {
                $error['code'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $days == 0 ) 
            {
                $error['days'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data['code'] = $intro->input->post('code');
        $data['days'] = $intro->input->post('days');
        $data['code_total'] = $intro->input->post('code_total');
        $data['forced_country'] = $forced_country;
        $data['status'] = intval($intro->input->post('status'));
        $intro->db->insert(PREFIX . '_free_code', $data);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $data['status'] = intval($intro->input->post('status'));
        $data['code'] = $intro->input->post('code');
        $data['days'] = $intro->input->post('days');
        $data['code_total'] = $intro->input->post('code_total');
        $data['forced_country'] = $forced_country;
        $id = intval($intro->input->post('id'));
        $intro->db->update(PREFIX . '_free_code', $data, 'id=' . $id);
        $intro->redirect($this->appname);
    }
    public function DelConfirm()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $code = trim($intro->input->get_post('code'));
        echo "<div class=\"panel panel-danger\">\r\n\t\t  <div class=\"panel-heading\">Confirm DELETE!!!</div>\r\n\t\t  <div class=\"panel-body\">\r\n\t\t  \r\n\t\t\t\t<h3 class='alert alert-danger'>Deleting this code: " . $code . " will delete all free codes from database!!!</h3>\r\n\t\t\t\t\r\n\t\t\t\t<a class=\"btn btn-danger p_del\"  onclick=\"return confirm('Are you sure?')\" href=\"" . $this->base . '/Del?id=' . $id . '&code=' . $code . '" title="' . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i> Yes Delete Now.</a>\r\n\t\t  </div>\r\n\t\t</div>";
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $code = trim($intro->input->get_post('code'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_codes_free WHERE code=\'' . $code . '\'; '));
        $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_free_code WHERE id=' . $id . ' '));
        $intro->redirect($this->appname);
    }
    public function DelFreeCode()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_codes_free WHERE id=' . $id . ' '));
        $intro->redirect($this->appname, 'ListCodes');
    }
}
