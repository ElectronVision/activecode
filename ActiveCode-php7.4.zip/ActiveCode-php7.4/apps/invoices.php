<?php 
class Invoices_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $goto = '';
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $qry_admin_father = '';
    public $qryWhereFather = '';
    public $admin = [];
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $adminid = intval($this->admin['adminid']);
        if( $this->admin['level'] != 1 ) 
        {
            $this->qry_admin = ' and admin=' . $adminid;
            $this->qry_admin_where = ' where admin=' . $adminid;
        }
        if( $this->admin['level'] == 6 ) 
        {
            $this->qry_admin_father = ' AND admin_father=\'' . $adminid . '\' ';
            $this->qryWhereFather = ' WHERE father=' . $adminid . ' ';
            $this->qry_sub = ' AND admin_father=\'' . $this->admin['adminid'] . '\' ';
        }
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = ' and isSub=0 ';
            $this->qry_sub = ' AND isSub=1 ';
            $this->qryWhereFather = ' WHERE father=0 ';
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        global $options;
        $addnew = '';
        if( in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            $addnew .= ('<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index_sub') . (' p_view" href="' . $this->base . '/index_sub"><icon class="icon-list"> Sub-Resel invoices</icon></a>  '));
            $addnew .= ('<a class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add&amp;goto=' . $this->goto . '"><icon class="icon-plus-squared"> Addd New invoice</icon></a>  '));
        }
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\">Invoices</icon></a> \r\n\t\t\t" . $addnew . "\t \t\t \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        global $sess_admin;
        $qry = $queryadmin = $params = $txt = '';
        $get_active = $intro->input->get_post('active');
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $Notes = trim($intro->input->get_post('Notes'));
        $date1 = trim($intro->input->get_post('date1'));
        $date2 = trim($intro->input->get_post('date2'));
        $admin = intval($intro->input->get_post('admin'));
        $depit = $intro->input->get_post('depit');
        $depit = ($depit != '' ? floatval($depit) : '');
        $Notes = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($Notes, ' ');
        $date1 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date1, '-');
        $date2 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date2, '-');
        $this->nav();
        $rows_per_page = '30';
        if( $Notes != '' ) 
        {
            $qry .= (' and Notes LIKE \'%' . $Notes . '%\' ');
            $params .= ('&Notes=' . $Notes);
            $txt .= (' | Notes: ' . $Notes);
        }
        if( $admin != 0 ) 
        {
            $qry .= (' AND admin=' . $admin . ' ');
            $params .= ('&admin=' . $admin);
            $rows_per_page = '500';
            $txt .= (' | Reseller: ' . $array['admins'][$admin]);
        }
        if( $date1 != '' && $date2 != '' ) 
        {
            $qry .= (' AND dateadded BETWEEN \'' . $date1 . '\' AND \'' . $date2 . '\' ');
            $params .= ('&date1=' . $date1 . '&date2=' . $date2);
            $rows_per_page = '5000';
            $txt .= (' | Date: ' . $date1 . '-' . $date2);
        }
        if( $depit > 0 ) 
        {
            $qry .= (' AND depit=\'' . $depit . '\'');
            $params .= ('&depit=' . $depit);
            $rows_per_page = '500';
            $txt .= (' | Amount: ' . $depit);
        }
        if( $order == '' ) 
        {
            $order = 'trans_id:desc';
        }
        $order = str_replace(':', ' ', $order);
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_trans where type=1 ' . $qry . ' ' . $this->qry_admin . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT trans_id from ' . PREFIX . ('_trans where type=1 ' . $qry . ' ' . $this->qry_admin));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Invoices (' . $totalrows . ') ' . $txt, 'info');
        if( $this->admin['level'] == 1 ) 
        {
            echo "<form action=\"\" method=\"GET\" class=\"form-inline\">\r\n\t\t\t<table class='table' style='max-width:600px;'>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reseller:</td>\r\n\t\t\t\t<td>" . form_resellers('admin', $admin, 'All Resellers') . ("</td>\r\n\t\t\t\t<td>Date:</td>\r\n\t\t\t\t<td>\r\n\t\t\t\t\t<input type=\"text\" name=\"date1\" value=\"" . $date1 . "\" placeholder='From' class='date_picker form-control form-inline' style='width:100px;'>\r\n\t\t\t\t\t<input type=\"text\" name=\"date2\" value=\"" . $date2 . "\" placeholder='To' class='date_picker form-control form-inline' style='width:100px;'>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Notes:</td>\r\n\t\t\t\t<td><input type=\"text\" name=\"Notes\" value=\"" . $Notes . "\" placeholder='Notes' class='form-control'></td>\r\n\t\t\t\t<td>Amount:</td>\r\n\t\t\t\t<td><input type=\"text\" name=\"depit\" value=\"" . $depit . "\" placeholder='Amount' class='form-control'></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td><input type=\"submit\" value=\" Search! \" class='btn btn-default'></td>\r\n\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t\t</form>");
        }
        echo "\t\t\t\r\n\t\t<form action=\"" . $this->base . "/index\" method=\"post\" name=\"fieldsForm\"  id=\"fieldsForm\">\r\n\r\n\t\t<table class=\"table table-hover table-striped table-bordered table-condensed\" id=\"table_trans\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t\t\r\n\t\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('trans_id', 'index', $params) . "</th>\r\n\t\t\t\t<th>Date " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('dateadded', 'index', $params) . "</th>\r\n                <th>Reseller   " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('adminid', 'index', $params) . " </th>\r\n                <th>Amount " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('depit', 'index', $params) . " </th>\r\n                <th>Notes " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('depit', 'index', $params) . " </th>\r\n                <th>TransID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('code_trans', 'index', $params) . " </th>\r\n                <th>Codes " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('all_data', 'index', $params) . ' </th>';
        if( $this->admin['level'] == 1 ) 
        {
            echo '<th>Options</th>';
        }
        echo "\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\">" . $trans_id . "</td>\r\n\t\t\t\t<td class=\"center\">") . $dateadded . "</td>\r\n\t\t\t\t<td class=\"center\">" . $array['admins'][$admin] . ("</td>\r\n\t\t\t\t<td class=\"center\">" . $depit . "</td>\r\n\t\t\t\t<td>" . $Notes . "</td>\r\n\t\t\t\t<td>") . (($code_trans > 0 ? '<a href="' . $intro->app_url('trans', 'index') . ('?id=' . $code_trans . '">' . $code_trans . '</a>') : '-')) . "</td>\r\n\t\t\t\t<td>" . (($all_data != '' ? '<a class="AjaxModal" href=\'' . $this->base . '/ViewCodes?id=' . $trans_id . '\'>View Codes</a>' : '')) . '</td>';
            if( $this->admin['level'] == 1 ) 
            {
                echo "<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&trans_id=' . $trans_id . '" title="' . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?trans_id=' . $trans_id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>";
            }
            echo "\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t\t</table>";
        $order = str_replace(' ', ':', $order);
        $page = _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?order=' . $order . $params, $totalrows, $rows_per_page, $page);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411($page);
    }
    public function index_sub()
    {
        global $intro;
        global $array;
        global $sess_admin;
        $qry = $queryadmin = $params = '';
        $get_active = $intro->input->get_post('active');
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $admin = intval($intro->input->get_post('admin'));
        $this->goto = 'index_sub';
        $this->nav();
        $rows_per_page = '30';
        if( $admin != 0 ) 
        {
            $qry .= (' AND admin=' . $admin . ' ');
            $params .= ('&admin=' . $admin);
            $rows_per_page = '500';
        }
        if( $order == '' ) 
        {
            $order = 'trans_id:desc';
        }
        $order = str_replace(':', ' ', $order);
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . '_trans ' . (' where type=1 ' . $this->qry_sub . ' ' . $qry . '  order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT trans_id from ' . PREFIX . '_trans ' . (' where type=1 ' . $this->qry_sub . ' ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo "\r\n\t\t<fieldset><legend><i class=\"icon-list\"></i> Sub-Resellers Payments (" . $totalrows . ')</legend>';
        echo "<form action=\"\" method=\"GET\">\r\n\t\t\t" . form_resellers('admin', $admin, 'All Resellers', 'WHERE father=\'' . $this->admin['adminid'] . '\'') . " \r\n\t\t\t<input type=\"submit\" class=\"btn btn-success\" value=\" Search! \" class='btn btn-default'>\r\n\t\t\t</form>";
        echo "\r\n\r\n\t\t<table class=\"DataTable table-striped table-bordered\" id=\"table_trans\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('trans_id', 'index') . "</th>\r\n\t\t\t<th> " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('method', 'index') . "</th>\r\n\t\t\t<th>Date " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('dateadded', 'index') . '</th>';
        if( $this->admin['level'] == 1 ) 
        {
            echo '<th>Father  ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('admin_father', 'index') . ' </th>';
        }
        echo "\r\n\t\t\t<th>Reseller  " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('admin', 'index') . " </th>\r\n\t\t\t<th>Amount " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('depit', 'index') . " </th>\r\n\t\t\t<th>Notes " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('depit', 'index') . " </th>\r\n\t\t\t<th>Options</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = $total = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $total += $depit;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\">" . $trans_id . "</td>\r\n\t\t\t\t<td class=\"center\">") . $intro->pay_method[$method] . "</td>\r\n\t\t\t\t<td class=\"center\">" . $dateadded . '</td>';
            if( $this->admin['level'] == 1 ) 
            {
                echo '<td>' . $array['admins'][$admin_father] . '</td>';
            }
            echo "\r\n\t\t\t\t<td class=\"center\">" . $array['admins'][$admin] . "</td>\r\n\t\t\t\t<td class='c'>" . number_format($depit) . ("</td>\r\n\t\t\t\t<td>" . $Notes . "</td>\r\n\t\t\t\t<td class=\"center\">");
            if( $this->admin['level'] == 1 ) 
            {
                echo "\t\t\t\t\r\n\t\t\t\t\t<a class=\"btn btn-info btn-xs p_edit\" href=\"" . $this->base . '/Form?t=edit&trans_id=' . $trans_id . '&amp;goto=' . $this->goto . '" title="' . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a> \r\n\t\t\t\t\t<a class=\"btn btn-danger btn-xs p_del intro_ui_del\" href=\"" . $this->base . '/Del?trans_id=' . $trans_id . '" OnClick="return false;" title="') . $intro->lang['del'] . '"><i class="icon-cancel-circled2"></i></a> ';
            }
            echo "\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo '</tbody>';
        if( $admin != 0 ) 
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t" . (($this->admin['level'] == 1 ? '<td></td>' : '')) . "\r\n\t\t\t\t<td class='text-right'>Total:</td>\r\n\t\t\t\t<th class='c'>" . number_format($total) . "</th>\r\n\t\t\t\t<td></td>\r\n\t\t\t\t<td></td>\r\n\t\t\t</tr>";
        }
        echo '</table>';
        $order = str_replace(' ', ':', $order);
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index_sub?' . $params . '&order=' . $order, $totalrows, $rows_per_page, $page) . '</center>';
        echo '</fieldset>';
    }
    public function ViewCodes()
    {
        global $intro;
        $this->nav();
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_trans where trans_id=\'' . $id . '\''));
        $row = $intro->db->fetch_assoc($sql);
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('All Codes for Invoice #: ' . $id, 'info');
        echo nl2br($row['all_data']);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $amount;
        global $array;
        global $userid;
        global $adminid;
        global $depit;
        global $credit;
        global $admin;
        global $dateadded;
        global $period;
        global $Notes;
        if( $_GET != null ) 
        {
            @extract($_GET);
        }
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        if( $this->admin['level'] != 1 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $trans_id = intval($intro->input->get_post('trans_id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_trans where trans_id=\'' . $trans_id . '\''));
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = ' Edit <b>' . $trans_id . '</b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $btn['copy'] = "<button class=\"mult_submit\" type=\"submit\" name=\"app_action\" value=\"doAdd\" title=\"add new\">\r\n\t\t\t\t\t\t<span class=\"icon-floppy\"> حفظ كسجل جديد</span>\r\n\t\t\t\t\t</button>";
            $date = $dateadded;
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add Invoices';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = 'Add New';
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
            $btn['copy'] = '';
            $date = date('Y-m-d H:i:s');
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ');
        echo "\r\n\t\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t\t<table class=\"table table-bordered\">\r\n\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reseller : </td>\r\n\t\t\t\t<td>" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('adminid', 'Choose Reseller', 'solus_admin', $admin, 'adminid', 'admin_name') . ('  ' . $this->error('adminid') . "</td>\r\n\t\t\t</tr>\r\n\t\t\r\n\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Date Added  : </td>\r\n\t\t\t\t<td><input dir=\"ltr\" type=\"text\" name=\"dateadded\" value=\"" . $date . '" size="30"> ' . $this->error('dateadded') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Amount : </td>\r\n\t\t\t\t<td>\r\n\t\t\t\t<input dir=\"ltr\" type=\"text\" name=\"amount\" value=\"" . $amount . "\" size=\"30\"> \r\n\t\t\t\t" . $this->error('amount') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Notes  : </td>\r\n\t\t\t\t<td><textarea cols=35 rows= 5 name='Notes'>" . $Notes . '</textarea> ' . $this->error('Notes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"center\" colspan=\"2\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"trans_id\"  value=\"" . $trans_id . "\">\r\n\t\t\t\t\t<button class=\"mult_submit\" type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . '" title="' . $btn['name'] . "\">\r\n\t\t\t\t\t<span class=\"" . $btn['img_icon'] . '"> ' . $btn['name'] . " </span>\r\n\t\t\t\t\t</button>\r\n\t\t\t\t\t\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t</table>\r\n\t\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $userid = intval($intro->input->post('userid'));
        $adminid = intval($intro->input->post('adminid'));
        $amount = $intro->input->post('amount');
        $dateadded = trim($intro->input->post('dateadded'));
        $period = intval($intro->input->post('period'));
        $Notes = trim($intro->input->post('Notes'));
        if( $admin != 0 ) 
        {
            $editadmin = $admin;
        }
        if( $adminid == 0 ) 
        {
            if( $adminid == 0 ) 
            {
                $error['adminid'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $period = $intro->input->post('period');
        $data['admin'] = $intro->input->post('adminid');
        $data['dateadded'] = $intro->input->post('dateadded');
        $data['Notes'] = $intro->input->post('Notes');
        $data['type'] = 1;
        $sess_admin = $intro->auth->sess_admin();
        $checkadmin = $sess_admin['adminid'];
        $data['amount'] = $amount;
        $data['depit'] = $amount;
        $intro->db->insert(PREFIX . '_trans', $data);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $period = $intro->input->post('period');
        $amount = $intro->input->post('amount');
        $data['admin'] = $intro->input->post('adminid');
        $data['dateadded'] = $intro->input->post('dateadded');
        $data['Notes'] = $intro->input->post('Notes');
        $data['type'] = 1;
        $sess_admin = $intro->auth->sess_admin();
        $checkadmin = $sess_admin['adminid'];
        $data['amount'] = $amount;
        $data['depit'] = $amount;
        $trans_id = intval($intro->input->post('trans_id'));
        if( $this->admin['level'] == 1 ) 
        {
            $intro->db->update(PREFIX . '_trans', $data, 'trans_id=' . $trans_id);
        }
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $trans_id = intval($intro->input->get_post('trans_id'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        if( $this->admin['level'] == 1 ) 
        {
            $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_trans WHERE trans_id=' . $trans_id . ' '));
        }
        $intro->redirect($this->appname);
    }
    public function Active()
    {
        global $intro;
        global $trans_id;
        $sql = $intro->db->query('UPDATE ' . PREFIX . ('_trans SET status=\'1\' WHERE trans_id=\'' . $trans_id . '\' '));
        $intro->redirect($this->appname);
    }
}
