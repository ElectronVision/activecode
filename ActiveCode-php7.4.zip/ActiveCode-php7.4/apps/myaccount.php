<?php 
class Myaccount_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $canSubResel = 0;
    public $qry_admin = '';
    public $groups = [];
    public $adminRow = [];
    public $level = [
        '1' => 'Admin', 
        '2' => 'Super Reseller', 
        '3' => 'Reseller', 
        '4' => 'Reset Codes Only', 
        '5' => 'Reset,Expire,Suspend', 
        '6' => 'Reseller With Sub-Resel', 
        '7' => 'Reselller [S]', 
        '8' => 'Reset,Expire,Suspend, Streams, Logs, Bouquets', 
        '9' => 'Admin No bulk,inv,pay,code list'
    ];
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $options;
        $this->admin = $intro->auth->sess_admin();
        $this->adminRow = $intro->auth->admin_data($this->admin['adminid']);
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        echo "<div class=\"app_nav\">\n\t\t <a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . (' icon-info" href="' . $this->base . "/index\">My Account</a> \n\t\t \n\t\t</div>");
    }
    public function yesNo($str)
    {
        return ($str == 1 ? 'Yes' : 'No');
    }
    public function cost($enable, $cost)
    {
        if( $enable == 1 ) 
        {
            return $cost;
        }
        else
        {
            return '---';
        }
    }
    public function index()
    {
        global $intro;
        global $array;
        global $options;
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('My Account Details', 'info');
        $row = $this->adminRow;
        extract($row);
        echo "\n\t\t <table align=\"center\" border=\"1\" width=\"100%\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\" class=\"table table-striped table-hover table-bordered\">\n\t\t\t\t";
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>Name: </td>\n\t\t\t\t<td style='width:70%'>" . $admin_name . "</td>\n\t\t\t</tr>\n\n\t\t\t<tr>\n\t\t\t\t<td>Username:</td>\n\t\t\t\t<td>" . $adm_username . "</td>\n\t\t\t</tr>\n\n\t\t\t<tr>\n\t\t\t\t<td>Password:</td>\n\t\t\t\t<td><a href=\"" . $this->base . "/ChangePassword\" class=\"btn btn-success\">Change Password Now!</a></td>\n\t\t\t</tr>\n\n\t\t\t<tr>\n\t\t\t\t<td>Email:</td>\n\t\t\t\t<td>" . $email . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td> Account Type: </td>\n\t\t\t\t<td>" . $this->level[$level] . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Logo & Brandname :</th>\n\t\t\t</tr><!--\n\t\t\t<tr>\n\t\t\t\t<td>Logo: </td>\n\t\t\t\t<td>\n\t\t\t\t\t<img src=\"data:image/png;base64," . base64_encode(stripslashes($logo)) . ("\" style=\"max-height:100px;\">\n\t\t\t\t\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Brand Name: </td>\n\t\t\t\t<td>" . $brand . "</td>\n\t\t\t</tr>-->\n\t\t\t<tr>\n\t\t\t\t<td>Host (DNS): </td>\n\t\t\t\t<td>" . $host . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Service :</th>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Add Codes : </td>\n\t\t\t\t<td>Yes</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Add Users : </td>\n\t\t\t\t<td>") . $this->yesNo($can_add_users) . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Add MAG : </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_mag) . "</td>\n\t\t\t</tr>";
        echo "\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Service Price :</th>\n\t\t\t</tr>\t\n\t\t\t<tr>\n\t\t\t\t<td>Total free Users/Codes/MAGs : </td>\n\t\t\t\t<td>" . ((($num_free == -1 ? 'Unlimimted' : $num_free == 0) ? 'disabled' : $num_free)) . ("</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td> Extra free days : </td>\n\t\t\t\t<td>" . $extra_free_days . "</td>\n\t\t\t</tr>");
        if( $this->adminRow['postpaid'] == 1 ) 
        {
            echo "\t\n\t\t\t<tr>\n\t\t\t\t<td> Postpaid : </td>\n\t\t\t\t<td> " . $this->yesNo($postpaid) . " </td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['can_add_free_1'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 1 days : </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_free_1) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['can_add_free_3'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 3 days : </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_free_3) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['can_add_free_7'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 7 days : </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_free_7) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['cost_1_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> Free 10 days : </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_free_10) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['cost_1_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td> 1 Month | Cost: </td>\n\t\t\t\t<td>" . $this->cost($cost_1_enabled, $cost_1) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['cost_3_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>3 Months | Cost: </td>\n\t\t\t\t<td>" . $this->cost($cost_3_enabled, $cost_3) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['cost_6_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>6 Months |  Cost: </td>\n\t\t\t\t<td>" . $this->cost($cost_6_enabled, $cost_6) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['cost_12_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>12 Months | Cost: </td>\n\t\t\t\t<td>" . $this->cost($cost_12_enabled, $cost_12) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['cost_24_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>2 Years | Cost: </td>\n\t\t\t\t<td>" . $this->cost($cost_24_enabled, $cost_24) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['cost_36_enabled'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>3 Years | Cost: </td>\n\t\t\t\t<td>" . $this->cost($cost_36_enabled, $cost_36) . "</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<th colspan=2>Other Options:</th>\n\t\t\t</tr>";
        if( isset($options['opt_stb_to_iptv']) && $options['opt_stb_to_iptv'] == 'yes' ) 
        {
        }
        if( isset($options['opt_activation_count']) && $options['opt_activation_count'] == 'yes' ) 
        {
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>Download <span class='label label-success icon-download'>m3u</span> file: </td>\n\t\t\t\t<td>" . $this->yesNo($can_m3u) . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Add Codes By MAC <span class='icon-maxcdn'></span>: </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_mac) . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Add Codes By Serial <span class='icon-barcode'></span>: </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_sn) . "</td>\n\t\t\t</tr>";
        if( $this->adminRow['can_add_free'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allow <span class='label label-primary icon-plus'>add</span> Free Codes: </td>\n\t\t\t\t<td>" . $this->yesNo($can_add_free) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['can_delete'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allow <span class='label label-danger icon-trash'>Delete</span> Codes + Invoices: </td>\n\t\t\t\t<td>" . $this->yesNo($can_delete) . "</td>\n\t\t\t</tr>";
        }
        if( $this->adminRow['can_change'] == 1 ) 
        {
            echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allow <span class='label label-info icon-edit'>Change</span> Codes: </td>\n\t\t\t\t<td>" . $this->yesNo($can_change) . "</td>\n\t\t\t</tr>";
        }
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>Packages (Bouquets):</td>\n\t\t\t\t<td><!--" . $resel_bouquets . "--> --soon--</td>\n\t\t\t</tr>";
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>Group: </td>\n\t\t\t\t<td>" . (($group_id == 0 ? 'ALL' : 'You are on group id: ' . $group_id)) . "</td>\n\t\t\t</tr>";
        echo "\n\t\t\t<tr>\n\t\t\t\t<td>Allowed IPs :</td>\n\t\t\t\t<td>" . $allowed_ips . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Message:</td>\n\t\t\t\t<td>" . $msg_welcome . "</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Notes :</td>\n\t\t\t\t<td>" . $notes . "</td>\n\t\t\t</tr>\n\t\t</table>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function ChangePassword()
    {
        global $intro;
        global $error;
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Change My Password ');
        echo "<style>\n\t\tmeter {\n\t\t\t/* Reset the default appearance */\n\t\t\t-webkit-appearance: none;\n\t\t\t   -moz-appearance: none;\n\t\t\t\t\tappearance: none;\n\t\t\tmargin: 0 auto 1em;\n\t\t\twidth: 100%;\n\t\t\theight: .5em;\n\t\t\t\n\t\t\t/* Applicable only to Firefox */\n\t\t\tbackground: none;\n\t\t\tbackground-color: rgba(0,0,0,0.1);\n\t\t}\n\t\tmeter::-webkit-meter-bar {\n\t\t\tbackground: none;\n\t\t\tbackground-color: rgba(0,0,0,0.1);\n\t\t}\n\t\tmeter[value=\"1\"]::-webkit-meter-optimum-value { background: red; }\n\t\tmeter[value=\"2\"]::-webkit-meter-optimum-value { background: yellow; }\n\t\tmeter[value=\"3\"]::-webkit-meter-optimum-value { background: orange; }\n\t\tmeter[value=\"4\"]::-webkit-meter-optimum-value { background: green; }\n\n\t\tmeter[value=\"1\"]::-moz-meter-bar { background: red; }\n\t\tmeter[value=\"2\"]::-moz-meter-bar { background: yellow; }\n\t\tmeter[value=\"3\"]::-moz-meter-bar { background: orange; }\n\t\tmeter[value=\"4\"]::-moz-meter-bar { background: green; }\n\n\t\t</style>";
        echo '<form method="POST" name="form_add" id=\'frmResetPWD\' action="' . $this->base . "/doPWD/?NH=1\">\n\t\t<div style='color:#ff9999'>Once you change password you will logout.</div>\n\t\t<table class=\"table table-bordered\">\n\t\t\n\t\t\t<tr>\n\t\t\t\t<td>Old Password :</td>\n\t\t\t\t<td>\n\t\t\t\t\t<div class=\"form-inline\">\n\t\t\t\t\t\t<input class=\"form-control\" type=\"password\" name=\"old_pass\" value=\"\" required=\"\"> " . $this->error('old_pass') . " \n\t\t\t\t\t</div>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t\n\t\t\t<tr>\n\t\t\t\t<td>New Password :</td>\n\t\t\t\t<td>\n\t\t\t\t\t<div class=\"form-inline\">\n\t\t\t\t\t\t<input class=\"form-control\" type=\"password\" name=\"new_pwd\" value=\"\" id=\"password\" required=\"\" oninput=\"setPasswordConfirmValidity();\"> " . $this->error('new_pwd') . " \n\t\t\t\t\t\t<meter max=\"4\" id=\"password-strength-meter\"></meter>\n\t\t\t\t\t\t<p id=\"password-strength-text\"></p>\n\t\t\t\t\t</div>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Confirm Password:</td>\n\t\t\t\t<td>\n\t\t\t\t\t<div class=\"form-inline\">\n\t\t\t\t\t\t<input class=\"form-control\" type=\"password\" name=\"new_pwd2\"  id=\"password2\" value=\"\" required=\"\" oninput=\"setPasswordConfirmValidity();\"> " . $this->error('new_pwd2') . " \n\t\t\t\t\t\t<span id=\"must_match\"></span>\n\t\t\t\t\t</div>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t\n\t\t\t<tr>\n\t\t\t\t<td class=\"center\" colspan=\"2\">\n\t\t\t\t<div style='color:#ff9999'>Once you change password you will logout.</div>\n\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success\">Change Password</button>\n\t\t\t\t\t<span id='spanSpin' class='icon-spin5' style='display:none'></span> \n\t\t\t\t\t<div id='result'></div>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t</table>\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\n\t\tfunction setPasswordConfirmValidity(str) {\n\t\t\tvar password1 = document.getElementById('password');\n\t\t\tvar password2 = document.getElementById('password2');\n\t\t\tvar must_match = \$('#must_match');\n\n\t\t\tif (password1.value === password2.value) {\n\t\t\t\t must_match.html('');\n\t\t\t} else {\n\t\t\t\tmust_match.html('<span class=\"label label-danger\">Passwords must match</span>');\n\t\t\t}\n\t\t}\n\t\t\$(document).ready(function(){\n\t\t\tvar strength = {\n\t\t\t\t0: \"Worst ☹\",\n\t\t\t\t1: \"Bad ☹\",\n\t\t\t\t2: \"Weak ☹\",\n\t\t\t\t3: \"Good ☺\",\n\t\t\t\t4: \"Strong ☻\" \n\t\t\t};\n\n\t\t\tvar password = document.getElementById('password');\n\t\t\tvar meter = document.getElementById('password-strength-meter');\n\t\t\tvar text = document.getElementById('password-strength-text');\n\n\t\t\tpassword.addEventListener('input', function ()\n\t\t\t{\n\t\t\t\tvar val = password.value;\n\t\t\t\tvar result = zxcvbn(val);\n\n\t\t\t\t// Update the password strength meter\n\t\t\t\tmeter.value = result.score;\n\n\t\t\t\t// Update the text indicator\n\t\t\t\tif (val !== \"\") {\n\t\t\t\t\ttext.innerHTML = \"Strength: \" \n\t\t\t\t\t+ \"<strong>\" + strength[result.score] + \"</strong>\" \n\t\t\t\t\t+ \"<span class='feedback'>\" + result.feedback.warning + \" \" + result.feedback.suggestions + \"</span\";\n\t\t\t\t} else\n\t\t\t\t{\n\t\t\t\ttext.innerHTML = '';\n\t\t\t\t}\n\t\t\t});\n\t\t\t\n\t\t\t\n\t\t\t\$(\"#frmResetPWD\").submit(function(event){\n\t\t\t\tevent.preventDefault();\n\t\t\t\tvar act = \$(this).attr('action');\n\t\t\t\t\t\t\t\n\t\t\t\t\$('#spanSpin').show().addClass('animate-spin');\n\t\t\t\t\n\t\t\t\t\$.ajax({\n\t\t\t\t\turl: act,\n\t\t\t\t\ttype:'POST',\n\t\t\t\t\tdata:\$(this).serialize(),\n\t\t\t\t\tsuccess:function(result){\n\t\t\t\t\t\t\$('#result').html(result);\n\t\t\t\t\t\t\$('#spanSpin').removeClass('animate-spin').hide();\n\t\t\t\t\t}\n\n\t\t\t\t});\n\t\t\t});\n\t\t\t\n\t\t});\n\t\t</script>";
    }
    public function doPWD()
    {
        global $intro;
        $old_pass = trim($intro->input->post('old_pass'));
        $new_pwd = trim($intro->input->post('new_pwd'));
        $new_pwd2 = trim($intro->input->post('new_pwd2'));
        $old_pass_hash = $intro->pwd($old_pass);
        $new_pwd_hash = $intro->pwd($new_pwd);
        if( $this->adminRow['adm_password'] != $old_pass_hash ) 
        {
            exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: your old password is wrong!.', 'danger') );
        }
        if( $this->adminRow['adm_password'] == $new_pwd_hash ) 
        {
            exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: your old password is the same as the new password! Please choose a new strong password.', 'danger') );
        }
        if( $new_pwd != $new_pwd2 ) 
        {
            exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: your new password is not mtaching!. Please make sure both password are the same.', 'danger') );
        }
        $adminid = intval($this->adminRow['adminid']);
        $data = [];
        $data['adm_password'] = $new_pwd_hash;
        $intro->db->update(PREFIX . '_admin', $data, 'adminid=\'' . $adminid . '\'');
        exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Success! Your new Password is: ' . $new_pwd . '<br/><br/> You need to login again.', 'success') );
    }
}
