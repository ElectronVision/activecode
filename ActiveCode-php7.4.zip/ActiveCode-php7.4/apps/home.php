<?php 
class Home_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $date = null;
    public $date_7 = null;
    public $icons = null;
    public $tables = [
        'client_logs', 
        'solus_logs', 
        'user_activity', 
        'user_activity_now', 
        'stream_logs'
    ];
    public $tables_names = [
        'client_logs' => 'Client Error Logs:', 
        'solus_logs' => 'Active Code Logs:', 
        'user_activity' => 'Closed Connections:', 
        'user_activity_now' => 'Online Now', 
        'stream_logs' => 'Stream Logs:'
    ];
    public $admin = [];
    public $adminRow = [];
    public function __construct($appname, $base)
    {
        global $intro;
        global $sess_admin;
        $this->date = date('Y-m-d');
        $this->date_7 = date('Y-m-d', strtotime('+7 days'));
        $this->appname = $appname;
        $this->base = $base;
        $this->icons = admin_path . 'style/img/';
        $this->admin = $intro->auth->sess_admin();
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
    }
    public function index()
    {
        global $intro;
        global $sess_admin;
        global $array;
        global $options;
        global $config;
        $item_no = $intro->input->get_post('item_no');
        $jsjs = '';
        echo _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911();
        $intro->db->halt_on_errors = false;
        if( $this->admin['level'] == 1 ) 
        {
            if( !isset($intro->option['db_ver']) ) 
            {
                $intro->db->query('INSERT IGNORE  INTO `solus_options` (`id`, `name`, `val`) VALUES (NULL, \'db_ver\', \'230\'); ');
            }
            if( isset($intro->option['db_ver']) && $intro->option['db_ver'] != '' && _intro_db_ver != intval($intro->option['db_ver']) ) 
            {
                echo '<a href="' . $this->base . '/Update" class="btn btn-success btn-lg">New update click here to update.</a><br/><br/>';
            }
            $this->alert();
            echo "\n\t\t\t<div class=\"row\">\n\t\t\t\t<div class=\"col-md-12\" style='position: relative;'><div id='cdown_timer' style='position:absolute;right:20px;z-index:1000;'></div>\n\t\t\t\t\t<div id='div_refresh'>";
            $this->dash();
            echo "</div>\n\t\t\t\t\t\n\t\t\t\t</div>\n\t\t\t</div>";
            echo "<script>\n\t\t\t\$(document).ready(function() {\n\t\t\t\tvar counter = 15;\n\t\t\t\tvar interval = setInterval(function() {\n\t\t\t\t\tcounter--;\n\t\t\t\t\tif (counter <= 0) {\n\t\t\t\t\t\tcounter = 16;\n\t\t\t\t\t\treturn;\n\t\t\t\t\t}else{\n\t\t\t\t\t\t\$('#cdown_timer').text(counter);\n\t\t\t\t\t\tif(counter == 1){\n\t\t\t\t\t\t\t\$('#div_refresh').load('" . $this->base . "/dash?NH=1&refresh=ok');\n\t\t\t\t\t\t}\n\t\t\t\t\t}\n\t\t\t\t}, 1000);\n\t\t\t});\n\t\t\t</script>";
        }
        $this->adminRow = $intro->auth->admin_data(intval($this->admin['adminid']));
        $hide = false;
        if( isset($intro->option['global_msg_expiry']) && _obf_0D24242D0C22102F0715263F3E193B275B1B06383C3401($intro->option['global_msg_expiry']) && $intro->option['global_msg_expiry'] < date('Y-m-d') ) 
        {
            $hide = true;
        }
        $time = time();
        $time7 = strtotime('+7 day');
        $qry_adm_code = $qry_adm_user = '';
        if( $this->admin['level'] != 1 ) 
        {
            $qry_adm_code = ' and adminid=' . intval($this->admin['adminid']);
            $qry_adm_user = ' and member_id=' . intval($this->admin['adminid']);
        }
        $intro->db->query('SELECT id from ' . PREFIX . ('_codes where  status=4 ' . $qry_adm_code . ';'));
        $code_expired = $intro->db->returned_rows;
        $intro->db->query('SELECT id from users where exp_date <= \'' . $time . '\' AND exp_date!=\'\' AND exp_date IS NOT NULL ' . $qry_adm_user . ';');
        $user_expired = $intro->db->returned_rows;
        $intro->db->query('SELECT id from users where exp_date BETWEEN \'' . $time . '\' AND \'' . $time7 . '\' ' . $qry_adm_user . ';');
        $user_soon_to_expire = $intro->db->returned_rows;
        $sql2 = $intro->db->query('SELECT id from ' . PREFIX . ('_codes where status=3 ' . $qry_adm_code . ';'));
        $del = $intro->db->returned_rows;
        if( $this->admin['level'] == 1 ) 
        {
            $panel1 = "\n\t\t\t<div class=\"panel panel-default\">\n\t\t\t  <div class=\"panel-heading\">Logs</div>\n\t\t\t  <div class=\"panel-body\">\n\t\t\t  \n\t\t\t  From this screen you can clear big Logs (these logs are not necessary and cause big load on database).\n\t\t\t   <table class=\"table table-striped\">\n\t\t\t\t<thead>\n\t\t\t\t  <tr>\n\t\t\t\t\t<th>Table</th>\n\t\t\t\t\t<th>Rows</th>\n\t\t\t\t\t<th>Options</th>\n\t\t\t\t  </tr>\n\t\t\t\t</thead>\n\t\t\t\t<tbody>";
            $jsjs = '';
            $i = -1;
            $tblz = [];
            foreach( $this->tables as $table ) 
            {
                $tblz[] = '\'' . $table . '\'';
            }
            $sql = $intro->db->query("SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_ROWS,AUTO_INCREMENT\n\t\t\t\t\t\t\tFROM information_schema.TABLES WHERE\n\t\t\t\t\t\t\t\t  TABLE_SCHEMA = '" . $config['db']['database'] . "' \n\t\t\t\t\t\t\t\t  AND \n\t\t\t\t\t\t\t\t  TABLE_NAME IN (" . implode(',', $tblz) . ');');
            while( $row = $intro->db->fetch_assoc($sql) ) 
            {
                $table = $row['TABLE_NAME'];
                $table_name = $this->tables_names[$table];
                $num = number_format($row['TABLE_ROWS']);
                if( $table != 'user_activity_now' && intval($row['TABLE_ROWS']) > 1000000 ) 
                {
                    $intro->db->query_fast('TRUNCATE ' . $table . ';');
                    $num = 'Cleaned';
                }
                if( $table == 'user_activity_now' && intval($row['AUTO_INCREMENT']) >= 2000000000 ) 
                {
                    $intro->db->query_fast('TRUNCATE user_activity_now;');
                    echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h2>Online Users has been auto fixed successfully.</h2>');
                }
                $panel1 .= ("\t\n\t\t\t\t\t <tr>\n\t\t\t\t\t\t<td>" . $table_name . "</td>\n\t\t\t\t\t\t<td id=\"numResult" . $i . '"><!--<span class=\'icon-spin5 animate-spin\'></span>-->' . $num . "</td>\n\t\t\t\t\t\t<td>" . (($table != 'user_activity_now' ? '<a href="' . $this->base . '/Truncate?table=' . $table . '">Truncate</a>' : '-')) . "</td>\n\t\t\t\t\t  </tr>");
            }
            $panel1 .= "\n\t\t\t\t</tbody>\n\t\t\t  </table>\n\t\t\t\t<br/>\n\t\t\t  </div>\n\t\t\t</div>";
            $panel2 = "\n\t\t\t<div class=\"panel panel-default\">\n\t\t\t  <div class=\"panel-heading\">Expired Codes AND Users</div>\n\t\t\t  <div class=\"panel-body\">\n\t\t\t  \n\t\t\t   <table class=\"table table-striped\">\n\t\t\t\t<thead>\n\t\t\t\t  <tr>\n\t\t\t\t\t<th>Name</th>\n\t\t\t\t\t<th>Count</th>\n\t\t\t\t\t<th>Options</th>\n\t\t\t\t  </tr>\n\t\t\t\t</thead>\n\t\t\t\t<tbody>\n\t\t\t\t\n\t\t\t\t\t <tr>\n\t\t\t\t\t\t<td>Deleted Codes</td>\n\t\t\t\t\t\t<td>" . $del . "</td>\n\t\t\t\t\t\t<td><a class='intro_ui_del' href=\"" . $this->base . "/Delete?mode=del_codes\" OnClick=\"return false\"></a></td>\n\t\t\t\t\t  </tr>\n\t\t\t\t\t  <tr>\n\t\t\t\t\t\t<td>Expired Codes</td>\n\t\t\t\t\t\t<td><a class='btn btn-info' href=\"" . $intro->app_url('codes', 'index') . '?view=expired">' . $code_expired . "</a></td>\n\t\t\t\t\t\t<td><!--<a href=\"" . $this->base . "/Delete?mode=del_expired_codes\" OnClick=\"return confirm('Are you sure?');\">Move to Delete</a>--></td>\n\t\t\t\t\t  </tr>\n\t\t\t\t\t  <tr>\n\t\t\t\t\t\t<td>Users Expiring in 7 days</td>\n\t\t\t\t\t\t<td><a class='btn btn-warning' href=\"" . $intro->app_url('users', 'index') . '?view=soon_to_expire">' . $user_soon_to_expire . "</a></td>\n\t\t\t\t\t\t<td><!--<a class='intro_ui_del' href=\"" . $this->base . "/Delete?mode=del_user_expired\" OnClick=\"return false\">Delete</a>--></td>\n\t\t\t\t\t  </tr>\n\t\t\t\t\t  <tr>\n\t\t\t\t\t\t<td>Expired Users</td>\n\t\t\t\t\t\t<td><a class='btn btn-info' href=\"" . $intro->app_url('users', 'index') . '?view=expired">' . $user_expired . "</a></td>\n\t\t\t\t\t\t<td><!--<a class='intro_ui_del' href=\"" . $this->base . "/Delete?mode=del_user_expired\" OnClick=\"return false\">Delete</a>--></td>\n\t\t\t\t\t  </tr>\n\t\t\t\t\t  <tr>\n\t\t\t\t\t\t<td>LYNX IPTV:</td>\n\t\t\t\t\t\t<td>V" . _intro_db_ver . "</td>\n\t\t\t\t\t\t<td></td>\n\t\t\t\t\t  </tr>\n\t\t\t\t\t  <tr>\n\t\t\t\t\t\t<td>PHP Ver:</td>\n\t\t\t\t\t\t<td>" . phpversion() . "</td>\n\t\t\t\t\t\t<td></td>\n\t\t\t\t\t  </tr>";
            if( function_exists('sys_getloadavg') ) 
            {
                $cpu = '';
                $load = sys_getloadavg();
                if( is_array($load) ) 
                {
                    foreach( $load as $key => $val ) 
                    {
                        $cpu .= ($val . ' ');
                    }
                }
                if( $cpu != '' ) 
                {
                    $panel2 .= ("\n\t\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t\t<td>CPU:</td>\n\t\t\t\t\t\t\t\t\t<td>" . $cpu . "</td>\n\t\t\t\t\t\t\t\t\t<td></td>\n\t\t\t\t\t\t\t\t  </tr>");
                }
            }
            $panel2 .= "\n\t\t\t\t\t  \n\t\t\t\t</tbody>\n\t\t\t  </table>\n\t\t\t  \n\t\t\t  </div>\n\t\t\t</div>";
            $this->nav();
            echo "<div class=\"row\">\n\t\t\t\t<div class=\"col-md-6\">" . $panel2 . "</div>\n\t\t\t\t<div class=\"col-md-6\">" . $panel1 . "</div>\n\t\t\t</div>";
            echo "<div class=\"row\">\n\t\t\t\n\t\t\t\t<div class=\"col-md-12\">\n\t\t\t\t<div style='color:#fff'>\n\t\t\t\tV2.38 \n\t\t\t\t\t[Force Update (<a href=\"" . $this->base . "/Update/?force=236\">236</a>)\n\t\t\t\t\t(<a href=\"" . $this->base . "/Update/?force=237\">237</a>) ]\n\t\t\t\t<ul>\n\t\t\t\t\t<li>When you have CPU very High 100%. Check DDOS Attack, [*Reboot Server then Reload*].\n\t\t\t\t\t<br>\n\t\t\t\t\tCheck Loop-Back Streams (When you exchange streams with others and you use the same Stream)\n\t\t\t\t\t</li>\n\t\t\t\t\t<li>Resellers Packges and Groups.</li>\n\t\t\t\t\t<li>Edit any Reseller AND set Group to Use Credit System.\n\t\t\t\t\t<br>\n\t\t\t\t\tWhen Reseller add Credit to his Sub-Reseller it will deduct/cut his credit. \n\t\t\t\t\t</li>\n\t\t\t\t\t<li>Mass Encode/Delete Movies & Episodes.</li>\n\t\t\t\t\t<li>Filter Movies/Episodes by Encode Type and Servers.</li>\n\t\t\t\t\t<li>You can know each Movie/Episodes on it's server.</li>\n\t\t\t\t\t<li>Sort Bouquets by Mouse. Resellers and admins can Sort for codes/users/mag/e2</li>\n\t\t\t\t\t<li>Disallow Resellers to add users with password. User+Password will be Auto Generated.</li>\n\t\t\t\t\t<li>Added Reset Password for every User.</li>\n\t\t\t\t\t<li>When you disallow reseller to set password, the reseller can use: Reset Password to Change passwords for his users.</li>\n\t\t\t\t\t<li>Mass Edit Resellers - Beta.</li>\n\t\t\t\t\t<li>Added Options for Reseller to : Set Password, Country, E2 , Change Codes MAC options ... etc </li>\n\t\t\t\t\t<li>Fix Transcoding Profiles.</li>\n\t\t\t\t\t<li>Servers: Sort and Arrange Server.</li>\n\t\t\t\t\t<li>Servers: Clean iptables firewall rules from Servers.</li>\n\t\t\t\t\t<li>Servers: Update GeoIP database. </li>\n\t\t\t\t\t<li>Sort Users & Online Users.</li>\n\t\t\t\t\t<li>On Next update we will add TMDB and force use of Credit System, beta New Design.</li>\n\t\t\t\t\t<li style='color:#ffbfbf;'>!!!Contact Us to setup Automatic Remote FTP backup and make sure you have backup of your database Daily!!!.</li>\n\t\t\t\t\t<li>to send bugs and requests <a target='_blank' href='https://intro.ps/sys/submitticket.php?step=2&deptid=2'>\n\t\t\t\t\t\tClick Here\n\t\t\t\t\t\t</a>\n\t\t\t\t\t</li>\n\t\t\t\t</ul>\n\t\t\t\tV2.37\n\t\t\t\t<ul>\n\t\t\t\t\t<li> *** First Reload Main Server. *** </li>\n\t\t\t\t\t<li>Fix series update when add new Episodes.</li>\n\t\t\t\t\t<li>Fix movies remote from other server.</li>\n\t\t\t\t\t<li>Fix created channels.</li>\n\t\t\t\t\t<li>Added Restart all streams in Servers.</li>\n\t\t\t\t\t<li>Added kill all active connections (kick) in | Servers and Online users.</li>\n\t\t\t\t\t<li>MAG: You can add new MAG Device types | in Tools->General Setting  MAG Devices </li>\n\t\t\t\t\t<li>Added Resellers Packages and Resellers/Admins Groups (Beta) </li>\n\t\t\t\t\t<li>Fix many bugs.</li>\n\t\t\t\t\t\n\t\t\t\t</ul>\n\t\t\t\t<!--\n\t\t\t\tV2.36\n\t\t\t\t<ul>\n\t\t\t\t\t<li>Search by date ranges in Users/MAG.</li>\n\t\t\t\t\t<li>Inhanced Streams</li>\n\t\t\t\t\t<li>Inhanced MAG</li>\n\t\t\t\t\t<li>Added Blocked IPs and Failed Logins Alert on Home</li>\n\t\t\t\t\t<li>Fix admin and resellers bugs.</li>\n\t\t\t\t\t<li>Added option to change api.php | in Tools-> Code Options.</li>\n\t\t\t\t\t<li>Added option to change M3U downloader get.php and use Custom Domain | in Tools-> Code Options.</li>\n\t\t\t\t\t<li>Added Brute Force Login Attacks.</li>\n\t\t\t\t\t<li>EPG - Flsh + Reload.</li>\n\t\t\t\t\t<li>Fix many bugs.</li>\n\t\t\t\t</ul>\n\t\t\t\t\n\t\t\t\tV2.35\n\t\t\t\t<ul>\n\t\t\t\t\t<li>Mass add Movies , Episodes from icon: <span class=\"btn-xs icon-magic\"></span></li>\n\t\t\t\t\t<li>Added Tasks System</li>\n\t\t\t\t\t<li>Added option for Reseller to Manage Movies/Series/Streams | edit any reseller and set options.</li>\n\t\t\t\t\t<li>Improve Server. Now you can see offline servers and CPU usage.</li>\n\t\t\t\t\t<li>Fix admin and resellers notes.</li>\n\t\t\t\t\t<li>Fixed many bugs.</li>\n\t\t\t\t\t\n\t\t\t\t</ul>\n\t\t\t\t\n\t\t\t\tV2.34\n\t\t\t\t<ul>\n\t\t\t\t\t<li>Fingerprint System (FULL) | from Streams->Streams List, Choose any stream with online users and click: <i class='icon-address-card-o'></i> (You must do Reload for Main server First)</li>\n\t\t\t\t\t<li>Transcoding Profiles | from Streams->Transcoding Profiles</li>\n\t\t\t\t\t<li>Browser Server for Movies files (beta) (Don't Add/Edit Movies) (beta)</li>\n\t\t\t\t\t<li>Fix Unknown Reseller ID when renew users.</li>\n\t\t\t\t\t<li>Fix many bugs.</li>\n\t\t\t\t\t\n\t\t\t\t</ul>\n\t\t\t\t\t\n\t\t\t\tV2.33\n\t\t\t\t<ul>\n\t\t\t\t\t<li>Load Balance Tree (Beta)</li>\n\t\t\t\t\t<li>Change streams category, User agent in mass edit streams and other fetch options.</li>\n\t\t\t\t\t<li>Added for On-Demand Streams (when you ADD/EDIT): Probesize On-Demand:  You can set value 512000 to not lose audio.</li>\n\t\t\t\t\t<li>Add Fetch Options for streams and all other options.</li>\n\t\t\t\t\t<li>List users whois soon to expire on Home for Admins and Resellers.</li>\n\t\t\t\t\t<li>Delete expired users for past 5 days.</li>\n\t\t\t\t\t<li>Suspend/Unsuspend resellers and thier accounts. | from Resellers ->  Suspend</li>\n\t\t\t\t\t<li>Fix categories search error.</li>\n\t\t\t\t\t<li>EPG full (You can set EPG for Streams form EPG Page.)</li>\n\t\t\t\t\t<li>Created channels (Beta)</li>\n\t\t\t\t\t<li>Radio channels (Beta)</li>\n\t\t\t\t</ul>\n\t\t\t\tV2.32\n\t\t\t\t<ul>\n\t\t\t\t\t<li>Add Upgrade Button.</li>\n\t\t\t\t\t<li>Enhanced Users , add Unlimited Expire date for users and colors.</li>\n\t\t\t\t\t<li>Added security for username and password creation to be very strong and never use waek user/pass by resellers.</li>\n\t\t\t\t\t<li>EPG Beta | From Streams -> EPG</li>\n\t\t\t\t\t<li>Added more options for streams.</li>\n\t\t\t\t\t<li>Enhanced m3u file upload for streams.</li>\n\t\t\t\t\t<li>Enhanced Servers.</li>\n\t\t\t\t\t<li>Enhanced Bouquets and activated delete option.</li>\n\t\t\t\t\t<li>Fix many bugs.</li>\n\t\t\t\t</ul>\n\t\t\t\tV2.31\n\t\t\t\t<ul>\n\t\t\t\t\t<li>Add Unimited Load Balance Servers | from Streams->Servers</li>\n\t\t\t\t\t<li>Added Quick Tools | from Tools->Quick Tools (Delete trails,unlock ISP, transfer andswap Streams)</li>\n\t\t\t\t\t<li>Added General Settings | from Tools->General Settings.</li>\n\t\t\t\t\t<li>Added Points System (Beta).</li>\n\t\t\t\t\t<li>Fixed session collision.</li>\n\t\t\t\t\t<li>Import m3u file for VOD+Series (Beta).</li>\n\t\t\t\t\t<li>View users active connections in Users.</li>\n\t\t\t\t\t\n\t\t\t\t</ul>\n\t\t\t\tV2.30\n\t\t\t\t<ul>\n\t\t\t\t\t<li>E2 List [Adding new E2 Device soon...].</li>\n\t\t\t\t\t<li>Sort Streams from Streams->Streams List [Sort Streams].</li>\n\t\t\t\t\t<li>Bouquets full control.</li>\n\t\t\t\t\t<li>Add streams by uploading m3u file</li>\n\t\t\t\t\t<li>Delete streams from Streams-> Bulk Edit Streams</li>\n\t\t\t\t\t<li>Add movies,Series,Episodes by direct source, from http url. (LB comming soon)</li>\n\t\t\t\t\t<li>Online Users, Offline Streams, Client Error logs from Logs-> menu</li>\n\t\t\t\t\t<li>TRMP IPs, from Tools-> TRMP IPs</li>\n\t\t\t\t\t<li>Now you can set Hours for Free 1 day test accounts, from Tools->Options [1 Day Test Period:] so the user will expire after x hours</li>\n\t\t\t\t</ul>-->\n\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t\t\n\t\t\t</div>";
            if( isset($options['opt_security']) && $options['opt_security'] == 'yes' ) 
            {
                $this->top_faild_tries();
            }
        }
        else
        {
            echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22();
            echo "<div class=\"row\">\n\t\t\t<div class=\"col-md-6\">\n\t\t\t\n\t\t\t\t<!-- Welcome to IntroTik IPTV Panel with Active Code. Please choose your needs form top menu.--->\n\t\t\t\t\n\t\t\t\t\n\t\t\t\t<br/>\n\t\t\t\t<table class=\"table table-striped\">\n\t\t\t\t<thead>\n\t\t\t\t  <tr>\n\t\t\t\t\t<th>Name</th>\n\t\t\t\t\t<th>Count</th>\n\t\t\t\t\t<th></th>\n\t\t\t\t  </tr>\n\t\t\t\t</thead>\n\t\t\t\t<tbody>\n\t\t\t\n\t\t\t\t  <tr>\n\t\t\t\t\t<td>Expired Codes</td>\n\t\t\t\t\t<td><a class='btn btn-info' href=\"" . $intro->app_url('codes', 'index') . '?view=expired">' . $code_expired . "</a></td>\n\t\t\t\t\t<td><!--<a href=\"" . $this->base . "/Delete?mode=del_expired_codes\" OnClick=\"return confirm('Are you sure?');\">Move to Delete</a>--></td>\n\t\t\t\t  </tr>\n\t\t\t\t  <tr>\n\t\t\t\t\t<td>Users Expiring in 7 days</td>\n\t\t\t\t\t<td><a class='btn btn-warning' href=\"" . $intro->app_url('users', 'index') . '?view=soon_to_expire">' . $user_soon_to_expire . "</a></td>\n\t\t\t\t\t<td><!--<a class='intro_ui_del' href=\"" . $this->base . "/Delete?mode=del_user_expired\" OnClick=\"return false\">Delete</a>--></td>\n\t\t\t\t  </tr>\n\t\t\t\t  <tr>\n\t\t\t\t\t<td>Expired Users</td>\n\t\t\t\t\t<td><a class='btn btn-info' href=\"" . $intro->app_url('users', 'index') . '?view=expired">' . $user_expired . "</a></td>\n\t\t\t\t\t<td><!--<a class='intro_ui_del' href=\"" . $this->base . "/Delete?mode=del_user_expired\" OnClick=\"return false\">Delete</a>--></td>\n\t\t\t\t  </tr>\n\t\t\t\t  </tbody>\n\t\t\t\t  </table>\n\t\t\t\t\n\t\t\t\t<br/>\n\t\t\t\t<br/>\n\t\t\t\t<br/>\n\t\t\t\t<br/>\n\t\t\t\n\t\t\t</div>\n\t\t\t<div class=\"col-md-6\"> </div>\n\t\t</div>";
            echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
            if( isset($intro->option['global_msg']) && strlen($intro->option['global_msg']) > 20 && !$hide ) 
            {
                echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Global Message', 'danger');
                echo $intro->option['global_msg'];
                echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
            }
            if( strlen($this->adminRow['msg_welcome']) > 20 ) 
            {
                echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Message to: ' . $this->admin['admin_name'], 'warning');
                echo $this->adminRow['msg_welcome'];
                echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
            }
        }
        echo '<script src="' . admin_path . 'style/js/ajaxq.js"></script>';
        echo "<script>\n\t\t\$(function() {\n\t\t\t" . $jsjs . "\n\t\t});\n\t\t</script>";
    }
    public function Alert()
    {
        global $intro;
        global $sess_admin;
        echo '<div class="row"><div class="col-md-12 text-right" style=\'margin-bottom:5px;\'>';
        $blocked_ips = $intro->db->dcount('id', 'blocked_ips', '');
        if( $blocked_ips == 0 ) 
        {
            echo '<a class="btn btn-info icon-cancel" href="' . $intro->app_url('blocked_ips', 'index') . ('" title="Stream Blocked IPs">' . $blocked_ips . '</a>');
        }
        $login_fail = $intro->db->dcount('id', '' . PREFIX . '_logs_sys', 'action=\'login_fail\'');
        if( $login_fail > 0 ) 
        {
            echo ' <a class="btn btn-warning icon-login" href="' . $intro->app_url('logs_sys', 'index') . ('?action=login_fail" title="Failed Logins Attempts">' . $login_fail . '</a>');
        }
        $brute_force = $intro->db->dcount('id', '' . PREFIX . '_login_ips', '');
        if( $brute_force > 0 ) 
        {
            echo ' <a class="btn btn-danger icon-bug blinking" href="' . $intro->app_url('logs', 'BruteForce') . ('" title="Brute Force Login Attacks">' . $brute_force . '</a>');
        }
        echo '</div></div>';
    }
    public function GetTableRows()
    {
        global $intro;
        global $sess_admin;
        $id = intval($intro->input->get('id'));
        $table = $this->tables[$id];
        $intro->db->debug = false;
        $intro->db->halt_on_errors = false;
        $sql = $intro->db->query('SELECT count(*) as tot from ' . $table . ';');
        $row = $intro->db->fetch_assoc($sql);
        echo number_format($row['tot']);
    }
    public function Truncate()
    {
        global $intro;
        global $sess_admin;
        $table = trim($intro->input->get('table'));
        if( in_array($table, $this->tables) ) 
        {
            $intro->db->query('TRUNCATE ' . $table . ';');
        }
        $intro->redirect($this->appname, 'index');
    }
    public function Delete()
    {
        global $intro;
        global $sess_admin;
        $mode = trim($intro->input->get('mode'));
        $time = time();
        if( $mode == 'del_codes' ) 
        {
        }
        if( $mode == 'del_expired_codes' ) 
        {
            $intro->db->query('UPDATE ' . PREFIX . ('_codes set status=4 WHERE date_expire <= \'' . $time . '\' and date_expire<>\'\';'));
        }
        if( $mode == 'del_user_expired' ) 
        {
        }
        $intro->redirect($this->appname, 'index');
    }
    public function dash()
    {
        global $intro;
        $sql1 = $intro->db->query('SELECT count(*) AS tot_conns FROM `user_activity_now` ');
        $row1 = $intro->db->fetch_assoc($sql1);
        $tot_conns = number_format(intval($row1['tot_conns']));
        $intro->db->query('SELECT user_id FROM `user_activity_now` GROUP BY user_id');
        $tot_users = number_format($intro->db->returned_rows);
        $intro->db->query('SELECT sys.stream_id FROM `streams_sys` sys,`streams` s where sys.stream_id=s.id  AND sys.`pid` > 0 AND type=1 AND stream_status=0 GROUP BY stream_id');
        $stream_on = number_format($intro->db->returned_rows);
        $intro->db->query('SELECT sys.stream_id FROM `streams_sys` sys,`streams` s where sys.stream_id=s.id AND type=1 AND stream_status=1 GROUP BY stream_id');
        $stream_off = number_format($intro->db->returned_rows);
        $bytes_sent = $bytes_received = 0;
        $result = $intro->db->query('SELECT watchdog_data from streaming_servers');
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            $w = json_decode($myrow['watchdog_data'], true);
            $bytesX_sent = (isset($w['bytes_sent']) ? $w['bytes_sent'] : 0);
            $bytes_receivedX = (isset($w['bytes_received']) ? $w['bytes_received'] : 0);
            $bytes_sent += round($bytesX_sent, 2);
            $bytes_received += round($bytes_receivedX, 2);
        }
        echo '<div class="row">';
        echo "\n\t\t\t<div class=\"col-xl-3 col-lg-3 col-md-3 col-sm-6 text-center\">\n\t\t\t\t<div class=\"panel panel-default panel-body\">\n\t\t\t\t\t<h3>Online Users <br/> <a href=\"" . $intro->app_url('online', 'Online') . ('"><span class="label label-success icon-user-circle-o">' . $tot_users . " </span></a></h3>\n\t\t\t\t</div>\n\t\t\t</div>");
        echo "\n\t\t\t<div class=\"col-xl-3 col-lg-3 col-md-3 col-sm-6 text-center\">\n\t\t\t\t<div class=\"panel panel-default panel-body\">\n\t\t\t\t\t<h3>Connections <br/> <a href=\"" . $intro->app_url('online', 'Online') . ('"><span class="label label-success icon-flash">' . $tot_conns . " </span></a>\n\t\t\t\t\t\t&nbsp; <a href=\"") . $intro->app_url('servers', 'Monitoring') . "\"><span class=\"icon-server label label-default\">Servers</span></a> </h3> \n\t\t\t\t</div>\n\t\t\t</div>";
        echo "\n\t\t\t<div class=\"col-xl-3 col-lg-3 col-md-3 col-sm-6 text-center\">\n\t\t\t\t<div class=\"panel panel-default panel-body\">\n\t\t\t\t\t<h3><sub style='color:#5bc0de;font-size:12px;'>Up</sub> Network <sub style='color:#5bc0de;font-size:12px;'>Down</sub> \n\t\t\t\t\t<br/> <span class=\"label label-info\">" . number_format($bytes_sent, 2) . ' | ' . number_format($bytes_received, 2) . "</span></h3> \n\t\t\t\t</div>\t\n\t\t\t</div>";
        echo "\n\t\t\t<div class=\"col-xl-3 col-lg-3 col-md-3 col-sm-6 text-center\">\n\t\t\t\t<div class=\"panel panel-default panel-body\">\n\t\t\t\t\t<h3>Streams <br/> \n\t\t\t\t\t<a href=\"" . $intro->app_url('streams', 'index') . ('?stream_status=online"><span class="label label-success icon-volume-up">' . $stream_on . "</span></a> \n\t\t\t\t\t\n\t\t\t\t\t<a href=\"") . $intro->app_url('streams', 'index') . ('?view=stopped"><span class="label label-danger icon-volume-off">' . $stream_off . "</span></a></h3>\n\t\t\t\t</div>\n\t\t\t</div>");
        echo '</div>';
    }
    public function Update()
    {
        global $intro;
        global $config;
        $intro->db->debug = false;
        $intro->db->halt_on_errors = false;
        $up_count = 0;
        if( !isset($intro->option['db_ver']) ) 
        {
            $intro->db->query('INSERT IGNORE  INTO `solus_options` (`id`, `name`, `val`) VALUES (NULL, \'db_ver\', \'230\'); ');
        }
        if( intval($intro->input->get('force')) >= 235 ) 
        {
            $intro->option['db_ver'] = intval($intro->input->get('force'));
        }
        if( intval($intro->input->get('force')) == 230 ) 
        {
            $intro->option['db_ver'] = 230;
        }
        if( intval($intro->input->get('db_ver')) > 0 ) 
        {
            $intro->option['db_ver'] = intval($intro->input->get('db_ver'));
        }
        if( $intro->option['db_ver'] == '230' ) 
        {
            $intro->db->query('UPDATE `solus_admin` set `no_invoice`=0;');
            $intro->db->query('UPDATE `users` set `is_trial`=0 WHERE id IN (select userid from  solus_users_data WHERE period IN (1,3,6,12,24,36));');
            $intro->db->halt_on_errors = false;
            $intro->db->query('ALTER TABLE `solus_admin`  ADD `manage_vod` TINYINT NULL DEFAULT NULL  AFTER `msg_welcome`,  ADD `manage_streams` TINYINT NULL DEFAULT NULL  AFTER `manage_vod`;');
            $intro->db->query("CREATE TABLE IF NOT EXISTS `solus_tasks` (\n\t\t\t\t\t  `task_id` int(11) NOT NULL AUTO_INCREMENT,\n\t\t\t\t\t  `task_for` varchar(50) COLLATE utf8_unicode_ci NOT NULL,\n\t\t\t\t\t  `task_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,\n\t\t\t\t\t  `task_table` varchar(30) COLLATE utf8_unicode_ci NOT NULL,\n\t\t\t\t\t  `task_keyid` int(11) NOT NULL,\n\t\t\t\t\t  `task_date` datetime NOT NULL,\n\t\t\t\t\t  `cmd_start` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `cmd_start_status` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `cmd_stop` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `cmd_stop_status` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `cmd_restart` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `cmd_restart_status` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `cmd_fetch` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `cmd_fetch_status` tinyint(4) DEFAULT NULL,\n\t\t\t\t\t  `task_status` int(11) NOT NULL,\n\t\t\t\t\t  `task_reply` text COLLATE utf8_unicode_ci,\n\t\t\t\t\t  PRIMARY KEY (`task_id`),\n\t\t\t\t\t  KEY `task_type` (`task_name`),\n\t\t\t\t\t  KEY `task_date` (`task_date`),\n\t\t\t\t\t  KEY `task_status` (`task_status`),\n\t\t\t\t\t  KEY `task_keyid` (`task_keyid`),\n\t\t\t\t\t  KEY `task_for` (`task_for`)\n\t\t\t\t\t) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
            $intro->db->query('COMMIT;');
            $up_count++;
        }
        if( $intro->option['db_ver'] == '235' ) 
        {
            $intro->db->query($this->find_index('solus_logs_sys', 'ip'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_logs_sys` ADD INDEX(`ip`);');
            }
            $intro->db->query("CREATE TABLE IF NOT EXISTS `solus_login_ips` (\n\t\t\t\t  `id` int(11) NOT NULL AUTO_INCREMENT,\n\t\t\t\t  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,\n\t\t\t\t  `ip` varchar(46) COLLATE utf8_unicode_ci NOT NULL,\n\t\t\t\t  `timeDiff` int(11) NOT NULL,\n\t\t\t\t  `tries` int(11) NOT NULL,\n\t\t\t\t  PRIMARY KEY (`id`),\n\t\t\t\t  UNIQUE KEY `ipuniq` (`ip`) USING BTREE,\n\t\t\t\t  KEY `ip` (`ip`),\n\t\t\t\t  KEY `timeDiff` (`timeDiff`)\n\t\t\t\t) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
            $intro->db->query('ALTER TABLE `member_groups` ADD `lock_device` TINYINT(1) NOT NULL AFTER `allow_download`;  ');
            $intro->db->query("ALTER TABLE `packages` ADD `can_add_codes` TINYINT NOT NULL DEFAULT '0' AFTER `lock_device`, \n\t\t\t\tADD `can_add_users` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_codes`, \n\t\t\t\tADD `can_add_mag` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_users`, \n\t\t\t\tADD `can_add_e2` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_mag`; ");
            $up_count++;
        }
        if( $intro->option['db_ver'] == '236' ) 
        {
            $intro->db->query('ALTER TABLE `member_groups` ADD `lock_device` TINYINT(1) NOT NULL AFTER `allow_download`;  ');
            $intro->db->query("ALTER TABLE `packages` ADD `can_add_codes` TINYINT NOT NULL DEFAULT '0' AFTER `lock_device`, \n\t\t\t\tADD `can_add_users` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_codes`, \n\t\t\t\tADD `can_add_mag` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_users`, \n\t\t\t\tADD `can_add_e2` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_mag`; ");
            $up_count++;
        }
        if( $intro->option['db_ver'] == '237' ) 
        {
            $intro->db->query("ALTER TABLE `solus_admin`  ADD `can_set_country` TINYINT NOT NULL  AFTER `can_m3u`,  \n\t\t\tADD `can_set_pass` TINYINT NOT NULL  AFTER `can_set_country`,  \n\t\t\tADD `can_set_mac_opt` TINYINT NOT NULL  AFTER `can_set_pass`; ");
            $intro->db->query('UPDATE `solus_admin`  set can_set_country=1,can_set_pass=1,can_set_mac_opt=1;');
            $intro->db->query($this->find_index('solus_codes', 'date_expire'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_codes` ADD INDEX(`date_expire`);  ');
            }
            $intro->db->query('ALTER TABLE `solus_admin`  ADD `can_add_e2` TINYINT(1) NOT NULL  AFTER `can_add_mag`');
            $intro->db->query('ALTER TABLE `solus_codes` CHANGE `bouquets` `bouquets` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL; ');
            $intro->db->query("ALTER TABLE `packages` ADD `can_set_country` TINYINT(1) NOT NULL AFTER `can_add_e2`,\n\t\t\tADD `can_set_pass` TINYINT(1) NOT NULL AFTER `can_set_country`,\n\t\t\tADD `can_set_mac_opt` TINYINT(1) NOT NULL AFTER `can_set_pass`,\n\t\t\tADD `can_set_act_count` TINYINT(1) NOT NULL AFTER `can_set_mac_opt`; ");
            $intro->db->query($this->find_index('solus_trans', 'dateadded'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_trans` ADD INDEX(`dateadded`); ');
            }
            $intro->db->query($this->find_index('solus_trans', 'userid'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_trans` ADD INDEX(`userid`); ');
            }
            $intro->db->query($this->find_index('solus_trans', 'admin'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_trans` ADD INDEX(`admin`); ');
            }
            $intro->db->query($this->find_index('solus_trans', 'admin_father'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_trans` ADD INDEX(`admin_father`); ');
            }
            $intro->db->query($this->find_index('solus_trans', 'period'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_trans` ADD INDEX(`period`); ');
            }
            $up_count++;
        }
        if( $up_count > 0 ) 
        {
            $intro->db->query('UPDATE `solus_options` set val=\'' . _intro_db_ver . '\' WHERE name=\'db_ver\';');
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Update success!', 'success');
        }
        else
        {
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Update Failed! <a class="btn btn-success" href="' . $this->base . '/Update?force=237"> Click to force Update!</a>', 'danger');
        }
        if( intval($intro->input->get('force')) == 0 ) 
        {
            $intro->db->query('ALTER TABLE `member_groups` ADD `lock_device` TINYINT(1) NOT NULL AFTER `allow_download`;  ');
            $intro->db->query("ALTER TABLE `packages` ADD `can_add_codes` TINYINT NOT NULL DEFAULT '0' AFTER `lock_device`, \n\t\t\t\tADD `can_add_users` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_codes`, \n\t\t\t\tADD `can_add_mag` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_users`, \n\t\t\t\tADD `can_add_e2` TINYINT NOT NULL DEFAULT '0' AFTER `can_add_mag`; ");
            $intro->db->query(' ALTER TABLE `solus_admin` ADD `member_group_id` SMALLINT NOT NULL AFTER `host`;  ');
            $intro->db->query(' ALTER TABLE `streaming_servers` ADD `view_order` MEDIUMINT NOT NULL AFTER `timeshift_only`; ');
            $intro->db->query(' ALTER TABLE `users` ADD `is_code` TINYINT NULL AFTER `is_e2`;  ');
            $intro->db->query(' ALTER TABLE `users` ADD `fullname` VARCHAR(50) NULL DEFAULT NULL AFTER `member_id`;   ');
            $intro->db->query(' ALTER TABLE `users` ADD `pkg` SMALLINT NULL DEFAULT NULL AFTER `password`;    ');
            $intro->db->query(' ALTER TABLE `solus_trans` ADD `pkg` SMALLINT NULL AFTER `period`;     ');
            $intro->db->query(' ALTER TABLE `solus_codes` ADD `pkg` SMALLINT NOT NULL AFTER `period`;     ');
            $intro->db->query(' ALTER TABLE `solus_admin` ADD `main_father` INT NOT NULL AFTER `adminid`;     ');
            $intro->db->query(' ALTER TABLE `solus_admin` CHANGE `resel_bouquets` `resel_bouquets` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL;');
            $intro->db->query(' ALTER TABLE `solus_logs` ADD `country` VARCHAR(3) NULL DEFAULT NULL AFTER `ip`; ');
            $intro->db->query(' ALTER TABLE `solus_logs_sys` ADD `country` VARCHAR(3) NULL DEFAULT NULL AFTER `ip`;  ');
            $intro->db->query(' ALTER TABLE `solus_login_ips` ADD `country` VARCHAR(3) NULL DEFAULT NULL AFTER `ip`;   ');
            $intro->db->query(' ALTER TABLE `solus_logs_sys` CHANGE `ip` `ip` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL; ');
            $intro->db->query($this->find_index('solus_codes', 'pkg'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_codes` ADD INDEX(`pkg`); ');
            }
            $intro->db->query($this->find_index('users', 'fullname'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `users` ADD INDEX(`fullname`); ');
            }
            $intro->db->query($this->find_index('users', 'pkg'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `users` ADD INDEX(`pkg`); ');
            }
            $intro->db->query($this->find_index('users', 'is_code'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `users` ADD INDEX(`is_code`); ');
            }
            $intro->db->query($this->find_index('solus_trans', 'pkg'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_trans` ADD INDEX(`pkg`);  ');
            }
            $intro->db->query($this->find_index('solus_admin', 'member_group_id'));
            if( $intro->db->returned_rows == 0 ) 
            {
                $intro->db->query('ALTER TABLE `solus_admin` ADD INDEX(`member_group_id`);   ');
            }
        }
        $intro->db->query('UPDATE `solus_options` set val=\'' . _intro_db_ver . '\' WHERE name=\'db_ver\';');
        _obf_0D29240218250E143407102A213F0D2D3907013C1A3F22();
        $intro->redirect($this->appname);
    }
    public function find_index($table, $index)
    {
        global $config;
        return "select distinct index_name from information_schema.statistics \n\t\t\t\twhere table_schema = '" . $config['db']['database'] . "' \n\t\t\t\tand table_name = '" . $table . '\' and index_name like \'' . $index . '\'';
    }
}
