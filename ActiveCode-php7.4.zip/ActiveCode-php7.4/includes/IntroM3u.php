<?php 
class IntroM3u
{
    public $url = '';
    public $user = '';
    public $pass = '';
    public $bouquet = '';
    public $FileName = '';
    public $post = [];
    public $timeout = 5;
    public function __construct($userid, $user, $pass, $bouquet)
    {
        global $intro;
        global $array;
        $this->url = '';
        $this->user = $user;
        $this->pass = $pass;
        $this->bouquet = $bouquet;
        $sql3 = $intro->db->query('SELECT `userid`,`token`  FROM `' . PREFIX . ('_data` WHERE `userid` = ' . $userid . ';'));
        if( $intro->db->returned_rows == 0 ) 
        {
            $data = [];
            $data['userid'] = $userid;
            $data['token'] = _token();
            $token = $data['token'];
            $intro->db->insert('' . PREFIX . '_data', $data);
        }
        else
        {
            $row3 = $intro->db->fetch_assoc($sql3);
            $token = $row3['token'];
        }
        $this->FileName = '../m3u/' . ($userid + 100000) . '-' . $token . '.m3u';
        $this->getM3u($user, $pass, $bouquet);
    }
    public function getM3u($user, $pass, $bouquet)
    {
        global $intro;
        global $array;
        $_M3U = "#EXTM3U\n";
        $bouquet = json_decode($bouquet, true);
        $sql = $intro->db->query('SELECT SQL_CACHE * FROM bouquets  WHERE id IN (' . implode(',', $bouquet) . ') order by view_order asc;');
        $i = 0;
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $i++;
            $bouquet_channels = @json_decode($row['bouquet_channels'], true);
            $bouquet_name = $row['bouquet_name'];
            $ch_count = @count($bouquet_channels);
            $chans = implode(',', $bouquet_channels);
            $sql_ch = $intro->db->query('SELECT id, stream_display_name,stream_source,stream_icon  FROM streams ' . (' WHERE  id IN (' . $chans . ') order by field(id, ' . $chans . ');'));
            while( $row = $intro->db->fetch_assoc($sql_ch) ) 
            {
                extract($row);
                $stream = str_replace([
                    '{type}', 
                    '{user}', 
                    '{pass}', 
                    '{ch}'
                ], [
                    'live', 
                    $user, 
                    $pass, 
                    $id
                ], trim($intro->option['iptv_host']));
                $_M3U .= ('#EXTINF:-1 tvg-id="" tvg-name="' . $stream_display_name . '" ' . ('tvg-logo="' . $stream_icon . '" group-title="' . $bouquet_name . '",' . $stream_display_name . "\n") . ($stream . "\n"));
            }
        }
        $curl = new IntroCurl($intro->option['remote_movies_api']);
        $_M3U .= $curl->getM3uVOD();
        file_put_contents($this->FileName, $_M3U);
        unset($_M3U);
    }
    public function html()
    {
        global $intro;
        global $array;
        echo '<input type=\'text\' class=\'AutoCopy form-control\' ' . (' value=\'' . $intro->option['m3u_host']) . str_replace('../m3u/', '', $this->FileName) . '\' />';
        $url = parse_url($intro->option['m3u_host']);
        $data = 'Host: ' . $url['scheme'] . '://' . $url['host'] . ":80\n";
        $data .= ('Username: ' . $this->user . "\n");
        $data .= ('Password: ' . $this->pass . "\n");
        echo '<textarea class=\'AutoCopy form-control\'  style=\'height:100px;font-size:16px;\' spellcheck="false" data-gramm="false">' . ($data . '</textarea>');
    }
    public function set($name, $value)
    {
        $this->$name = $value;
    }
}
