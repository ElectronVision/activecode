<?php 
$menu = $dropcod = $main_menu = '';
$app_name = $intro->app;
if( isset($intro->lang[$app_name]) ) 
{
    $app_name = $intro->lang[$app_name];
}
$sess_admin = $intro->auth->sess_admin();
$rowadmin = $intro->auth->admin_data();
$sessadmin = $sess_admin['adminid'];
$logo = admin_path . 'style/img/logo.png';
if( $rowadmin['logo'] != '' ) 
{
    $logo = 'data:image/png;base64,' . base64_encode(stripslashes($rowadmin['logo']));
}
$balance = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($sess_admin['adminid']);
if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 || $rowadmin['manage_vod'] == 1 || $rowadmin['manage_streams'] == 1 ) 
{
    global $options;
    $main_menu = "\n\t<li class=\"dropdown\">\n\t\t<a class=\"icon-podcast dropdown-toggle\" href=\"" . $intro->app_url('streams', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\t\tStreams <span class=\"caret\"></span>\n\t\t</a>\n\t\t<ul class=\"dropdown-menu\">";
    if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 || $rowadmin['manage_streams'] == 1 || $rowadmin['manage_bq'] == 1 || $rowadmin['manage_cats'] == 1 ) 
    {
        if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 || $rowadmin['manage_streams'] == 1 ) 
        {
            $main_menu .= ('<li><a class="icon-podcast" href="' . $intro->app_url('streams', 'index') . "\">Streams List</a></li>\n\t\t\t<li><a class=\"icon-plus\" href=\"" . $intro->app_url('streams', 'Form') . "?t=add\">Add New Stream</a></li>\n\t\t\t<li><a class=\"icon-edit-1\" href=\"" . $intro->app_url('streams_created', 'index') . "\">Created Channels</a></li>\n\t\t\t<li><a class=\"icon-mic-2\" href=\"" . $intro->app_url('streams_radio', 'index') . "\">Radio Channels</a></li>\n\t\t\t<li><a class=\"icon-code\" href=\"" . $intro->app_url('streams_bulk', 'index') . '">Mass Edit Streams</a></li>');
        }
        if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 || $rowadmin['manage_streams'] == 1 || $rowadmin['manage_cats'] == 1 ) 
        {
            $main_menu .= ('<li><a class="icon-folder" href="' . $intro->app_url('categories', 'index') . '">Categories</a></li>');
        }
        if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 || $rowadmin['manage_streams'] == 1 || $rowadmin['manage_bq'] == 1 ) 
        {
            $main_menu .= ('<li><a class="icon-gift" href="' . $intro->app_url('bouquets', 'index') . '">Bouquets</a></li>');
        }
    }
    if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 ) 
    {
        $main_menu .= ('<li><a class="icon-video-2" href="' . $intro->app_url('transcode_profiles', 'index') . '">Transcoding Profiles</a></li>');
    }
    $main_menu .= '<li class="divider"></li>';
    if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 || $rowadmin['manage_vod'] == 1 ) 
    {
        $main_menu .= ('<li><a class="icon-list-alt" href="' . $intro->app_url('movies', 'index') . '">Movies</a></li>');
        $main_menu .= ('<li><a class="icon-magic" href="' . $intro->app_url('movies', 'MassAdd') . '">Mass Add Movies</a></li>');
        $main_menu .= ('<li><a class="icon-list-alt" href="' . $intro->app_url('series', 'index') . '">Series</a></li>');
    }
    if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 ) 
    {
        $main_menu .= ("\n\t\t\t<li class=\"divider\"></li>\n\t\t\t<li><a class=\"icon-calendar\" href=\"" . $intro->app_url('epg', 'index') . '">EPG</a></li>');
        if( isset($options['opt_stb_to_iptv']) && $options['opt_stb_to_iptv'] == 'yes' ) 
        {
            $main_menu .= ('<li><a class="icon-picture" href="' . $intro->app_url('sat2iptv', 'index') . '">SAT2IPTV</a></li>');
        }
        $main_menu .= ("\n\t\t\t<li class=\"divider\"></li>\n\t\t\t<li><a class=\"icon-server\" href=\"" . $intro->app_url('servers', 'index') . '">Servers</a></li>');
        if( isset($options['opt_import_xml']) && $options['opt_import_xml'] == 'yes' ) 
        {
            $main_menu .= ("\n\t\t\t<li class=\"divider\"></li>\n\t\t\t<li><a class=\"icon-building\" href=\"" . $intro->app_url('xml_import', 'index') . "\">Import XML Streams</a></li>\n\t\t\t<li><a class=\"icon-building\" href=\"" . $intro->app_url('xml_import', 'vod') . '">Import XML VODS</a></li>');
        }
        if( isset($options['opt_xml_export']) && $options['opt_xml_export'] == 'yes' ) 
        {
            $main_menu .= ('<li><a class="icon-picture" href="' . $intro->app_url('xml_export', 'index') . '">Export XML</a></li>');
        }
        if( isset($options['opt_strm_token']) && $options['opt_strm_token'] == 'yes' ) 
        {
            $main_menu .= ('<li><a class="icon-exchange" href="' . $intro->app_url('streams', 'Token') . '">Token Update</a></li>');
        }
        $main_menu .= ('<li><a class="icon-chart-bar" href="' . $intro->app_url('streams', 'Report') . '">Streams Report</a></li>');
        $main_menu .= ('<li><a class="icon-chart-bar" href="' . $intro->app_url('streams', 'ChangeDNS') . '">Change DNS</a></li>');
    }
    $main_menu .= "\n\t\t</ul>\n\t</li>";
    if( $sess_admin['level'] == 1 || $sess_admin['level'] == 9 ) 
    {
        $main_menu .= ("\n\t<li class=\"dropdown\">\n\t\t<a class=\"icon-bug dropdown-toggle\" href=\"" . $intro->app_url('logs', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\t\tLogs <span class=\"caret\"></span>\n\t\t</a>\n\t\t<ul class=\"dropdown-menu\">\n\t\t\t<li><a class=\"icon-bug\" href=\"" . $intro->app_url('logs_sys', 'index') . "\">System Logs</a></li>\n\t\t\t<li><a class=\"icon-login\" href=\"" . $intro->app_url('logs', 'BruteForce') . "\">Brute Force Login Attacks</a></li>\n\t\t\t<li><a class=\"icon-bug\" href=\"" . $intro->app_url('logs', 'index') . "\">Active Code Logs</a></li>\n\t\t\t<li><a class=\"icon-user\" href=\"" . $intro->app_url('logs', 'Clients') . "?t=add\">Client Error Logs</a></li>\n\t\t\t<li><a class=\"icon-bug\" href=\"" . $intro->app_url('logs', 'Top100Clients') . "?t=add\">Top 100 Client Error Logs</a></li>\n\t\t\t<li><a class=\"icon-podcast\" href=\"" . $intro->app_url('logs', 'Streams') . "?t=add\">Stream Error Logs</a></li>\n\t\t</ul>\n\t</li>\n\t\n\n\t<li class=\"dropdown\">\n\t\t<a class=\"icon-users dropdown-toggle\" href=\"" . $intro->app_url('resellers', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\t\tResellers <span class=\"caret\"></span>\n\t\t</a>\n\t\t<ul class=\"dropdown-menu\">\n\t\t\t<li><a class=\"icon-users\" href=\"" . $intro->app_url('resellers', 'index') . "\">Resellers List</a></li>\n\t\t\t<li><a class=\"icon-plus\" href=\"" . $intro->app_url('resellers', 'Form') . "?t=add\">Add New Reseller</a></li>\n\t\t\t<li><a class=\"icon-box\" href=\"" . $intro->app_url('resellers_packages', 'index') . "\">Packages</a></li>\n\t\t\t<li><a class=\"icon-users\" href=\"" . $intro->app_url('resellers_group', 'index') . "\">Reseller Groups</a></li>\n\t\t\t<li><a class=\"icon-code\" href=\"" . $intro->app_url('commands_resel', 'index') . ("\">Mass Edit Resellers</a></li>\n\t\t\t\n\t\t</ul>\n\t</li>\n\t\n\t<li class=\"dropdown\">\n\t\t<a class=\"icon-cog dropdown-toggle\" href=\"" . $intro->app_url('tools', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\t\tTools <span class=\"caret\"></span>\n\t\t</a>\n\t\t<ul class=\"dropdown-menu\">"));
        $main_menu .= ('<li><a class="icon-cog" href="' . $intro->app_url('settings', 'index') . '">General Settings</a></li>');
        $main_menu .= ('<li><a class="icon-cog" href="' . $intro->app_url('options', 'index') . '">Codes Options</a></li>');
        $main_menu .= ('<li><a class="icon-cog" href="' . $intro->app_url('tools', 'quick') . '">Quick Tools</a></li>');
        $main_menu .= ("\n\t\t\t<li><a class=\"icon-login\" href=\"" . $intro->app_url('sessions', 'index') . "\">Sessions</a></li>\n\t\t\t<li><a class=\"icon-bug\" href=\"" . $intro->app_url('logs_sys', 'index') . "\">System Logs</a></li>\n\t\t\t<li><a class=\"icon-doc\" href=\"" . $intro->app_url('pages', 'index') . "\">Pages</a></li>\n\t\t\t<li><a class=\"icon-wrench\" href=\"" . $intro->app_url('fix', 'index') . '">Fix Codes with Xtream</a></li>');
        $main_menu .= '<li class="divider"></li>';
        $main_menu .= ('<li><a class="icon-list-alt" href="' . $intro->app_url('demand', 'index') . '">Users Demands</a></li>');
        $main_menu .= ('<li><a class="icon-list-alt" href="' . $intro->app_url('comments', 'index') . '">Comments</a></li>');
        $main_menu .= '<li class="divider"></li>';
        $main_menu .= ("\n\t\t\t<li><a class=\"icon-hdd\" href=\"" . $intro->app_url('backup', 'index') . "\">Backup</a></li>\n\t\t\t<li><a class=\"icon-shield\" href=\"" . $intro->app_url('firewall', 'index') . "\">ِActive Code IPs Attack</a></li>\n\t\t\t<li><a class=\"icon-cancel\" href=\"" . $intro->app_url('blocked_ips', 'index') . "\">Blocked Stream IPs (Flood)</a></li>\n\t\t\t<li><a class=\"icon-cancel-circled\" href=\"" . $intro->app_url('blocked_user_agents', 'index') . "\">Blocked User Agents</a></li>\n\t\t\t<li><a class=\"icon-up\" href=\"" . $intro->app_url('rtmp_ips', 'index') . "\">RTMP IPs</a></li>\n\t\t\t<li class=\"divider\"></li>\n\t\t\t<li><a class=\"icon-arrows-cw\" href=\"" . $intro->app_url('tools', 'String2MAC') . "\">String to MAC</a></li>\n\t\t\t<li class=\"divider\"></li>\n\t\t\t<li><a class=\"icon-link\" href=\"" . $intro->app_url('tools', 'CheckLine') . "\">Check m3u Line</a></li>\n\t\t\t<li><a class=\"icon-arrows-cw\" href=\"" . $intro->app_url('tools', 'ClearCache') . "\">Clear Cache</a></li>\n\t\t\t\n\t\t</ul>\n\t</li>");
    }
}
if( $sess_admin['level'] != 1 && isset($intro->option['AllowReseToSeeLogs']) && intval($intro->option['AllowReseToSeeLogs']) == 1 ) 
{
    $main_menu .= ('<li><a class="icon-bug" href="' . $intro->app_url('logs', 'index') . '">Logs</a></li>');
}
$admin_welcome = $intro->lang['welcome'] . ' <b>' . $sess_admin['admin_name'] . '</b>';
if( $rowadmin['level'] == 1 || $rowadmin['can_add_codes'] == 1 ) 
{
    $menu = "\n<li class=\"dropdown\">\n\t<a class=\"icon-list dropdown-toggle\" href=\"" . $intro->app_url('codes', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\tCodes <span class=\"caret\"></span>\n\t</a>\n\t<ul class=\"dropdown-menu\">\n\t\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('codes', 'index') . '"> Codes List</a></li>';
    if( $sess_admin['level'] != 9 ) 
    {
        $menu .= ("\n\t\t\t<li><a class=\"icon-plus\" href=\"" . $intro->app_url('codes', 'Form') . "?t=add\"> Add Codes</a></li>\n\t\t\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('trans', 'index') . '">Code Trans</a></li>');
        if( $sess_admin['level'] == 1 ) 
        {
            $menu .= ("\n\t\t\t\t<li><a class=\"icon-bookmark\" href=\"" . $intro->app_url('codes_master', 'index') . "\">Master Codes</a></li>\n\t\t\t\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('model', 'index') . "\">STB Models</a></li>\n\t\t\t\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('free_code', 'index') . "\">Free Code</a></li>\n\t\t\t\t<li><a class=\"icon-up\" href=\"" . $intro->app_url('codes_import', 'index') . '">Import Codes</a></li>');
        }
        if( $sess_admin['level'] == 1 || $GLOBALS['_ADMIN']['can_add_mac'] == 1 ) 
        {
            $menu .= ('<li><a class="icon-maxcdn" href="' . $intro->app_url('codes', 'FormSerialMac') . '?t=mac">Add By MAC</a></li>');
        }
        if( $sess_admin['level'] == 1 || $GLOBALS['_ADMIN']['can_add_sn'] == 1 ) 
        {
            $menu .= ('<li><a class="icon-barcode" href="' . $intro->app_url('codes', 'FormSerialMac') . '?t=serial">Add By Serial</a></li>');
        }
        if( $sess_admin['level'] == 2 ) 
        {
            $menu .= ('<li><a class="icon-up" href="' . $intro->app_url('codes_import', 'index') . '">Import Codes</a></li>');
        }
        $menu .= ("\n\t\t\t<li><a class=\"icon-globe\" href=\"" . $intro->app_url('online', 'index') . '">Online</a></li>');
        if( $sess_admin['level'] == 1 ) 
        {
            $menu .= ('<li><a class="icon-list" href="' . $intro->app_url('act_count', 'index') . '">Activation Count</a></li>');
        }
        $menu .= ("\n\t\t\t<li><a class=\"icon-exchange\" href=\"" . $intro->app_url('codes', 'CodeChange') . "\">Changed Codes</a></li>\n\t\t\t<li><a class=\"icon-list-alt\" href=\"" . $intro->app_url('codes', 'Report') . '">Report</a></li>');
        if( $sess_admin['level'] == 1 ) 
        {
            $menu .= ('<li><a class="icon-code" href="' . $intro->app_url('commands', 'index') . '">Mass Edit (Codes)</a></li>');
        }
    }
    $menu .= "\n\t</ul>\n</li>";
}
if( $sess_admin['level'] == 1 || $rowadmin['can_add_users'] == 1 ) 
{
    $menu .= ("\n<li class=\"dropdown\">\n\t<a class=\"icon-user dropdown-toggle\" href=\"" . $intro->app_url('users', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\tUsers <span class=\"caret\"></span>\n\t</a>\n\t<ul class=\"dropdown-menu\">\n\t\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('users', 'index') . "\"> Users List</a></li>\n\t\t<li><a class=\"icon-plus\" href=\"" . $intro->app_url('users', 'Form') . '?t=add"> Add User</a></li>');
    if( $sess_admin['level'] == 1 ) 
    {
        $menu .= ('<li><a class="icon-list" href="' . $intro->app_url('users', 'index', '?is_restreamer=1') . '">Restreamers</a></li>');
    }
    $menu .= ('<li><a class="icon-globe" href="' . $intro->app_url('online', 'Online') . '">Online Users</a></li>');
    if( $sess_admin['level'] == 1 ) 
    {
        $menu .= ('<li><a class="icon-podcast" href="' . $intro->app_url('online', 'FindRestreamers') . '">Find Restreamers</a></li>');
        $menu .= ('<li><a class="icon-bug" href="' . $intro->app_url('online', 'UsersConnectSameIP') . '">Users Connect From Same IP</a></li>');
        $menu .= ('<li><a class="icon-list bg-danger" href="' . $intro->app_url('users', 'index') . '?view=UsersEqPass">Weak Password !!! </a></li>');
        $menu .= ('<li><a class="icon-code" href="' . $intro->app_url('commands_users', 'index') . '">Mass Edit (Users)</a></li>');
    }
    $menu .= "\n\t</ul>\n</li>";
}
if( $sess_admin['level'] == 1 || $rowadmin['can_add_e2'] == 1 ) 
{
    $menu .= ("\n<li class=\"dropdown\">\n\t<a class=\"icon-eq-outline dropdown-toggle\" href=\"" . $intro->app_url('e2', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\tE2 <span class=\"caret\"></span>\n\t</a>\n\t<ul class=\"dropdown-menu\">\n\t\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('e2', 'index') . "\"> E2 List</a></li>\n\t\t<li><a class=\"icon-plus\" href=\"" . $intro->app_url('e2', 'Form') . '?t=add"> Add New E2 Device</a></li>');
    $menu .= "\n\t</ul>\n</li>";
}
if( $sess_admin['level'] == 1 || $rowadmin['can_add_users'] == 1 ) 
{
    $menu .= ("\n<li class=\"dropdown\">\n\t<a class=\"icon-desktop dropdown-toggle\" href=\"" . $intro->app_url('mag', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\tMAG <span class=\"caret\"></span>\n\t</a>\n\t<ul class=\"dropdown-menu\">\n\t\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('mag', 'index') . "\"> MAG List</a></li>\n\t\t<li><a class=\"icon-plus\" href=\"" . $intro->app_url('mag', 'Form') . '?t=add"> Add MAG</a></li>');
    if( $sess_admin['level'] == 1 ) 
    {
        $menu .= ('<li><a class="icon-key" href="' . $intro->app_url('mag', 'ChangeAllPass') . '">Change All Passwords</a></li>');
    }
    $menu .= "</ul>\n</li>";
}
if( $sess_admin['level'] != 9 ) 
{
    $menu .= ("\n<li class=\"dropdown\">\n\t<a class=\"icon-money dropdown-toggle\" href=\"" . $intro->app_url('statement', 'index') . "\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">\n\t\tBilling <span class=\"caret\"></span>\n\t</a>\n\t<ul class=\"dropdown-menu\">\n\t\t<li><a class=\"icon-money\" href=\"" . $intro->app_url('payments', 'index') . "\">Payments</a></li>\n\t\t<li><a class=\"icon-doc-text-inv\" href=\"" . $intro->app_url('invoices', 'index') . "?t=add\">Invoices</a></li>\n\t\t<li><a class=\"icon-calendar\" href=\"" . $intro->app_url('statement', 'index') . '?t=add">Statement</a></li>');
    if( in_array($sess_admin['level'], [
        1, 
        6
    ]) ) 
    {
        $menu .= ('<li><a class="dropdown-item icon-exchange" href="' . $intro->app_url('payments', 'Transfer') . '">Transfer Credit</a></li>');
    }
    $menu .= "\n\t</ul>\n</li>";
}
if( isset($options['opt_resel_edit_pkgs']) && $options['opt_resel_edit_pkgs'] == 'yes' && $sess_admin['level'] != 1 ) 
{
    $menu .= ('<li><a class="icon-edit" href="' . $intro->app_url('bouquets_resel', 'index') . '">Bouquets</a></li>');
}
$menu .= $main_menu;
if( in_array($sess_admin['level'], [
    5, 
    8
]) ) 
{
    $menu = "\n\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('codes_mini', 'index') . "\">Codes</a></li>\n\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('streams', 'index') . '">Streams</a></li>';
}
if( $sess_admin['level'] == 8 ) 
{
    $menu .= ("\n\t<li><a class=\"icon-list\" href=\"" . $intro->app_url('logs', 'index') . "\">Logs</a></li>\n\t");
}
if( $rowadmin['member_group_id'] == 0 && intval($rowadmin['level']) == 6 || $rowadmin['member_group_id'] > 0 && $array['member_groups'][intval($rowadmin['member_group_id'])]['create_sub_resellers'] == 1 ) 
{
    $menu .= ('<li><a class="icon-users" href="' . $intro->app_url('resellers', 'index') . '">Resellers</a></li>');
}
if( isset($intro->option['hide_introtech_copy']) && $intro->option['hide_introtech_copy'] == 1 ) 
{
    $copyright = '';
}
else
{
    $copyright = _intro_ver;
}
include('style/header.php');
