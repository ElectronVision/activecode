<?php 
define('_ENABLE_LOGIN_HASH_CODE', 'no');
define('_LOGIN_HASH_CODE', '12985');
