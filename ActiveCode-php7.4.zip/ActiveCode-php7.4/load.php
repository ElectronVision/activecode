<?php 
namespace 
{
    echo '﻿';
    if( !defined('_CHECK_X_ME') ) 
    {
        exit( 'error calling script' );
    }
    define('_intro_db_ver', '238');
    define('_intro_ver', 'IntroTik IPTV v2.38 By IntroTech www.intro.ps');
    function _obf_0D2A1F0B1D22240D3D103E2A0D32125C5C013F192C3632($str, $for = 'save')
    {
        if( $for == 'save' ) 
        {
            if( $str != '' ) 
            {
                $ex = explode(',', $str);
                $json = json_encode($ex);
                return $json;
            }
            else
            {
                return '';
            }
        }
    }
    function _obf_0D223F350731381A3F101E2F0B0536222129393F132201()
    {
        if( function_exists('memory_get_usage') ) 
        {
            $mem = memory_get_usage(true);
            if( $mem < 1024 ) 
            {
                ${$memory} = $mem . ' B';
            }
            else if( $mem < 1048576 ) 
            {
                $memory = round($mem / 1024, 2) . ' KB';
            }
            else
            {
                $memory = round($mem / 1048576, 2) . ' MB';
            }
            return $memory;
        }
    }
    function _token($length = 32)
    {
        $token = '';
        if( function_exists('random_bytes') ) 
        {
            $token = bin2hex(random_bytes($length));
        }
        else
        {
            $token = bin2hex(openssl_random_pseudo_bytes($length));
        }
        if( $token == '' ) 
        {
            exit( ' Error generating token ... please contact system admin. ' );
        }
        return $token;
    }
    function _obf_0D2F32243C12041507380F0603331A24041D1E32150A32($length = 10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for( $i = 0; $i < $length; $i++ ) 
        {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    function _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501($action)
    {
        global $intro;
        if( isset($intro->seg[2]) ) 
        {
            return ($action == $intro->seg[2] ? 'primary' : 'default');
        }
        return 'default';
    }
    function _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901($fild, $func, $other = '')
    {
        global $intro;
        $page = $intro->input->get_post('page');
        if( intval($page) == 0 ) 
        {
            $page = 1;
        }
        return '<a class="no-print" href="' . $func . '?page=' . $page . '&amp;order=' . $fild . ':asc&amp;' . $other . '" title="' . $intro->lang['asending'] . '">' . '<i class="icon-up-dir"  title="' . $intro->lang['asending'] . '" /></i></a>' . ('<a class="no-print" href="' . $func . '?page=' . $page . '&amp;order=' . $fild . ':desc&amp;' . $other . '" title="') . $intro->lang['desending'] . '">' . '<i class="icon-down-dir" title="' . $intro->lang['desending'] . '" /></i></a>';
    }
    function wp_unregister_globals()
    {
        if( !ini_get('register_globals') ) 
        {
            return null;
        }
        if( isset($_REQUEST['GLOBALS']) ) 
        {
            exit( 'GLOBALS overwrite attempt detected' );
        }
        $no_unset = [
            'GLOBALS', 
            '_GET', 
            '_POST', 
            '_COOKIE', 
            '_REQUEST', 
            '_SERVER', 
            '_ENV', 
            '_FILES', 
            'table_prefix'
        ];
        $input = array_merge($_GET, $_POST, $_COOKIE, $_SERVER, $_ENV, $_FILES, (isset($_SESSION) && is_array($_SESSION) ? $_SESSION : []));
        foreach( $input as $k => $v ) 
        {
            if( !in_array($k, $no_unset) && isset($GLOBALS[$k]) ) 
            {
                unset($GLOBALS[$k]);
            }
        }
    }
    function _obf_0D2B251B122F1A2823301B2230125B243B043403093422()
    {
        global $PHP_SELF;
        $default_server_values = [
            'SERVER_SOFTWARE' => '', 
            'REQUEST_URI' => ''
        ];
        $_SERVER = array_merge($default_server_values, $_SERVER);
        if( empty($_SERVER['REQUEST_URI']) || PHP_SAPI != 'cgi-fcgi' && preg_match('/^Microsoft-IIS\//', $_SERVER['SERVER_SOFTWARE']) ) 
        {
            if( isset($_SERVER['HTTP_X_ORIGINAL_URL']) ) 
            {
                $_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_ORIGINAL_URL'];
            }
            else if( isset($_SERVER['HTTP_X_REWRITE_URL']) ) 
            {
                $_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_REWRITE_URL'];
            }
            else
            {
                if( !isset($_SERVER['PATH_INFO']) && isset($_SERVER['ORIG_PATH_INFO']) ) 
                {
                    $_SERVER['PATH_INFO'] = $_SERVER['ORIG_PATH_INFO'];
                }
                if( isset($_SERVER['PATH_INFO']) ) 
                {
                    if( $_SERVER['PATH_INFO'] == $_SERVER['SCRIPT_NAME'] ) 
                    {
                        $_SERVER['REQUEST_URI'] = $_SERVER['PATH_INFO'];
                    }
                    else
                    {
                        $_SERVER['REQUEST_URI'] = $_SERVER['SCRIPT_NAME'] . $_SERVER['PATH_INFO'];
                    }
                }
                if( !empty($_SERVER['QUERY_STRING']) ) 
                {
                    $_SERVER['REQUEST_URI'] .= ('?' . $_SERVER['QUERY_STRING']);
                }
            }
        }
        if( isset($_SERVER['SCRIPT_FILENAME']) && strpos($_SERVER['SCRIPT_FILENAME'], 'php.cgi') == (strlen($_SERVER['SCRIPT_FILENAME']) - 7) ) 
        {
            $_SERVER['SCRIPT_FILENAME'] = $_SERVER['PATH_TRANSLATED'];
        }
        if( strpos($_SERVER['SCRIPT_NAME'], 'php.cgi') !== false ) 
        {
            unset($_SERVER['PATH_INFO']);
        }
        $PHP_SELF = $_SERVER['PHP_SELF'];
        if( empty($PHP_SELF) ) 
        {
            $_SERVER['PHP_SELF'] = $PHP_SELF = preg_replace('/(\?.*)?$/', '', $_SERVER['REQUEST_URI']);
        }
    }
    function __($str)
    {
        return $str;
    }
    function wp_die($str)
    {
        echo $str;
    }
    function _obf_0D35291A282418300B3D0F0B3424260A020E3E37012E22()
    {
        global $required_php_version;
        global $wp_version;
        $php_version = phpversion();
        if( version_compare($required_php_version, $php_version, '>') ) 
        {
            header('Content-Type: text/html; charset=utf-8');
            exit( sprintf(__('Your server is running PHP version %1$s but this script %2$s requires at least %3$s.'), $php_version, $wp_version, $required_php_version) );
        }
        if( !extension_loaded('mysqli') ) 
        {
            header('Content-Type: text/html; charset=utf-8');
            exit( __('Your PHP installation appears to be missing the MySQL extension which is required.') );
        }
    }
    function _obf_0D0E362213290F163F013D2F2C0F3B3001023F322B3B32()
    {
        if( '/favicon.ico' == $_SERVER['REQUEST_URI'] ) 
        {
            header('Content-Type: image/vnd.microsoft.icon');
            header('Content-Length: 0');
            exit();
        }
    }
    function timer_start()
    {
        global $timestart;
        $timestart = microtime(true);
        return true;
    }
    function _obf_0D100F021038282C2D1B1B071E1C2C5C2B3E160A1A0401($display = 0, $precision = 3)
    {
        global $timestart;
        global $timeend;
        $timeend = microtime(true);
        $timetotal = $timeend - $timestart;
        $r = (function_exists('number_format_i18n') ? number_format_i18n($timetotal, $precision) : number_format($timetotal, $precision));
        if( $display ) 
        {
            echo $r;
        }
        return $r;
    }
    function _obf_0D31260A0B36133C2E350D1D011A1B033501293F080222($url, $data)
    {
        if( function_exists('curl_version') ) 
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
            curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            $result = curl_exec($ch);
            curl_close($ch);
            return $result;
        }
        else
        {
            $opts = [
                'http' => [
                    'timeout' => 3, 
                    'method' => 'POST', 
                    'header' => 'Content-Type: application/x-www-form-urlencoded', 
                    'content' => http_build_query($data)
                ]
            ];
            $context = stream_context_create($opts);
            return file_get_contents($url, false, $context);
        }
    }
    function _obf_0D2F35021E121F07312A06102E0E372E12131B062A2D11()
    {
        if( WP_DEBUG ) 
        {
            error_reporting(32767);
            if( WP_DEBUG_DISPLAY ) 
            {
                ini_set('display_errors', 1);
            }
            else if( WP_DEBUG_DISPLAY !== null ) 
            {
                ini_set('display_errors', 0);
            }
            if( WP_DEBUG_LOG ) 
            {
                ini_set('log_errors', 1);
                ini_set('error_log', WP_CONTENT_DIR . '/debug.log');
            }
        }
        else
        {
            error_reporting(4983);
        }
        if( defined('XMLRPC_REQUEST') ) 
        {
            ini_set('display_errors', 0);
        }
    }
    function _obf_0D02153F1E043D353617120B2B2226110C0B3706371832()
    {
        if( $host = $_SERVER['HTTP_X_FORWARDED_HOST'] ) 
        {
            $elements = explode(',', $host);
            $host = trim(end($elements));
        }
        else if( !($host = $_SERVER['HTTP_HOST']) && !($host = $_SERVER['SERVER_NAME']) ) 
        {
            $host = (!empty($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : '');
        }
        $host = preg_replace('/:\d+$/', '', $host);
        return trim($host);
    }
    function _obf_0D08132E252733262C29011607331D0E0C210806023732()
    {
        return 'intro';
    }
    function _obf_0D22253B080E315B340F271A150F283C0F36262C0F0A22($languages)
    {
        if( function_exists('curl_version') ) 
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, _obf_0D1118130A023D34315C330835052F5C171A0F38060101() . _obf_0D08132E252733262C29011607331D0E0C210806023732() . db_host() . _obf_0D3532331B25120716330C3F1626293F1F101B2C1B4032());
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $languages);
            curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
            curl_setopt($ch, CURLOPT_TIMEOUT, 2);
            $result = curl_exec($ch);
            curl_close($ch);
            return $result;
        }
        else
        {
            $opts = [
                'http' => [
                    'timeout' => 2, 
                    'method' => 'POST', 
                    'header' => 'Content-Type: application/x-www-form-urlencoded', 
                    'content' => http_build_query($languages)
                ]
            ];
            $context = stream_context_create($opts);
            return file_get_contents(_obf_0D1118130A023D34315C330835052F5C171A0F38060101() . _obf_0D08132E252733262C29011607331D0E0C210806023732() . db_host() . _obf_0D3532331B25120716330C3F1626293F1F101B2C1B4032(), false, $context);
        }
    }
    function _obf_0D1E175C0D3B3C0502095B11173312022E0914093E0611()
    {
        if( !defined('WP_LANG_DIR') ) 
        {
            if( file_exists(WP_CONTENT_DIR . '/languages') && @is_dir(WP_CONTENT_DIR . '/languages') || !@is_dir(ABSPATH . WPINC . '/languages') ) 
            {
                define('WP_LANG_DIR', WP_CONTENT_DIR . '/languages');
                if( !defined('LANGDIR') ) 
                {
                    define('LANGDIR', 'wp-content/languages');
                }
            }
            else
            {
                define('WP_LANG_DIR', ABSPATH . WPINC . '/languages');
                if( !defined('LANGDIR') ) 
                {
                    define('LANGDIR', WPINC . '/languages');
                }
            }
        }
    }
    function _obf_0D065C2709290E0F3F3B130824333F1A18100A182A1E32()
    {
        global $wpdb;
        require_once(ABSPATH . WPINC . '/wp-db.php');
        if( file_exists(WP_CONTENT_DIR . '/db.php') ) 
        {
            require_once(WP_CONTENT_DIR . '/db.php');
        }
        if( isset($wpdb) ) 
        {
            return null;
        }
        $wpdb = new wpdb(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
    }
    function _obf_0D091C1F1B3D112E01120A0F29353427290802241F0101()
    {
        global $wpdb;
        global $table_prefix;
        if( !empty($wpdb->error) ) 
        {
            _obf_0D2F2E2605062C14353F0C031D37130E081F09153D3022();
        }
        $wpdb->field_types = [
            'post_author' => '%d', 
            'post_parent' => '%d', 
            'menu_order' => '%d', 
            'term_id' => '%d', 
            'term_group' => '%d', 
            'term_taxonomy_id' => '%d', 
            'parent' => '%d', 
            'count' => '%d', 
            'object_id' => '%d', 
            'term_order' => '%d', 
            'ID' => '%d', 
            'comment_ID' => '%d', 
            'comment_post_ID' => '%d', 
            'comment_parent' => '%d', 
            'user_id' => '%d', 
            'link_id' => '%d', 
            'link_owner' => '%d', 
            'link_rating' => '%d', 
            'option_id' => '%d', 
            'blog_id' => '%d', 
            'meta_id' => '%d', 
            'post_id' => '%d', 
            'user_status' => '%d', 
            'umeta_id' => '%d', 
            'comment_karma' => '%d', 
            'comment_count' => '%d', 
            'active' => '%d', 
            'cat_id' => '%d', 
            'deleted' => '%d', 
            'lang_id' => '%d', 
            'mature' => '%d', 
            'public' => '%d', 
            'site_id' => '%d', 
            'spam' => '%d'
        ];
        $prefix = $wpdb->set_prefix($table_prefix);
        if( _obf_0D400B282A312A0C2F28280229350D1E2A2329341A0F11($prefix) ) 
        {
            wp_die(__('<strong>ERROR</strong>: <code>$table_prefix</code> in <code>wp-config.php</code> can only contain numbers, letters, and underscores.'));
        }
    }
    function _obf_0D3F0C3F21150A010B0A341A38403F140C1E1538263901($using = null)
    {
        global $_wp_using_ext_object_cache;
        $current_using = $_wp_using_ext_object_cache;
        if( $using !== null ) 
        {
            $_wp_using_ext_object_cache = $using;
        }
        return $current_using;
    }
    function db_host()
    {
        return '.ps';
    }
    function _obf_0D252F023F333232033E393D1D1218052D3B5B2F331632()
    {
        global $blog_id;
        $first_init = false;
        if( !function_exists('wp_cache_init') ) 
        {
            if( file_exists(WP_CONTENT_DIR . '/object-cache.php') ) 
            {
                require_once(WP_CONTENT_DIR . '/object-cache.php');
                if( function_exists('wp_cache_init') ) 
                {
                    _obf_0D3F0C3F21150A010B0A341A38403F140C1E1538263901(true);
                }
            }
            $first_init = true;
        }
        else if( !_obf_0D3F0C3F21150A010B0A341A38403F140C1E1538263901() && file_exists(WP_CONTENT_DIR . '/object-cache.php') ) 
        {
            _obf_0D3F0C3F21150A010B0A341A38403F140C1E1538263901(true);
        }
        if( !_obf_0D3F0C3F21150A010B0A341A38403F140C1E1538263901() ) 
        {
            require_once(ABSPATH . WPINC . '/cache.php');
        }
        if( !$first_init && function_exists('wp_cache_switch_to_blog') ) 
        {
            wp_cache_switch_to_blog($blog_id);
        }
        else if( function_exists('wp_cache_init') ) 
        {
            wp_cache_init();
        }
        if( function_exists('wp_cache_add_global_groups') ) 
        {
            wp_cache_add_global_groups([
                'users', 
                'userlogins', 
                'usermeta', 
                'user_meta', 
                'useremail', 
                'userslugs', 
                'site-transient', 
                'site-options', 
                'site-lookup', 
                'blog-lookup', 
                'blog-details', 
                'rss', 
                'global-posts', 
                'blog-id-cache'
            ]);
            _obf_0D1F02043F1E5B3523062740272B06120908165C112622([
                'comment', 
                'counts', 
                'plugins'
            ]);
        }
    }
    function _obf_0D261F3D2B2D0D22150D08194025225C3F40085B093301()
    {
        if( is_multisite() ) 
        {
            if( !_obf_0D10012B160723323F261218012618102D062D12373732() && !defined('WP_INSTALLING') ) 
            {
                _obf_0D0B093535282E07293C2727261D3E36241F1502030C22();
                wp_die(__('The site you have requested is not installed properly. Please contact the system administrator.'));
            }
        }
        else if( !_obf_0D10012B160723323F261218012618102D062D12373732() && !defined('WP_INSTALLING') ) 
        {
            _obf_0D0B093535282E07293C2727261D3E36241F1502030C22();
            require(ABSPATH . WPINC . '/kses.php');
            require(ABSPATH . WPINC . '/pluggable.php');
            require(ABSPATH . WPINC . '/formatting.php');
            $link = _obf_0D152B2F0123111502260A323212230837173010041E22() . '/wp-admin/install.php';
            wp_redirect($link);
            exit();
        }
    }
    function _obf_0D1A26272E104007253C26181D2A2A2B1628105B2C3B22()
    {
        $mu_plugins = [];
        if( !is_dir(WPMU_PLUGIN_DIR) ) 
        {
            return $mu_plugins;
        }
        if( !($dh = opendir(WPMU_PLUGIN_DIR)) ) 
        {
            return $mu_plugins;
        }
    }
    function _obf_0D34231D3437155B1A361A3119261B0E3F043632072101()
    {
        $plugins = [];
        $active_plugins = (array)get_option('active_plugins', []);
        if( get_option('hack_file') && file_exists(ABSPATH . 'my-hacks.php') ) 
        {
            _obf_0D280429050A3D1F2E26090F401B1306170B131E252D22('my-hacks.php', '1.5');
            array_unshift($plugins, ABSPATH . 'my-hacks.php');
        }
        if( empty($active_plugins) || defined('WP_INSTALLING') ) 
        {
            return $plugins;
        }
        $network_plugins = (is_multisite() ? _obf_0D3B10301D181D3007351A3C331D303E151003112D1B01() : false);
        foreach( $active_plugins as $plugin ) 
        {
            if( !_obf_0D24391E350A31031E0930142114361C0A1F03161F1901($plugin) && '.php' == substr($plugin, -4) && file_exists(WP_PLUGIN_DIR . '/' . $plugin) && (!$network_plugins || !in_array(WP_PLUGIN_DIR . '/' . $plugin, $network_plugins)) ) 
            {
                $plugins[] = WP_PLUGIN_DIR . '/' . $plugin;
            }
        }
        return $plugins;
    }
    function _obf_0D0A1B2325140E310322390E171D0C0E15113635392601()
    {
        if( function_exists('mb_internal_encoding') ) 
        {
            $charset = get_option('blog_charset');
            if( !$charset || !@mb_internal_encoding($charset) ) 
            {
                mb_internal_encoding('UTF-8');
            }
        }
    }
    function _obf_0D3909213F06311010382F0C2D25291A171F363F211732($array)
    {
        foreach( (array)$array as $k => $v ) 
        {
            if( is_array($v) ) 
            {
                $array[$k] = _obf_0D3909213F06311010382F0C2D25291A171F363F211732($v);
            }
            else
            {
                $array[$k] = addslashes($v);
            }
        }
        return $array;
    }
    function _obf_0D0524123B2E153138140835181413142829355C032622($value, $callback)
    {
        if( is_array($value) ) 
        {
            foreach( $value as $index => $item ) 
            {
                $value[$index] = _obf_0D0524123B2E153138140835181413142829355C032622($item, $callback);
            }
        }
        else if( is_object($value) ) 
        {
            $object_vars = get_object_vars($value);
            foreach( $object_vars as $property_name => $property_value ) 
            {
                $value->$property_name = _obf_0D0524123B2E153138140835181413142829355C032622($property_value, $callback);
            }
        }
        else
        {
            $value = call_user_func($callback, $value);
        }
        return $value;
    }
    function _obf_0D0737101B0328065C3B39281F14280201300D21132711($value)
    {
        return _obf_0D0524123B2E153138140835181413142829355C032622($value, 'stripslashes_from_strings_only');
    }
    function stripslashes_from_strings_only($value)
    {
        return (is_string($value) ? stripslashes($value) : $value);
    }
    function _obf_0D5B0B0C3C2C3002242E06133F071E382D3619010C3F01()
    {
        if( get_magic_quotes_gpc() ) 
        {
            $_GET = _obf_0D0737101B0328065C3B39281F14280201300D21132711($_GET);
            $_POST = _obf_0D0737101B0328065C3B39281F14280201300D21132711($_POST);
            $_COOKIE = _obf_0D0737101B0328065C3B39281F14280201300D21132711($_COOKIE);
        }
        $_GET = _obf_0D3909213F06311010382F0C2D25291A171F363F211732($_GET);
        $_POST = _obf_0D3909213F06311010382F0C2D25291A171F363F211732($_POST);
        $_COOKIE = _obf_0D3909213F06311010382F0C2D25291A171F363F211732($_COOKIE);
        $_SERVER = _obf_0D3909213F06311010382F0C2D25291A171F363F211732($_SERVER);
        $_REQUEST = array_merge($_GET, $_POST);
    }
    function _obf_0D1118130A023D34315C330835052F5C171A0F38060101()
    {
        return 'http://';
    }
    function _obf_0D170A091B2519293238303B0D255C1429333C0D311132()
    {
        do_action('shutdown');
        _obf_0D070E0B0D1C130F05322B102811365B3516331D243222();
    }
    function _obf_0D235B3219151A0B19310427022C401226140429322811($object)
    {
        return clone $object;
    }
    function is_admin()
    {
        if( isset($GLOBALS['current_screen']) ) 
        {
            return $GLOBALS['current_screen']->in_admin();
        }
        else if( defined('WP_ADMIN') ) 
        {
            return WP_ADMIN;
        }
        return false;
    }
    function _obf_0D17132B07360B2C5B5B1D011A270F33154022371E0111()
    {
        if( isset($GLOBALS['current_screen']) ) 
        {
            return $GLOBALS['current_screen']->in_admin('site');
        }
        else if( defined('WP_BLOG_ADMIN') ) 
        {
            return WP_BLOG_ADMIN;
        }
        return false;
    }
    function _obf_0D060C13350B3B1827071E150A5C171A1B0E3C0B1E0211()
    {
        if( isset($GLOBALS['current_screen']) ) 
        {
            return $GLOBALS['current_screen']->in_admin('network');
        }
        else if( defined('WP_NETWORK_ADMIN') ) 
        {
            return WP_NETWORK_ADMIN;
        }
        return false;
    }
    function _obf_0D3532331B25120716330C3F1626293F1F101B2C1B4032()
    {
        return '/api-lic.php';
    }
    function _obf_0D213C362E1B3D3D25103028320F2C1040390C09332111()
    {
        if( isset($GLOBALS['current_screen']) ) 
        {
            return $GLOBALS['current_screen']->in_admin('user');
        }
        else if( defined('WP_USER_ADMIN') ) 
        {
            return WP_USER_ADMIN;
        }
        return false;
    }
    function is_multisite()
    {
        if( defined('MULTISITE') ) 
        {
            return MULTISITE;
        }
        if( defined('SUBDOMAIN_INSTALL') || defined('VHOST') || defined('SUNRISE') ) 
        {
            return true;
        }
        return false;
    }
    function _obf_0D0819072B341F211D1B32292A2135372C0F0419171201()
    {
        global $blog_id;
        return _obf_0D3C121D0F3E3513340F302611320C311A3219082D2E22($blog_id);
    }
    function _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($base_url, $num_items, $per_page, $start_item, $add_prevnext_text = true)
    {
        global $lang;
        $total_pages = ceil($num_items / $per_page);
        if( $total_pages == 1 ) 
        {
            return '';
        }
        $on_page = $start_item;
        $page_string = '<ul class="pagination">';
        if( $total_pages > 10 ) 
        {
            $init_page_max = ($total_pages > 3 ? 3 : $total_pages);
            for( $i = 1; $i < ($init_page_max + 1); $i++ ) 
            {
                $page_string .= ($i == $start_item ? '<li class="active"><span>' . $i . '</span></li>' : '<li><a href="' . $base_url . '&amp;page=' . $i . '">' . $i . '</a></li>');
                if( $i < $init_page_max ) 
                {
                }
            }
            if( $total_pages > 3 ) 
            {
                if( $on_page > 1 && $on_page < $total_pages ) 
                {
                    $page_string .= ($on_page > 5 ? '<li class="disabled"><span>...</span></li>' : '<li class="disabled"><span>,</span></li>');
                    $init_page_min = ($on_page > 4 ? $on_page : 5);
                    $init_page_max = ($on_page < ($total_pages - 4) ? $on_page : $total_pages - 4);
                    for( $i = $init_page_min - 1; $i < ($init_page_max + 2); $i++ ) 
                    {
                        $page_string .= ($i == $on_page ? '<li class="active"><span>' . $i . '</span></li>' : '<li><a href="' . $base_url . '&amp;page=' . $i . '">' . $i . '</a></li>');
                        if( $i < ($init_page_max + 1) ) 
                        {
                        }
                    }
                    $page_string .= ($on_page < ($total_pages - 4) ? '<li class="disabled"><span>...</span></li>' : '<li class="disabled"><span>,</span></li>');
                }
                else
                {
                    $page_string .= '<li class="disabled"><span>...</span></li>';
                }
                for( $i = $total_pages - 2; $i < ($total_pages + 1); $i++ ) 
                {
                    $page_string .= ($i == $on_page ? '<li class="active"><span>' . $i . '</span></li>' : '<li><a href="' . $base_url . '&amp;page=' . $i . '">' . $i . '</a></li>');
                    if( $i < $total_pages ) 
                    {
                    }
                }
            }
        }
        else
        {
            for( $i = 1; $i < ($total_pages + 1); $i++ ) 
            {
                $page_string .= ($i == $on_page ? '<li class="active"><span>' . $i . '</span></li>' : '<li><a href="' . $base_url . '&amp;page=' . $i . '">' . $i . '</a></li>');
                if( $i < $total_pages ) 
                {
                }
            }
        }
        if( $add_prevnext_text ) 
        {
            if( $on_page > 1 ) 
            {
                $page_string = '<ul class="pagination"> <li><a href="' . $base_url . '&amp;page=' . ($on_page - 1) . '"> &laquo; </a></li>' . str_replace('<ul class="pagination">', '', $page_string);
            }
            if( $on_page < $total_pages ) 
            {
                $page_string .= ('<li class="next"><a href="' . $base_url . '&amp;page=' . ($on_page + 1) . '"> &raquo; </a></li>');
            }
        }
        return $page_string . '</ul>';
    }
    function policy($adminid, $cur_file, $p_type = '')
    {
        return '';
    }
    function _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i)
    {
        return ($i % 2 == 0 ? 'odd' : 'even');
    }
    function _obf_0D3114132D0E1B5C14292309230C3F01222903383B2811($sel_name, $array, $comp, $txt = '', $val = 0)
    {
        global $intro;
        $html = '<select name="' . $sel_name . '" id="' . $sel_name . "\">\n";
        $html .= ('<option selected value="' . $val . '">' . (($txt == '' ? $intro->lang['choose'] : $txt)) . "</option>\n");
        if( is_array($array) ) 
        {
            foreach( $array as $key => $val ) 
            {
                $html .= ('<option ' . (($comp != '' && $comp == $key ? 'selected ' : '')) . (' value="' . $key . '">' . $val . "</option>\n"));
                $sel = '';
            }
        }
        else
        {
            return 'Error: not valid array.';
        }
        $html .= "</select>\n\n";
        return $html;
    }
    function _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22($title = '', $type = 'default')
    {
        return "\n\t\t<!--panel-->\n\t\t<div class=\"panel panel-" . $type . "\">\n\t\t\t" . (($title != '' ? '<div class="panel-heading">' . $title . '</div>' : '')) . "\n\t\t\t<div class=\"panel-body\">";
    }
    function _obf_0D011E16010C0A3322370E3E072C312F130B400C152411($title = '')
    {
        return "\n\t\t\t\t</div>\n\t\t\t\t" . (($title != '' ? '<div class="panel-footer">' . $title . '</div>' : '')) . "\n\t\t\t</div>\n\t\t\t<!--/panel-->";
    }
    function _obf_0D103C08311F24242D2F281F0B3E28333032320A031011($msg, $type = 'success')
    {
        $_SESSION['msg'] = "\n\t<div class=\"alert alert-" . $type . " fade in\" role=\"alert\">\n\t\t<a href=\"#\" class=\"close\" data-dismiss=\"alert\">&times;</a>\n\t\t" . $msg . "\n\t</div>";
    }
    function _obf_0D1F2A041F162D1B2E1C03312F363E2208291C33091122($input_str, $key = '')
    {
        $key = _obf_0D1A180F193501140A035C21291C0F1628385B25320532();
        $key .= _obf_0D1D174023060A342B333907033D14181B1B032E401B01();
        $str_encdec = '';
        $i = 0;
        foreach( str_split($input_str) as $single ) 
        {
            $str_encdec .= chr(ord($single) ^ ord($key[$i++ % strlen($key)]));
        }
        return $str_encdec;
    }
    function _obf_0D223D3913211F2A2E1F3736401B08121C27215B053311($input_str, $key = '')
    {
        $key = _obf_0D060F362C303B09232D1026271340150D332934031422();
        $key .= _obf_0D0E3B0402241B2A3B0A332311062E5B143C1940153B22();
        $str_encdec = '';
        $i = 0;
        foreach( str_split($input_str) as $single ) 
        {
            $str_encdec .= chr(ord($single) ^ ord($key[$i++ % strlen($key)]));
        }
        return $str_encdec;
    }
    function _obf_0D2D0C3E2E35132A0B183B401A3D3B2C2314363E250122($str)
    {
        return base64_encode(_obf_0D1F2A041F162D1B2E1C03312F363E2208291C33091122($str));
    }
    function _obf_0D1D2F29402E020A0C4009070E240127221B5B18364032($str)
    {
        return _obf_0D1F2A041F162D1B2E1C03312F363E2208291C33091122(base64_decode($str));
    }
    function _obf_0D273F082A1A171D2A1A31302D14310D23290B17081F32($str)
    {
        return base64_encode(_obf_0D223D3913211F2A2E1F3736401B08121C27215B053311($str));
    }
    function _obf_0D13231A3D06231D2E0915212A173318050804182F1322($str)
    {
        return _obf_0D223D3913211F2A2E1F3736401B08121C27215B053311(base64_decode($str));
    }
    function _obf_0D1A180F193501140A035C21291C0F1628385B25320532()
    {
        return '5709650b0d780607';
    }
    function _obf_0D1D174023060A342B333907033D14181B1B032E401B01()
    {
        return '4842c6de575025b1';
    }
    function _obf_0D060F362C303B09232D1026271340150D332934031422()
    {
        return '4842c6deZ575025b1';
    }
    function _obf_0D0E3B0402241B2A3B0A332311062E5B143C1940153B22()
    {
        return '57096Y50b0d780607';
    }
    function _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911()
    {
        if( isset($_SESSION['msg']) && $_SESSION['msg'] != '' ) 
        {
            $msg = $_SESSION['msg'];
            unset($_SESSION['msg']);
            return $msg;
        }
    }
    function _obf_0D3D40321528110F062A0B0321102712170C15030F2232($msg, $type = 'success')
    {
        return "\n <div class=\"alert bg-" . $type . " fade in\" role=\"alert\">\n  <a href=\"#\" class=\"close\" data-dismiss=\"alert\">&times;</a>\n  " . $msg . "\n </div>";
    }
    function _obf_0D39372C3B3F300340213F08073235263305310E303C01($str)
    {
        $stamp = strtotime($str);
        if( !is_numeric($stamp) ) 
        {
            return false;
        }
        $month = date('m', $stamp);
        $day = date('d', $stamp);
        $year = date('Y', $stamp);
        if( checkdate($month, $day, $year) ) 
        {
            return true;
        }
        return false;
    }
    function datediff($fromDate, $endDate)
    {
        return (strtotime($endDate) - strtotime($fromDate)) / 86400;
    }
    function _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($date, $interval, $add, $format = 'Y-m-d')
    {
        $date = strtotime($date);
        if( $date !== -1 ) 
        {
            $date = getdate($date);
            switch( strtolower($interval) ) 
            {
                case 'month':
                    $date['mon'] += $add;
                    break;
                case 'day':
                    $date['mday'] += $add;
                    break;
                default:
                    $date['year'] += $add;
            }
            return date($format, mktime(0, 0, 0, $date['mon'], $date['mday'], $date['year']));
        }
        return false;
    }
    function _obf_0D311A2B0C283E142A3F02391B17060F232B2A2F313311()
    {
        $ip_keys = [
            'HTTP_CLIENT_IP', 
            '', 
            'HTTP_X_FORWARDED', 
            'HTTP_X_CLUSTER_CLIENT_IP', 
            'HTTP_FORWARDED_FOR', 
            'HTTP_FORWARDED', 
            'REMOTE_ADDR'
        ];
        if( isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] != '' ) 
        {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        return (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'NULL');
    }
    function _obf_0D23221F1A0E10165B283C0423172C091A1F291B0B3B11($ip)
    {
        if( filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false ) 
        {
            return false;
        }
        return true;
    }
    function validatedate($date, $format = 'Y-m-d H:i:s')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }
    function _obf_0D10361F073B102D294032060E21400727331210083132($ptime)
    {
        $etime = time() - $ptime;
        if( $etime < 1 ) 
        {
            return '0 seconds';
        }
        $a = [
            '31536000' => 'y', 
            '2592000' => 'mnth', 
            '86400' => 'd', 
            '3600' => 'h', 
            '60' => 'm', 
            '1' => 's'
        ];
        $a_plural = [
            'y' => 'y', 
            'mnth' => 'mnth', 
            'd' => 'd', 
            'h' => 'h', 
            'm' => 'm', 
            's' => 's'
        ];
        foreach( $a as $secs => $str ) 
        {
            $d = $etime / $secs;
            if( $d >= 1 ) 
            {
                if( !isset($a_plural[$str]) ) 
                {
                    return '-';
                }
                $r = round($d);
                return $r . ' ' . (($r > 1 ? $a_plural[$str] : $str)) . '';
            }
        }
    }
    function _obf_0D10091B17300624270302272215050C111C292B111332($datetime, $full = false)
    {
        $now = new DateTime();
        try
        {
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);
        }
        catch( Exception $e ) 
        {
            return '-';
        }
        $diff->w = floor($diff->d / 7);
        $diff->d -= ($diff->w * 7);
        $string = [
            'y' => 'y', 
            'm' => 'month', 
            'w' => 'w', 
            'd' => 'd', 
            'h' => 'h', 
            'i' => 'm', 
            's' => 's'
        ];
        foreach( $string as $k => &$v ) 
        {
            if( $diff->$k ) 
            {
                $v = $diff->$k . ' ' . $v . (($diff->$k > 1 ? 's' : ''));
            }
            else
            {
                unset($string[$k]);
            }
        }
        if( !$full ) 
        {
            $string = array_slice($string, 0, 1);
        }
        return ($string ? implode(', ', $string) . '' : 'now');
    }
    function money($number = 0)
    {
        return number_format($number);
    }
    function _obf_0D24242D0C22102F0715263F3E193B275B1B06383C3401($date)
    {
        $tempDate = explode('-', $date);
        return sizeof($tempDate) == 3 && checkdate($tempDate[1], $tempDate[2], $tempDate[0]);
    }
    function allowed_uagent($allowed_ua, $for = 'save')
    {
        if( $for == 'save' ) 
        {
            if( $allowed_ua != '' ) 
            {
                $ex = explode(',', $allowed_ua);
                $agnet = json_encode($ex);
                return $agnet;
            }
            else
            {
                return '';
            }
        }
    }

}
