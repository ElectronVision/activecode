<?php 
class Bouquets
{
    public $adminid = 0;
    public $period = 0;
    public $userid = 0;
    public $num = 0;
    public $cost = 0;
    public $ResellerCost = 0;
    public $FatherCost = 0;
    public $AdminGroup = 0;
    public $packages = [];
    public $bouquets = [];
    public $error = '';
    public $user_bouquets = [];
    public function __construct()
    {
    }
    public function html()
    {
        global $intro;
        global $array;
        $html = $qry = $msg = '';
        $i = 0;
        if( isset($intro->option['BouquetsOrder']) && $intro->option['BouquetsOrder'] != '' ) 
        {
            $order = str_replace(':', ' ', $intro->option['BouquetsOrder']);
        }
        else
        {
            $order = 'id ASC';
        }
        if( is_array($this->bouquets) && count($this->bouquets) > 0 ) 
        {
            $qry = ' AND `id` IN (' . implode(',', $this->bouquets) . ') ';
        }
        else
        {
            $msg = '<h3>Contact Admin to Fix bouquets for you.</h3>';
            $qry = ' AND `id` IN (1500000) ';
            $html = $msg . '<table id=\'UsersBouquets\'><tbody>';
            if( is_array($this->user_bouquets) && count($this->user_bouquets) ) 
            {
                $order = 'ORDER BY IF(FIELD(id,' . implode(',', $this->user_bouquets) . (')=0,1,0),' . $order . ' ');
            }
            else
            {
                $order = 'order by ' . $order;
            }
            $sql = $intro->db->query('SELECT * FROM bouquets WHERE bouquet_status=1 ' . $qry . ' ' . $order);
            while( $row = $intro->db->fetch_assoc($sql) ) 
            {
                @extract($row);
                $i++;
                $html .= ("\n\t\t\t<tr> \n\t\t\t\t<td> </td>\n\t\t\t\t<td>\n\t\t\t\t<input " . (($i == 1 ? 'class=\'BQfirsOne\'' : 'class=\'BQother\'')) . ("\n\t\t\t\t\ttype=\"checkbox\" value=\"" . $id . "\" name=\"bouquets[]\"\n\t\t\t\t\t") . ((is_array($this->user_bouquets) && in_array($id, $this->user_bouquets) ? 'checked' : '')) . (' /> ' . $bouquet_name . "\n\t\t\t\t</td>\n\t\t\t</tr>"));
            }
            $html .= '</tbody></table>';
            $html .= "<script>\$(document).ready(function() { \$( \"#UsersBouquets>tbody\" ).sortable(); });\t</script>";
            return $html;
        }
    }
    public function set($name, $value)
    {
        $this->$name = $value;
    }
}
