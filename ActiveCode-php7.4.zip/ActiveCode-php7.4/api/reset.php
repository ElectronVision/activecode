<?php 
define('_CHECK_X_ME', true);
include('../load2.php');
$intro->admin_folder = '';
$intro->auth->flag = 'admin';
$class = new Reset();
$mode = get_post('mode');
if( $mode != '' && method_exists($class, $mode) ) 
{
    $class->$mode();
}
else
{
    exit( 'Error: mode (' . $mode . ') not defined.' );
}
class Reset
{
    public $user = '';
    public $pass = '';
    public $code = '';
    public $status = [
        'The Code is New. It\'s not Activated Yet!!!', 
        'The Code is Active', 
        'The Code is suspended', 
        'The Code is Deleted.', 
        'The Code is Expired.', 
        'The Code is replaced. {code_replaced}'
    ];
    public function __construct()
    {
        $this->user = preg_replace('/[^a-zA-Z0-9-]/ui', '', $_POST['user']);
        $this->pass = trim($_POST['pass']);
        $this->code = preg_replace('/[^a-zA-Z0-9-]/ui', '', $_POST['code']);
    }
    public function pwd($str)
    {
        $x1 = sha1($str . 'AniMoh');
        $pass = md5($x1 . 'AniSo');
        return $pass;
    }
    public function validate()
    {
        if( $this->user == '' && $this->pass == '' ) 
        {
            $this->msg(200, 'Error 200: Worng User or Password!');
            exit();
        }
    }
    public function login()
    {
        global $intro;
        $password = $this->pwd($this->pass);
        $result = $intro->db->query('SELECT * FROM ' . PREFIX . '_admin ' . (' WHERE adm_username=\'' . $this->user . '\' AND adm_password=\'' . $password . '\''));
        if( $intro->db->returned_rows == 1 ) 
        {
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('ResetApp', 'login_success', '', $this->user);
            $this->msg(100, 'Login Success!');
        }
        else
        {
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('ResetApp', 'login_fail', 'User=' . $this->user . '<br/> Pass=' . $this->pass . ' enc=(' . $password . ')', $this->user);
            $this->msg(200, 'Login Error Please check User/Password!');
        }
    }
    public function resetCode()
    {
        global $intro;
        $password = $this->pwd($this->pass);
        if( strlen($this->code) < 8 ) 
        {
            $this->msg(203, 'Error: code is too short.');
        }
        $sql5 = $intro->db->query('SELECT * FROM ' . PREFIX . '_admin ' . (' WHERE adm_username=\'' . $this->user . '\' AND adm_password=\'' . $password . '\''));
        if( intval($intro->db->returned_rows) == 0 ) 
        {
            $this->msg(200, 'Login Error, Please Logout and Login back again.');
        }
        $sql = $intro->db->query('SELECT id,status,date_expire,code_replaced FROM ' . PREFIX . ('_codes where code=\'' . $this->code . '\';'));
        $num = intval($intro->db->returned_rows);
        if( $num == 1 ) 
        {
            $row = $intro->db->fetch_assoc($sql);
            $id = intval($row['id']);
            $data = [];
            $data['mac'] = 'reset_me';
            $data['serial'] = 'reset_me';
            $status = intval($row['status']);
            if( $status == 1 ) 
            {
                $expire = date('Y-m-d', $row['date_expire']);
                if( $expire < date('Y-m-d') ) 
                {
                    $this->msg(301, 'Sorry: coed is expired!');
                    exit();
                }
                $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id . ' AND inputBy=0');
            }
            else
            {
                $this->msg(303, str_replace('{code_replaced}', ' With: ' . $row['code_replaced'], $this->status[$status]));
            }
            $this->msg(100, 'Code Reset Success!');
        }
        else if( $num == 0 ) 
        {
            $this->msg(201, 'Error 201: Code is not found!');
        }
        else if( $num > 1 ) 
        {
            $this->msg(202, 'Error 202: we found many codes like: ' . $this->code . '!');
        }
    }
    public function msg($status, $msg)
    {
        $ar = [
            'status' => $status, 
            'msg' => (string)$msg
        ];
        echo json_encode($ar);
        exit();
    }
}
function get_post($index = '')
{
    if( !isset($_POST[$index]) ) 
    {
        return $_GET[$index];
    }
    else
    {
        return $_POST[$index];
    }
}
