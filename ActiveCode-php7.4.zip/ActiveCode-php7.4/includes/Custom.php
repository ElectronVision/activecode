<?php 
class Custom
{
    public $option = null;
    public function __construct()
    {
        $option = [];
        $option['opt_aum_api'] = 'no';
        $this->option = $option;
    }
}
