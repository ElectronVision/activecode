<?php 
echo '﻿';
class Blocked_user_agents_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $intro->lang['blocked_user_agents_appname'] = 'Blocked User Agents';
        $intro->lang['blocked_user_agents_add'] = 'Blocked User Agents';
        $intro->lang['blocked_user_agents_edit'] = 'Blocked User Agents';
        $intro->lang['blocked_user_agents_cur'] = 'Blocked User Agents';
        $intro->lang['blocked_user_agents_user_agent'] = 'User Agent';
        $intro->lang['blocked_user_agents_exact_match'] = 'Exact Match';
        $intro->lang['blocked_user_agents_attempts_blocked'] = 'Attempts Blocked';
        $this->admin = $intro->auth->sess_admin();
        if( $this->admin['level'] != 1 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . '/index"><icon class="icon-list"></icon>') . $intro->lang['blocked_user_agents_appname'] . "</a> \r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add"><icon class="icon-plus-squared"></icon>') . $intro->lang['blocked_user_agents_add'] . "</a>  \t\t \t\t \r\n\t\t</div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = '';
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry = ' where user_agent  LIKE \'%' . $search_txt . '%\' ';
        }
        if( $order == '' ) 
        {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $result = $intro->db->query('SELECT * from blocked_user_agents ' . $qry . ' order by ' . $order);
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> ' . $intro->lang['blocked_user_agents_cur'] . (' (' . $totalrows . ')'), 'info');
        echo "\r\n\t\t\r\n\t\t<fieldset>\r\n\t\t\t<form action=\"\" method=\"post\">\r\n\t\t\t\t<input type=\"text\" name=\"search_txt\" value=\"" . $search_txt . "\" placeholder=\"User Agnet\" size=\"20\">\r\n\t\t\t\t<input name=\"name\" value=\"" . $intro->lang['search'] . "\" type=\"submit\">\r\n\t\t\t</form>\r\n\t\t</fieldset>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th> </th>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . "</th>\r\n\t\t\t<th>" . $intro->lang['blocked_user_agents_user_agent'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('user_agent', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['blocked_user_agents_exact_match'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('exact_match', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['blocked_user_agents_attempts_blocked'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('attempts_blocked', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\"><input type=\"checkbox\" value=\"" . $id . "\" name=\"selected_fld[]\"></td>\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td>" . $user_agent . "</td>\r\n\t\t\t\t<td>") . (($exact_match == 1 ? '<span class="label label-success">Yes</span>' : '<span class="label label-default">No</span>')) . ("</td>\r\n\t\t\t\t<td>" . $attempts_blocked . "</td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>\r\n\t\t</div>";
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $user_agent;
        global $exact_match;
        global $attempts_blocked;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM blocked_user_agents WHERE id=' . $id . ';');
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = $intro->lang['blocked_user_agents_edit'] . (' <b>' . $id . '</b>');
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = $intro->lang['blocked_user_agents_add'];
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['blocked_user_agents_user_agent'] . (" : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"user_agent\" value=\"" . $user_agent . '" size="30"> ' . $this->error('user_agent') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['blocked_user_agents_exact_match'] . " : </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('exact_match', $exact_match) . (' ' . $this->error('exact_match') . "</td>\r\n\t\t</tr>");
        if( $t == 'edit' ) 
        {
            echo "\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['blocked_user_agents_attempts_blocked'] . (" : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"attempts_blocked\" value=\"" . $attempts_blocked . '" size="10"> ' . $this->error('attempts_blocked') . "</td>\r\n\t\t</tr>");
        }
        echo "\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</div>\r\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $user_agent = trim($intro->input->post('user_agent'));
        $exact_match = trim($intro->input->post('exact_match'));
        $attempts_blocked = trim($intro->input->post('attempts_blocked'));
        if( $user_agent == '' || $exact_match == '' ) 
        {
            if( $user_agent == '' ) 
            {
                $error['user_agent'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $exact_match == '' ) 
            {
                $error['exact_match'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data['user_agent'] = $user_agent;
        $data['exact_match'] = $exact_match;
        $data['attempts_blocked'] = 0;
        $intro->db->insert('blocked_user_agents', $data);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $user_agent = trim($intro->input->post('user_agent'));
        $exact_match = trim($intro->input->post('exact_match'));
        $attempts_blocked = trim($intro->input->post('attempts_blocked'));
        $data['user_agent'] = $user_agent;
        $data['exact_match'] = $exact_match;
        $data['attempts_blocked'] = $attempts_blocked;
        $id = intval($intro->input->post('id'));
        $intro->db->update('blocked_user_agents', $data, 'id=' . $id);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('DELETE FROM blocked_user_agents WHERE id=' . $id . '; ');
        $intro->redirect($this->appname);
    }
}
