<?php 
class Resellers_group_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        $intro->db->halt_on_errors = false;
        echo "<div class=\"app_nav\">f\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-users\"></icon>Resellers Groups </a> \r\n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . "/Form?t=add\"><icon class=\"icon-plus-squared\"></icon>Add New Group</a>  \t\t \t\t \r\n\t\t<h1 style='color:red;'>Beta 1</h1>\r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $this->nav();
        $rows_per_page = 100;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT *  from member_groups order by group_id  limit ' . $nexlimit . ',' . $rows_per_page);
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT group_id from member_groups order by group_id ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i>Menu  (' . $totalrows . ')', 'info');
        echo "<form method=\"POST\"   id='drag' enctype=\"multipart/form-data\">\r\n\t\t<div class=\"\">\r\n\t\t\t<table class=\"table table-bordered \"  id=\"table_codes\" >\r\n\t\t\t<thead>\r\n\t\t\t<tr>\r\n\t\t\t\t<th>ID </th>\r\n\t\t\t\t<th>Group Name</th>\r\n\t\t\t\t<!--<th>Color</th>-->\r\n\t\t\t\t<th>Admin CP?</th>\r\n\t\t\t\t<th>Banned?</th>\r\n\t\t\t\t<th>Is Reseller?</th>\r\n\t\t\t\t<th>Options</th>\r\n\t\t\t</tr>\r\n\t\t\t</thead>\r\n\t\t\t<tbody>";
        $i = 0;
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            @extract($row);
            $i++;
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"center\">" . $i . "</td>\r\n\t\t\t\t<td " . (($group_color != '' ? 'style=\'color:' . $group_color . ';\'' : '')) . ('>' . $group_name . "</td>\r\n\t\t\t\t<!--<td class=\"center\" ") . (($group_color != '' ? 'style=\'color:' . $group_color . ';\'' : '')) . ('>' . $group_color . "</td>-->\r\n\t\t\t\t<td class=\"center\"><i ") . (($is_admin == 1 ? 'class=\'icon-check\' style=\'color:#2db300;\'' : 'class=\'icon-cancel\' style=\'color:#ff0000;\'')) . "></i></td>\r\n\t\t\t\t<td class=\"center\"><i " . (($is_banned == 1 ? 'class=\'icon-check\' style=\'color:#2db300;\'' : 'class=\'icon-cancel\' style=\'color:#ff0000;\'')) . "></i></td>\r\n\t\t\t\t<td class=\"center\">";
            if( $is_reseller == 1 ) 
            {
                echo '<i class=\'icon-check\' style=\'color:#2db300;\'></i>';
                echo '<div>(' . $total_allowed_gen_trials . ' Per ' . $total_allowed_gen_in . ' Trial)</div>';
            }
            else
            {
                echo '<i class=\'icon-cancel\' style=\'color:#ff0000;\'></i>';
            }
            echo "</td>\r\n\t\t\t\t<td class=\"center\">\r\n\t\t\t\t\t<a class=\"btn btn-info\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $group_id . '" title="' . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $group_id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-trash\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo '</table> </div>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</center>';
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $group_name;
        global $group_color;
        global $is_admin;
        global $is_banned;
        global $allowed_pages;
        global $is_reseller;
        global $total_allowed_gen_in;
        global $total_allowed_gen_trials;
        global $can_delete;
        global $reseller_force_server;
        global $create_sub_resellers_price;
        global $create_sub_resellers;
        global $alter_packages_ids;
        global $alter_packages_prices;
        global $reseller_client_connection_logs;
        global $reseller_assign_pass;
        global $allow_change_pass;
        global $allow_import;
        global $allow_export;
        global $reseller_trial_credit_allow;
        global $edit_mac;
        global $edit_isplock;
        global $lock_device;
        global $reseller_bonus_package_inc;
        global $reset_stb_data;
        global $allow_download;
        global $delete_users;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $IF = intval($intro->input->get_post('IF'));
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $viw_selcted_menu = '';
        if( $IF != 1 ) 
        {
            $this->nav();
        }
        $btn = [];
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM member_groups where group_id=\'' . $id . '\'');
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = ' Edit Group <b>' . $group_id . '</b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = 'Save Changes';
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $allowed_pages = json_decode($allowed_pages, true);
            if( is_null($allowed_pages) ) 
            {
                $allowed_pages = [];
            }
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add New Group';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = 'Add New';
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
            $allowed_pages = (!is_array($allowed_pages) ? [] : $allowed_pages);
            $reseller_trial_credit_allow = ($reseller_trial_credit_allow == '' ? 0 : $reseller_trial_credit_allow);
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<script src=\"" . admin_path . 'style/js/color/jscolor.js"></script>';
        echo '<form method="POST"   action="' . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<table class=\"table table-hover table-bordered\">\r\n\t\t\t<tbody>\r\n\t\t\t<tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Group Name: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td >\r\n\t\t\t\t\t<input type=text name='group_name' value='" . $group_name . "' class='form-control' style='width:70%;'>\t" . $error['group_name'] . "\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Group Color: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td >\r\n\t\t\t\t\t<input type=text name='group_color' id=\"group_color\" value='" . $group_color . "' class='form-control jscolor {hash:true}' style='width:70%;'>\t\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t<td style='width:300px;'>Allowed Pages: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td>\t" . $error['allowed_pages'];
        echo "<select name=\"allowed_pages[]\" multiple size=30 style='width:70%;'>\n";
        foreach( $array['menu'] as $key => $val ) 
        {
            echo ' <optgroup label="' . $key . "\">\n";
            foreach( $val as $key2 => $val2 ) 
            {
                echo ' <option  value="' . $key2 . '" ' . ((in_array($key2, $allowed_pages) ? 'selected' : '')) . ('> -------->  ' . $val2['title'] . " </option>\n");
            }
            echo '</optgroup>';
        }
        echo "</select>\n\n";
        echo "\r\n\t\t\t\t\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>This Group Can Access Admin CP?:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('is_admin', $is_admin, 'yes') . "</td>\r\n\t\t\t</tr>\t\r\n\t\t\t<tr class=\"is_banned\">\r\n\t\t\t\t<td>This is a Banned Group:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('is_banned', $is_banned, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr class=\"is_reseller\">\r\n\t\t\t\t<td>Is Reseller:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('is_reseller', $is_reseller, 'yes') . ("</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Total allowed Trials:</td>\r\n\t\t\t\t<td><input type=\"text\" name=\"total_allowed_gen_trials\" value=\"" . $total_allowed_gen_trials . "\">\r\n\t\t\t\t\tIN: ") . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('total_allowed_gen_in', $array['total_allowed_gen_in'], $total_allowed_gen_in, '', '') . "\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Delete Users?:</td>\r\n\t\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('delete_users', $delete_users, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Can Delete?:</td>\r\n\t\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('can_delete', $can_delete, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Force connect to Server:</td>\r\n\t\t\t\t<td >" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('reseller_force_server', 'Default', 'streaming_servers', $reseller_force_server, 'id', 'server_name') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Create sub resellers:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('create_sub_resellers', $create_sub_resellers, 'yes') . ("</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Create sub resellers price:</td>\r\n\t\t\t\t<td><input type=\"text\" name=\"create_sub_resellers_price\" value=\"" . $create_sub_resellers_price . "\"></td>\r\n\t\t\t</tr>\r\n\t\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Alter packages ids:</td>\r\n\t\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('alter_packages_ids', $alter_packages_ids, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Alter packages prices?:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('alter_packages_prices', $alter_packages_prices, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reseller see client connection logs:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('reseller_client_connection_logs', $reseller_client_connection_logs, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reseller assign pass:</td>\r\n\t\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('reseller_assign_pass', $reseller_assign_pass, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Allow change passwords:</td>\r\n\t\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('allow_change_pass', $allow_change_pass, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Allow Export Users?:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('allow_export', $allow_export, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Allow Import Users?:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('allow_import', $allow_import, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Set trial credit fro Resellers?</td>\r\n\t\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('reseller_trial_credit_allow', $reseller_trial_credit_allow, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Edit Mac?:</td>\r\n\t\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('edit_mac', $edit_mac, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Edit ISP Lock?:</td>\r\n\t\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('edit_isplock', $edit_isplock, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Lock device?:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('lock_device', $lock_device, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reset MAG STB Data?:</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('reset_stb_data', $reset_stb_data, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<!--\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Reseller bonus package inc</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('reseller_bonus_package_inc', $reseller_bonus_package_inc, 'yes') . "</td>\r\n\t\t\t</tr>\r\n\t\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Allow download</td>\r\n\t\t\t\t<td >" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('allow_download', $allow_download, 'yes') . ("</td>\r\n\t\t\t</tr>-->\r\n\t\t\t\r\n\t\t\t<tr>\r\n\t\t\t\t<td> </td>\r\n\t\t\t\t<td>\r\n\t\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"IF\"  value=\"" . $IF . "\">\r\n\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success\">\r\n\t\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t\t</button>\t\t\t\t\t\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t\t</tbody>\t\r\n\t\t\t</table>\t\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        global $array;
        $group_name = $intro->input->post('group_name');
        $group_color = $intro->input->post('group_color');
        $is_admin = $intro->input->post('is_admin');
        $is_banned = $intro->input->post('is_banned');
        $allowed_pages = $intro->input->post('allowed_pages');
        $is_reseller = $intro->input->post('is_reseller');
        $total_allowed_gen_in = $intro->input->post('total_allowed_gen_in');
        $total_allowed_gen_trials = $intro->input->post('total_allowed_gen_trials');
        $can_delete = $intro->input->post('can_delete');
        $reseller_force_server = $intro->input->post('reseller_force_server');
        $create_sub_resellers_price = $intro->input->post('create_sub_resellers_price');
        $create_sub_resellers = $intro->input->post('create_sub_resellers');
        $alter_packages_ids = $intro->input->post('alter_packages_ids');
        $alter_packages_prices = $intro->input->post('alter_packages_prices');
        $reseller_client_connection_logs = $intro->input->post('reseller_client_connection_logs');
        $reseller_assign_pass = $intro->input->post('reseller_assign_pass');
        $allow_change_pass = $intro->input->post('allow_change_pass');
        $allow_import = $intro->input->post('allow_import');
        $allow_export = $intro->input->post('allow_export');
        $reseller_trial_credit_allow = $intro->input->post('reseller_trial_credit_allow');
        $edit_mac = $intro->input->post('edit_mac');
        $edit_isplock = $intro->input->post('edit_isplock');
        $lock_device = $intro->input->post('lock_device');
        $reset_stb_data = $intro->input->post('reset_stb_data');
        $reseller_bonus_package_inc = $intro->input->post('reseller_bonus_package_inc');
        $allow_download = $intro->input->post('allow_download');
        if( $group_name == '' || $allowed_pages == null ) 
        {
            if( $group_name == '' ) 
            {
                $error['group_name'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $allowed_pages == null ) 
            {
                $error['allowed_pages'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data['group_name'] = $group_name;
        $data['allowed_pages'] = json_encode($allowed_pages);
        $data['group_color'] = $group_color;
        $data['allow_download'] = $allow_download;
        $data['reseller_bonus_package_inc'] = $reseller_bonus_package_inc;
        $data['reset_stb_data'] = $reset_stb_data;
        $data['lock_device'] = $lock_device;
        $data['edit_isplock'] = $edit_isplock;
        $data['edit_mac'] = $edit_mac;
        $data['reseller_trial_credit_allow'] = $reseller_trial_credit_allow;
        $data['allow_export'] = $allow_export;
        $data['allow_import'] = $allow_import;
        $data['allow_change_pass'] = $allow_change_pass;
        $data['reseller_assign_pass'] = $reseller_assign_pass;
        $data['reseller_client_connection_logs'] = $reseller_client_connection_logs;
        $data['is_admin'] = $is_admin;
        $data['is_banned'] = $is_banned;
        $data['is_reseller'] = $is_reseller;
        $data['total_allowed_gen_in'] = $total_allowed_gen_in;
        $data['total_allowed_gen_trials'] = $total_allowed_gen_trials;
        $data['can_delete'] = $can_delete;
        $data['reseller_force_server'] = $reseller_force_server;
        $data['create_sub_resellers_price'] = $create_sub_resellers_price;
        $data['create_sub_resellers'] = $create_sub_resellers;
        $data['alter_packages_ids'] = $alter_packages_ids;
        $data['alter_packages_prices'] = $alter_packages_prices;
        $intro->db->insert('member_groups', $data);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        global $error;
        global $bouquet_channels;
        $id = intval($intro->input->post('id'));
        $group_name = $intro->input->post('group_name');
        $group_color = $intro->input->post('group_color');
        $is_admin = $intro->input->post('is_admin');
        $is_banned = $intro->input->post('is_banned');
        $allowed_pages = $intro->input->post('allowed_pages');
        $is_reseller = $intro->input->post('is_reseller');
        $total_allowed_gen_in = $intro->input->post('total_allowed_gen_in');
        $total_allowed_gen_trials = $intro->input->post('total_allowed_gen_trials');
        $can_delete = $intro->input->post('can_delete');
        $reseller_force_server = $intro->input->post('reseller_force_server');
        $create_sub_resellers_price = $intro->input->post('create_sub_resellers_price');
        $create_sub_resellers = $intro->input->post('create_sub_resellers');
        $alter_packages_ids = $intro->input->post('alter_packages_ids');
        $alter_packages_prices = $intro->input->post('alter_packages_prices');
        $reseller_client_connection_logs = $intro->input->post('reseller_client_connection_logs');
        $reseller_assign_pass = $intro->input->post('reseller_assign_pass');
        $allow_change_pass = $intro->input->post('allow_change_pass');
        $allow_import = $intro->input->post('allow_import');
        $allow_export = $intro->input->post('allow_export');
        $reseller_trial_credit_allow = $intro->input->post('reseller_trial_credit_allow');
        $edit_mac = $intro->input->post('edit_mac');
        $edit_isplock = $intro->input->post('edit_isplock');
        $lock_device = $intro->input->post('lock_device');
        $reset_stb_data = $intro->input->post('reset_stb_data');
        $reseller_bonus_package_inc = $intro->input->post('reseller_bonus_package_inc');
        $allow_download = $intro->input->post('allow_download');
        if( $group_name == '' || $allowed_pages == null ) 
        {
            if( $group_name == '' ) 
            {
                $error['group_name'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $allowed_pages == null ) 
            {
                $error['allowed_pages'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data['group_name'] = $group_name;
        $data['allowed_pages'] = json_encode($allowed_pages);
        $data['group_color'] = $group_color;
        $data['allow_download'] = $allow_download;
        $data['reseller_bonus_package_inc'] = $reseller_bonus_package_inc;
        $data['reset_stb_data'] = $reset_stb_data;
        $data['edit_isplock'] = $edit_isplock;
        $data['edit_mac'] = $edit_mac;
        $data['reseller_trial_credit_allow'] = $reseller_trial_credit_allow;
        $data['allow_export'] = $allow_export;
        $data['allow_import'] = $allow_import;
        $data['allow_change_pass'] = $allow_change_pass;
        $data['reseller_assign_pass'] = $reseller_assign_pass;
        $data['reseller_client_connection_logs'] = $reseller_client_connection_logs;
        $data['is_admin'] = $is_admin;
        $data['is_banned'] = $is_banned;
        $data['is_reseller'] = $is_reseller;
        $data['total_allowed_gen_in'] = $total_allowed_gen_in;
        $data['total_allowed_gen_trials'] = $total_allowed_gen_trials;
        $data['can_delete'] = $can_delete;
        $data['reseller_force_server'] = $reseller_force_server;
        $data['create_sub_resellers_price'] = $create_sub_resellers_price;
        $data['create_sub_resellers'] = $create_sub_resellers;
        $data['alter_packages_ids'] = $alter_packages_ids;
        $data['alter_packages_prices'] = $alter_packages_prices;
        $intro->db->update('member_groups', $data, 'group_id=' . $id);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $intro->redirect($this->appname);
    }
}
