<?php 
define('_CHECK_X_ME', true);
require(dirname(__FILE__) . '/load2.php');
define('admin_path', $config['base_url']);
$intro->auth->flag = 'admin';
if( $intro->auth->auth_admin() ) 
{
    $_ADMIN = $intro->auth->admin_data();
    $sess_admin = $intro->auth->sess_admin();
    if( $sess_admin['level'] == 1 ) 
    {
        $intro->db->halt_on_errors = true;
    }
    $file = 'apps/' . $intro->app . '.php';
    if( file_exists($file) ) 
    {
        include($file);
    }
    else
    {
        exit( 'not found' );
    }
    $app_class = $intro->app . '_appadmin';
    $app_class = ucfirst($app_class);
    $class = new $app_class($intro->app, $config['base_url'] . 'index.php/' . $intro->app, null);
    if( $intro->input->get_post('NH') != 1 ) 
    {
        include('header.php');
    }
    $act = str_replace('.php', '', $intro->act);
    if( method_exists($class, $act) ) 
    {
        $class->$act();
    }
    else
    {
        echo '<h3>404 page not found: ' . $intro->app . '/' . $act . ') </h3>';
    }
    if( $intro->input->get_post('NH') != 1 ) 
    {
        include('footer.php');
    }
}
else
{
    $admin_folder = admin_path . 'login.php';
    $location = str_replace('//', '/', $admin_folder);
    if( !headers_sent() ) 
    {
        header('Location: ' . $location);
    }
    else
    {
        echo '<script type="text/javascript">window.location.href="' . $location . '";</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . $location . '" /></noscript>';
    }
    exit();
}
