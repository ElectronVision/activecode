<?php 
class M3uParse
{
    public $url = '';
    public $post = [];
    public $found_titles = [];
    public $timeout = 5;
    public function __construct($data)
    {
        $this->Parse($data);
    }
    public function Parse($data)
    {
        global $intro;
        global $array;
        $data = file_get_contents($data);
        $data = explode("\n", $data);
        if( isset($data[0]) && strlen($data[0]) < 10 ) 
        {
            $data[0] = '';
            unset($data[0]);
        }
        $i = 0;
        $newdata = '';
        foreach( $data as $line ) 
        {
            $i++;
            if( strlen($line) > 4 ) 
            {
                if( $i & 1 ) 
                {
                    $newdata .= (preg_replace("/\r|\n/", '', $line) . '|||');
                }
                else
                {
                    $newdata .= (preg_replace("/\r|\n/", '', $line) . "\n");
                }
            }
        }
        $i = 0;
        $flusonic = '';
        $data = explode("\n", $newdata);
        $ar = [];
        foreach( $data as $line ) 
        {
            $i++;
            $x = explode('|||', $line);
            $name = (isset($x[0]) ? $x[0] : '');
            $url = (isset($x[1]) ? $x[1] : '');
            if( $name == '' || $url == '' ) 
            {
                continue;
            }
            $name = substr(strrchr($name, ','), 1);
            if( $name == '' ) 
            {
                $name = (isset($x[0]) ? $x[0] : '');
            }
            if( preg_match('@^http://@i', $name) ) 
            {
                continue;
            }
            $this->found_titles[] = [
                'title' => trim($name), 
                'url' => trim($url)
            ];
        }
    }
    public function set($name, $value)
    {
        $this->$name = $value;
    }
}
