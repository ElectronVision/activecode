var to_val = -1;
var isDragged = false;

var selector1 = "#search";
var selector2 = "#search_to";
var mInit = false;


function _ms_get_firstValueOfSelectedElements()
{
    var s = false;
    //var index = 0;
    var val = -1;
    $(selector2).find("option").each(function(i,e)
    {
        if($(selector2).val().indexOf($(this).val())!=-1)
        {
            if(s==false)
            {
                //index = i;
                if(i>0)
                {
                    val = $(selector2).find("option").eq(i-1).val();
                }
                //val = $(this).val();
                s=true;
                //console.log(i+"!");
            }
            
        }
    });
    return val;
}

function _ms_get_lastValueOfSelectedElements()
{
    
    //var index = 0;
    var val = 0;
    $(selector2).find("option").each(function(i,e)
    {
        if($(selector2).val().indexOf($(this).val())!=-1)
        {
            
                //index = i;
                val = $(selector2).find("option").eq(i+2).val();
                //val = $(this).val();
                //console.log(i+"!");
            
            
        }
    });
    return val;
}


$(document).ready(function() {

     $("body").on("mousemove",function(event)
    {
          //var st = $("#search_to").scrollTop();
            //$("#search_to").scrollTop(st+5);
            //$(".prettyprint").text(event.offsetY+","+event.pageY+","+event.clientY+","+$("#search_to").offset().top);
            //console.log(isDragged);
            //return;
            if(isDragged==false) return;
            
            var sy = $(selector2).offset().top;
            console.log(event.clientY+","+sy+","+sy+parseInt($(selector2).css("height")));
            if(event.clientY<sy)
            {
                //40032168
                var st = $(selector2).scrollTop();
                $(selector2).scrollTop(st-5);
            }
            if(event.clientY>parseInt(sy)+parseInt($(selector2).css("height")))
            {

                var st = $(selector2).scrollTop();
                $(selector2).scrollTop(st+5);
            }


    });   

    setTimeout(function()
    {
        $(".btnAsc").on("click",function()
        {
            sort("asc");
        });
        $(".btnDesc").on("click",function()
        {
            sort("desc");
        });
        $(".btnUp").on("click",function()
        {
            var val = _ms_get_firstValueOfSelectedElements();
            to_val = val;
            //console.log(to_val);
            moveToSameRightBox();
            //console.log(index);
        });
        $(".btnDown").on("click",function()
        {
            var val = _ms_get_lastValueOfSelectedElements();
            to_val = val;
            //console.log(to_val);
            moveToSameRightBox();
            //console.log(index);
        });
    },500);

    $(selector2).droppable({tolerance:'touch',drop: function( event, ui ) {
        if(ui.draggable.attr('data-selector')=="search")
        {
            moveToRightBox();
        }
        else if(ui.draggable.attr('data-selector')=="search_to")
        {
            moveToSameRightBox();
            $(selector2+" option:selected").removeAttr("selected");
        }
            
      }});


    
});



function mouseMoveFunction()
{
    mInit = true;
    $("select option").on("mousemove",function(e)
    {
        if(!isDragged)
        {
            return;
        }
        var pid = $(this).parent().attr("id");
        if(pid=="search_to")
        {
            to_val = $(this).val();
            //$(this).parent().find("option").css("background","transparent");
            $(this).parent().find("option").css({"background":"transparent","color":"#333","font-weight":"normal"});
            //$(this).attr("selected",true);
            
            $(this).css({background: 'rgb(236, 109, 109)',
    color: '#fff',
    'font-weight': 'bold'});
            //console.log($(this).offset().top);
            //$(this).parent().val($(this).val());
            //comboScroll($(this).parent(),$(this));
        }
    });
}

function comboScroll(c,o)
{
    var h = parseInt($(c).height());
    h = h/2;
    var oh = parseInt($(o).height());
    //var opos = $(o).position().top;
    //console.log(opos-h);
    //$(c).scrollTop((opos-h)+oh);
    var offset = $(o).index() * oh;
    var scrollAmount = offset - h;
    scrollAmount += oh;
    //console.log(scrollAmount);
    $(c).scrollTop(scrollAmount);

}


(function() { 

    // how many milliseconds is a long press?
    var longpress = 500;
    // holds the start time
    var start;


    jQuery( "selects option" ).on( 'mousedown', function( e ) {
        start = new Date().getTime();
        return dragEvent(e);
        

    } );


    jQuery( "selects option" ).on( 'mousemove', function( e ) {
            //dragEvent(e);    

    } );    

    jQuery( "selects option" ).on( 'mouseleave', function( e ) {
        start = 0;
    } );

    jQuery( "selects option" ).on( 'mouseup', function( e ) {
        if ( new Date().getTime() >= ( start + longpress )  ) {
           //alert('long press!');   
           //document.title = "Long press";
           
        } else {
            //$(this).parent().find("option").removeAttr("selected");
            //$(this).attr("selected",true);
           //document.title = "short press"; 
           //alert('short press!');   
        }
    } );

}());


function dragEvent(e)
{
     var select = $(this).parent();
    var id = $(select).attr("id");

    if(select.attr("id")=="search")
    {
        if($(selector1).val()==null) return;
    }
    else if(select.attr("id")=="search_to")
    {
        if($(selector2).val()==null) return;
    }
    else
    {
        return;
    }

    if($("#"+id).val()==null || $("#"+id).val().indexOf($(this).val())==-1)
    {
        return;
    }
    
    if(e.shiftKey==true) return;
    if(e.ctrlKey==true) return;
    var h = "";
    var selecteds = $(select).val();
    var addedElements = 0;
    var overflowed = false;
    var limit = 4;
    $(select).find("option").each(function(i,e)
    {
        if(selecteds.indexOf($(e).val())>=0)
        {
            if(addedElements>limit-1)
            {
                overflowed = true;
                return;
            }
            addedElements++;
            h += "<div>"+$(e).text()+"</div>";
        }
    });
    if(overflowed)
    {
        var remaining = selecteds.length - limit;
        h += "<div>+ "+remaining+" others</div>";
    }
    
    
    var self = $(this);
    var offset = self.offset();
    var draggableDiv = $('<div />').prop('id', 'draggable').css({
        position: 'absolute',
        padding: '5px',
        'padding-left':'10px',
        'padding-right':'30px',
        'border-radius':'10px',
        'box-shadow':'2px 2px 4px #aaa',
        visibility:'hidden',
        left: e.pageX+5,   // <-HERE
        top:  e.pageY+5,
        cursor: 'default',
        background: '#ff0',
        opacity: 0.5
    }).html(h);//text(self.text());
    $('body').append(draggableDiv);
    
    draggableDiv.draggable({
        revert: false,
        opacity:0.8,
        helper:"clone",
        start: function(e, ui)
        {
            $(ui.helper).css("visibility","visible");
            isDragged = true;
        },
        drag:function(e,ui)
        {
        },
        stop:function(e,ui)
        {
            $(draggableDiv).remove();
            isDragged = false;

        },
        containment: 'window'
    });
    $(draggableDiv).attr("data-selector",$(select).attr("id"));

    e.target=draggableDiv.get(0);  // <-HERE
    // function to start drag goes here
    draggableDiv.trigger(e);
}



$(document).on('mousedown', 'select option', function(e) {

    var option = $(this);
    /* This function does drag for both boxes */
    /* Determine which box first */
    
    var select = $(this).parent();
    var id = $(select).attr("id");

    if("#"+select.attr("id")==selector1)
    {
        if($(selector1).val()==null) return;
    }
    else if("#"+select.attr("id")==selector2)
    {
        if($(selector2).val()==null) return;
    }
    else
    {
        return;
    }

    if($("#"+id).val()==null || $("#"+id).val().indexOf($(this).val())==-1)
    {
        return;
    }
    
    if(e.shiftKey==true) return;
    if(e.ctrlKey==true) return;
    var h = "";
    var selecteds = $(select).val();
    var addedElements = 0;
    var overflowed = false;
    var limit = 4;
    $(select).find("option").each(function(i,e)
    {
        if(selecteds.indexOf($(e).val())>=0)
        {
            if(addedElements>limit-1)
            {
                overflowed = true;
                return;
            }
            addedElements++;
            h += "<div>"+$(e).text()+"</div>";
        }
    });
    if(overflowed)
    {
        var remaining = selecteds.length - limit;
        h += "<div>+ "+remaining+" others</div>";
    }
    
    
    var self = $(this);
    var offset = self.offset();
    var draggableDiv = $('<div />').prop('id', 'draggable').css({
        position: 'absolute',
        padding: '5px',
        'padding-left':'10px',
        'padding-right':'30px',
        'border-radius':'10px',
        'box-shadow':'2px 2px 4px #aaa',
        visibility:'hidden',
        left: e.pageX+5,   // <-HERE
        top:  e.pageY+5,
        cursor: 'default',
        background: '#ff0',
        opacity: 0.5
    }).html(h);//text(self.text());
    $('body').append(draggableDiv);
    
    draggableDiv.draggable({
        revert: false,
        opacity:0.8,
        helper:"clone",
        create:function(event,ui)
        {
            this.start = new Date().getTime();
            /* If mousemovefunction wasnt called before call it
                This is used for sorting within the list */
                if(mInit==false) mouseMoveFunction();


            this.timer = setTimeout(function()
            {
                $(draggableDiv).draggable('destroy');
                $(option).parent().find("option").removeAttr("selected");
                $(option).attr("selected",true);
                $(select).val($(option).val());
                

                //$(option).fadeTo(100,0.5);
            },700);
        },
        start: function(e, ui)
        {
            //document.title = "started!";
            $(ui.helper).css("visibility","visible");
            isDragged = true;
            if(this.timer) clearTimeout(this.timer);
            
        },
        drag:function(e,ui)
        {

        },
        stop:function(e,ui)
        {
            $(draggableDiv).remove();
            isDragged = false;
            if ( new Date().getTime() >= ( this.start + 500 )  )
            {
                //document.title = "short!";
            }
            else
            {
                //document.title = "long";
            }
        },
        containment: 'window'
    });
    $(draggableDiv).attr("data-selector",$(select).attr("id"));

    e.target=draggableDiv.get(0);  // <-HERE
    // function to start drag goes here
    draggableDiv.trigger(e);
});


function moveToRightBox()
{

    var s2 = Math.random();
    var elems = $(selector1).val();
    if(elems.length==0) return;
    
    var labels = new Array();

    /* Remove From Left Box */
    for(var i=0;i<elems.length;i++)
    {
        var value = elems[i];
        var label = $(selector1+" option[value='"+value+"']").text();
        labels[value] = label;
        $(selector1+" option[value='"+value+"']").remove();
    }


    /* If Right Box is empty, then simply append */
    if($(selector2+" option").length==0)
    {
        for(var i=0;i<elems.length;i++)
        {
            var value = elems[i];
            var label = labels[value];
            $(selector2).append($("<option value='"+value+"'>"+label+"</option>"));
        }
    }
    else /* If Right Box not empty, then find the spot to append to */
    {
        //var elementToBePlacedAfter = null;
        var elementToBePlacedBefore = null;
        $(selector2+" option").each(function(i,e)
        {
            /* If spot is found */
            if($(e).val()==to_val)
            {
                //elementToBePlacedAfter = $(e);
                elementToBePlacedBefore = $(e);
            }
        });
        /* Append after spot */
        //if(elementToBePlacedAfter!=null)
        if(elementToBePlacedBefore!=null)
        {
            //for(var ind=elems.length-1;ind>=0;ind--)
            for(var ind=0;ind<elems.length;ind++)
            {  
                var value = elems[ind];
                var label = labels[value];
                //$(elementToBePlacedAfter).after($("<option value='"+value+"'>"+label+"</option>"));
                $(elementToBePlacedBefore).before($("<option value='"+value+"'>"+label+"</option>"));
            }
        }
        else
        {
            /* Append to end */
            for(var i=0;i<elems.length;i++)
            {  
                var value = elems[i];
                var label = labels[value];
                $(selector2).append($("<option value='"+value+"'>"+label+"</option>"));
            }
        }
    }
    mouseMoveFunction();
    to_val = -1;
    $(selector2).find("option").css({"background":"transparent","color":"#333","font-weight":"normal"});
    //$(selector2).find("option").removeAttr("selected");
    //$(selector2).val('');
}


function moveToSameRightBox()
{
    //alert(to_val+"!");
    var elems = $(selector2).val();
    if(elems.length==0) return;
    var actualElements = new Array();
    $(selector2+" option").each(function(i,e)
    {
        if(elems.indexOf($(e).val())!=-1)
        {
            actualElements[$(e).val()] = $(e);
        }
    });
    var labels = new Array();
    //var elementToBePlacedAfter = null;
    var elementToBePlacedBefore = null;
    $(selector2+" option").each(function(i,e)
    {
        /* If spot is found */
        if($(e).val()==to_val)
        {
            //elementToBePlacedAfter = $(e);
            elementToBePlacedBefore = $(e);
        }
    });
    /* Append after spot */
    //if(elementToBePlacedAfter!=null)
    if(elementToBePlacedBefore!=null)
    {
        for(var ind=0;ind<elems.length;ind++)
        {  
            var value = elems[ind];
            var elem = actualElements[value];
            //if(elem[0]==elementToBePlacedAfter[0]) continue;
            if(elem[0]==elementToBePlacedBefore[0]) continue;
            //$(elementToBePlacedAfter).after(elem);
            $(elementToBePlacedBefore).before(elem);
        }
    }
    to_val = -1;
    $(selector2).find("option").css({"background":"transparent","color":"#333","font-weight":"normal"});
}


function sort(order)
{
    var tmp = $("<div></div>");
    $(selector2+" option").each(function(i,e)
    {
        if($(selector2).val()!=null && $(selector2).val().indexOf($(e).val())!=-1)
        {
            $(tmp).append($("<div class='srt' data-v='"+$(e).val()+"' data-value='"+$(e).text()+"'>"+$(e).text()+"</div>"));
        }
    });
    if(order==null || order==undefined) order = "asc";
    var alphabeticallyOrderedDivs = null;
    if(order=="asc")
    {
        alphabeticallyOrderedDivs = $(tmp).find(".srt").sort(function (a, b) {
        return $(a).attr("data-value") < $(b).attr("data-value");
        });
    }
    else if(order=="desc")
    {
        alphabeticallyOrderedDivs = $(tmp).find(".srt").sort(function (a, b) {
        return $(a).attr("data-value") > $(b).attr("data-value");
        });   
    }
    var labels = new Array();
    var vals = new Array();
    $(alphabeticallyOrderedDivs).each(function(i,e)
    {
        labels.push($(e).text());
        vals.push($(e).attr("data-v"));
    });
    $(selector2+" option").each(function(i,e)
    {
        if($(selector2).val()!=null && $(selector2).val().indexOf($(e).val())!=-1)
        {
            var val = $(e).val();
            var label = labels.pop();
            var v = vals.pop();
            var newNode = $("<option selected='selected' value='"+v+"'>"+label+"</option>");
            $(e).replaceWith(newNode);
        }
    });
    mouseMoveFunction();
}

jQuery(document).ready(function($) {
    $('#search').MultipleSelector({
        sort:false,
        search: {
            left: '<input type="text" name="q" class="form-control" placeholder="Search..." />',
            right: '<input type="text" name="q" class="form-control" placeholder="Search..." />',
        }
    });
});