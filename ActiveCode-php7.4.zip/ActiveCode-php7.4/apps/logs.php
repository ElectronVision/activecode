<?php 
class Logs_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $options;
        $this->admin = $intro->auth->sess_admin();
        if( !in_array($this->admin['level'], [
            1, 
            9
        ]) && isset($intro->option['AllowReseToSeeLogs']) && intval($intro->option['AllowReseToSeeLogs']) == 0 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function nav()
    {
        global $cur_file;
        echo "<div class=\"app_nav\">\t \t\t \n\t\t<a href=\"" . $this->base . '/index" class="btn btn-' . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ' icon-bug">Active Code Logs</a>';
        if( $this->admin['level'] == 1 ) 
        {
            echo "\t\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Clients') . ('" href="' . $this->base . "/Clients\"><icon class=\"icon-user\"> Client Error Logs  </icon> </a>\n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Top100Clients') . ('" href="' . $this->base . "/Top100Clients\"><icon class=\"icon-bug\"> Top 100 Client Error Logs  </icon> </a>\n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Streams') . ('" href="' . $this->base . '/Streams"><icon class="icon-podcast"> Stream Error Logs  </icon> </a>  ');
        }
        echo "\n\t\t</div>";
    }
    public function LogsDel()
    {
        global $intro;
        if( $this->admin['level'] == 1 ) 
        {
            $intro->db->query('truncate ' . PREFIX . '_logs ');
        }
        $intro->redirect($this->appname);
    }
    public function index()
    {
        global $intro;
        global $array;
        global $code;
        global $serial;
        global $mac;
        global $thelog;
        global $ip;
        global $order;
        global $qry;
        global $page;
        global $ver;
        $qry = $params = '';
        $page = intval($intro->input->get_post('page'));
        $code = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('code'));
        $serial = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('serial'), ':.-_');
        $mac = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('mac'), ':');
        $thelog = $intro->db->escape($intro->input->get_post('thelog'));
        $ip = $intro->db->escape($intro->input->get_post('ip'));
        $ver = $intro->db->escape($intro->input->get_post('ver'));
        $this->nav();
        if( $code != '' ) 
        {
            $qry .= (' AND code  LIKE \'%' . $code . '%\'');
            $params .= ('&code=' . $code);
        }
        if( $serial != '' ) 
        {
            $qry .= (' AND serial  LIKE \'%' . $serial . '%\'');
            $params .= ('&serial=' . $serial);
        }
        if( $mac != '' ) 
        {
            $qry .= (' AND mac  LIKE \'%' . $mac . '%\'');
            $params .= ('&mac=' . $mac);
        }
        if( $thelog != '' ) 
        {
            $qry .= (' AND thelog  LIKE \'%' . $thelog . '%\'');
            $params .= ('&thelog=' . $thelog);
        }
        if( $ip != '' ) 
        {
            $qry .= (' AND ip LIKE \'%' . $ip . '%\'');
            $params .= ('&ip=' . $ip);
        }
        if( $ver != '' ) 
        {
            $qry .= (' AND ver LIKE \'%' . $ver . '%\'');
            $params .= ('&ver=' . $ver);
        }
        if( $qry != '' ) 
        {
            $qry = 'WHERE true ' . $qry;
        }
        if( $order == '' ) 
        {
            $order = 'id_desc';
        }
        $order = str_replace('_desc', ' desc', $order);
        $order = str_replace('_asc', ' asc', $order);
        $rows_per_page = '50';
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_logs  ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $resultnumm = $intro->db->query('SELECT id from ' . PREFIX . ('_logs  ' . $qry));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<span class=\'icon-list\'></span> Logs (' . $totalrows . ')', 'primary');
        if( $this->admin['level'] == 1 ) 
        {
            echo "<div class=\"row\">\n\t\t\t<div class=\"pull-right\" style='margin-right:5px;'>\n\t\t\t<a href='" . $this->base . "/LogsDel' class=\"btn btn-danger icon-trash\" OnClick=\"return confirm('Are you sure?');\">Delete Active Code logs</a>\n\t\t\t</div>\n\t\t\t</div>";
        }
        echo "<fieldset>\n\t\t<form action=\"\" method=\"post\" class=''>\n\t\t\t<input type=\"text\" name=\"code\" value=\"" . $code . "\" size=\"20\" placeholder=\"Code\">\n\t\t\t<input type=\"text\" name=\"serial\" value=\"" . $serial . "\" size=\"25\" placeholder=\"Serial\">\n\t\t\t<input type=\"text\" name=\"mac\" value=\"" . $mac . "\" size=\"25\" placeholder=\"Mac\">\n\t\t\t<input type=\"text\" name=\"ip\" value=\"" . $ip . "\" size=\"20\" placeholder=\"IP\">\n\t\t\t<input type=\"text\" name=\"thelog\" value=\"" . $thelog . "\" size=\"30\" placeholder=\"Log text\">\n\t\t\t<input type=\"text\" name=\"ver\" value=\"" . $ver . "\" size=\"10\" placeholder=\"ver\">\n\t\t\t\n\t\t\t<input  name=\"name\" value=\"Search\" type=\"submit\">\n\t\t</form>\n\t\t</fieldset>";
        echo "\n\t  <table class=\"table table-condensed table-bordered table-hover\">\n            <tr>\n\t\t\t\t<th>ID</th>\n\t\t\t\t<th>Ver</th>\n\t\t\t\t<th>Resel</th>\n\t\t\t\t<th>Date</th>\n\t\t\t\t<th>Model</th>\n\t\t\t\t<th>Code</th>\n\t\t\t\t<th>Serial</th>\n\t\t\t\t<th>Mac</th>\n\t\t\t\t<th>IP</th>\n\t\t\t\t<th></th>\n\t\t\t\t<th>Log</th>\n\t\t\t\t<th>UserAgent</th>\n\t    </tr>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $dtime = date('Y-m-d H:i:s', (int)$dtime);
            $thelog = str_replace('+', '<br/>', $thelog);
            $thelog = str_replace('@Wrong Code', '<span class=\'label label-danger\'>@Wrong Code</span>', $thelog);
            $thelog = str_replace('@NotValidForDevice', '<span class=\'label label-danger\'>@NotValidForDevice</span>', $thelog);
            $thelog = str_replace('ReActivation', '<span class=\'label label-default\'>ReActivation</span>', $thelog);
            $thelog = str_replace('Success', '<span class=\'label label-success\'>Success</span>', $thelog);
            $thelog = str_replace('byCode', '<span class=\'label label-info\'>byCode</span>', $thelog);
            $thelog = str_replace('byMAC', '<span class=\'label label-info\'>byMAC</span>', $thelog);
            $thelog = str_replace('bySerial', '<span class=\'label label-info\'>bySerial</span>', $thelog);
            if( $country == '' ) 
            {
                $country = $intro->maxmind->get($ip)['country']['iso_code'];
            }
            if( $country == '' ) 
            {
                $flag = '';
            }
            else
            {
                $flag = 'flag flag-' . strtolower($country);
            }
            echo "\n\t\t\t<tr>\n\t\t\t\t<td class=\"center\">" . $id . "</td>\n\t\t\t\t<td class=\"center\">" . $ver . "</td>\n\t\t\t\t<td class=\"center\">" . $array['admins'][$adminid] . "</td>\n\t\t\t\t<td class=\"center\">" . $dtime . "</th>\n\t\t\t\t<td class=\"center\">" . $model . "</th>\n\t\t\t\t<td class=\"center\">" . $code . "</th>\n\t\t\t\t<td class=\"center\">" . $serial . "</th>\n\t\t\t\t<td class=\"center\">" . $mac . "</th>\n\t\t\t\t<td class=\"center\"><a href='https://www.ip2location.com/demo/" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\n\t\t\t\t<td><img src=\"" . admin_path . ('style/css/flags/blank.gif" class="' . $flag . '" title="' . $country . "\" /></th>     \n\t\t\t\t<td>" . $thelog . "</th>     \n\t\t\t\t<td>" . $uagent . "</th>     \n\t\t </tr>");
        }
        echo '</table>';
        $order = str_replace(' desc', '_desc', $order);
        $order = str_replace(' asc', '_asc', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411(_obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?order=' . $order . $params, $totalrows, $rows_per_page, $page));
    }
    public function Clients()
    {
        global $intro;
        global $array;
        $qry = $params = '';
        $order = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('order'), '');
        $page = intval($intro->input->get_post('page'));
        $user_name = $intro->db->escape($intro->input->get_post('user_name'));
        $stream_name = $intro->db->escape($intro->input->get_post('stream_name'));
        $client_status = $intro->db->escape($intro->input->get_post('client_status'));
        $user_agent = $intro->db->escape($intro->input->get_post('user_agent'));
        $user_ip = $intro->db->escape($intro->input->get_post('user_ip'));
        if( $user_name != '' ) 
        {
            $qry .= (' AND usr.username  LIKE \'%' . $user_name . '%\' ');
            $params .= ('&user_name=' . $user_name);
        }
        if( $stream_name != '' ) 
        {
            $qry .= (' AND str.stream_display_name  LIKE \'%' . $stream_name . '%\' ');
            $params .= ('&stream_name=' . $stream_name);
        }
        if( $client_status != '' ) 
        {
            $qry .= (' AND cl.client_status  LIKE \'%' . $client_status . '%\' ');
            $params .= ('&client_status=' . $client_status);
        }
        if( $user_agent != '' ) 
        {
            $qry .= (' AND cl.user_agent  LIKE \'%' . $user_agent . '%\' ');
            $params .= ('&user_agent=' . $user_agent);
        }
        if( $user_ip != '' ) 
        {
            $qry .= (' AND cl.ip  LIKE \'%' . $user_ip . '%\' ');
            $params .= ('&user_ip=' . $user_ip);
        }
        $order = str_replace('desc', ' desc', $order);
        $order = str_replace('asc', ' asc', $order);
        $rows_per_page = '100';
        if( intval($page) == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $this->nav();
        $result = $intro->db->query(" select usr.username as user_name ,str.stream_display_name as stream_name,\n\t\t\t\t\t\t\t\t\tcl.client_status,cl.query_string,cl.user_agent,cl.ip,cl.extra_data,cl.date\n\t\t\t\t\t\t\t\t\tFROM client_logs cl\n\t\t\t\t\t\t\t\t\tleft JOIN users usr on cl.user_id=usr.id\n\t\t\t\t\t\t\t\t\tleft JOIN streams str on cl.stream_id=str.id\n\t\t\t\t\t\t\t\t\twhere true " . $qry . ' ORDER BY cl.id DESC  limit ' . $nexlimit . ',' . $rows_per_page . ' ');
        $resultnumm = $intro->db->query(' select id FROM client_logs   ORDER BY id ASC');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Clients Error Log' . (' (' . $totalrows . ')'), 'danger');
        echo "\n\t\t<form action=\"\" method=\"post\" class=''>\n\t\t\t<input type=\"text\" name=\"user_name\" value=\"" . $user_name . "\" size=\"20\" placeholder=\"User Name\">\n\t\t\t<input type=\"text\" name=\"stream_name\" value=\"" . $stream_name . "\" size=\"25\" placeholder=\"Stream Name\">\n\t\t\t<input type=\"text\" name=\"client_status\" value=\"" . $client_status . "\" size=\"25\" placeholder=\"Client Status \">\n\t\t\t<input type=\"text\" name=\"user_agent\" value=\"" . $user_agent . "\" size=\"25\" placeholder=\"User Agent \">\n\t\t\t<input type=\"text\" name=\"user_ip\" value=\"" . $user_ip . "\" size=\"25\" placeholder=\"User ip \">\n\t\t\n\t\t\t<input  name=\"name\" value=\"Search\" type=\"submit\">\n\t\t</form>\n\t\t<br>";
        echo "\n\t\t<table dir=ltr class=\"table table-bordered table-condensed table-hover\">\n\t\t<tr>\n\t\t\t<th class='c'>User</th>\n\t\t\t<th class='c'>Stream</th>\n\t\t\t<th class='c'>Client status</th>\n\t\t\t<th class='c'>query string</th>\n\t\t\t<th class='c'>UserAgent</th>\n\t\t\t<th class='c'>User IP</th>\n\t\t\t<th class='c'>extra_data</th>\n\t\t\t<th class='c'>Date</th>\n\t\t</tr>";
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $date = ($date != '' ? date('Y-m-d H:i:s', $date) : '');
            echo "<tr>\n\t\t\t\t<td class=\"center\">" . $user_name . "</td>\n\t\t\t\t<td class=\"c\">" . $stream_name . "</td>\n\t\t\t\t<td class=\"c\">" . $client_status . "</th>\n\t\t\t\t<td class=\"c\">" . $query_string . "</th>\n\t\t\t\t<td class=\"c\"><a title=\"" . $user_agent . '">' . substr($user_agent, 0, 15) . ("</a></th>\n\t\t\t\t<td class=\"c\"><a href='https://www.ip2location.com/demo/" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\n\t\t\t\t<td class=\"c\">" . $extra_data . "</th>\n\t\t\t\t<td class=\"c\">" . $date . "</th>\n\n\t\t\t</tr>");
        }
        echo '</table>';
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/Clients?order=' . $order . $params, $totalrows, $rows_per_page, $page) . '</center>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function Streams()
    {
        global $intro;
        global $array;
        $qry = $params = '';
        $order = $intro->db->escape($intro->input->get_post('order'));
        $page = intval($intro->input->get_post('page'));
        $stream_name = $intro->db->escape($intro->input->get_post('stream_name'));
        $server_name = $intro->db->escape($intro->input->get_post('server_name'));
        if( $server_name != '' ) 
        {
            $qry .= (' AND  svr.server_name  LIKE \'%' . $server_name . '%\' ');
            $params .= ('&server_name=' . $server_name);
        }
        if( $stream_name != '' ) 
        {
            $qry .= (' AND str.stream_display_name  LIKE \'%' . $stream_name . '%\' ');
            $params .= ('&stream_name=' . $stream_name);
        }
        $order = str_replace('desc', ' desc', $order);
        $order = str_replace('asc', ' asc', $order);
        $rows_per_page = '100';
        if( intval($page) == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $this->nav();
        $result = $intro->db->query(" select stl.date,stl.error, svr.server_name as server_name,str.stream_display_name as stream_name\n\t\t\t\t\t\t\t\tFROM stream_logs stl\n\t\t\t\t\t\t\t\tleft JOIN streaming_servers svr on stl.server_id=svr.id\n\t\t\t\t\t\t\t\tleft JOIN streams str on stl.stream_id=str.id\n\t\t\t\t\t\t\t\twhere true " . $qry . ' ORDER BY stl.id DESC  limit ' . $nexlimit . ',' . $rows_per_page . ' ');
        $resultnumm = $intro->db->query('SELECT id FROM stream_logs ORDER BY id ASC');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('All Online Users' . (' (' . $totalrows . ')'), 'success');
        echo "\n\t\t<form action=\"\" method=\"post\" class=''>\n\t\t\t<input type=\"text\" name=\"server_name\" value=\"" . $server_name . "\" size=\"20\" placeholder=\"Server Name\">\n\t\t\t<input type=\"text\" name=\"stream_name\" value=\"" . $stream_name . "\" size=\"20\" placeholder=\"Stream Name\">\n\t\t\n\t\t\t<input  name=\"name\" value=\"Search\" type=\"submit\">\n\t\t</form>\n\t\t<br>";
        echo "\n\t\t<table dir=ltr class=\"table table-bordered table-condensed table-hover\">\n            <tr>\n\t\t\t\t<th class='c'>Stream</th>\n\t\t\t\t<th class='c'>Servers</th>\n\t\t\t\t<th class='c'>Date</th>\n\t\t\t\t<th class='c'>Error</th>\n\t\t\t\t\n\t\t\t\n\t\t\t\t\n\t\t</tr>";
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $date = ($date != '' ? date('Y-m-d H:i:s', $date) : '');
            echo "<tr>\n\t\t\t\t<td class=\"c\">" . $stream_name . "</td>\n\t\t\t\t<td class=\"c\">" . $server_name . "</th>\n\t\t\t\t<td class=\"c\">" . $date . "</th>\n\t\t\t\t<td class=\"c\">" . $error . "</th>\n\t\t\t\n\t\t\t</tr>";
        }
        echo '</table>';
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/Streams?order=' . $order . $params, $totalrows, $rows_per_page, $page) . '</center>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function Top100Clients()
    {
        global $intro;
        global $sess_admin;
        $this->nav();
        $sql = $intro->db->query('SELECT *,count(*) as cnt FROM `client_logs` group by ip order by cnt desc LIMIT 100');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<span class=\'icon-list\'></span>Top 100 Clients Error Logs (' . $totalrows . ')', 'primary');
        echo "\n\t\t<table class=\"table table-condensed table-bordered table-hover\">\n\t\t\t<tr>\n\t\t\t\t<th>ID</th>\n\t\t\t\t<th>Stream</th>\n\t\t\t\t<th>User</th>\n\t\t\t\t<th>Status</th>\n\t\t\t\t<th>Query</th>\n\t\t\t\t<th>Agent</th>\n\t\t\t\t<th>IP</th>\n\t\t\t\t<th>Date</th>\n\t\t\t\t<th>Count</th>\n\t\t\t</tr>";
        $i = 0;
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            $i++;
            echo "<tr>\n\t\t\t\t<td class=\"center\">" . $id . "</td>\n\t\t\t\t<td class=\"center\">" . $stream_id . "</td>\n\t\t\t\t<td class=\"center\">" . $user_id . "</td>\n\t\t\t\t<td class=\"center\">" . $client_status . "</th>\n\t\t\t\t<td class=\"center\">" . $query_string . "</th>\n\t\t\t\t<td class=\"center\">" . $user_agent . "</th>\n\t\t\t\t<td class=\"center\"><a href='https://www.ip2location.com/demo/" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\n\t\t\t\t<td class=\"center\">" . @date('Y-m-d H:i:s', $date) . ("</th>\n\t\t\t\t<td>" . $cnt . "</th>     \n\t\t\t\t\t\n\t\t\t</tr>");
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function BruteForce()
    {
        global $intro;
        global $sess_admin;
        $qry = $params = '';
        $ip = $intro->db->escape(trim($intro->input->get_post('ip')));
        if( $ip != '' ) 
        {
            $qry .= (' WHERE  ip  LIKE \'%' . $ip . '%\' ');
            $params .= ('&ip=' . $ip);
        }
        if( intval($intro->input->get_post('clear')) == 1 ) 
        {
            $intro->db->query('TRUNCATE `' . PREFIX . '_login_ips`;');
        }
        $this->nav();
        $sql = $intro->db->query('SELECT * FROM `' . PREFIX . '_login_ips` ORDER BY `id` DESC');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<span class=\'icon-list\'></span>Brute Force Login Attacks (' . $totalrows . ')', 'danger');
        echo '<a class="btn btn-success" href="' . $this->base . '/BruteForce/?clear=1" OnClick="return confirm(\'Are You Sure?\');"><icon class="icon-trash"></icon>  Clear All </a>';
        echo "\n\t\t<table class=\"table table-condensed table-bordered table-hover\">\n\t\t\t<tr>\n\t\t\t\t<th>ID</th>\n\t\t\t\t<th>Reseller</th>\n\t\t\t\t<th>IP</th>\n\t\t\t\t<th>Country</th>\n\t\t\t\t<th>Tries</th>\n\t\t\t\t<th>Last Try</th>\n\t\t\t\t<th></th>\n\t\t\t</tr>";
        $i = 0;
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            $i++;
            if( $country == '' ) 
            {
                $country = $intro->maxmind->get($ip)['country']['iso_code'];
            }
            if( $country == '' ) 
            {
                $flag = '';
            }
            else
            {
                $flag = 'flag flag-' . strtolower($country);
            }
            echo "<tr>\n\t\t\t\t<td class=\"center\">" . $id . "</td>\n\t\t\t\t<td class=\"center\">" . $username . "</td>\n\t\t\t\t<td class=\"center\"><a href='https://www.ip2location.com/demo/" . $ip . '\' target=\'_blank\'>' . $ip . "</a></td>\n\t\t\t\t<td class=\"center\"><img src=\"" . admin_path . ('style/css/flags/blank.gif" class="' . $flag . '" title="' . $country . "\" /></td>\n\t\t\t\t<td class=\"center\">" . $tries . "</th>\n\t\t\t\t<td class=\"center\">") . date('Y-m-d H:i:s', $timeDiff) . ("</th>\n\t\t\t\t<td><a class=\"btn btn-danger btn-xs p_del intro_ui_del\" href=\"" . $this->base . '/DelBF?id=' . $id . "\" OnClick=\"return false;\" title=\"Delete and allow reseller to login\"><i class=\"icon-cancel-circled2\"></i></a></th>     \n\t\t\t\t\t\n\t\t\t</tr>");
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function DelBF()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('DELETE FROM `' . PREFIX . ('_login_ips` WHERE id=' . $id . '; '));
    }
}
