<?php 
echo '﻿';
class Transcode_Profiles_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $array;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $intro->lang['trans_appname'] = 'Transcode Profiles';
        $intro->lang['trans_add'] = 'Add New Transcode Profile';
        $intro->lang['trans_edit'] = 'Edit  Transcode Profile';
        $intro->lang['trans_cur'] = 'Current Transcode Profiles';
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . '/index"><icon class="icon-list"></icon>') . $intro->lang['trans_appname'] . "</a> \r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add"><icon class="icon-plus-squared"></icon>') . $intro->lang['trans_add'] . "</a>  \t\t \t\t \r\n\t\t</div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = '';
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry = ' where profile_name  LIKE \'%' . $search_txt . '%\' ';
        }
        if( $order == '' ) 
        {
            $order = 'profile_id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 30;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from  transcoding_profiles ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page);
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT profile_id from  transcoding_profiles ' . $qry . ' ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> ' . $intro->lang['trans_cur'] . (' (' . $totalrows . ')'), 'info');
        echo "\r\n\t\t\r\n\t\t<fieldset>\r\n\t\t\t<form action=\"\" method=\"post\">\r\n\t\t\t\t<input type=\"text\" name=\"search_txt\" value=\"" . $search_txt . '" placeholder="' . $intro->lang['search_form'] . "\" size=\"20\">\r\n\t\t\t\t<input name=\"name\" value=\"" . $intro->lang['search'] . "\" type=\"submit\">\r\n\t\t\t</form>\r\n\t\t</fieldset>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID </th>\r\n\t\t\t<th>Profile Name</th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\">" . $profile_id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $profile_name . "</td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $profile_id . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $profile_id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>\r\n\t\t</div>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?search_txt=' . $search_txt . '&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</div>');
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $profile_name;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM transcoding_profiles WHERE profile_id=' . $id . ';');
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = $intro->lang['trans_edit'] . (' <b>' . $id . '</b>');
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $profile_options = json_decode($profile_options, true);
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $profile_options = [];
            $btn['legend_name'] = $intro->lang['trans_add'];
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>Profile Name\t</td>\r\n\t\t\t<td><input  type=\"text\" name=\"profile_name\" placeholder=\"My Transcode Profile...\" class='form-control' value=\"" . $profile_name . '" size="30"> ' . $this->error('epg_name') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>Video Codec</td>\r\n\t\t\t<td>" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('transcode_attributes[-vcodec]', $array['vedio_codec'], $profile_options['-vcodec']) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>Audio Codec</td>\r\n\t\t\t<td>" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('transcode_attributes[-acodec]', $array['audio_codec'], $profile_options['-acodec']) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>Preset</td>\r\n\t\t\t<td>" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('transcode_attributes[-preset]', $array['preset'], $profile_options['-preset']) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>Video Profile</td>\r\n\t\t\t<td>" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('transcode_attributes[-profile:v]', $array['vedio_profile'], $profile_options['-profile:v']) . "</td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'> " . tooltip('trans_prof_tooltip', 'arg3') . " Average Video Bit Rate</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[3]\"  class='form-control' value=\"" . $profile_options[3]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>" . tooltip('trans_prof_tooltip', 'arg4') . "Average Audio Bitrate</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[4]\"  class='form-control' value=\"" . $profile_options[4]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg5') . " Minimum Bitrate Tolerance</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[5]\"  class='form-control' value=\"" . $profile_options[5]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg6') . " Maximum Bitrate Tolerance</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[6]\"  class='form-control' value=\"" . $profile_options[6]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg7') . " Buffer Size</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[7]\"  class='form-control' value=\"" . $profile_options[7]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'> " . tooltip('trans_prof_tooltip', 'arg8') . " CRF Value</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[8]\"  class='form-control' value=\"" . $profile_options[8]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>" . tooltip('trans_prof_tooltip', 'arg9') . " Scaling</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[9]\"  class='form-control' value=\"" . $profile_options[9]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg10') . " Aspect</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[10]\"  class='form-control' value=\"" . $profile_options[10]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>" . tooltip('trans_prof_tooltip', 'arg11') . " Target Video FrameRate</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[11]\"  class='form-control' value=\"" . $profile_options[11]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>" . tooltip('trans_prof_tooltip', 'arg12') . " Audio Sample Rate</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[12]\"  class='form-control' value=\"" . $profile_options[12]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg13') . " Audio Channels</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[13]\"  class='form-control' value=\"" . $profile_options[13]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg14') . " Remove Sensitive Parts (delogo filter)</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[14]\"  class='form-control' value=\"" . $profile_options[14]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>" . tooltip('trans_prof_tooltip', 'arg15') . " Threads</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[15]\"  class='form-control' value=\"" . $profile_options[15]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg16') . " Logo Path</td>\r\n\t\t\t<td><input  type=\"text\" name=\"arguments[16]\"  class='form-control' value=\"" . $profile_options[16]['val'] . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>\t" . tooltip('trans_prof_tooltip', 'arg18') . " DeInterlacing Filter</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('arguments[18]', $profile_options[18]['val'], $type = 'yes') . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "\t<script>\r\n\t\$(function () {\r\n\t\t  \$('[data-toggle=\"tooltip\"]').tooltip();\r\n\t\t});\r\n\t</script>\r\n\t\r\n\t";
    }
    public function streams_arguments()
    {
        global $intro;
        global $error;
        $ar = [];
        $sql = $intro->db->query('SELECT id,argument_cmd FROM `streams_arguments` order by id ASC');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $ar[$row['id']] = $row['argument_cmd'];
        }
        return $ar;
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $profile_name = trim($intro->input->post('profile_name'));
        $transcode_attributes = $intro->input->post('transcode_attributes');
        $arguments = $intro->input->post('arguments');
        if( $profile_name == '' ) 
        {
            if( $profile_name == '' ) 
            {
                $error['profile_name'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data = [];
        $data['profile_name'] = $profile_name;
        $json = [];
        $json['-vcodec'] = $transcode_attributes['-vcodec'];
        $json['-acodec'] = $transcode_attributes['-acodec'];
        $json['-preset'] = $transcode_attributes['-preset'];
        $json['-profile:v'] = $transcode_attributes['-profile:v'];
        if( $transcode_attributes['-profile:v'] == 0 ) 
        {
            unset($json['-profile:v']);
        }
        $db_profiles = $this->streams_arguments();
        foreach( $arguments as $key => $val ) 
        {
            if( isset($db_profiles[$key]) && $val != '' && ($key == 18 && $val == 1 || $key != 18) ) 
            {
                $json[$key] = [
                    'cmd' => vsprintf($db_profiles[$key], $val), 
                    'val' => $val
                ];
            }
        }
        $data['profile_options'] = json_encode($json, JSON_UNESCAPED_SLASHES);
        $intro->db->insert('transcoding_profiles', $data);
        $id = $intro->db->insert_id();
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $profile_name = trim($intro->input->post('profile_name'));
        $transcode_attributes = $intro->input->post('transcode_attributes');
        $arguments = $intro->input->post('arguments');
        if( $profile_name == '' ) 
        {
            if( $profile_name == '' ) 
            {
                $error['profile_name'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data = [];
        $data['profile_name'] = $profile_name;
        $json = [];
        $json['-vcodec'] = $transcode_attributes['-vcodec'];
        $json['-acodec'] = $transcode_attributes['-acodec'];
        $json['-preset'] = $transcode_attributes['-preset'];
        $json['-profile:v'] = $transcode_attributes['-profile:v'];
        if( $transcode_attributes['-profile:v'] == 0 ) 
        {
            unset($json['-profile:v']);
        }
        $db_profiles = $this->streams_arguments();
        foreach( $arguments as $key => $val ) 
        {
            if( isset($db_profiles[$key]) && $val != '' && ($key == 18 && $val == 1 || $key != 18) ) 
            {
                $json[$key] = [
                    'cmd' => vsprintf($db_profiles[$key], $val), 
                    'val' => $val
                ];
            }
        }
        $data['profile_options'] = json_encode($json, JSON_UNESCAPED_SLASHES);
        $id = intval($intro->input->post('id'));
        $intro->db->update('transcoding_profiles', $data, 'profile_id=' . $id);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('DELETE FROM transcoding_profiles WHERE profile_id=' . $id . '; ');
        $intro->redirect($this->appname);
    }
}
