<?php 
class Commands_users_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $qry_admin = '';
    public $max_input_vars = 0;
    public $admin = [];
    public $inputBy = [
        'Code', 
        'MAC', 
        'Serial'
    ];
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        if( $this->admin['level'] != 1 ) 
        {
            exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Sorry: no access!!!', 'danger') );
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo "\n\t\t<div class=\"app_nav\">\n\t\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $intro->app_url('commands_users', 'index') . "\">\n\t\t\t\t<icon class=\"icon-code\"></icon>\n\t\t\t\tBulk Commands for Users\n\t\t\t</a>\n\t\t\t\n\t\t\t<a class=\"btn btn-default\" href=\"" . $intro->app_url('commands', 'index') . "\">\n\t\t\t\t<icon class=\"icon-list\"></icon>\n\t\t\t\tBulk Commands for Codes\n\t\t\t</a>\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        $this->nav();
        echo '<div class=\'ltr\' dir=\'ltr\'>';
        $this->search_form();
        echo '</div>';
    }
    public function form_resellers($html_name, $txt = 'Reseller')
    {
        global $intro;
        $html = '<select name="' . $html_name . "\" class=\"searchable\"  style='min-width:500px'>\n\n\t\t<option value='' selected>" . $txt . "</option>\n";
        $sql_q = $intro->db->query('select * from ' . PREFIX . '_admin order by admin_name ASC');
        while( $row = $intro->db->fetch_assoc($sql_q) ) 
        {
            $db_adminid = $row['adminid'];
            $db_modname = $row['admin_name'];
            $html .= ('<option value="' . $db_adminid . '">' . $db_modname . " </option>\n");
            $sql2 = $intro->db->query('select * from ' . PREFIX . ('_admin where father=' . $db_adminid . ' order by admin_name ASC'));
            if( $intro->db->returned_rows > 0 ) 
            {
                while( $row2 = $intro->db->fetch_assoc($sql2) ) 
                {
                    $db2_adminid = $row2['adminid'];
                    $db2_modname = $row2['admin_name'];
                    $html .= ('<option value="' . $db2_adminid . '">' . $db_modname . ' -> ' . $db2_modname . " </option>\n");
                }
            }
        }
        $html .= "</select>\n\n\n";
        return $html;
    }
    public function search_form()
    {
        global $intro;
        global $array;
        $max_input_vars = @ini_get('max_input_vars');
        $max_input_vars = intval($max_input_vars);
        if( $max_input_vars == 0 ) 
        {
            $max_input_vars = 1000;
        }
        else
        {
            $max_input_vars = $max_input_vars - 100;
        }
        if( $max_input_vars > 5000 ) 
        {
            $max_input_vars = 5000;
        }
        $is_mag = $is_e2 = 0;
        $this->max_input_vars = $max_input_vars;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Users Oprations', 'danger');
        echo "\n\t\t<form id=\"form_add\" action=\"\" method=\"post\">\n\t\tThis will search for all users (User/MAG/E2) Except: Restreamers\n\t\t<table class='table table-bordered' style='max-width:600px'>\n\t\t<tr>\n\t\t\t\t<td>IS MAG:</td>\n\t\t\t\t<td></td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('is_mag', $is_mag, 1, 'Yes', 'No', 'primary') . "</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t\t<td>IS Enigma2:</td>\n\t\t\t\t<td></td>\n\t\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('is_e2', $is_e2, 1, 'Yes', 'No', 'primary') . "</td>\n\t\t</tr>\n\n\t\t<tr>\n\t\t\t\t<td>Bulk Users</td>\n\t\t\t\t<td><input type='hidden' name='bulk_users_op' value='='></td>\n\t\t\t\t<td><textarea style=\"width:500px;height:50px\" name=\"bulk_users\" value=\"\" id=\"bulk_users\"></textarea>\n\t\t\t\t<br/>Put each user in separate line.\n\t\t\t\t</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t\t<td>Username</td>\n\t\t\t\t<td>Use * for wildcards <input type='hidden' name='username_op' value='LIKE'></td>\n\t\t\t\t<td><input type=\"text\" name=\"username\" value=\"\" id=\"username\" /> Put * to list all users</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t\t<td>Fullname</td>\n\t\t\t\t<td>Use * for wildcards <input type='hidden' name='fullname_op' value='LIKE'></td>\n\t\t\t\t<td><input type=\"text\" name=\"fullname\" value=\"\" id=\"fullname\" /> exaple: jhon* or *hon* </td>\n\t\t</tr> \n\n\t\t<tr>\n\t\t\t\t<td>Reseller:</td>\n\t\t\t\t<td>" . $this->operator('member_id') . "</td>\n\t\t\t\t<td>" . $this->form_resellers('member_id', 'ALL ...') . "</td>\n\t\t</tr> \n\t\t<tr>\n\t\t\t\t<td>Days (Months)</td>\n\t\t\t\t<td>" . $this->operator('period') . "</td>\n\t\t\t\t<td>" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', $array['period'], '', 'ALL ...') . "</td>\n\t\t</tr> \n\t\t\n\t\t<!--\n\t\t<tr>\n\t\t\t\t<td>Status</td>\n\t\t\t\t<td>" . $this->operator('status') . "</td>\n\t\t\t\t<td>" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('status', $intro->status, '', 'ALL ...') . ("</td>\n\t\t</tr>\n\t\t-->\n\t\t\n\t\t<tr>\n\t\t\t\t<td>Row Limit : " . $max_input_vars . "</td>\n\t\t\t\t<td> Example:</td>\n\t\t\t\t<td><input type=\"text\" name=\"limit\" value=\"0\" id=\"limit\" size=\"10\" /> 0= unlimited\n\t\t\t\t<ul><li>0,1000 this will list first 1000 records</li>\n\t\t\t\t<li>1000,1000 this will skip 1000 records first and list the next 1000  </li>\n\t\t\t\t<li>2000,1000 this will skip 2000 records first and list the next 1000</li>\n\t\t\t\t\n\t\t\t\t</ul>\n\t\t\t\tUse the limit to update large data.\n\t\t\t\t</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t\t<td> </td>\n\t\t\t\t<td> </td>\n\t\t\t\t<td><input name=\"name\" value=\" Search Users\" type=\"submit\"></td>\n\t\t</tr>\t\t\n\t\t</table>\n\t\t<input type=\"hidden\" name=\"max_input_vars\" value=\"" . $max_input_vars . "\" />\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "\t\t<script type=\"text/javascript\">\n\t\t\$(document).ready(function(){\n\t\t\t\$(\"#form_add\").submit( function () {   \n\t\t\t\t\$('#result').html('loading...');\n\t\t\t\t\$.post('";
        echo $this->base;
        echo "/doSearch?NH=1',\$(this).serialize(),function(data){\n\t\t\t\t\t\$(\"#result\").html(data)\n\t\t\t\t}\n\t\t\t  );\n\t\t\t  return false;   \n\t\t\t});   \n\t\t});\n\t\t</script>\n\t\t<div id=\"result\"></div>\n\t\t";
    }
    public function operator($fld)
    {
        return '<select name="' . $fld . "_op\">\n\t\t<option value=\"=\">=</option>\n\t\t<option value=\">\">&gt;</option>\n\t\t<option value=\">=\">&gt;=</option>\n\t\t<option value=\"<\">&lt;</option>\n\t\t<option value=\"<=\">&lt;=</option>\n\t\t<option value=\"!=\">!=</option>\n\t\t<option value=\"LIKE\">LIKE * *</option>\n\t\t<option value=\"NOT LIKE\">NOT LIKE</option>\n\t\t<option value=\"IN (...)\">IN (...)</option>\n\t\t<option value=\"NOT IN (...)\">NOT IN (...)</option>\n\t\t<option value=\"IS NULL\">IS NULL</option>\n\t\t<option value=\"IS NOT NULL\">IS NOT NULL</option>\n\t\t</select>";
    }
    public function _getWhereClause($post)
    {
        global $intro;
        $where = '';
        if( isset($_POST['bulk_users']) && $_POST['bulk_users'] != '' ) 
        {
            $data = explode("\n", $_POST['bulk_users']);
            if( count($data) > 1 ) 
            {
                $ar = [];
                foreach( $data as $u ) 
                {
                    $u = trim($u);
                    $ar[] = '\'' . $u . '\'';
                }
                return 'AND username IN (' . implode(',', $ar) . ') ';
            }
            else
            {
                return '';
            }
        }
        if( intval($intro->input->post('is_mag')) == 1 ) 
        {
            $where .= ' AND is_mag=1 ';
        }
        if( intval($intro->input->post('is_e2')) == 1 ) 
        {
            $where .= ' AND is_e2=1 ';
        }
        if( intval($intro->input->post('is_restreamer')) == 1 ) 
        {
            $where .= ' AND is_restreamer=1 ';
        }
        foreach( $post as $key => $val ) 
        {
            $op = $key . '_op';
            if( isset($post[$op]) ) 
            {
                if( $op == 'member_id_op' ) 
                {
                }
                if( $post[$op] == '=' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' = \'' . $val . '\' ');
                }
                if( $post[$op] == '>' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' > \'' . $val . '\' ');
                }
                if( $post[$op] == '<' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' < \'' . $val . '\' ');
                }
                if( $post[$op] == '!=' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' != \'' . $val . '\'');
                }
                if( $post[$op] == '>=' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' >= \'' . $val . '\' ');
                }
                if( $post[$op] == '<=' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' <= \'' . $val . '\' ');
                }
                if( $post[$op] == 'LIKE' && $val != '' ) 
                {
                    $val = str_replace('*', '%', $val);
                    $where .= ('AND ' . $key . ' LIKE \'' . $val . '\' ');
                }
                if( $post[$op] == 'IN (...)' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' IN (' . $val . ') ');
                }
                if( $post[$op] == 'NOT IN (...)' && $val != '' ) 
                {
                    $where .= ('AND ' . $key . ' NOT IN (' . $val . ') ');
                }
            }
        }
        return $where;
    }
    public function doSearch()
    {
        global $intro;
        global $array;
        $limit = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->post('limit'), ',');
        $max_input_vars = intval($intro->input->post('max_input_vars'));
        if( $limit != 0 ) 
        {
            $limit = 'LIMIT ' . $limit;
        }
        else
        {
            $limit = '';
        }
        $qry = $this->_getWhereClause($_POST);
        if( $qry == '' ) 
        {
            exit( '<fieldset><span class=\'red big\'>Please put anything to search for.</span></fieldset>' );
        }
        $qry = 'WHERE is_restreamer=0 AND id NOT IN (select userid from ' . PREFIX . ('_codes) ' . $qry . ' ');
        echo '<fieldset>' . $limit . '</fieldset>';
        $result = $intro->db->query('SELECT * from users  LEFT JOIN ' . PREFIX . '_users_data ud on users.id=ud.userid ' . (' ' . $qry . ' order by exp_date ASC ' . $limit));
        $totalrows = $intro->db->returned_rows;
        if( $max_input_vars < $totalrows ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h4>We found: ' . number_format($totalrows) . (" Users.\n\t\t\t<br/>Users are more than " . $max_input_vars . ", please narrow your search.<br/>\n\t\t\tYou can run the following commands on the (") . number_format($totalrows) . ' rows) at once.</h4>', 'info');
            $this->sqlCMD($qry, $totalrows);
            exit();
        }
        if( $totalrows > 0 ) 
        {
            echo '<form action="' . $this->base . '/doCMD" method="post" name="fieldsForm"  id="fieldsForm">';
            echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Found Users (' . $totalrows . ') ', 'info');
            echo "\n\t\t\t<table class=\"DataTable table-striped table-bordered table-condensed\" id=\"CodesTable\">\n\t\t\t<thead>\n\t\t\t<tr>\n\t\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . " </th>\n\t\t\t\t<th></th>\n\t\t\t\t<th>Reseller</th>\n\t\t\t\t<th>Fullname</th>";
            if( intval($intro->input->post('is_mag')) == 1 ) 
            {
                echo '<th>MAC</th>';
            }
            echo '<th>Username ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('username', 'index') . " </th>\n\t\t\t\t<th>Password</th>\n\t\t\t\t<th>Period</th>\n\t\t\t\t\n\t\t\t\t<th>Expire</th>\n\t\t\t\t<th>" . (($this->admin['level'] == 1 ? 'Admin ' : '')) . "Notes</th>\n\t\t\t\t<th>MAX Conn.</th>\n\t\t\t\t<th> </th>\n\t\t\t\t<th>Options</th>\n\t\t\t</tr>\n\t\t\t</thead>\n\t\t\t\n\t\t\t<tbody>";
            $i = 0;
            while( $myrow = $intro->db->fetch_assoc($result) ) 
            {
                @extract($myrow);
                $i++;
                $user_id = $id;
                $userid = $id;
                $online = '';
                if( $exp_date == '' ) 
                {
                    $exp_date = 'Unlimited';
                }
                else if( $exp_date < time() ) 
                {
                    $exp_date = 'Expired';
                }
                else
                {
                    $exp_date = date('Y-m-d H:i', $exp_date);
                }
                if( $enabled == 0 ) 
                {
                    $online = '<span class="icon-off label label-danger" title="Disabled!"> </span>';
                }
                if( $admin_enabled == 0 ) 
                {
                    $online = '<span class="icon-block label label-danger" title="Banned!"> </span>';
                }
                echo "\n\t\t\t\t<tr id='tr_" . $id . "'>\n\t\t\t\t\t<td class='c'>" . $id . '<input type="checkbox" id="checkbox_row_' . $id . ('" value="' . $id . "\" name=\"selected_fld[]\"></td>\n\t\t\t\t\t<td class='c' id='status_" . $id . '\'>' . $online . "</td>\n\t\t\t\t\t<td class='c'>") . ((isset($array['admins'][$created_by]) ? $array['admins'][$created_by] : 'not set')) . ("</td>\t\n\t\t\t\t\t<td>" . $fullname . '</td>');
                if( intval($intro->input->post('is_mag')) == 1 ) 
                {
                    echo '<td>MAG</td>';
                }
                echo '<td>' . $username . "</td>\n\t\t\t\t\t<td>" . $password . "</td>\t\n\t\t\t\t\t<td>" . period($period, $free_days) . ("</td>\t\n\t\t\t\t\t<td class='c'><span class=\"editExpireDate\" data-type=\"text\" data-pk=\"" . $id . '" data-name="exp_date">' . $exp_date . "</span></td>\n\t\t\t\t\t<td class='c'>") . (($this->admin['level'] == 1 ? $admin_notes : $reseller_notes)) . ("</td>\n\t\t\t\t\t<td class='c'>" . $max_connections . "</td>\n\t\t\t\t\t<td class='c'></td>\n\t\t\t\t\t<td class='c'></td>\n\t\t\t\t</tr>");
            }
            echo "</tbody>\n\t\t\t</table>";
            $this->optionCMD();
            echo '</fieldset>';
            echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
            echo "\n\t\t\t<input type='hidden' name='totalrows' value='" . $totalrows . "'>\n\t\t\t</form>";
            echo '<div id="resultCMD"></div>';
            echo $this->base;
            echo "/doCMD?NH=1',\$(this).serialize(),function(data){\n\t\t\t\t\t\t\n\t\t\t\t\t\t\$(\"#resultCMD\").html(data)\n\t\t\t\t\t}\n\t\t\t\t  );\n\t\t\t\t  return false;   \n\t\t\t\t});\n\t\t\t\t\n\t\t\t\tvar \$checkboxes = \$('#CodesTable input[type=\"checkbox\"]');\n\t\t\t\t\n\t\t\t\t\$(\"#checkAllCodes\").change(function () {\n\t\t\t\t\t\$(\"#CodesTable input:checkbox\").prop('checked', \$(this).prop(\"checked\"));\n\t\t\t\t\tvar countCheckedCheckboxes = \$checkboxes.filter(':checked').length;\n\t\t\t\t\t\$('#checked_count').html(countCheckedCheckboxes);\n\t\t\t\t});\n\n\t\t\t\t\$checkboxes.change(function()\n\t\t\t\t{\n\t\t\t\t\tvar countCheckedCheckboxes = \$checkboxes.filter(':checked').length;\n\t\t\t\t\t\$('#checked_count').html(countCheckedCheckboxes);\n\t\t\t\t\t\n\t\t\t\t});\n\t\t\t});\n\t\t\t</script>\n\t\t\t";
        }
        else
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Nothing found.', 'danger');
        }
    }
    public function doCMD()
    {
        global $intro;
        $selected_fld = $intro->input->post('selected_fld');
        $totalrows = intval($intro->input->post('totalrows'));
        if( !is_array($selected_fld) || count($selected_fld) <= 0 ) 
        {
            exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Please select Users', 'danger') );
        }
        $IDs = implode(',', $selected_fld);
        $qry = ' WHERE id IN (' . $IDs . ')';
        $_POST['qry'] = $qry;
        $this->doCMDsql();
    }
    public function optionCMD($totalrows = 0)
    {
        global $intro;
        global $array;
        global $type;
        global $status;
        echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Warning: Warning: Warning: Backup your database first!!! ', 'danger');
        $i = 1;
        echo " \n\t\t<table class=\"table table-bordered\" id=\"TableCMD\">\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"delete\"/>\n\t\t\t<td style=\"width:250px\">" . $i++ . "- Delete Users from Database.</td>\n\t\t\t<td> </td>\n\t\t</tr>\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"renew\"/></td>\n\t\t\t<td>" . $i++ . "- Renew For: </td>\n\t\t\t<td> " . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('renew_val', $array['period'], '') . " this will renew all and extend expire date. </td>\n\t\t</tr>\n\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"date_expire\"/></td>\n\t\t\t<td>" . $i++ . "- Update Expire Date (End Date): </td>\n\t\t\t<td> <input dir=ltr type=\"text\" name=\"date_expire_val\" value=\"\" maxlength=\"10\" placeholder=\"yyyy-mm-dd\" /></td>\n\t\t</tr>\n\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"member_id\"/></td>\n\t\t\t<td>" . $i++ . "- Change (Reseller): </td>\n\t\t\t<td> " . form_resellers('member_id_val', 0) . " </td>\n\t\t</tr>\n\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"period\"/></td>\n\t\t\t<td>" . $i++ . "- Change Days (Months): </td>\n\t\t\t<td> " . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period_val', $array['period'], '') . " this will change the Period only and will not change expire date. </td>\n\t\t</tr>\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"forced_country\"/></td>\n\t\t\t<td>" . $i++ . "- Override General Country Restriction : </td>\n\t\t\t<td>" . forced_country('') . "</td>\n\t\t</tr>\n\t\t\n\t\t<tr>\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"bouquets\"/></td>\n\t\t\t<td>" . $i++ . "- Change Bouquets:\n\t\t\t\t<div>\n\t\t\t\t\t   <input type=\"checkbox\" id=\"checkAll\"/> <b>Check All</b>\n\t\t\t\t</div>\n\t\t\t\t<h3>Choose from the following:</h3>\n\t\t\t\t<div style='color:red;'>\n\t\t\t\t\t<input type=\"radio\" name=\"bouquetsOptions\" value=\"all\"/>\n\t\t\t\t\t(Replace ALL) This will override all Bouquets for all selected codes.\n\t\t\t\t</div>\n\t\t\t\t<div style='color:green;'>\n\t\t\t\t\t<input type=\"radio\" name=\"bouquetsOptions\" value=\"add\"/>\n\t\t\t\t\t(Add Selected) Select the Bouquets to add to codes , this option will keep all packages and add the new ones you select.\n\t\t\t\t</div>\n\t\t\t\t<div style='color:blue;'>\n\t\t\t\t\t<input type=\"radio\" name=\"bouquetsOptions\" value=\"remove\"/>\n\t\t\t\t\t(Remove Selected) Remove selected Bouquets, this option will keep all packages and remove the new ones you select.\n\t\t\t\t</div>\n\t\t\t</td>\n\t\t\t<td id=\"BQ_CHECK_BOXES\">" . bouquets([]) . "</td>\n\t\t</tr>\n\t\t\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"fullname\"/></td>\n\t\t\t<td>" . $i++ . "- Change Fullname: </td>\n\t\t\t<td> <input dir=ltr type=\"text\" name=\"fullname_val\" value=\"\" maxlength=\"50\" size='40' /></td>\n\t\t</tr>\n\t\t<tr>\t\n\t\t\t<td> <input type=\"radio\" name=\"maa\" value=\"useragent\"/></td>\n\t\t\t<td>" . $i++ . "- Change Useragent: </td>\n\t\t\t<td> <input dir=ltr type=\"text\" name=\"useragent_val\" value=\"\" maxlength=\"150\" size='40' placeholder='Useragent' /></td>\n\t\t</tr>";
        echo "\n\t\t<tr>\t\n\t\t\t<td> </td>\n\t\t\t<td> <input class=\"btn btn-danger\" name=\"namesubbtn\" value=\"  " . (($totalrows > 0 ? ' Update All (' . number_format($totalrows) . ') rows Now!' : '  GO  ')) . " \" type=\"submit\" OnClick=\"return confirm('Are you sure? this is final.');\"></td>\n\t\t\t<td> </td>\n\t\t</tr>\n\t\t</table>";
        echo "\n\t\t<style>\n\t\t\t#TableCMD tr{cursor:pointer}\n\t\t</style>\n\t\t<script>\n\t\t\$(document).ready(function(){\n\t\t\t\$(\"#TableCMD input[type='radio']\").on( \"click\", function() {\n\t\t\t\t\n\t\t\t\t\$(\"#TableCMD tr\").removeClass('info');\n\t\t\t\t\$(this).closest('tr').addClass('info');\n\t\t\t});\n\t\t\t\$('#TableCMD tr').click(function() {\n\t\t\t\t\n\t\t\t\t\$(\"#TableCMD tr\").removeClass('info');\n\t\t\t\t\$(this).addClass('info');\n\t\t\t\t\$(this).find('td:first-child input:radio').prop('checked', true);\n\t\t\t});\n\t\t\t\n\t\t\t\$(\"#checkAll\").change(function () {\n\t\t\t\t\$(\"#BQ_CHECK_BOXES input:checkbox\").prop('checked', \$(this).prop(\"checked\"));\n\t\t\t});\n\t\t\t\n\t\t\t\$(\"#forced_country,#renew_val,#period_val\").addClass('chosen').chosen({search_contains: true});\n\t\t\t\$(\"select[name='member_id_val']\").addClass('chosen').chosen({search_contains: true});\n\t\t\t\n\t\t});\n\t\t</script>";
    }
    public function sqlCMD($qry, $totalrows = 0)
    {
        global $intro;
        echo "\n\t\t<form action=\"" . $this->base . '/doCMDsql" method="post" name="fieldsForm"  id="fieldsForm">';
        echo '<fieldset>';
        $this->optionCMD($totalrows);
        echo '</fieldset>';
        echo "\n\t\t\t<input type=\"hidden\" name=\"qry\" value=\"" . $qry . "\" />\n\n\t\t\t</form>";
        echo "\t\t<script>\n\t\t\$(document).ready(function(){\n\t\t\t\$(\"#fieldsForm\").submit( function () {   \n\t\t\t\t\$('#resultCMD').html('<span style=\"background:#fff\">loading... this could take serveral minutes</span>');\n\t\t\t\t\$.post('";
        echo $this->base;
        echo "/doCMDsql?NH=1',\$(this).serialize(),function(data){\n\t\t\t\t\t\n\t\t\t\t\t\$(\"#resultCMD\").html(data)\n\t\t\t\t}\n\t\t\t  );\n\t\t\t  return false;   \n\t\t\t});   \n\t\t});\n\t\t</script>\n\t\t<div id=\"resultCMD\"></div>\n\t\t";
    }
    public function doCMDsql()
    {
        global $intro;
        global $array;
        ignore_user_abort(true);
        @set_time_limit(0);
        ob_start();
        $xtream = '';
        $maa = trim($intro->input->post('maa'));
        $bouquetsOptions = trim($intro->input->post('bouquetsOptions'));
        $bouquets_post_array = $intro->input->post('bouquets');
        if( is_array($bouquets_post_array) ) 
        {
            $bouquets_str = implode(',', $bouquets_post_array);
        }
        if( $maa == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Please choose command. ', 'danger');
            exit();
        }
        $qry = $_POST['qry'];
        if( $qry == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Unknown Query !!! ', 'danger');
            exit();
        }
        $qry = preg_replace('/AND/', 'WHERE', $qry, 1);
        $qry = str_replace('WHERE id NOT IN', 'AND id NOT IN', $qry);
        if( $qry == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Please choose command. ', 'danger');
            exit();
        }
        $num = $num2 = 0;
        if( $maa == 'delete' ) 
        {
            $intro->db->query_fast('DELETE from users ' . $qry . ';');
            $num = $intro->db->affected_rows;
        }
        else if( $maa == 'renew' ) 
        {
            $period = intval($_POST['renew_val']);
            if( $period > 0 ) 
            {
                $sql = $intro->db->query_fast('select id,exp_date from users ' . $qry . ';');
                while( $row = $intro->db->fetch_assoc($sql) ) 
                {
                    $id = intval($row['id']);
                    $expire = $this->calcPeriod($period, $row['exp_date']);
                    if( $expire != 0 && $expire != '' ) 
                    {
                        $intro->db->query_fast('UPDATE users SET exp_date=\'' . $expire . '\',enabled=1 where id=' . $id . ';');
                        $num += $intro->db->affected_rows;
                    }
                    ob_flush();
                    flush();
                    echo '. ';
                }
            }
            else
            {
                exit( _obf_0D3D40321528110F062A0B0321102712170C15030F2232('ERROR: choose the period : 1 or 3 or 6 or 16 months etc... ', 'danger') );
            }
        }
        else if( $maa == 'date_expire' ) 
        {
            $value = strtotime($_POST['date_expire_val']);
            $intro->db->query_fast('UPDATE users set exp_date=\'' . $value . '\' ' . $qry . ';');
            $num = $intro->db->affected_rows;
        }
        else if( $maa == 'unsuspend' ) 
        {
            $num += $intro->db->affected_rows;
        }
        else if( $maa == 'bouquets' ) 
        {
            $sql = $intro->db->query_fast('select id,bouquet from users ' . $qry . ';');
            while( $row = $intro->db->fetch_assoc($sql) ) 
            {
                $id = intval($row['id']);
                $db_bq = json_decode($row['bouquet'], true);
                if( $bouquetsOptions == 'add' ) 
                {
                    $merge = array_merge($db_bq, $bouquets_post_array);
                    $unique = array_unique($merge);
                    $bouquets_str = implode(',', $unique);
                }
                if( $bouquetsOptions == 'remove' ) 
                {
                    $diff = array_diff($db_bq, $bouquets_post_array);
                    $bouquets_str = implode(',', $diff);
                }
                $intro->db->query_fast('UPDATE users SET bouquet=\'[' . $bouquets_str . ']\' where id=' . $id . ';');
                $num += $intro->db->affected_rows;
                ob_flush();
                flush();
                echo '. ';
            }
        }
        else if( $maa == 'forced_country' ) 
        {
            $forced_country = trim($_POST['forced_country']);
            $intro->db->query_fast('UPDATE users SET forced_country=\'' . $forced_country . '\'  ' . $qry . ';');
            $num += $intro->db->affected_rows;
        }
        else if( $maa == 'useragent' ) 
        {
            $useragent = trim($intro->input->post('useragent_val'));
            if( $useragent != '' ) 
            {
                $ex = explode(',', $useragent);
                $agnet = json_encode($ex);
            }
            else
            {
                $agnet = '';
            }
            $intro->db->query_fast('UPDATE users SET allowed_ua=\'' . $agnet . '\' ' . $qry . ';');
            $num += $intro->db->affected_rows;
        }
        else
        {
            $field = $maa;
            $value = $_POST[$maa . '_val'];
            $intro->db->query('UPDATE users set ' . $field . '=\'' . $value . '\' ' . $qry . ';');
            $num = $intro->db->affected_rows;
        }
        echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232(' Affected Rows = (' . $num . ') ', 'success');
    }
    public function calcPeriod($period, $expire)
    {
        global $array;
        if( $period == 0 ) 
        {
            return 0;
        }
        $exp_date = '';
        if( $expire < time() ) 
        {
            $expire = time();
        }
        if( in_array($period, $array['free']) ) 
        {
            $dd = $period - 100;
            $exp_date = strtotime('+' . $dd . ' days', $expire);
        }
        else
        {
            $exp_date = strtotime('+' . $period . ' month', $expire);
        }
        if( $exp_date != '' ) 
        {
            return $exp_date;
        }
        else
        {
            return 0;
        }
    }
}
