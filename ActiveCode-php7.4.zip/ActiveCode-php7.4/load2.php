<?php 
namespace 
{
    error_reporting(1);
    define('WP_CONTENT_DIR', '.');
    $conf_file = dirname(__FILE__) . '/includes/Config.php';
    if( !file_exists($conf_file) ) 
    {
        exit( '<h4 style=\'color:red\'>Please rename includes/Config.default.php TO: includes/Config.php<br/> or config file is missing.</h4>' );
    }
    require($conf_file);
    if( isset($config['production']) && $config['production'] ) 
    {
        error_reporting(32767);
    }
    require(dirname(__FILE__) . '/includes/functions_forms.php');
    require(dirname(__FILE__) . '/load.php');
    _obf_0D35291A282418300B3D0F0B3424260A020E3E37012E22();
    @ini_set('magic_quotes_runtime', 0);
    @ini_set('magic_quotes_sybase', 0);
    wp_unregister_globals();
    _obf_0D2B251B122F1A2823301B2230125B243B043403093422();
    _obf_0D0E362213290F163F013D2F2C0F3B3001023F322B3B32();
    timer_start();
    if( isset($config['panel']) && $config['panel'] == 'creed' ) 
    {
        define('XC_DIR', '/home/streamcreed/');
    }
    else
    {
        define('XC_DIR', '/home/xtreamcodes/iptv_xtream_codes/');
    }
    spl_autoload_register(null, false);
    $intro = new autoloader('includes');
    $doc_root = $_SERVER['DOCUMENT_ROOT'] . $config['base_url'];
    spl_autoload_register([
        $intro, 
        'autoload'
    ]);
    $db = new Db();
    $intro->maxmind = new Maxmind($doc_root . 'geo/GeoLite2-Country.mmdb');
    $db->connect($config['db']['hostname'], $config['db']['username'], $config['db']['password'], $config['db']['database'], (isset($config['db']['port']) ? $config['db']['port'] : ''));
    $db->set_charset($config['db']['charset'], $config['db']['collation']);
    $db->query('set sql_mode = \'\';');
    $db->debug = false;
    if( isset($config['production']) && $config['production'] ) 
    {
        $db->halt_on_errors = true;
    }
    $intro->db = $db;
    $intro->sess = new Session($intro->db->get_link(), 'xJHGJGKJSxsjkxjk', 7200, true, true);
    $intro->sec = new Security();
    $intro->input = new Input();
    $intro->auth = new Auth($db);
    $intro->groups = [];
    $intro->hide_baranding = 'No';
    $sql = $intro->db->query('select * from ' . PREFIX . '_options');
    while( $row = $intro->db->fetch_assoc($sql) ) 
    {
        $op_name = trim($row['name']);
        $intro->option[$op_name] = trim($row['val']);
    }
    $sqlSet = $intro->db->query('SELECT id,server_name FROM `streaming_servers` ORDER BY server_name ASC;');
    while( $rowS = $intro->db->fetch_assoc($sqlSet) ) 
    {
        $intro->servers[$rowS['id']] = trim($rowS['server_name']);
    }
    @date_default_timezone_set('Asia/Baghdad');
    $intro->groups[-1] = 'ALL';
    $intro->groups[0] = 'Default By Reseller Group';
    $sql = $intro->db->query('SELECT SQL_CACHE * from ' . PREFIX . '_admin_groups order by g_name ASC');
    while( $row = $intro->db->fetch_assoc($sql) ) 
    {
        $intro->groups[$row['g_id']] = trim($row['g_name']);
    }
    $intro->packages[0] = '-';
    $sql = $intro->db->query('SELECT SQL_CACHE * from packages');
    while( $row = $intro->db->fetch_assoc($sql) ) 
    {
        $intro->packages[$row['id']] = trim($row['package_name']);
    }
    unset($row);
    unset($sql);
    $intro->option['debug'] = 0;
    include('includes/Lang.php');
    include('includes/array_isp.php');
    include('includes/array_tooltip.php');
    include('includes/array_tprofile.php');
    include('includes/array_menu.php');
    $sql = $intro->db->query('SELECT SQL_CACHE * FROM member_groups order by group_id asc;');
    while( $row = $intro->db->fetch_assoc($sql) ) 
    {
        $array['member_groups'][$row['group_id']] = $row;
        $array['resel_groups'][$row['group_id']] = $row['group_name'];
    }
    unset($sql);
    unset($row);
    $custom = new Custom();
    if( is_array($custom->option) && count($custom->option) > 0 ) 
    {
        foreach( $custom->option as $opt_key => $opt_val ) 
        {
            $intro->option[$opt_key] = $opt_val;
        }
    }
    $array['admins'][0] = 'no resel';
    $aql_admins = $intro->db->query('SELECT adminid,admin_name FROM ' . PREFIX . '_admin order by adminid desc');
    if( $intro->db->returned_rows > 0 ) 
    {
        while( $row = $intro->db->fetch_assoc($aql_admins) ) 
        {
            $adminid = $row['adminid'];
            $array['admins'][$adminid] = $row['admin_name'];
        }
    }
    $array['servers'][0] = '-';
    $result = $intro->db->query('SELECT id,server_name from streaming_servers order by server_name ASC');
    while( $myrow = $intro->db->fetch_assoc($result) ) 
    {
        $array['servers'][$myrow['id']] = $myrow['server_name'];
    }
    $array['period'] = [
        '4294967295' => 'Unlimited', 
        '101' => 'Free 1 day', 
        '103' => 'Free 3 days', 
        '107' => 'Free 7 days', 
        '110' => 'Free 10 days', 
        '1' => '1 month', 
        '3' => '3 months', 
        '6' => '6 months', 
        '12' => '12 months', 
        '24' => '2 Years', 
        '36' => '3 Years'
    ];
    $array['free'] = [
        -1, 
        101, 
        103, 
        107, 
        110
    ];
    class autoloader
    {
        public $dir = null;
        public $path_info = null;
        public $seg = null;
        public $app = null;
        public $act = null;
        public function __construct($dir)
        {
            global $config;
            $this->dir = $dir;
            $this->path_info = (!empty($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : (!empty($_SERVER['ORIG_PATH_INFO']) ? $_SERVER['ORIG_PATH_INFO'] : ''));
            if( $this->path_info == '' ) 
            {
                $url = str_replace($config['base_url'], '', $_SERVER['REQUEST_URI']);
                $url = explode('?', $url);
                $this->path_info = $url[0];
            }
            $this->seg = (!empty($this->path_info) ? array_filter(explode('/', $this->path_info)) : null);
            $this->app = (isset($this->seg[1]) && $this->seg[1] != '' ? $this->seg[1] : 'home');
            $this->act = (isset($this->seg[2]) && $this->seg[2] != '' ? $this->seg[2] : 'index');
            if( isset($this->seg[2]) && $this->seg[2] == 'index.php' ) 
            {
                $this->app = 'home';
                $this->act = 'index';
            }
        }
        public function autoload($class_name)
        {
            global $config;
            $file_name = $class_name . '.php';
            $file = $this->dir . '/' . $file_name;
            if( !file_exists($file) ) 
            {
                $file = $_SERVER['DOCUMENT_ROOT'] . $config['base_url'] . $file;
                if( !file_exists($file) ) 
                {
                    return false;
                }
                include($file);
                return true;
            }
            include($file);
        }
        public function admin_url($app, $action = 'index')
        {
            global $config;
            return $config['base_url'] . 'index.php/' . $app . '/' . $action;
        }
        public function app_url($app, $action = 'index', $args = '')
        {
            global $config;
            return $config['base_url'] . 'index.php/' . $app . '/' . $action . $args;
        }
        public function redirect($app, $method = 'index', $args = '')
        {
            global $config;
            $location = $config['base_url'] . 'index.php/' . $app . '/' . $method . $args;
            if( !headers_sent() ) 
            {
                header('Location: ' . $location);
            }
            else
            {
                echo '<script type="text/javascript">window.location.href="' . $location . '";</script>';
                echo '<noscript><meta http-equiv="refresh" content="0;url=' . $location . '" /></noscript>';
            }
            exit();
        }
        public function pwd($str)
        {
            $x1 = sha1($str . 'AniMoh');
            $pass = md5($x1 . 'AniSo');
            return $pass;
        }
    }
    function _obf_0D1D0D3E131403283E0110300F230D3D195B38065B3711($mem_group = null)
    {
        global $intro;
        $return = [];
        $result = $intro->db->query('SELECT * FROM `packages` ORDER BY `id` ASC;');
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            if( in_array(intval($mem_group), json_decode($row['groups'], true)) ) 
            {
                $return[intval($row['id'])] = $row;
            }
        }
        return $return;
    }
    function _obf_0D31033702041D1F0B1015180339183714070C36032811($htmlname, $values = [])
    {
        global $intro;
        if( !is_array($values) ) 
        {
            $values = [];
        }
        $result = $intro->db->query('SELECT * FROM `streaming_servers` ORDER BY id ASC');
        for( $html = '<select multiple="multiple" name="' . $htmlname . '" id="' . str_replace('[]', '', $htmlname) . '" class=\'searchable chosen\'>'; $myrow = $intro->db->fetch_assoc($result); $html .= ('<option value="' . $server_id . '" ' . ((in_array($server_id, $values) ? 'selected="selected"' : '')) . ('>' . $server_name . '</option>')) ) 
        {
            $server_name = $myrow['server_name'];
            $server_id = intval($myrow['id']);
        }
        $html .= '</select>';
        return $html;
    }
    function _obf_0D3B0A102B29073D0C153B282D0C1D183D1E3D27320122($stream_id)
    {
        global $intro;
        $ar = [];
        $result = $intro->db->query('SELECT server_id FROM `streams_sys` WHERE stream_id=' . $stream_id . ';');
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            $ar[] = $myrow['server_id'];
        }
        return $ar;
    }
    function forced_country($str = '')
    {
        global $intro;
        $html = "<select name=\"forced_country\" id=\"forced_country\" class=\"searchable chosen\" >\t\n\t\t\t<option value=\"\" selected=\"selected\">Don't override</option>";
        foreach( $intro->country as $key => $val ) 
        {
            $html .= ('<option value="' . $key . '" ' . (($str == $key ? 'selected="selected"' : '')) . ('>' . $val . '</option>'));
        }
        $html .= '</select>';
        return $html;
    }
    function _obf_0D013F08222413321E283D40402B3E082C2B3F29103432($id, $failed, $return)
    {
        global $intro;
        global $array;
        $id = intval($id);
        if( $id == 0 ) 
        {
            return '';
        }
        $aql_admins = $intro->db->query('SELECT adminid FROM ' . PREFIX . '_admin ' . (' WHERE adminid=' . $id . ' OR father=' . $id . ' OR main_father=' . $id));
        if( $intro->db->returned_rows > 0 ) 
        {
            $ids = [];
            while( $row = $intro->db->fetch_assoc($aql_admins) ) 
            {
                $ids[] = $row['adminid'];
            }
            if( $return == 'AND_IN' ) 
            {
                return ' AND ' . $failed . ' IN (' . implode(',', $ids) . ') ';
            }
        }
    }
    function period($period, $free_days = 0)
    {
        global $intro;
        global $array;
        if( $period == 0 ) 
        {
            return '-';
        }
        if( $period == -1 ) 
        {
            return 'Unlimited';
        }
        if( in_array($period, $array['free']) ) 
        {
            $pp = ($period - 100) . ' Free Day(s)';
        }
        else
        {
            $pp = $period . ' Month(s)';
            if( $free_days > 0 ) 
            {
                $pp = $period . 'M + ' . $free_days . 'D';
            }
        }
        return $pp;
    }
    function _obf_0D381B16302D3B293D133D2821143C143322063F341001()
    {
        global $intro;
        $ar = [];
        $sql = $intro->db->query("SELECT * FROM `streaming_servers` WHERE status=1\t ORDER BY `id` ASC;");
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $ar[$row['id']] = $row;
        }
        return $ar;
    }
    function _obf_0D3F5B5B312E2F352234142C1C1F3C1B0C06231A292732($return = '')
    {
        global $intro;
        global $array;
        global $config;
        $sql = $intro->db->query('SELECT * FROM streaming_servers WHERE id=1;');
        $row = $intro->db->fetch_assoc($sql);
        if( isset($config['panel']) && $config['panel'] == 'creed' ) 
        {
            $domain_name = trim($row['broadcast']);
        }
        else
        {
            $domain_name = trim($row['domain_name']);
        }
        $server_ip = trim($row['server_ip']);
        $http_broadcast_port = intval($row['http_broadcast_port']);
        if( $domain_name == '' ) 
        {
            $domain_name = $server_ip;
        }
        if( $return == 'row' ) 
        {
            return $row;
        }
        else if( $return == 'cmd' ) 
        {
            return 'http://' . $server_ip . ':' . $http_broadcast_port . '/dir.php';
        }
        else if( $return == 'api' ) 
        {
            if( isset($intro->option['iptv_api_url']) && $intro->option['iptv_api_url'] != '' ) 
            {
                $url = parse_url($intro->option['iptv_api_url']);
                if( isset($url['path']) && $url['path'] != '' ) 
                {
                    $api = str_replace('/', '', $url['path']);
                }
                else
                {
                    $api = 'api.php';
                }
            }
            else
            {
                $api = 'api.php';
            }
            return 'http://' . $server_ip . ':' . $http_broadcast_port . '/' . $api;
        }
        else if( $return == 'm3u' ) 
        {
            $path = 'get.php';
            if( isset($intro->option['m3u_host']) && $intro->option['m3u_host'] != '' ) 
            {
                $url = parse_url($intro->option['m3u_host']);
                if( isset($url['scheme']) && isset($url['host']) && isset($url['port']) && isset($url['path']) ) 
                {
                    return $url;
                }
                if( !isset($url['scheme']) && !isset($url['host']) && !isset($url['port']) && isset($url['path']) ) 
                {
                    $path = $url['path'];
                }
            }
            return [
                'scheme' => 'http', 
                'host' => $domain_name, 
                'port' => $http_broadcast_port, 
                'path' => $path
            ];
        }
        else if( $return == 'host_port' ) 
        {
            return 'http://' . $domain_name . ':' . $http_broadcast_port . '/';
        }
    }
    function _obf_0D16342C3B25040E30351911133C313C1B1D23050B1B11($field = '')
    {
        global $intro;
        global $array;
        $sql = '*';
        if( $field != '' ) 
        {
            $sql = (string)$field;
        }
        $sql = $intro->db->query('SELECT ' . $sql . ' FROM settings WHERE id=1;');
        $row = $intro->db->fetch_assoc($sql);
        if( $field != '' ) 
        {
            return $row[$field];
        }
        else
        {
            return $row;
        }
    }
    function _obf_0D322A5B141A102E2824032B03230A35140306272F2F11($page = '')
    {
        global $intro;
        global $array;
        $adm = $intro->auth->sess_admin();
        if( $adm['level'] == 1 && $page == 'page_users' ) 
        {
            return $array['period'];
        }
        $adm = $intro->auth->admin_data($adm['adminid']);
        $can_add_free_1 = intval($adm['can_add_free_1']);
        $can_add_free_3 = intval($adm['can_add_free_3']);
        $can_add_free_7 = intval($adm['can_add_free_7']);
        $can_add_free_10 = intval($adm['can_add_free_10']);
        $cost_1_enabled = intval($adm['cost_1_enabled']);
        $cost_3_enabled = intval($adm['cost_3_enabled']);
        $cost_6_enabled = intval($adm['cost_6_enabled']);
        $cost_12_enabled = intval($adm['cost_12_enabled']);
        $cost_24_enabled = intval($adm['cost_24_enabled']);
        $cost_36_enabled = intval($adm['cost_36_enabled']);
        $array['period'] = [];
        if( $can_add_free_1 == 1 ) 
        {
            $array['period'][101] = 'Free 1 day';
        }
        if( $can_add_free_3 == 1 ) 
        {
            $array['period'][103] = 'Free 3 days';
        }
        if( $can_add_free_7 == 1 ) 
        {
            $array['period'][107] = 'Free 7 days';
        }
        if( $can_add_free_10 == 1 ) 
        {
            $array['period'][110] = 'Free 10 days';
        }
        if( $cost_1_enabled == 1 ) 
        {
            $array['period'][1] = '1 month';
        }
        if( $cost_3_enabled == 1 ) 
        {
            $array['period'][3] = '3 months';
        }
        if( $cost_6_enabled == 1 ) 
        {
            $array['period'][6] = '6 months';
        }
        if( $cost_12_enabled == 1 ) 
        {
            $array['period'][12] = '12 months';
        }
        if( $cost_24_enabled == 1 ) 
        {
            $array['period'][24] = '2 years';
        }
        if( $cost_36_enabled == 1 ) 
        {
            $array['period'][36] = '3 Years';
        }
        if( intval($adm['num_free']) == 0 && $adm['level'] != 1 ) 
        {
            unset($array['period'][101]);
            unset($array['period'][103]);
            unset($array['period'][107]);
            unset($array['period'][110]);
        }
        if( isset($intro->option['BlockAddFree']) && intval($intro->option['BlockAddFree']) == 1 && $adm['level'] != 1 ) 
        {
            unset($array['period'][101]);
            unset($array['period'][103]);
            unset($array['period'][107]);
            unset($array['period'][110]);
        }
        return $array['period'];
    }
    function _obf_0D2B32145C223B0E151F22302C132E2A0A0539333E3722($adminid, $amount, $add_sub)
    {
        global $intro;
        $adminid = intval($adminid);
        $intro->db->query('UPDATE ' . PREFIX . ('_admin set balance=balance' . $add_sub . $amount . ' WHERE adminid=' . $adminid . ';'));
    }
    function _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($adminid)
    {
        global $intro;
        $adminid = intval($adminid);
        $sql = $intro->db->query('SELECT sum(credit-depit) as bal FROM ' . PREFIX . ('_trans where admin=' . $adminid . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $bal = floatval($row['bal']);
        return $bal;
    }
    function _obf_0D1A103E0E3F192D062A303301251B141F191A0D390432($adminid)
    {
        global $intro;
        $adminid = intval($adminid);
        $bal = _obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901($adminid);
        $intro->db->query('UPDATE ' . PREFIX . '_admin set balance=' . floatval($bal) . (' WHERE adminid=' . $adminid . ';'));
    }
    function _obf_0D3F5B193D1C173D1A38222C36313C19262B1734343932($id, $calc_expire = '', $old_date = 0, $OverPackages = '')
    {
        global $intro;
        global $error;
        $id = intval($id);
        $result = $intro->db->query('SELECT * from packages where id=' . $id . ' ');
        $row = $intro->db->fetch_assoc($result);
        if( !$row ) 
        {
            return [];
        }
        if( strlen($OverPackages) > 10 ) 
        {
            $json = json_decode($OverPackages, true);
            if( isset($json[$id]['official_credits']) && floatval($json[$id]['official_credits']) > 0 ) 
            {
                $row['official_credits'] = floatval($json[$id]['official_credits']);
            }
        }
        $is_trial = $row['is_trial'];
        $trial_credits = $row['trial_credits'];
        $trial_duration = $row['trial_duration'];
        $trial_duration_in = $row['trial_duration_in'];
        $is_official = $row['is_official'];
        $official_credits = $row['official_credits'];
        $official_duration = $row['official_duration'];
        $official_duration_in = $row['official_duration_in'];
        $row['exp_date'] = null;
        $row['duration'] = null;
        $row['duration_in'] = null;
        $row['new_expire_date'] = 0;
        if( $is_trial == 1 ) 
        {
            $row['exp_date'] = strtotime('+' . $row['trial_duration'] . ' ' . $row['trial_duration_in']);
            $row['inv_notes'] = $row['trial_duration'] . ' ' . $row['trial_duration_in'];
            $row['duration'] = $row['trial_duration'];
            $row['duration_in'] = $row['trial_duration_in'];
        }
        if( $is_official == 1 ) 
        {
            $row['exp_date'] = strtotime('+' . $row['official_duration'] . ' ' . $row['official_duration_in']);
            $row['inv_notes'] = $row['official_duration'] . ' ' . $row['official_duration_in'];
            $row['duration'] = $row['official_duration'];
            $row['duration_in'] = $row['official_duration_in'];
        }
        $row['exp_date_mysql'] = date('Y-m-d H:i:s', $row['exp_date']);
        $row['output_formats_array'] = json_decode($row['output_formats'], true);
        if( $calc_expire == 'calc_expire' ) 
        {
            if( $old_date <= time() ) 
            {
                $old_date = time();
            }
            $row['new_expire_date'] = strtotime(date('Y-m-d H:i:s', $old_date) . (' +' . $row['duration'] . ' ' . $row['duration_in']));
            $row['exp_date_mysql'] = date('Y-m-d H:i:s', $row['new_expire_date']);
        }
        return $row;
    }
    function bouquets($bouquets = [], $view = '', $resellers_control_order = true)
    {
        global $intro;
        global $error;
        $html = $qry = $msg = '';
        $i = 0;
        $adm = $intro->auth->sess_admin();
        if( isset($intro->option['BouquetsOrder']) && $intro->option['BouquetsOrder'] != '' ) 
        {
            $order = str_replace(':', ' ', $intro->option['BouquetsOrder']);
        }
        else
        {
            $order = 'id ASC';
        }
        if( $view != 'all' ) 
        {
            if( !in_array($adm['level'], [
                1, 
                9
            ]) ) 
            {
                $bq = $adm['resel_bouquets'];
                if( $bq == '' ) 
                {
                    $bq = (is_array($bouquets) ? implode(',', $bouquets) : '');
                }
                if( $bq == '' ) 
                {
                    $msg = '<h3 style=\'color:red\'>Contact Admin to Fix bouquets for you.</h3>';
                    $qry = ' AND `id` IN (1500000) ';
                    if( isset($intro->code_pkg) && $intro->code_pkg > 0 ) 
                    {
                        $msg = '';
                        $pkg = $intro->code_pkg;
                        $sql = $intro->db->query('SELECT * from packages where id=' . $pkg . ';');
                        $r = $intro->db->fetch_assoc($sql);
                        $bq = json_decode($r['bouquets'], true);
                        $qry = ' AND `id` IN (' . implode(',', $bq) . ') ';
                    }
                }
                else
                {
                    $qry = ' AND `id` IN (' . $bq . ') ';
                }
                if( isset($intro->code_pkg) && $intro->code_pkg > 0 ) 
                {
                    $msg = '';
                    $pkg = $intro->code_pkg;
                    $sql = $intro->db->query('SELECT * from packages where id=' . $pkg . ';');
                    $r = $intro->db->fetch_assoc($sql);
                    $bq = json_decode($r['bouquets'], true);
                    $qry = ' AND `id` IN (' . implode(',', $bq) . ') ';
                }
                if( $intro->member_group_id > 0 && $intro->code_pkg == 0 ) 
                {
                    $msg = '';
                    $qry = '  ';
                    $resellers_control_order = false;
                }
            }
            if( isset($intro->option['forceAdminUseBouquets']) && $intro->option['forceAdminUseBouquets'] == 1 ) 
            {
                $bq = $adm['resel_bouquets'];
                if( $bq == '' ) 
                {
                    $msg = '<h3 style=\'color:red\'>Please edit your reseller username and add bouquets for you.</h3>';
                    $qry = ' AND `id` IN (1500000) ';
                }
                else
                {
                    $qry = ' AND `id` IN (' . $bq . ') ';
                }
            }
        }
        $html = $msg . '<table id=\'UsersBouquets\'><tbody>';
        if( is_array($bouquets) && count($bouquets) && $resellers_control_order ) 
        {
            if( $bouquets[0] == '' ) 
            {
                $order = 'ORDER BY  ' . $order . ' ';
            }
            else
            {
                $x = [];
                foreach( $bouquets as $s ) 
                {
                    $x[] = 'id=\'' . $s . '\' DESC';
                }
                $order = 'ORDER BY  ' . implode(',', $x) . (', ' . $order);
            }
        }
        else
        {
            $order = 'order by ' . $order;
        }
        $sql = $intro->db->query('SELECT * FROM bouquets WHERE bouquet_status=1 ' . $qry . ' ' . $order);
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($row);
            $i++;
            $html .= ("\n\t\t<tr> \n\t\t\t<td>" . (($adm['level'] == 1 ? '[' . $id . ']' : '')) . " </td>\n\t\t\t<td>\n\t\t\t<input \n\t\t\t\t" . (($i == 1 ? 'class=\'BQfirsOne\'' : 'class=\'BQother\'')) . ("\n\t\t\t\ttype=\"checkbox\" value=\"" . $id . "\" name=\"bouquets[]\"\n\t\t\t\t") . ((is_array($bouquets) && in_array($id, $bouquets) ? 'checked' : '')) . (' /> ' . $bouquet_name . "\n\t\t\t</td>\n\t\t</tr>"));
        }
        $html .= '</tbody></table>';
        return $html;
    }
    function random_number($length)
    {
        if( $length == '' ) 
        {
            $length = 12;
        }
        $random = substr(number_format(time() * rand(), 0, '', ''), 0, $length);
        return $random;
    }
    function getUserIP()
    {
        if( !empty($_SERVER['HTTP_CLIENT_IP']) ) 
        {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        else if( !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ) 
        {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        else
        {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }
    function _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222($app, $act, $the_log, $admin = '')
    {
        global $intro;
        global $error;
        $data_log = '';
        if( $admin == '' ) 
        {
            $sess_admin = $intro->auth->sess_admin();
            $admin = $sess_admin['admin_name'];
        }
        $ip = getUserIP();
        if( is_array($the_log) ) 
        {
            foreach( $the_log as $key => $val ) 
            {
                $data_log .= ($key . ' = ' . $val . "\n");
            }
        }
        else
        {
            $data_log = $the_log;
        }
        $data['dtime'] = date('Y-m-d H:i:s');
        $data['admin_user'] = $admin;
        $data['app'] = $app;
        $data['ip'] = $ip;
        $data['action'] = $act;
        $data['the_log'] = $data_log;
        $intro->db->insert(PREFIX . '_logs_sys', $data);
    }
    function _obf_0D162C393D0808073D1A062223322C0919102C28242A11($str, $reg = '')
    {
        $ar = 'اأإء-ي';
        if( $reg != '' ) 
        {
            $reg = str_replace('{ar}', $ar, $reg);
        }
        return preg_replace('/[^a-zA-Z0-9' . $reg . ']/ui', '', $str);
    }
    function _obf_0D1E12391F102F2E2A3E23330537315C320C3910402322($period, $free_days = 0)
    {
        global $intro;
        global $array;
        if( $period == -1 ) 
        {
            return null;
        }
        if( isset($intro->option['day1_period']) && intval($intro->option['day1_period']) > 0 && $period == 101 ) 
        {
            $per = intval($intro->option['day1_period']);
            return strtotime('+' . $per . ' hours');
        }
        if( in_array($period, $array['free']) ) 
        {
            $dd = $period - 100;
            $exp_date = strtotime('+' . $dd . ' days');
        }
        else
        {
            $exp_date = strtotime('+' . $period . ' month');
            if( $free_days > 0 ) 
            {
                $exp_date = strtotime('+' . $free_days . ' days', $exp_date);
            }
        }
        return $exp_date;
    }
    function tooltip($arr_name, $index)
    {
        global $array;
        return "\n\t\t<span class=\"d-inline-block\" tabindex=\"0\" data-toggle=\"tooltip\" title=\"" . $array[$arr_name][$index] . "\" style='color:blue;'>\n\t\t\t<span class=\"glyphicon glyphicon-question-sign\" aria-hidden=\"true\"></span>\n\t\t</span>";
    }
    function _obf_0D12262623113F1D022A011A3E1D1B253D294027090E01($htmlname, $comp)
    {
        global $intro;
        $result = $intro->db->query('SELECT * FROM `streaming_servers` WHERE `status`=1 ORDER BY id ASC');
        $html = '<select name="' . $htmlname . '" id="' . $htmlname . '" class=\'searchable chosen\'>';
        $html .= '<option value="">-</option>';
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $html .= ('<option value="' . $id . '" ' . (($id == $comp ? 'selected="selected"' : '')) . ('>' . $server_name . '</option>'));
        }
        $html .= ('<option value="remote" ' . (($comp == 'remote' ? 'selected="selected"' : '')) . '>Remote in other server</option>');
        $html .= '</select>';
        return $html;
    }
    function _obf_0D1E2701171B3D1C36152B2D2512305C1003175B1E3E11($stream_source, $stream_id)
    {
        global $intro;
        $stream_id = intval($stream_id);
        $load_balancer_servers = [];
        $sql = $intro->db->query('SELECT * FROM `streams_sys` WHERE `stream_id`=' . $stream_id);
        if( $intro->db->returned_rows > 0 ) 
        {
            while( $row = $intro->db->fetch_assoc($sql) ) 
            {
                $load_balancer_servers[] = intval($row['server_id']);
            }
        }
        $stream_source = json_decode($stream_source, true);
        if( is_array($stream_source) && count($stream_source) == 1 ) 
        {
            if( strpos($stream_source[0], 'http') === 0 ) 
            {
                $stream_source = $stream_source[0];
                $movie_location = 'remote';
            }
            else
            {
                $x = explode(':', $stream_source[0]);
                if( count($x) == 1 ) 
                {
                    $stream_source = $stream_source[0];
                    $movie_location = 'remote';
                }
                else if( count($x) > 1 ) 
                {
                    $movie_location = $x[1];
                    $stream_source = $x[2];
                }
            }
        }
        return [
            'movie_location' => $movie_location, 
            'stream_source' => $stream_source, 
            'load_balancer_servers' => $load_balancer_servers
        ];
    }
    function _obf_0D3015381834391534383C26052A360C113F3E3D383B32($vars = [])
    {
        global $intro;
        $server_id = intval($vars['server_id']);
        $sql = $intro->db->query('SELECT server_ip,http_broadcast_port FROM `streaming_servers` WHERE id=' . $server_id . ';');
        $row = $intro->db->fetch_assoc($sql);
        $cmd = '';
        $cmd_data = [];
        $cmd_data['password'] = urlencode(_obf_0D16342C3B25040E30351911133C313C1B1D23050B1B11('live_streaming_pass'));
        if( $vars['for'] == 'viewDir' ) 
        {
            $cmd_data['action'] = 'viewDir';
            $cmd_data['dir'] = trim($vars['dir']);
        }
        if( $vars['for'] == 'fp' ) 
        {
            $cmd_data['action'] = 'signal_send';
            foreach( $vars['fp_array'] as $key => $val ) 
            {
                $cmd_data[$key] = $val;
            }
        }
        if( $vars['for'] == 'reload_epg' ) 
        {
            $cmd_data['action'] = 'reload_epg';
        }
        if( $vars['for'] == 'vod' || $vars['for'] == 'stream' ) 
        {
            if( !is_array($vars['stream_ids']) ) 
            {
                $vars['stream_ids'] = [$vars['stream_ids']];
            }
            $cmd_data['action'] = $vars['for'];
            $cmd_data['function'] = $vars['function'];
            $cmd_data['stream_ids'] = $vars['stream_ids'];
        }
        if( $vars['for'] == 'XXXstreamXX' ) 
        {
            if( !is_array($vars['stream_ids']) ) 
            {
                $vars['stream_ids'] = [$vars['stream_ids']];
            }
            if( isset($intro->option['iptv_api_url']) && $intro->option['iptv_api_url'] != '' ) 
            {
                $url = parse_url($intro->option['iptv_api_url']);
                if( isset($url['path']) && $url['path'] != '' ) 
                {
                    $api = str_replace('/', '', $url['path']);
                }
                else
                {
                    $api = 'api.php';
                }
            }
            else
            {
                $api = 'api.php';
            }
            $cmd = 'http://' . $row['server_ip'] . ':' . $row['http_broadcast_port'] . '/system_api.php?password=' . urlencode(_obf_0D16342C3B25040E30351911133C313C1B1D23050B1B11('live_streaming_pass')) . ('&action=' . $vars['for'] . '&function=' . $vars['function'] . '&') . http_build_query(['stream_ids' => $vars['stream_ids']]);
        }
        if( $vars['for'] == 'view_log' ) 
        {
            $cmd = 'http://' . $row['server_ip'] . ':' . $row['http_broadcast_port'] . '/system_api.php?password=' . urlencode(_obf_0D16342C3B25040E30351911133C313C1B1D23050B1B11('live_streaming_pass')) . ('&action=view_log&stream_id=' . $vars['stream_ids']);
        }
        if( $vars['for'] == 'stats' ) 
        {
            $cmd_data['action'] = 'stats';
        }
        if( $vars['for'] == 'BackgroundCLI' ) 
        {
            $cmd_data['action'] = 'BackgroundCLI';
            $cmd_data['cmds'] = [$vars['command']];
        }
        if( $vars['for'] == 'runCMD' ) 
        {
            $cmd_data['action'] = 'runCMD';
            $cmd_data['command'] = $vars['command'];
        }
        if( $vars['for'] == 'del_vod' ) 
        {
            $command = 'rm -f ' . XC_DIR . 'movies/' . $vars['stream_ids'] . '.*';
            $cmd_data['action'] = 'runCMD';
            $cmd_data['command'] = $command;
        }
        $main_url = _obf_0D3F5B5B312E2F352234142C1C1F3C1B0C06231A292732('cmd');
        $cmd_url = 'http://' . $row['server_ip'] . ':' . $row['http_broadcast_port'] . '/system_api.php';
        $post_data = [
            'cmd_url' => base64_encode($cmd_url), 
            'cmd_data' => base64_encode(json_encode($cmd_data))
        ];
        $context = [
            'http' => [
                'method' => 'POST', 
                'header' => 'Content-type: application/x-www-form-urlencoded', 
                'timeout' => 5, 
                'content' => http_build_query($post_data)
            ]
        ];
        $data = file_get_contents($main_url, false, stream_context_create($context));
        $error = error_get_last();
        if( isset($error['message']) && $error['message'] != '' ) 
        {
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('remote-cmd', 'cmd-error', $error['message'] . ('<br/> ' . $main_url), '');
            return 'err:sys:log';
        }
        if( $vars['for'] == 'reload_epg' ) 
        {
            return 'success';
        }
        if( $vars['for'] == 'runCMD' ) 
        {
            return '[]';
        }
        if( $data == '' ) 
        {
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('api-conn', 'failed-' . $vars['for'], 'null reply', '');
            return 'err:null:reply';
        }
        if( $data != '' ) 
        {
            $json = json_decode($data, true);
            if( isset($json['result']) && $json['result'] ) 
            {
                return 'success';
            }
            else
            {
                return $data;
            }
        }
        else
        {
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('api-conn', 'failed-' . $vars['for'], 'reply = ' . $data, '');
            return 'failed';
        }
        return 'unknow:err';
    }
    function _obf_0D01250828283822072939021F5B09051E1F2B2A073411($stream_id, $row)
    {
        global $intro;
        $stream_id = intval($stream_id);
        $server_id = intval($row['server_id']);
        if( !isset($row['pid']) ) 
        {
            $row['pid'] = 0;
        }
        if( !isset($row['to_analyze']) ) 
        {
            $row['to_analyze'] = 0;
        }
        if( !isset($row['stream_status']) ) 
        {
            $row['stream_status'] = 0;
        }
        if( intval($row['direct_source']) == 1 ) 
        {
            return '<span class="label label-default">Direct</span>';
        }
        $stream_status = intval($row['stream_status']);
        $to_analyze = intval($row['to_analyze']);
        $pid = intval($row['pid']);
        if( $server_id == 0 ) 
        {
            return '<span class="label label-danger">Missing Server</span>';
        }
        $url_start = $intro->app_url('movies', 'start') . ('?NH=1&id=' . $stream_id . '&server=' . $server_id . '&act=start');
        $start = '<a href="' . $url_start . '" data-id="vod_' . $stream_id . '" class="triggerEncode btn btn-info btn-xs" OnCLick="return false;">Start Encode</a>';
        $re_encode = '<a href="' . $url_start . '" data-id="vod_' . $stream_id . '" class="triggerEncode btn btn-info btn-xs" OnCLick="return false;" title="Re-encode"><i class=\'icon-cw\'></i></a>';
        $stop = '<a href="' . $intro->app_url('movies', 'start') . ('?NH=1&id=' . $stream_id . '&server=' . $server_id . '&act=stop" data-id="vod_' . $stream_id . '" class="triggerEncode btn btn-default btn-xs" OnCLick="return false;"><i class="icon-cancel-circled2"></i></a>');
        if( $stream_status == 1 ) 
        {
            return '<span class="label label-danger">Bad Vod</span>' . $start;
        }
        if( $pid <= 0 && $stream_status != 1 ) 
        {
            return $start;
        }
        if( $pid > 0 && $to_analyze == 0 && $stream_status != 1 ) 
        {
            return '<span class="btn btn-success icon-thumbs-up-alt" title="vod is encoded and ready"> </span> ' . $re_encode;
        }
        if( $pid > 0 && $row['to_analyze'] == 1 && $stream_status != 1 ) 
        {
            return '<span class="label label-warning">Encoding...</span> ' . $stop;
        }
        return 'UNKNOWN';
    }
    function _obf_0D152E0528111E401A021F33243837101D0A2D23141711($t, $stream_id, $server_id, $direct_source)
    {
        global $intro;
        if( $t == 'add' && $direct_source == 1 ) 
        {
            return null;
        }
        if( $t == 'edit' && $direct_source == 1 ) 
        {
            $intro->db->query('DELETE FROM streams_sys WHERE stream_id=' . $stream_id);
        }
        else
        {
            $stream_id = intval($stream_id);
            $server_id = intval($server_id);
            if( $server_id == 0 ) 
            {
                return null;
            }
            $sql = $intro->db->query('SELECT server_stream_id,server_id FROM `streams_sys` WHERE stream_id=' . $stream_id . ';');
            if( $intro->db->returned_rows == 0 ) 
            {
                $data2 = [];
                $data2['server_id'] = $server_id;
                $data2['stream_id'] = $stream_id;
                $data2['on_demand'] = 0;
                $intro->db->insert('streams_sys', $data2);
            }
            if( $intro->db->returned_rows == 1 ) 
            {
                $intro->db->query('update streams_sys set server_id=' . $server_id . ' where stream_id=' . $stream_id);
            }
            if( $intro->db->returned_rows > 1 ) 
            {
                $intro->db->query('DELETE FROM streams_sys WHERE stream_id=' . $stream_id);
            }
            if( (intval($intro->input->post('reEncode')) == 1 || $t == 'add') && $stream_id > 0 && $server_id > 0 ) 
            {
                $x = new XtreamApi('EmptyFunc');
                $x->StartVod('start', $stream_id, $server_id);
            }
        }
    }
    function _obf_0D131A5B0C3F26380F370F1A2B22021B0F1B1C3B112232()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $sql = $intro->db->query('SELECT adminid FROM ' . PREFIX . '_admin ');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $intro->db->query_fast('UPDATE ' . PREFIX . '_admin set balance=' . floatval(_obf_0D3B1A30163C23381912245B381E2D3F0B0B340C070901(intval($row['adminid']))) . ' WHERE adminid=' . intval($row['adminid']) . ';');
        }
    }
    function _obf_0D32120E092719172E3B07383704171F252C3C5B172C22()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $intro->db->query('UPDATE ' . PREFIX . '_admin SET main_father=0;');
        $sql = $intro->db->query('SELECT adminid,member_group_id,logo FROM ' . PREFIX . '_admin WHERE father=0;');
        while( $r = $intro->db->fetch_assoc($sql) ) 
        {
            $main_father = $r['adminid'];
            $sql2 = $intro->db->query('SELECT adminid FROM ' . PREFIX . ('_admin WHERE father=' . $r['adminid'] . ';'));
            if( $intro->db->returned_rows > 0 ) 
            {
                while( $r2 = $intro->db->fetch_assoc($sql2) ) 
                {
                    $data = [];
                    $data['main_father'] = $main_father;
                    $data['logo'] = $r['logo'];
                    if( $r['member_group_id'] > 0 ) 
                    {
                        $data['level'] = 6;
                    }
                    $intro->db->update(PREFIX . '_admin', $data, 'adminid=\'' . $r2['adminid'] . '\'');
                    $sql3 = $intro->db->query('SELECT adminid FROM ' . PREFIX . ('_admin WHERE father=' . $r2['adminid'] . ';'));
                    while( $r3 = $intro->db->fetch_assoc($sql3) ) 
                    {
                        $data = [];
                        $data['main_father'] = $main_father;
                        $data['logo'] = $r['logo'];
                        if( $r['member_group_id'] > 0 ) 
                        {
                            $data['level'] = 7;
                        }
                        $intro->db->update(PREFIX . '_admin', $data, 'adminid=\'' . $r3['adminid'] . '\'');
                        $sql4 = $intro->db->query('SELECT adminid,admin_name FROM ' . PREFIX . ('_admin WHERE father=' . $r3['adminid'] . ';'));
                        if( $r4 = $intro->db->fetch_assoc($sql4) ) 
                        {
                            $data = [];
                            $data['main_father'] = $main_father;
                            $data['logo'] = $r['logo'];
                            if( $r['member_group_id'] > 0 ) 
                            {
                                $data['level'] = 7;
                            }
                            $intro->db->update(PREFIX . '_admin', $data, 'adminid=\'' . $r4['adminid'] . '\'');
                            exit( '<h1 style=\'color:red\'>Danger: Level 4 detected. ' . (' (id={' . $r4['adminid'] . '} | name=' . $r4['admin_name'] . ') please contact us.</h1>') );
                        }
                    }
                }
            }
        }
    }

}
