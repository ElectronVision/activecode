<?php 
class Admin_Menu_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        $intro->db->halt_on_errors = false;
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\"></icon>Admin menu </a> \r\n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . "/Form?t=add\"><icon class=\"icon-plus-squared\"></icon>Add New menu</a>  \t\t \t\t \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $this->nav();
        $rows_per_page = 100;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT *  from member_groups order by group_id  limit ' . $nexlimit . ',' . $rows_per_page);
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT group_id from member_groups order by group_id ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i>Menu  (' . $totalrows . ')', 'info');
        echo "<form method=\"POST\"   id='drag' enctype=\"multipart/form-data\">\r\n\t\t<div class=\"\">\r\n\t\t\t<table class=\"table table-bordered \"  id=\"table_codes\" >\r\n\t\t\t\t <thead>\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t<th >group_id </th>\r\n\t\t\t\t\t\t\t<th>group_ name</th>\r\n\t\t\t\t\t\t\t<th></th>\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t</thead>\r\n\t\t\t\t<tbody>";
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            @extract($row);
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>" . $group_id . "</td>\r\n\t\t\t\t<td>" . $group_name . "</td>\r\n\t\t\t\t\t<td class=\"center\">\r\n\t\t\t\t\t<a class=\"btn_s btn-info  \" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $group_id . '" title="' . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn_s  btn-danger  p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $group_id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t\t\r\n\t\t\t</tr>\r\n\t\t\t";
        }
        echo '</table> </div>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</center>';
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $group_name;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $IF = intval($intro->input->get_post('IF'));
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $viw_selcted_menu = '';
        if( $IF != 1 ) 
        {
            $this->nav();
        }
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM member_groups where group_id=\'' . $id . '\'');
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = ' Edit Menu <b>' . $group_id . '</b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = 'Save Changes';
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $menu_links_edit = [];
            echo $allowed_pages;
            foreach( $array['menu'][$group_name] as $key => $val ) 
            {
                $menu_links_edit[$key] = $key;
            }
            $viw_selcted_menu = _obf_0D042827394002382E07271E152934171C2F1B331B0C11('options[]', $menu_links_edit, json_decode($allowed_pages), $txt = '', $first_value = 0, $height = '');
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add New Menu';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = 'Add New';
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        $sql2 = $intro->db->query('SELECT * FROM member_groups ');
        $old_menu = [];
        while( $row2 = $intro->db->fetch_assoc($sql2) ) 
        {
            $old_menu[] = $row2['group_name'];
        }
        $menu_links = [];
        foreach( $array['menu'] as $key => $val ) 
        {
            if( !in_array($key, $old_menu) ) 
            {
                $menu_links[$key] = $key;
            }
        }
        echo '<form method="POST"   action="' . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<div class=\"table-responsive\">\r\n\t\t\t<table class=\"table table-hover table-bordered\">\r\n\t\t\t\t<tbody>\r\n\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t<td>Menu Name </td>\r\n\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('menu_links', $menu_links, $group_name) . ("\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t</td>\r\n\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t<td>Menu Name </td>\r\n\t\t\t\t\t\t<td id='view_submen'>\r\n\t\t\t\t\t\t" . $viw_selcted_menu . "\r\n\t\t\t\t\t\t</td>\r\n\t\t\t\t\t</tr>\r\n\t\t\t\t\t\r\n\t\t\t\t\t\r\n\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t<td> </td>\r\n\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t\t\t\t<input type=\"hidden\" name=\"IF\"  value=\"" . $IF . "\">\r\n\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success\">\r\n\t\t\t\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t\t\t\t</button>\t\t\t\t\t\r\n\t\t\t\t\t\t</td>\r\n\t\t\t\t\t</tr>\r\n\t\t\r\n\t\r\n\t\t\t\r\n\t\t\t\t\t\r\n\t\t\t\t</tbody>\t\r\n\t\t\t\t</table>\t\r\n\t\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "\t\t<script>\r\n\t\t\$(document).ready(function() {\r\n\t\t\t\t\$( \"#menu_links\" ).change(function() {\r\n\t\t\t\t\tvar optionval =\$(this).val();\r\n\t\t\t\t\t\$('#view_submen').html(optionval);\r\n\t\t\t\t\t\r\n\t\t\t\t\t \$.ajax({\r\n                       type: \"GET\",\r\n                       url: '";
        echo $this->base . '/view_sub_menu?NH=1&id=';
        echo "'+ optionval,\r\n\t\t\t\t\t\tsuccess: function(result){\r\n                         \$(\"#view_submen\").html(result);\r\n                       }\r\n                     });\r\n\t\t\t\t});\r\n\t\t\r\n\t\t\r\n\t\t});\r\n\t\t</script>\r\n\t\t";
    }
    public function view_sub_menu()
    {
        global $intro;
        global $error;
        global $array;
        $menu_links = [];
        $id = $intro->input->get('id');
        foreach( $array['menu'][$id] as $key => $val ) 
        {
            $menu_links[$key] = $key;
        }
        $x = _obf_0D042827394002382E07271E152934171C2F1B331B0C11('options[]', $menu_links, 0, $txt = '', $first_value = 0, $height = '');
        echo $x;
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        global $array;
        $menu_links = $intro->input->post('menu_links');
        $options = $intro->input->post('options');
        $data['group_name'] = $menu_links;
        $data['allowed_pages'] = json_encode($options);
        $data['is_reseller'] = 1;
        $intro->db->insert('member_groups', $data);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        global $error;
        global $bouquet_channels;
        $id = intval($intro->input->post('id'));
        $menu_links = $intro->input->post('menu_links');
        $options = $intro->input->post('options');
        $data['group_name'] = $menu_links;
        $data['allowed_pages'] = json_encode($options);
        $data['is_reseller'] = 1;
        $intro->db->update('member_groups', $data, 'group_id=' . $id);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('DELETE FROM member_groups WHERE group_id=' . $id . ' ');
        $intro->redirect($this->appname);
    }
}
