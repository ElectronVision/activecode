<?php 
class XtreamApi
{
    public $error = '';
    public $success = false;
    public $xtream_api_url = '';
    public $xtream_api_pass = '';
    public $post_data = [];
    public function __construct($mode, $data = [])
    {
        global $intro;
        $this->post_data = $data;
        $this->post_data['api_pass'] = $this->xtream_api_pass = _obf_0D3015381834391534383C26052A360C113F3E3D383B32('api_pass');
        $this->xtream_api_url = _obf_0D3F5B5B312E2F352234142C1C1F3C1B0C06231A292732('api');
        $this->$mode();
    }
    public function EmptyFunc()
    {
    }
    public function Start($streams)
    {
        return $this->StopOrStart($streams, 'start');
    }
    public function Stop($streams, $mode = 'stop')
    {
        return $this->StopOrStart($streams, $mode);
    }
    public function StopOrStart($streams, $mode = 'stop')
    {
        global $intro;
        global $sess_admin;
        $sysResult = '';
        $date = date('Y-m-d H:i:s');
        if( is_array($streams) ) 
        {
            $qry = ' IN (' . implode(',', $streams) . ')';
        }
        else
        {
            $qry = ' =' . $streams;
        }
        $ar = [];
        $result = $intro->db->query_fast('SELECT server_id,stream_id FROM `streams_sys` WHERE stream_id ' . $qry . ';');
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            $ar[$myrow['server_id']] = $myrow['stream_id'];
        }
        $res = '';
        foreach( $ar as $serv => $strm ) 
        {
            $res = _obf_0D3015381834391534383C26052A360C113F3E3D383B32([
                'for' => 'stream', 
                'server_id' => $serv, 
                'function' => $mode, 
                'stream_ids' => $strm
            ]);
        }
        return $res;
    }
    public function Restart($streams)
    {
        global $intro;
        global $sess_admin;
        $date = date('Y-m-d H:i:s');
        $this->StopOrStart($streams, 'stop');
        sleep(1);
        return $this->StopOrStart($streams, 'start');
    }
    public function DelVod($stream_id)
    {
        global $intro;
        global $sess_admin;
        $stream_id = intval($stream_id);
        $rep = '';
        $result = $intro->db->query('SELECT server_id FROM `streams_sys` WHERE stream_id=' . $stream_id . ';');
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            $rep = _obf_0D3015381834391534383C26052A360C113F3E3D383B32([
                'for' => 'del_vod', 
                'server_id' => $myrow['server_id'], 
                'stream_ids' => $stream_id
            ]);
        }
        return $rep;
    }
    public function VodMulti($start_stop, $ids)
    {
        global $intro;
        global $sess_admin;
        $rep = '';
        $result = $intro->db->query('SELECT server_id,stream_id FROM `streams_sys` WHERE stream_id IN (' . implode(',', $ids) . ');');
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            $rep = _obf_0D3015381834391534383C26052A360C113F3E3D383B32([
                'for' => 'vod', 
                'function' => (string)$start_stop, 
                'server_id' => $myrow['server_id'], 
                'stream_ids' => $myrow['stream_id']
            ]);
        }
        return $rep;
    }
    public function StartVod($start_stop, $streams, $servers)
    {
        global $intro;
        global $sess_admin;
        return _obf_0D3015381834391534383C26052A360C113F3E3D383B32([
            'for' => 'vod', 
            'server_id' => $servers, 
            'function' => (string)$start_stop, 
            'stream_ids' => $streams
        ]);
    }
    public function Created($stream_id, $urls)
    {
        global $intro;
        global $sess_admin;
        $data = $rep = '';
        $urls = json_decode($urls, true);
        $data = [];
        foreach( $urls as $link ) 
        {
            if( strlen($link) > 5 ) 
            {
                $data[] = 'file \'' . preg_replace("/\r|\n/", '', $link) . '\'';
            }
        }
        $command = ' echo \'' . base64_encode(implode("\n", $data)) . '\' | base64 --decode > ' . XC_DIR . ('/created_channels/' . $stream_id . '_.list');
        $result = $intro->db->query('SELECT server_id FROM `streams_sys` WHERE stream_id=' . $stream_id . ';');
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            $rep = _obf_0D3015381834391534383C26052A360C113F3E3D383B32([
                'for' => 'runCMD', 
                'server_id' => $myrow['server_id'], 
                'command' => $command
            ]);
        }
        if( $rep == '[]' ) 
        {
            return 'success';
        }
        else
        {
            return 'faild:' . $rep;
        }
    }
    public function KillPids($server_id, $pids)
    {
        global $intro;
        global $sess_admin;
        $data = [];
        if( is_array($pids) ) 
        {
            foreach( $pids as $pid ) 
            {
                $data[] = 'kill -9 ' . $pid;
            }
        }
        else
        {
            $data[] = 'kill -9 ' . $pids;
        }
        $command = implode(' && ', $data);
        $rep = _obf_0D3015381834391534383C26052A360C113F3E3D383B32([
            'for' => 'runCMD', 
            'server_id' => $server_id, 
            'command' => $command
        ]);
        if( $rep == '[]' ) 
        {
            return 'success';
        }
        else
        {
            return 'faild:' . $rep;
        }
    }
}
