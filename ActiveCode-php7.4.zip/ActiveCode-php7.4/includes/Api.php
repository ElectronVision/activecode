<?php 
class Api
{
    public $channels = null;
    public $url = null;
    public $api_host = '';
    public $stream_host = '';
    public function __construct($row = [])
    {
        global $intro;
        $this->stream_host = $row['stream_host'];
        $this->api_host = $row['api_host'];
        $this->host = $row['sname'];
        if( $this->stream_host = '' ) 
        {
            return null;
        }
        if( $this->api_host = '' ) 
        {
            return null;
        }
        $this->url = 'http://' . $this->api_host;
    }
    public function test()
    {
        if( $this->stream_host = '' ) 
        {
            return null;
        }
        if( $this->api_host = '' ) 
        {
            return null;
        }
        $data = $this->intro_url($this->url . '?mode=test', $this->host, null);
        return $data;
    }
    public function get_channels()
    {
        $data = $this->intro_url($this->url . '?mode=channels', $this->host, null);
        $data = base64_decode($data);
        $data = $this->intro_xor($data);
        $data = json_decode($data, true);
        var_dump($data);
    }
    public function intro_url($url, $host, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'host' => $host, 
            'data' => $data
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
    public function intro_xor($InputString, $KeyPhrase = 9120589)
    {
        $retString = '';
        for( $j = 0; $j < strlen($InputString); $j++ ) 
        {
            $retString .= chr(ord(substr($InputString, $j, 1)) ^ $KeyPhrase);
        }
        return $retString;
    }
}
