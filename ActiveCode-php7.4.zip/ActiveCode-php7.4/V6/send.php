<?php
header('Content-Type: application/json');

function runXOR($InputString)
{
	$XorKey = "98676774";
	$KeyLength = strlen($XorKey);
	for( $i = 0; $i < strlen($InputString); $i++ ) 
	{
		$rPos = $i % $KeyLength;
		$r = ord($InputString[$i]) ^ ord($XorKey[$rPos]);
		$InputString[$i] = chr($r);
	}
	return $InputString;
}
	
function url_contents($url,$method="GET",$headers="",$postdata=[],$timeout=-1)
{
	if($timeout < 0) $timeout=ini_get('default_socket_timeout');
	$opts = ['method' => $method, 'header' => $headers, 'content' => http_build_query($postdata), 'timeout' => $timeout];
	return file_get_contents($url, false, stream_context_create(['http' =>$opts]));
}
	
$data_xor = base64_encode(runXOR('{"mode":"myRadio","code":"284743215232","mac":"02:00:00:00:11:27","sn":"02:00:00:00:11:27","chipid":"123123124","catid":"34","model":"Xiaomi Redmi Note 7","firmware_ver":"1.0.3"}'));

$result = url_contents("http://onyx8.ddns.net:8880/ONYX/V6/V6-Box.php","POST","Content-Type: multipart/form-data"."\r\n"."User-Agent: SolusTV",["json"=>$data_xor]);
echo runXOR($result);
?>