<?php 
echo '﻿';
class Comments_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $status = [
        '<span class=\'label label-default\'>UnPub.</span>', 
        '<span class=\'label label-success\'>Pub.</span>'
    ];
    public function __construct($appname, $base, $img_path = '')
    {
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        $intro->db->query('SELECT id from ' . PREFIX . '_comments where theStatus=1');
        $pub = $intro->db->returned_rows;
        $intro->db->query('SELECT id from ' . PREFIX . '_comments where theStatus=0');
        $unpub = $intro->db->returned_rows;
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . '/index"><icon class="icon-list"></icon>') . $intro->lang['comments_appname'] . "</a> \r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add"><icon class="icon-plus-squared"></icon>') . $intro->lang['comments_add'] . ("</a>  \t\t \t\t \r\n\t\t \r\n\t\t<a class=\"btn btn-success\" href=\"" . $this->base . '/index?theStatus=1"><icon class="icon-check"></icon>Published (' . $pub . ")</a>  \r\n\t\t<a class=\"btn btn-default\" href=\"" . $this->base . '/index?theStatus=0"><icon class="icon-check-empty"></icon>UnPublished (' . $unpub . ")</a> \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = '';
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $theStatus = trim($intro->input->get_post('theStatus'));
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry .= (' AND name  LIKE \'%' . $search_txt . '%\' ');
        }
        if( $theStatus == 0 || $theStatus == 1 ) 
        {
            $qry .= (' AND theStatus=' . intval($theStatus));
        }
        if( $order == '' ) 
        {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 30;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT *,(SELECT title from ' . PREFIX . '_movies mv WHERE mv.id=comm.movie_id) AS title_movie ' . ',(SELECT s_title  FROM ' . PREFIX . '_series se where se.sid=comm.series_id) AS title_series ' . ' from ' . PREFIX . ('_comments comm where true ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from ' . PREFIX . ('_comments where true ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> ' . $intro->lang['comments_cur'] . (' (' . $totalrows . ')'), 'info');
        echo "\r\n\t\t\r\n\t\t<fieldset>\r\n\t\t\t<form action=\"\" method=\"post\">\r\n\t\t\t\t<input type=\"text\" name=\"search_txt\" value=\"" . $search_txt . '" placeholder="' . $intro->lang['search_form'] . "\" size=\"20\">\r\n\t\t\t\t<input name=\"name\" value=\"" . $intro->lang['search'] . "\" type=\"submit\">\r\n\t\t\t</form>\r\n\t\t</fieldset>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . "</th>\r\n\t\t\t<th>Movie/Series </th>\r\n\t\t\t<th>" . $intro->lang['comments_dtime'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('dtime', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['comments_name'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('name', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['comments_comment'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('comment', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['comments_ip'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('ip', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['comments_theStatus'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('theStatus', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['comments_rating_number'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('rating_number', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            list($date, $time) = explode(' ', $dtime);
            if( $movie_id > 0 ) 
            {
                $title = 'Movie: <a href="' . $intro->app_url('movies', 'Form?t=edit&id=' . $movie_id) . ('" target="_blank">' . $title_movie . '</a>');
            }
            if( $series_id > 0 ) 
            {
                $title = 'Series: <a href="' . $intro->app_url('series', 'Form?t=edit&sid=' . $series_id) . ('" target="_blank">' . $title_series . '</a>');
            }
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td>" . $title . "</td>\r\n\t\t\t\t<td>" . $date . "</td>\r\n\t\t\t\t<td>" . $name . "</td>\r\n\t\t\t\t<td>" . $comment . "</td>\r\n\t\t\t\t<td><a href=\"https://www.ip-tracker.org/locator/ip-lookup.php?ip=" . $ip . '" target=\'_blank\'>' . $ip . "</a></td>\r\n\t\t\t\t<td>") . $this->status[$theStatus] . "</td>\r\n\t\t\t\t<td class='text-center'><img src='" . admin_path . ('style/img/star_' . $rating_number . '.png\'> ' . $rating_number . "</td>\r\n\t\t\t\t<td class=\"center\">");
            if( $theStatus == 0 ) 
            {
                echo '<a class="btn btn-success p_edit" href="' . $this->base . '/Active?id=' . $id . '" title="Publish"><i class="icon-check"></i></a>';
            }
            echo "\r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="' . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>\r\n\t\t</div>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?search_txt=' . $search_txt . '&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</div>');
    }
    public function multiDel()
    {
        global $intro;
        global $error;
        global $sess_admin;
        $selected_fld = $_POST['selected_fld'];
        $count = count($selected_fld);
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        for( $i = 0; $i < $count; $i++ ) 
        {
            $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_comments WHERE id=\'' . $selected_fld[$i] . '\' '));
        }
        $intro->redirect($this->appname);
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $dtime;
        global $name;
        global $comment;
        global $ip;
        global $theStatus;
        global $rating_number;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_comments WHERE id=' . $id . ';'));
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = $intro->lang['comments_edit'] . (' <b>' . $id . '</b>');
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = $intro->lang['comments_add'];
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['comments_dtime'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"dtime\" value=\"" . $dtime . '" size="30"> ' . $this->error('dtime') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['comments_name'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"name\" value=\"" . $name . '" size="30"> ' . $this->error('name') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['comments_comment'] . (" : </td>\r\n\t\t\t<td><textarea name=\"comment\" cols=\"60\" rows=\"10\">" . $comment . '</textarea>' . $this->error('comment') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['comments_ip'] . (" : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"ip\" value=\"" . $ip . '" size="30"> ' . $this->error('ip') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['comments_theStatus'] . " : </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('theStatus', $theStatus) . (' ' . $this->error('theStatus') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['comments_rating_number'] . (" : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"rating_number\" value=\"" . $rating_number . '" size="30"> ' . $this->error('rating_number') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</div>\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $dtime = trim($intro->input->post('dtime'));
        $name = trim($intro->input->post('name'));
        $comment = trim($intro->input->post('comment'));
        $ip = trim($intro->input->post('ip'));
        $theStatus = intval($intro->input->post('theStatus'));
        $rating_number = intval($intro->input->post('rating_number'));
        if( $dtime == '' || $name == '' ) 
        {
            if( $dtime == '' ) 
            {
                $error['dtime'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $name == '' ) 
            {
                $error['name'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data['dtime'] = $dtime;
        $data['name'] = $name;
        $data['comment'] = addslashes(comment);
        $data['ip'] = $ip;
        $data['theStatus'] = $theStatus;
        $data['rating_number'] = $rating_number;
        $intro->db->insert(PREFIX . '_comments', $data);
        $id = $intro->db->insert_id();
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $dtime = trim($intro->input->post('dtime'));
        $name = trim($intro->input->post('name'));
        $comment = trim($intro->input->post('comment'));
        $ip = trim($intro->input->post('ip'));
        $theStatus = intval($intro->input->post('theStatus'));
        $rating_number = intval($intro->input->post('rating_number'));
        $data['dtime'] = $dtime;
        $data['name'] = $name;
        $data['comment'] = addslashes(comment);
        $data['ip'] = $ip;
        $data['theStatus'] = $theStatus;
        $data['rating_number'] = $rating_number;
        $id = intval($intro->input->post('id'));
        $intro->db->update(PREFIX . '_comments', $data, 'id=' . $id);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_comments WHERE id=' . $id . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_comments WHERE id=' . $id . '; '));
        $intro->redirect($this->appname);
    }
    public function Active()
    {
        global $intro;
        global $id;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('UPDATE ' . PREFIX . ('_comments SET theStatus=1 WHERE id=' . $id . ' '));
        $intro->redirect($this->appname);
    }
}
