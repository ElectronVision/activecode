<?php
#path for webfolder , iptv , if you change it chnage this value please

$config = array();
$config['base_url'] = '/ActiveCode/';
#database
$config['db']['hostname'] = 'localhost';
$config['db']['username'] = 'root';
$config['db']['password'] = 'iptv';
$config['db']['database'] = 'midnight_iptv';

$config['db']['port'] = '';//'7999';

$config['db']['charset'] = 'utf8';
$config['db']['collation'] = 'utf8_general_ci';
$config['production'] = false;


$options = array();
$options['opt_aum_api'] = "yes";
$options['opt_stb_to_iptv'] = "yes";
$options['opt_restart_strm'] = "yes";
$options['opt_strm_rpt'] = "yes";
$options['opt_subResel'] = "yes";
$options['opt_ReselExtraOpts'] = "yes";
$options['opt_groups'] = "yes";
$options['opt_remote_movies'] = "yes";
$options['opt_hide_introtik'] = "yes";

define("PREFIX","solus");
