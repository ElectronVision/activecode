<?php 
class Settings_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base)
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        $this->appname = $appname;
        $this->base = $base;
        if( !in_array($this->admin['level'], [
            1, 
            9
        ]) ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-cog\">General Settings </icon></a> \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        global $options;
        $this->nav();
        $sql2 = $intro->db->query('SHOW COLUMNS FROM `settings` LIKE \'crack_users\';');
        if( $intro->db->returned_rows == 0 ) 
        {
            $intro->db->query('ALTER TABLE `settings` ADD `crack_users` TINYINT NOT NULL AFTER `mag_security`, ADD `crack_users_times` TINYINT NOT NULL AFTER `crack_users`, ADD `crack_mag` TINYINT NOT NULL AFTER `crack_users_times`, ADD `crack_mag_times` TINYINT NOT NULL AFTER `crack_mag`; ');
        }
        $sql = $intro->db->query('select * from settings where id=1');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-cog"></i> General Settings', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . "/doSave\" enctype=\"multipart/form-data\">\r\n\t\t<table class=\"table table-bordered table-hover\">\r\n\t\t\t" . $this->general_settings($row) . "\r\n\t\t\t" . $this->security($row) . "\r\n\t\t\t" . $this->perfomance_settings($row) . "\r\n\t\t\t" . $this->connection_settings($row) . "\r\n\t\t\t" . $this->MAG_Devices($row) . "\r\n\t\t\t" . $this->streams_settings($row) . "\r\n\t\t\t" . $this->VOD_Settings($row) . "\r\n\t\t\t" . $this->Streaming_client_settings($row) . "\r\n\t\t\t<!--" . $this->Mail_Settings($row) . "\r\n\t\t\t" . $this->Registration_Settings($row) . "-->\r\n\t\t\t" . $this->API_Settings($row) . "\r\n\t\t\t" . $this->Video_Settings($row) . ("\r\n\t\t\r\n\t\t<!--<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span > </span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>block_svp:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"block_svp\" value=\"" . $block_svp . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>autobackup_status:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"autobackup_status\" value=\"" . $autobackup_status . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>autobackup_pass:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"autobackup_pass\" value=\"" . $autobackup_pass . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>reshare_deny_addon:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"reshare_deny_addon\" value=\"" . $reshare_deny_addon . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>restart_http:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"restart_http\" value=\"" . $restart_http . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>backup_source_all:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"backup_source_all\" value=\"" . $backup_source_all . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>portal_block:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"portal_block\" value=\"" . $portal_block . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>streaming_block:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"streaming_block\" value=\"" . $streaming_block . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>stream_start_delay:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"stream_start_delay\" value=\"" . $stream_start_delay . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>enable_pseudo_hls:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"enable_pseudo_hls\" value=\"" . $enable_pseudo_hls . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>persistent_connections:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"persistent_connections\" value=\"" . $persistent_connections . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>record_max_length:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"record_max_length\" value=\"" . $record_max_length . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>total_records_length:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"total_records_length\" value=\"" . $total_records_length . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>max_local_recordings:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"max_local_recordings\" value=\"" . $max_local_recordings . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\r\n\t\t<tr>\r\n\t\t\t<td>dynamic_timezone:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"dynamic_timezone\" value=\"" . $dynamic_timezone . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>e2_mipsel:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"e2_mipsel\" value=\"" . $e2_mipsel . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>e2_mips32el:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"e2_mips32el\" value=\"" . $e2_mips32el . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>e2_sh4:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"e2_sh4\" value=\"" . $e2_sh4 . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>e2_arm:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"e2_arm\" value=\"" . $e2_arm . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t-->\r\n\t\t<tr>\r\n\t\t\t<td>Message of The Day:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"message_of_day\" value=\"" . $message_of_day . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<!--\r\n\t\t<tr>\r\n\t\t\t<td>double_auth:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"double_auth\" value=\"" . $double_auth . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>userpanel_mainpage:</td>\r\n\t\t\t<td>" . $userpanel_mainpage . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>mobile_apps:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"mobile_apps\" value=\"" . $mobile_apps . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>-->\r\n\t\r\n\t\t<tr>\r\n\t\t\t<td class=\"center\" colspan=\"2\">\r\n\t\t\t\t<button class=\"btn btn-success\" type=\"submit\"><i class=\"icon-floppy\"> </i> Save </button>\t\t\t\t\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('');
    }
    public function doSave()
    {
        global $intro;
        global $array;
        $this->general_post($_POST);
        $this->security_post($_POST);
        $this->perfomance_post($_POST);
        $this->connection_post($_POST);
        $this->MAG_Devices_post($_POST);
        $this->streams_post($_POST);
        $this->VOD_post($_POST);
        $this->Streaming_client_post($_POST);
        $this->API_post($_POST);
        $this->Video_post($_POST);
        $this->Mail_post($_POST);
        $this->Registration_post($_POST);
        $data = [];
        $data['message_of_day'] = trim($intro->input->post('message_of_day'));
        $intro->db->update('settings', $data, 'id=1');
        $intro->redirect($this->appname);
    }
    public function general_settings($row)
    {
        global $intro;
        global $sess_admin;
        global $new_sorting_bouquet;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span > General Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>Server Name:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"server_name\" value=\"" . $server_name . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Default Timezone:</td>\r\n\t\t\t<td>" . _obf_0D121115021E2F112D152B220538232718040E3D0E3301('default_timezone', $default_timezone) . ("</td>\r\n\t\t</tr>\r\n\t\t<!--\r\n\t\t<tr>\r\n\t\t\t<td>Default Language\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"default_lang\" value=\"" . $default_lang . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>-->\r\n\t\t<tr>\r\n\t\t\t<td>Your Logo URL\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"logo_url\" value=\"" . $logo_url . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>xc_support_allow:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"xc_support_allow\" value=\"" . $xc_support_allow . "\" class=\"form-control\"  /> Please put 0</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Live streaming password:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"live_streaming_pass\" value=\"" . $live_streaming_pass . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Encryption Key\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"crypt_load_balancing\" value=\"" . $crypt_load_balancing . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\r\n\t\t<tr>\r\n\t\t\t<td style='width:20%;'>Bouquet Name</td>\r\n\t\t\t<td ><input dir=ltr type=\"text\" name=\"bouquet_name\" value=\"" . $bouquet_name . "\" class=\"form-control\"  style='width:50%;' /></td>\r\n\t\t</tr>\r\n\r\n\t\t<tr>\r\n\t\t\t<td> Use Buffer On Tables\t:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('use_buffer_table', $use_buffer_table) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> TMDB API Key\t:</td>\r\n\t\t\t<td class=\"form-inline\"><input dir=ltr type=\"text\" name=\"tmdb_api_key\" value=\"" . $tmdb_api_key . "\" class=\"form-control\" style=\"width:350px;\"  />\r\n\t\t\t <a href=\"https://www.themoviedb.org/settings/api\" target=\"_blank\"> Get API Key (v3 auth) from themoviedb.org</a>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t\t<tr>\r\n\t\t\t<td> TMDB Default Language\t:</td>\r\n\t\t\t<td>") ._obf_0D303E153F1434130E373D01173C280D3E14021B012832('tmdb_default', $tmdb_default) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>css layout:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"css_layout\" value=\"" . $css_layout . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Enable X-Firewall:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('firewall', $firewall) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Use Newest Sorting methods For Bouquets:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('new_sorting_bouquet', $new_sorting_bouquet) . "</td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<!--\r\n\t\t<tr>\r\n\t\t\t<td>toggle_menu:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('toggle_menu', $toggle_menu) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Default MAG locale:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"default_locale\" value=\"" . $default_locale . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>-->\r\n\t\t");
        return $html;
    }
    public function toolTip($key)
    {
        $txt = [];
        $txt['flood_limit'] = 'The script checks for flood attack every 5 seconds. The Flood limit is the Maximum number of requests that a Single IP can do EVERY 5 seconds before it gets blocked. You can anytime see the blocked IPs under Block IP/CIDR Section. Enter 0 To disable DDos security check';
        $txt['allowed_ips_admin'] = 'Allowed IPs to access the Admin Live/VOD Streaming. In general your Load Balancer servers are using this module to transfer the stream data to other servers. You are using this module too when you press the example output at the Manage Streams. By default all administrators have access to this function. However, you can specify more IPs (separated by comma) in case you need to do something else. By default you shouldn\'t allow more IPs.';
        $txt['flood_ips_exclude'] = 'The script will not check the following IPs and will not be blocked';
        return '<div style=\'font-size:11px;color:#555555\'>' . $txt[$key] . '</div>';
    }
    public function security($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $flood_limit_txt = '';
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span >Security Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Protect Users from Cracking:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('crack_users', $crack_users) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Block Cracker After x failed logins:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"crack_users_times\" value=\"" . $crack_users_times . "\" class=\"form-control\"  style=\"width:150px;\"/></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Protect MAG from Cracking:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('crack_mag', $crack_mag) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Block MAG Cracker After x failed logins:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"crack_mag_times\" value=\"" . $crack_mag_times . "\" class=\"form-control\"  style=\"width:150px;\"/></td>\r\n\t\t</tr>\r\n\t\t<tr style=\"border-top:4px solid #888888\">\r\n\t\t\t<td> Show Recaptcha On Login Form\t:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('show_captcha', $show_captcha) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Flood Limit\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"flood_limit\" value=\"" . $flood_limit . "\" class=\"form-control\"  />\r\n\t\t\t") . $this->toolTip('flood_limit') . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Request Frequency in Seconds:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"flood_seconds\" value=\"" . $flood_seconds . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Exclude IPs (Seperate by comma):</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"flood_ips_exclude\" value=\"" . $flood_ips_exclude . '" class="form-control"  />' . $this->toolTip('flood_ips_exclude') . "</td>\r\n\t\t</tr>") . "<tr>\r\n\t\t\t<td> Secure MySQL Remote\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('mysql_remote_sec', $mysql_remote_sec) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Use Case Sensitivity For Usernames/Password\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('case_sensitive_line', $case_sensitive_line) . (" </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Flood MAX Attempts:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"flood_max_attempts\" value=\"" . $flood_max_attempts . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Apply flood to clients?:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('flood_apply_clients', $flood_apply_clients) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Apply flood to restreamers?:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('flood_apply_restreamers', $flood_apply_restreamers) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Flood get block:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('flood_get_block', $flood_get_block) . " </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t\r\n\t\t";
        return $html;
    }
    public function perfomance_settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span >Perfomance Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td  class='red'> Save Closed Connection\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('save_closed_connection', $save_closed_connection) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td  class='red'> Save Error Client Log\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('client_logs_save', $client_logs_save) . "</td>\r\n\t\t</tr>";
        return $html;
    }
    public function connection_settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span >Connection Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Auto kick users if they are online for x hours\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"user_auto_kick_hours\" value=\"" . $user_auto_kick_hours . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Show In Red The User Connections, Based On Total Time Online\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"show_in_red_online\" value=\"" . $show_in_red_online . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td class='red'> Disallow connections with empty user agent\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('disallow_empty_user_agents', $disallow_empty_user_agents) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Show ISP Names\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('show_isps', $show_isps) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Override Client's Country upon first connection\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('county_override_1st', $county_override_1st) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td class='red'> Don't allow connections from Different IPs while User is online\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('disallow_2nd_ip_con', $disallow_2nd_ip_con) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Enable ISP Lock:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('enable_isp_lock', $enable_isp_lock) . " </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t";
        return $html;
    }
    public function MAG_Devices($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $allowed_stb_types = json_decode($allowed_stb_types);
        if( is_array($allowed_stb_types) && count($allowed_stb_types) == 0 || !is_array($allowed_stb_types) ) 
        {
            $allowed_stb_types = $array['allowed_stb_types'];
        }
        $imgs = '["ImageDescription: 0.2.18-r11-250; ImageDate: Wed Mar 18 17:54:59 EET 2015; PORTAL version: 5.3.0; API Version: JS API version: 331; STB API version: 141; Player Engine version: 0x572","ImageDescription: Cityphone_250; ImageDate: Thu Mar 26 12:35:29 CET 2015; PORTAL version: 5.3.0; API Version: JS API version: 331; STB API version: 140; Player Engine version: 0x570","ImageDescription: 0.2.18-r19-254; ImageDate: Mon Jun 12 11:34:37 EEST 2017; PORTAL version: 5.3.0; API Version: JS API version: 340; STB API version: 146; Player Engine version: 0x582","ImageDescription: 0.2.18-r10-254; ImageDate: Wed Jan 14 13:36:32 EET 2015; PORTAL version: IPTV; API Version: JS API version: 331; STB API version: 140; Player Engine version: 0x570","ImageDescription: 0.2.18-r23-250; ImageDate: Thu Sep 13 11:31:16 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c","ImageDescription: 2.20.05-324; ImageDate: Wed Dec 27 12:58:50 EET 2017; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 0; Player Engine version: 0x 0","ImageDescription: 0.2.18-r11-250; ImageDate: Wed Mar 18 17:54:59 EET 2015; PORTAL version: 4.9.22; API Version: JS API version: 331; STB API version: 141; Player Engine version: 0x572","ImageDescription: Factory image; ImageDate: ; PORTAL version: 5.3.0; API Version: JS API version: 331; STB API version: 141; Player Engine version: 0x572","ImageDescription: Cityphone_MAG254; ImageDate: Mon Dec 7 07:52:41 CST 2015; PORTAL version: 5.3.0; API Version: JS API version: 329; STB API version: 137; Player Engine version: 0x563","ImageDescription: 0.2.18-r23-254; ImageDate: Wed Aug 29 10:49:53 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c","ImageDescription: Factory image; ImageDate: ; PORTAL version: 5.3.0; API Version: JS API version: 333; STB API version: 142; Player Engine version: 0x579","ImageDescription: 0.2.18-r17-254; ImageDate: Mon Feb 20 15:19:12 EET 2017; PORTAL version: 5.3.0; API Version: JS API version: 340; STB API version: 146; Player Engine version: 0x57d","ImageDescription: 0.2.18-r14-250; ImageDate: Fri Jan 15 15:24:06 EET 2016; PORTAL version: 5.3.0; API Version: JS API version: 333; STB API version: 142; Player Engine version: 0x579","ImageDescription: 0.2.18-r19-250; ImageDate: Mon Jun 12 11:15:29 EEST 2017; PORTAL version: 5.3.0; API Version: JS API version: 340; STB API version: 146; Player Engine version: 0x582","ImageDescription: 0.2.16-r2; ImageDate: Fri Oct 25 17:28:41 EEST 2013; PORTAL version: 5.3.0; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566","ImageDescription: 2.20.05-256; ImageDate: Fri Aug 3 14:46:35 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 0; Player Engine version: 0x 0","ImageDescription: 0.2.18-r14-pub-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; PORTAL version: 5.3.0; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566","ImageDescription: Factory image; ImageDate: ; PORTAL version: 5.3.0; API Version: JS API version: 340; STB API version: 146; Player Engine version: 0x582","ImageDescription: 0.2.18-r14-254; ImageDate: Fri Jan 15 15:42:08 EET 2016; PORTAL version: 5.3.0; API Version: JS API version: 333; STB API version: 142; Player Engine version: 0x579","ImageDescription: 2.20.04-256; ImageDate: Wed Jan 31 20:08:52 EET 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 0; Player Engine version: 0x 0","ImageDescription: Factory image; ImageDate: ; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 0; Player Engine version: 0x 0","ImageDescription: 2.20.01-256; ImageDate: Mon Feb 27 16:50:14 EET 2017; PORTAL version: 5.3.0; API Version: JS API version: 341; STB API version: 0; Player Engine version: 0x 0","ImageDescription: 2.20.08r2-324; ImageDate: Mon Jan 28 18:18:52 EET 2019; PORTAL version: 5.3.0; API Version: JS API version: 344; STB API version: 0; Player Engine version: 0x 0","ImageDescription: 0.2.18-r12-pub-250; ImageDate: Thu Oct 8 14:27:25 EEST 2015; PORTAL version: 5.3.0; API Version: JS API version: 333; STB API version: 142; Player Engine version: 0x578","ImageDescription: 218; ImageDate: Fri Jan 15 15:20:44 EET 2016; PORTAL version: 5.0.3; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566","ImageDescription: 2.20.07r2-324; ImageDate: Tue Jul 10 13:14:06 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 0; Player Engine version: 0x 0"]';
        $ex = json_decode($stalker_lock_images, true);
        if( is_array($ex) && count($ex) > 0 ) 
        {
            $stalker_lock_images = implode("\n", $ex);
        }
        else
        {
            $stalker_lock_images = '';
        }
        if( strlen($stalker_lock_images) > 1000 ) 
        {
            $height = 300;
        }
        else
        {
            $height = 70;
        }
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span >MAG Devices</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Lock STB To Images\t: <br/>\r\n\t\t\t\r\n\t\t\tEnter each image name in single line.<br/>\r\n\t\t\tTo disable Images Lock just clear this text field.</td>\r\n\t\t\t<td><textarea name=\"stalker_lock_images\" wrap=\"off\" class=\"form-control\" style=\"height:" . $height . 'px;" placeholder="When this field is empty, this feature is disabled.">' . $stalker_lock_images . "</textarea></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Allowed STB Types\t:</td>\r\n\t\t\t<td>" . _obf_0D182C25111E19341D351701193E051435032F27102311('allowed_stb_types[]', $allowed_stb_types, $allowed_stb_types) . "\r\n\t\t\t<div><hr style='margin:7px 0 4px 0;'>\r\n\t\t\t<input type=\"text\" id='inputAddMagStb' placeholder=\"Enter new MAG STB Name\" style=\"width: 200px;\">\r\n\t\t\t<input type='button' id='btnAddMagStb' value='Add New'>\r\n\t\t\t</div>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Allowed STB Types for local recording:</td>\r\n\t\t\t<td>\r\n\t\t\t" . _obf_0D182C25111E19341D351701193E051435032F27102311('allowed_stb_types_for_local_recording[]', $allowed_stb_types, json_decode($allowed_stb_types_for_local_recording)) . "\t\t\r\n\t\t</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Allowed STB Types recording:</td>\r\n\t\t\t<td>\r\n\t\t\t" . _obf_0D182C25111E19341D351701193E051435032F27102311('allowed_stb_types_for_local_recording[]', $allowed_stb_types, json_decode($allowed_stb_types_rec)) . "\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td> Stalker VOD Container Priority\t:</td>\r\n\t\t\t<td>" . _obf_0D042827394002382E07271E152934171C2F1B331B0C11('stalker_container_priority[]', $array['target_container'], json_decode($stalker_container_priority), $txt = '', $first_value = 0) . ("  </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td> SpeedTest URL\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"test_download_url\" value=\"" . $test_download_url . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Default Channel Aspect\t:</td>\r\n\t\t\t<td>\r\n\t\t\t") . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('tv_channel_default_aspect', $array['tv_channel_default_aspect'], $tv_channel_default_aspect) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Stalker Portal Theme\t:</td>\r\n\t\t\t<td>" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('stalker_theme', $array['stalker_theme'], $stalker_theme) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Enable Subtitles By Default\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('always_enabled_subtitles', $always_enabled_subtitles) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> PlayBack Limit\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"playback_limit\" value=\"" . $playback_limit . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Show TV Channel Logos\t:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('show_tv_channel_logo', $show_tv_channel_logo) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Show TV Channel Logos on Channel List\t:</td>\r\n\t\t\t<td></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Enable Connection Problem Message\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('enable_connection_problem_indication', $enable_connection_problem_indication) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Assign Channel Number Based On\t:</td>\r\n\t\t\t<td>" . _obf_0D282D3708280221011E043117082204131B1A2B400622('channel_number_type', $array['channel_number_type'], $channel_number_type) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Stream Output Format\t:</td>\r\n\t\t\t<td>" . _obf_0D282D3708280221011E043117082204131B1A2B400622('mag_container', $array['mag_container'], $mag_container) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Show All Category in MAG Devices\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('show_all_category_mag', $show_all_category_mag) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Change MAG Password On Handshake\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('stb_change_pass', $stb_change_pass) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Mag Security:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('mag_security', $mag_security) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Enable Stalker Debug Mode\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('enable_debug_stalker', $enable_debug_stalker) . "</td>\r\n\t\t</tr>";
        return $html;
    }
    public function streams_settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span >Streams Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Stream analyze duration\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"stream_max_analyze\" value=\"" . $stream_max_analyze . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>ProbeSize:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"probesize\" value=\"" . $probesize . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Restart Streams on Audio Loss\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('audio_restart_loss', $audio_restart_loss) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Buffer Size For Reading\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"read_buffer_size\" value=\"" . $read_buffer_size . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Use Priority In Backup Sources\t:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('priority_backup', $priority_backup) . " </td>\r\n\t\t</tr>";
        return $html;
    }
    public function VOD_Settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span >VOD Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Limit VOD Download Speed After % Size read\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"vod_limit_at\" value=\"" . $vod_limit_at . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Increase Download Speed Limit for VOD By X Percent\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"vod_bitrate_plus\" value=\"" . $vod_bitrate_plus . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Generic VOD Container Priority\t:</td>\r\n\t\t\t<td>" . _obf_0D042827394002382E07271E152934171C2F1B331B0C11('gen_container_priority[]', $array['target_container'], json_decode($gen_container_priority)) . "\r\n\t\t</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Use Custom Name on Series Episodes\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('series_custom_name', $series_custom_name) . " </td>\r\n\t\t</tr>";
        return $html;
    }
    public function Streaming_client_settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span > Streaming and client settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Enable HTTPs in the following servers\t:</td>\r\n\t\t\t<td>" . _obf_0D042827394002382E07271E152934171C2F1B331B0C11('use_https[]', $intro->servers, json_decode($use_https, true)) . "  </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Balance Clients:</td>\r\n\t\t\t<td>" . _obf_0D282D3708280221011E043117082204131B1A2B400622('split_clients', [
            'equal' => 'Equally', 
            'load' => 'Load'
        ], $split_clients) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Balance Connections by\t:</td>\r\n\t\t\t<td>" . _obf_0D282D3708280221011E043117082204131B1A2B400622('split_by', $array['split_by'], $split_by) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Prebuffer In seconds\t:</td>\r\n\t\t\t<td>" . _obf_0D282D3708280221011E043117082204131B1A2B400622('client_prebuffer', $array['client_prebuffer'], $client_prebuffer) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Prebuffer enable for Restreamers\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('restreamer_prebuffer', $restreamer_prebuffer) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Use Buffer to store the Data Before Sending them to client\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('use_buffer', $use_buffer) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Use Main Domain in playlists\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('use_mdomain_in_lists', $use_mdomain_in_lists) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Get Real IP Client Header\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"get_real_ip_client\" value=\"" . $get_real_ip_client . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Give Random RTMP Server to PlayLists\t:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('rtmp_random', $rtmp_random) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Get Server Capacity Every X Seconds\t\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"online_capacity_interval\" value=\"" . $online_capacity_interval . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Hash/Crypt For Load Balancing\t:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('hash_lb', $hash_lb) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Use Double Secure Authentication in LB\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('double_auth', $double_auth) . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Allowed IPs to access admin streaming\t\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"allowed_ips_admin\" value=\"" . $allowed_ips_admin . '" class="form-control"  />' . $this->toolTip('allowed_ips_admin') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Allow connections from these countries\t:</td>\r\n\t\t\t<td> \r\n\t\t\t\t") . _obf_0D192107040A1D2A031C033725325B09190E3D34050511('allow_countries[]', json_decode($allow_countries, true)) . "\r\n\t\t\t</td>\r\n\t\t</tr>";
        return $html;
    }
    public function Mail_Settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span >Mail Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Enter the email address which you want the emails to come from\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"mail_from\" value=\"" . $mail_from . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>SMTP Host\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"smtp_host\" value=\"" . $smtp_host . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>SMTP Port :</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"smtp_port\" value=\"" . $smtp_port . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>SMTP Encryption\t:</td>\r\n\t\t\t<td>" . _obf_0D282D3708280221011E043117082204131B1A2B400622('smtp_encryption', $array['smtp_encryption'], $smtp_encryption) . (" </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>SMTP Username\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"smtp_username\" value=\"" . $smtp_username . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>SMTP Password\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"smtp_password\" value=\"" . $smtp_password . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>smtp from name\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"smtp_from_name\" value=\"" . $smtp_from_name . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>email_verify_cont:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"email_verify_cont\" value=\"" . $email_verify_cont . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>email_forgot_sub:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"email_forgot_sub\" value=\"" . $email_forgot_sub . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>email_forgot_cont:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"email_forgot_cont\" value=\"" . $email_forgot_cont . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>email_new_pass_sub:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"email_new_pass_sub\" value=\"" . $email_new_pass_sub . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\r\n\t\t<tr>\r\n\t\t\t<td>email_new_pass_cont:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"email_new_pass_cont\" value=\"" . $email_new_pass_cont . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>unique_id:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"unique_id\" value=\"" . $unique_id . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t");
        return $html;
    }
    public function Registration_Settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span > Registration Settings </span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Allow Registrations\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('allow_registrations', $allow_registrations) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Send Confirmation E-mail After Registration\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('confirmation_email', $confirmation_email) . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Allow Users to Register Multiple Accounts\t:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('allow_multiple_accs', $allow_multiple_accs) . (" </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Max Username Lengths During Registration\t:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"username_strlen\" value=\"" . $username_strlen . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Allow Only AlphaNumeric In Usernames\t:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('username_alpha', $username_alpha) . ("  </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>min_password:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"min_password\" value=\"" . $min_password . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t");
        return $html;
    }
    public function API_Settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span > API Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> Allowed IPs:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"api_ips\" value=\"" . $api_ips . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> API Password Key\t:<a name='api_pass'></a></td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"api_pass\" value=\"" . $api_pass . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>";
        return $html;
    }
    public function gsa($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = '';
        return $html;
    }
    public function Video_Settings($row)
    {
        global $intro;
        global $sess_admin;
        global $array;
        @extract($row);
        $html = "<tr>\r\n\t\t\t<th colspan=2 >\r\n\t\t\t\t<span > Video Settings</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Show A Video When a Stream is not working:</td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('show_not_on_air_video', $show_not_on_air_video) . (" </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Specify The FULL URL Path to your Video:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"not_on_air_video_path\" value=\"" . $not_on_air_video_path . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Show A Video When a line is banned:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('show_banned_video', $show_banned_video) . (" </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Specify The FULL URL Path to your Video:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"banned_video_path\" value=\"" . $banned_video_path . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Show A Video when an Expired User is trying to access a Stream:</td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('show_expired_video', $show_expired_video) . (" </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>Specify The FULL URL Path to your Video:</td>\r\n\t\t\t<td><input dir=ltr type=\"text\" name=\"expired_video_path\" value=\"" . $expired_video_path . "\" class=\"form-control\"  /></td>\r\n\t\t</tr>");
        return $html;
    }
    public function option($index)
    {
        return (isset($this->db_options[$index]) ? $this->db_options[$index] : '');
    }
    public function general_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $fields = [
            'server_name', 
            'default_timezone', 
            'logo_url', 
            'live_streaming_pass', 
            'crypt_load_balancing', 
            'bouquet_name', 
            'new_sorting_bouquet', 
            'use_buffer_table', 
            'tmdb_api_key', 
            'tmdb_default', 
            'css_layout', 
            'firewall'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( count($data) > 0 ) 
        {
            $intro->db->update('settings', $data, 'id=1');
        }
    }
    public function security_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $fields = [
            'crack_users', 
            'crack_users_times', 
            'crack_mag', 
            'crack_mag_times', 
            'show_captcha', 
            'flood_limit', 
            'flood_seconds', 
            'flood_ips_exclude', 
            'xc_support_allow', 
            'mysql_remote_sec', 
            'case_sensitive_line', 
            'flood_max_attempts', 
            'flood_apply_clients', 
            'flood_apply_restreamers', 
            'flood_get_block'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( count($data) > 0 ) 
        {
            $intro->db->update('settings', $data, 'id=1');
        }
    }
    public function perfomance_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $fields = [
            'save_closed_connection', 
            'client_logs_save', 
            'client_area_plugin', 
            'split_clients'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( count($data) > 0 ) 
        {
            $intro->db->update('settings', $data, 'id=1');
        }
    }
    public function connection_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $fields = [
            'user_auto_kick_hours', 
            'show_in_red_online', 
            'disallow_empty_user_agents', 
            'show_isps', 
            'county_override_1st', 
            'disallow_2nd_ip_con', 
            'enable_isp_lock'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( count($data) > 0 ) 
        {
            $intro->db->update('settings', $data, 'id=1');
        }
    }
    public function MAG_Devices_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $stalker_lock_images = $intro->input->post('stalker_lock_images');
        if( strlen($stalker_lock_images) > 1000 ) 
        {
            $data['stalker_lock_images'] = json_encode(explode("\n", $stalker_lock_images));
        }
        else
        {
            $data['stalker_lock_images'] = '';
        }
        $data['allowed_stb_types'] = json_encode($intro->input->post('allowed_stb_types'));
        $data['allowed_stb_types_for_local_recording'] = json_encode($intro->input->post('allowed_stb_types_for_local_recording'));
        $data['allowed_stb_types_rec'] = json_encode($intro->input->post('allowed_stb_types_rec'));
        $data['stalker_container_priority'] = json_encode($intro->input->post('stalker_container_priority'));
        $data['test_download_url'] = trim($intro->input->post('test_download_url'));
        $data['tv_channel_default_aspect'] = trim($intro->input->post('tv_channel_default_aspect'));
        $data['stalker_theme'] = trim($intro->input->post('stalker_theme'));
        $data['always_enabled_subtitles'] = trim($intro->input->post('always_enabled_subtitles'));
        $data['playback_limit'] = trim($intro->input->post('playback_limit'));
        $data['show_tv_channel_logo'] = trim($intro->input->post('show_tv_channel_logo'));
        $data['enable_connection_problem_indication'] = intval($intro->input->post('enable_connection_problem_indication'));
        $data['channel_number_type'] = trim($intro->input->post('channel_number_type'));
        $data['mag_container'] = trim($intro->input->post('mag_container'));
        $data['show_all_category_mag'] = trim($intro->input->post('show_all_category_mag'));
        $data['stb_change_pass'] = trim($intro->input->post('stb_change_pass'));
        $data['mag_security'] = trim($intro->input->post('mag_security'));
        $data['enable_debug_stalker'] = trim($intro->input->post('enable_debug_stalker'));
        $intro->db->update('settings', $data, 'id=1');
    }
    public function streams_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $fields = [
            'stream_max_analyze', 
            'probesize', 
            'audio_restart_loss', 
            'read_buffer_size', 
            'priority_backup'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( count($data) > 0 ) 
        {
            $intro->db->update('settings', $data, 'id=1');
        }
    }
    public function VOD_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $data['vod_limit_at'] = trim($intro->input->post('vod_limit_at'));
        $data['vod_bitrate_plus'] = trim($intro->input->post('vod_bitrate_plus'));
        $data['gen_container_priority'] = json_encode($intro->input->post('gen_container_priority'));
        $data['series_custom_name'] = trim($intro->input->post('series_custom_name'));
        $intro->db->update('settings', $data, 'id=1');
    }
    public function Streaming_client_post($post = [])
    {
        global $intro;
        global $array;
        $allow_countries = $intro->input->post('allow_countries');
        $data = [];
        $fields = [
            'split_by', 
            'client_prebuffer', 
            'restreamer_prebuffer', 
            'use_buffer', 
            'use_mdomain_in_lists', 
            'get_real_ip_client', 
            'rtmp_random', 
            'online_capacity_interval', 
            'hash_lb', 
            'allowed_ips_admin'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( is_array($allow_countries) && count($allow_countries) > 0 ) 
        {
            $allow_countries = json_encode($allow_countries);
        }
        else
        {
            $allow_countries = '[]';
        }
        $data['use_https'] = json_encode($intro->input->post('use_https'));
        $data['allow_countries'] = $allow_countries;
        $intro->db->update('settings', $data, 'id=1');
    }
    public function API_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $fields = [
            'api_ips', 
            'api_pass'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( count($data) > 0 ) 
        {
            $intro->db->update('settings', $data, 'id=1');
        }
    }
    public function Video_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $fields = [
            'show_not_on_air_video', 
            'show_banned_video', 
            'not_on_air_video_path', 
            'banned_video_path', 
            'show_expired_video', 
            'expired_video_path'
        ];
        foreach( $fields as $field ) 
        {
            $val = trim($intro->input->post($field));
            if( $val != '' ) 
            {
                $data[$field] = $val;
            }
        }
        if( count($data) > 0 ) 
        {
            $intro->db->update('settings', $data, 'id=1');
        }
    }
    public function Mail_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $data['mail_from'] = trim($intro->input->post('mail_from'));
        $data['smtp_host'] = trim($intro->input->post('smtp_host'));
        $data['smtp_port'] = trim($intro->input->post('smtp_port'));
        $data['smtp_username'] = trim($intro->input->post('smtp_username'));
        $data['smtp_password'] = trim($intro->input->post('smtp_password'));
        $data['smtp_from_name'] = trim($intro->input->post('smtp_from_name'));
        $data['email_verify_cont'] = trim($intro->input->post('email_verify_cont'));
        $data['email_forgot_sub'] = trim($intro->input->post('email_forgot_sub'));
        $data['email_forgot_cont'] = trim($intro->input->post('email_forgot_cont'));
        $data['email_new_pass_sub'] = trim($intro->input->post('email_new_pass_sub'));
        $data['email_new_pass_cont'] = trim($intro->input->post('email_new_pass_cont'));
        $data['unique_id'] = trim($intro->input->post('unique_id'));
        $intro->db->update('settings', $data, 'id=1');
    }
    public function Registration_post($post = [])
    {
        global $intro;
        global $array;
        $data = [];
        $data['allow_registrations'] = trim($intro->input->post('allow_registrations'));
        $data['confirmation_email'] = trim($intro->input->post('confirmation_email'));
        $data['allow_multiple_accs'] = trim($intro->input->post('allow_multiple_accs'));
        $data['username_strlen'] = trim($intro->input->post('username_strlen'));
        $data['username_alpha'] = trim($intro->input->post('username_alpha'));
        $data['min_password'] = trim($intro->input->post('min_password'));
        $intro->db->update('settings', $data, 'id=1');
    }
}
