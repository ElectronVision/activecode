-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: xtream_iptvpro
-- ------------------------------------------------------
-- Server version	5.7.33-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_output`
--

DROP TABLE IF EXISTS `access_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_output` (
  `access_output_id` int(11) NOT NULL AUTO_INCREMENT,
  `output_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `output_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `output_ext` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`access_output_id`),
  KEY `output_key` (`output_key`),
  KEY `output_ext` (`output_ext`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_output`
--

LOCK TABLES `access_output` WRITE;
/*!40000 ALTER TABLE `access_output` DISABLE KEYS */;
INSERT INTO `access_output` (`access_output_id`, `output_name`, `output_key`, `output_ext`) VALUES (1,'HLS','m3u8','m3u8'),(2,'MPEGTS','ts','ts'),(3,'RTMP','rtmp','');
/*!40000 ALTER TABLE `access_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_settings`
--

DROP TABLE IF EXISTS `admin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_settings` (
  `type` varchar(128) NOT NULL DEFAULT '',
  `value` varchar(4096) NOT NULL DEFAULT '',
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_settings`
--

LOCK TABLES `admin_settings` WRITE;
/*!40000 ALTER TABLE `admin_settings` DISABLE KEYS */;
INSERT INTO `admin_settings` (`type`, `value`) VALUES ('auto_refresh','1'),('cc_time','1618024201'),('stats_pid','15865'),('tmdb_pid','15871'),('watch_pid','15872');
/*!40000 ALTER TABLE `admin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_ips`
--

DROP TABLE IF EXISTS `blocked_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  `attempts_blocked` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_2` (`ip`),
  UNIQUE KEY `ip_3` (`ip`),
  KEY `ip` (`ip`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_ips`
--

LOCK TABLES `blocked_ips` WRITE;
/*!40000 ALTER TABLE `blocked_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_user_agents`
--

DROP TABLE IF EXISTS `blocked_user_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_user_agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exact_match` int(11) NOT NULL DEFAULT '0',
  `attempts_blocked` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `exact_match` (`exact_match`),
  KEY `user_agent` (`user_agent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_user_agents`
--

LOCK TABLES `blocked_user_agents` WRITE;
/*!40000 ALTER TABLE `blocked_user_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_user_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bouquets`
--

DROP TABLE IF EXISTS `bouquets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bouquets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bouquet_name` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `bouquet_channels` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `bouquet_series` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `bouquet_order` int(16) NOT NULL DEFAULT '0',
  `bouquet_icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `view_order` int(11) NOT NULL,
  `bouquet_status` tinyint(1) NOT NULL,
  `isLocked` tinyint(1) NOT NULL,
  `bouquet_for` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bouquets`
--

LOCK TABLES `bouquets` WRITE;
/*!40000 ALTER TABLE `bouquets` DISABLE KEYS */;
INSERT INTO `bouquets` (`id`, `bouquet_name`, `bouquet_channels`, `bouquet_series`, `bouquet_order`, `bouquet_icon`, `view_order`, `bouquet_status`, `isLocked`, `bouquet_for`) VALUES (1,'TEST','[1,2]','[]',0,'',0,1,0,0),(2,'TEST2','[2]','[]',0,'',0,1,0,0),(3,'MOVIS-ARABIC','[\"3\"]','[]',1,'',0,1,0,0);
/*!40000 ALTER TABLE `bouquets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_logs`
--

DROP TABLE IF EXISTS `client_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query_string` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extra_data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_id` (`stream_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_logs`
--

LOCK TABLES `client_logs` WRITE;
/*!40000 ALTER TABLE `client_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `created`
--

DROP TABLE IF EXISTS `created`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `created` (
  `id` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `category_id` tinyint(4) NOT NULL,
  `stream_display_name` tinyint(4) NOT NULL,
  `stream_source` tinyint(4) NOT NULL,
  `stream_icon` tinyint(4) NOT NULL,
  `notes` tinyint(4) NOT NULL,
  `created_channel_location` tinyint(4) NOT NULL,
  `enable_transcode` tinyint(4) NOT NULL,
  `transcode_attributes` tinyint(4) NOT NULL,
  `custom_ffmpeg` tinyint(4) NOT NULL,
  `movie_propeties` tinyint(4) NOT NULL,
  `movie_subtitles` tinyint(4) NOT NULL,
  `read_native` tinyint(4) NOT NULL,
  `target_container` tinyint(4) NOT NULL,
  `stream_all` tinyint(4) NOT NULL,
  `remove_subtitles` tinyint(4) NOT NULL,
  `custom_sid` tinyint(4) NOT NULL,
  `epg_id` tinyint(4) NOT NULL,
  `channel_id` tinyint(4) NOT NULL,
  `epg_lang` tinyint(4) NOT NULL,
  `order` tinyint(4) NOT NULL,
  `auto_restart` tinyint(4) NOT NULL,
  `transcode_profile_id` tinyint(4) NOT NULL,
  `pids_create_channel` tinyint(4) NOT NULL,
  `cchannel_rsources` tinyint(4) NOT NULL,
  `gen_timestamps` tinyint(4) NOT NULL,
  `added` tinyint(4) NOT NULL,
  `series_no` tinyint(4) NOT NULL,
  `direct_source` tinyint(4) NOT NULL,
  `tv_archive_duration` tinyint(4) NOT NULL,
  `tv_archive_server_id` tinyint(4) NOT NULL,
  `tv_archive_pid` tinyint(4) NOT NULL,
  `movie_symlink` tinyint(4) NOT NULL,
  `redirect_stream` tinyint(4) NOT NULL,
  `rtmp_output` tinyint(4) NOT NULL,
  `number` tinyint(4) NOT NULL,
  `allow_record` tinyint(4) NOT NULL,
  `probesize_ondemand` tinyint(4) NOT NULL,
  `custom_map` tinyint(4) NOT NULL,
  `external_push` tinyint(4) NOT NULL,
  `delay_minutes` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `created`
--

LOCK TABLES `created` WRITE;
/*!40000 ALTER TABLE `created` DISABLE KEYS */;
/*!40000 ALTER TABLE `created` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credits_log`
--

DROP TABLE IF EXISTS `credits_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credits_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `date` int(11) NOT NULL,
  `reason` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `target_id` (`target_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credits_log`
--

LOCK TABLES `credits_log` WRITE;
/*!40000 ALTER TABLE `credits_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `credits_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cronjobs`
--

DROP TABLE IF EXISTS `cronjobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cronjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `run_per_mins` int(11) NOT NULL DEFAULT '1',
  `run_per_hours` int(11) NOT NULL DEFAULT '0',
  `enabled` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enabled` (`enabled`),
  KEY `filename` (`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cronjobs`
--

LOCK TABLES `cronjobs` WRITE;
/*!40000 ALTER TABLE `cronjobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cronjobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_statistics`
--

DROP TABLE IF EXISTS `dashboard_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(16) NOT NULL DEFAULT '',
  `time` int(16) NOT NULL DEFAULT '0',
  `count` int(16) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_statistics`
--

LOCK TABLES `dashboard_statistics` WRITE;
/*!40000 ALTER TABLE `dashboard_statistics` DISABLE KEYS */;
INSERT INTO `dashboard_statistics` (`id`, `type`, `time`, `count`) VALUES (1,'conns',1617369311,0),(2,'users',1617369311,0);
/*!40000 ALTER TABLE `dashboard_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `device_id` int(11) NOT NULL AUTO_INCREMENT,
  `device_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `device_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `device_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `device_header` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `device_conf` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `device_footer` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `default_output` int(11) NOT NULL DEFAULT '0',
  `copy_text` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`device_id`),
  KEY `device_key` (`device_key`),
  KEY `default_output` (`default_output`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` (`device_id`, `device_name`, `device_key`, `device_filename`, `device_header`, `device_conf`, `device_footer`, `default_output`, `copy_text`) VALUES (1,'GigaBlue','gigablue','userbouquet.favourites.tv','#NAME {BOUQUET_NAME}','#SERVICE 4097:0:1:0:0:0:0:0:0:0:{URL#:}\r\n#DESCRIPTION {CHANNEL_NAME}','',2,NULL),(2,'Enigma 2 OE 1.6','enigma16','userbouquet.favourites.tv','#NAME {BOUQUET_NAME}','#SERVICE 4097{SID}{URL#:}\r\n#DESCRIPTION {CHANNEL_NAME}','',2,NULL),(3,'DreamBox OE 2.0','dreambox','userbouquet.favourites.tv','#NAME {BOUQUET_NAME}','#SERVICE {ESR_ID}{SID}{URL#:}\r\n#DESCRIPTION {CHANNEL_NAME}','',2,NULL),(4,'m3u','m3u','tv_channels_{USERNAME}.m3u','#EXTM3U','#EXTINF:-1,{CHANNEL_NAME}\r\n{URL}','',2,NULL),(5,'Simple List','simple','simple_{USERNAME}.txt','','{URL} #Name: {CHANNEL_NAME}','',2,NULL),(6,'Octagon','octagon','internettv.feed','','[TITLE]\r\n{CHANNEL_NAME}\r\n[URL]\r\n{URL}\r\n[DESCRIPTION]\r\nIPTV\r\n[TYPE]\r\nLive','',2,NULL),(7,'Starlive v3/StarSat HD6060/AZclass','starlivev3','iptvlist.txt','','{CHANNEL_NAME},{URL}','',2,NULL),(8,'MediaStar / StarLive v4','mediastar','tvlist.txt','','{CHANNEL_NAME} {URL}','',2,NULL),(9,'Enigma 2 OE 1.6 Auto Script','enigma216_script','iptv.sh','USERNAME=\"{USERNAME}\";PASSWORD=\"{PASSWORD}\";bouquet=\"{BOUQUET_NAME}\";directory=\"/etc/enigma2/iptv.sh\";url=\"{SERVER_URL}get.php?username=$USERNAME&password=$PASSWORD&type=enigma16&output={OUTPUT_KEY}\";rm /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv;wget -O /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo \"[+]Creating Folder for iptv and rehashing...\";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo \'#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"userbouquet.\'$bouquet\'__tv_.tv\" ORDER BY bouquet\' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n \'2,$p\' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo \"writing to the file.. NO NEED FOR REBOOT\";echo \"/bin/sh \"$directory\" > /dev/null 2>&1 &\" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";','','',2,'wget -O /etc/enigma2/iptv.sh {DEVICE_LINK} && chmod 777 /etc/enigma2/iptv.sh && /etc/enigma2/iptv.sh'),(10,'Enigma 2 OE 2.0 Auto Script','enigma22_script','iptv.sh','USERNAME=\"{USERNAME}\";PASSWORD=\"{PASSWORD}\";bouquet=\"{BOUQUET_NAME}\";directory=\"/etc/enigma2/iptv.sh\";url=\"{SERVER_URL}get.php?username=$USERNAME&password=$PASSWORD&type=dreambox&output={OUTPUT_KEY}\";rm /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv;wget -O /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo \"[+]Creating Folder for iptv and rehashing...\";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo \'#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"userbouquet.\'$bouquet\'__tv_.tv\" ORDER BY bouquet\' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n \'2,$p\' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo \"writing to the file.. NO NEED FOR REBOOT\";echo \"/bin/sh \"$directory\" > /dev/null 2>&1 &\" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";','','',2,'wget -O /etc/enigma2/iptv.sh {DEVICE_LINK} && chmod 777 /etc/enigma2/iptv.sh && /etc/enigma2/iptv.sh'),(13,'m3u With Options','m3u_plus','tv_channels_{USERNAME}_plus.m3u','#EXTM3U','#EXTINF:-1 tvg-id=\"{CHANNEL_ID}\" tvg-name=\"{CHANNEL_NAME}\" tvg-logo=\"{CHANNEL_ICON}\" group-title=\"{CATEGORY}\",{CHANNEL_NAME}\r\n{URL}','',2,NULL),(14,'StarLive v5','starlivev5','channel.jason','','','',2,NULL),(15,'WebTV List','webtvlist','webtv list.txt','','Channel name:{CHANNEL_NAME}\r\nURL:{URL}','[Webtv channel END]',2,NULL),(16,'Octagon Auto Script','octagon_script','iptv','USERNAME=\"{USERNAME}\";PASSWORD=\"{PASSWORD}\";url=\"{SERVER_URL}get.php?username=$USERNAME&password=$PASSWORD&type=octagon&output={OUTPUT_KEY}\";rm /var/freetvplus/internettv.feed;wget -O /var/freetvplus/internettv.feed1 $url;chmod 777 /var/freetvplus/internettv.feed1;awk -v BINMODE=3 -v RS=\'(\\r\\n|\\n)\' -v ORS=\'\\n\' \'{ print }\' /var/freetvplus/internettv.feed1 > /var/freetvplus/internettv.feed;rm /var/freetvplus/internettv.feed1','','',2,'wget -qO /var/bin/iptv {DEVICE_LINK}'),(18,'Ariva','ariva','ariva_{USERNAME}.txt','','{CHANNEL_NAME},{URL}','',2,NULL),(19,'Spark','spark','webtv_usr.xml','<?xml version=\"1.0\"?>\r\n<webtvs>','<webtv title=\"{CHANNEL_NAME}\" urlkey=\"0\" url=\"{URL}\" description=\"\" iconsrc=\"{CHANNEL_ICON}\" iconsrc_b=\"\" group=\"0\" type=\"0\" />','</webtvs>',2,NULL),(20,'Geant/Starsat/Tiger/Qmax/Hyper/Royal','gst','{USERNAME}_list.txt','','I: {URL} {CHANNEL_NAME}','',2,NULL),(21,'Fortec999/Prifix9400/Starport','fps','Royal.cfg','','IPTV: { {CHANNEL_NAME} } { {URL} }','',2,NULL),(22,'Revolution 60/60 | Sunplus','revosun','network_iptv.cfg','','IPTV: { {CHANNEL_NAME} } { {URL} }','',2,NULL),(23,'Zorro','zorro','iptv.cfg','<NETDBS_TXT_VER_1>','IPTV: { {CHANNEL_NAME} } { {URL} } -HIDE_URL','',2,NULL);
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enigma2_actions`
--

DROP TABLE IF EXISTS `enigma2_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enigma2_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `type` text NOT NULL,
  `key` text NOT NULL,
  `command` text NOT NULL,
  `command2` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enigma2_actions`
--

LOCK TABLES `enigma2_actions` WRITE;
/*!40000 ALTER TABLE `enigma2_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `enigma2_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enigma2_devices`
--

DROP TABLE IF EXISTS `enigma2_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enigma2_devices` (
  `device_id` int(12) NOT NULL AUTO_INCREMENT,
  `mac` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `modem_mac` varchar(255) NOT NULL,
  `local_ip` varchar(255) NOT NULL,
  `public_ip` varchar(255) NOT NULL,
  `key_auth` varchar(255) NOT NULL,
  `enigma_version` varchar(255) NOT NULL,
  `cpu` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `lversion` text NOT NULL,
  `token` varchar(32) NOT NULL,
  `last_updated` int(11) NOT NULL,
  `watchdog_timeout` int(11) NOT NULL,
  `lock_device` tinyint(4) NOT NULL DEFAULT '0',
  `telnet_enable` tinyint(4) NOT NULL DEFAULT '1',
  `ftp_enable` tinyint(4) NOT NULL DEFAULT '1',
  `ssh_enable` tinyint(4) NOT NULL DEFAULT '1',
  `dns` varchar(255) NOT NULL,
  `original_mac` varchar(255) NOT NULL,
  `rc` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`device_id`),
  KEY `mac` (`mac`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enigma2_devices`
--

LOCK TABLES `enigma2_devices` WRITE;
/*!40000 ALTER TABLE `enigma2_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `enigma2_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enigma2_failed`
--

DROP TABLE IF EXISTS `enigma2_failed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enigma2_failed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_mac` varchar(255) NOT NULL,
  `virtual_mac` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `original_mac` (`original_mac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enigma2_failed`
--

LOCK TABLES `enigma2_failed` WRITE;
/*!40000 ALTER TABLE `enigma2_failed` DISABLE KEYS */;
/*!40000 ALTER TABLE `enigma2_failed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `epg`
--

DROP TABLE IF EXISTS `epg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `epg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epg_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `epg_file` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `integrity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_updated` int(11) DEFAULT NULL,
  `days_keep` int(11) NOT NULL DEFAULT '7',
  `data` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `epg`
--

LOCK TABLES `epg` WRITE;
/*!40000 ALTER TABLE `epg` DISABLE KEYS */;
/*!40000 ALTER TABLE `epg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `epg_data`
--

DROP TABLE IF EXISTS `epg_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `epg_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epg_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lang` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `channel_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `epg_id` (`epg_id`),
  KEY `start` (`start`),
  KEY `end` (`end`),
  KEY `lang` (`lang`),
  KEY `channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `epg_data`
--

LOCK TABLES `epg_data` WRITE;
/*!40000 ALTER TABLE `epg_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `epg_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `isp_addon`
--

DROP TABLE IF EXISTS `isp_addon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isp_addon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isp` text NOT NULL,
  `blocked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `isp_addon`
--

LOCK TABLES `isp_addon` WRITE;
/*!40000 ALTER TABLE `isp_addon` DISABLE KEYS */;
/*!40000 ALTER TABLE `isp_addon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence_key` varchar(29) COLLATE utf8_unicode_ci NOT NULL,
  `show_message` tinyint(4) NOT NULL,
  `update_available` int(11) NOT NULL DEFAULT '0',
  `reshare_deny_addon` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_flood`
--

DROP TABLE IF EXISTS `login_flood`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_flood` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL DEFAULT '',
  `ip` varchar(64) NOT NULL DEFAULT '',
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_flood`
--

LOCK TABLES `login_flood` WRITE;
/*!40000 ALTER TABLE `login_flood` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_flood` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_logs`
--

DROP TABLE IF EXISTS `login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `login_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_logs`
--

LOCK TABLES `login_logs` WRITE;
/*!40000 ALTER TABLE `login_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mag_claims`
--

DROP TABLE IF EXISTS `mag_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mag_claims` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mag_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `real_type` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mag_id` (`mag_id`),
  KEY `stream_id` (`stream_id`),
  KEY `real_type` (`real_type`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mag_claims`
--

LOCK TABLES `mag_claims` WRITE;
/*!40000 ALTER TABLE `mag_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `mag_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mag_devices`
--

DROP TABLE IF EXISTS `mag_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mag_devices` (
  `mag_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bright` int(10) NOT NULL DEFAULT '200',
  `contrast` int(10) NOT NULL DEFAULT '127',
  `saturation` int(10) NOT NULL DEFAULT '127',
  `aspect` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `video_out` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'rca',
  `volume` int(5) NOT NULL DEFAULT '50',
  `playback_buffer_bytes` int(50) NOT NULL DEFAULT '0',
  `playback_buffer_size` int(50) NOT NULL DEFAULT '0',
  `audio_out` int(5) NOT NULL DEFAULT '1',
  `mac` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ls` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ver` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en_GB.utf8',
  `city_id` int(11) DEFAULT '0',
  `hd` int(10) NOT NULL DEFAULT '1',
  `main_notify` int(5) NOT NULL DEFAULT '1',
  `fav_itv_on` int(5) NOT NULL DEFAULT '0',
  `now_playing_start` int(50) DEFAULT NULL,
  `now_playing_type` int(11) NOT NULL DEFAULT '0',
  `now_playing_content` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_last_play_tv` int(50) DEFAULT NULL,
  `time_last_play_video` int(50) DEFAULT NULL,
  `hd_content` int(11) NOT NULL DEFAULT '1',
  `image_version` varchar(350) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_change_status` int(11) DEFAULT NULL,
  `last_start` int(11) DEFAULT NULL,
  `last_active` int(11) DEFAULT NULL,
  `keep_alive` int(11) DEFAULT NULL,
  `playback_limit` int(11) NOT NULL DEFAULT '3',
  `screensaver_delay` int(11) NOT NULL DEFAULT '10',
  `stb_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `sn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_watchdog` int(50) DEFAULT NULL,
  `created` int(11) NOT NULL,
  `country` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plasma_saving` int(11) NOT NULL DEFAULT '0',
  `ts_enabled` int(11) DEFAULT '0',
  `ts_enable_icon` int(11) NOT NULL DEFAULT '1',
  `ts_path` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ts_max_length` int(11) NOT NULL DEFAULT '3600',
  `ts_buffer_use` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'cyclic',
  `ts_action_on_exit` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no_save',
  `ts_delay` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'on_pause',
  `video_clock` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Off',
  `rtsp_type` int(11) NOT NULL DEFAULT '4',
  `rtsp_flags` int(11) NOT NULL DEFAULT '0',
  `stb_lang` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `display_menu_after_loading` int(11) NOT NULL DEFAULT '1',
  `record_max_length` int(11) NOT NULL DEFAULT '180',
  `plasma_saving_timeout` int(11) NOT NULL DEFAULT '600',
  `now_playing_link_id` int(11) DEFAULT NULL,
  `now_playing_streamer_id` int(11) DEFAULT NULL,
  `device_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device_id2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hw_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0000',
  `spdif_mode` int(11) NOT NULL DEFAULT '1',
  `show_after_loading` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'main_menu',
  `play_in_preview_by_ok` int(11) NOT NULL DEFAULT '1',
  `hdmi_event_reaction` int(11) NOT NULL DEFAULT '1',
  `mag_player` varchar(20) COLLATE utf8_unicode_ci DEFAULT 'ffmpeg',
  `play_in_preview_only_by_ok` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'true',
  `watchdog_timeout` int(11) NOT NULL,
  `fav_channels` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `tv_archive_continued` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `tv_channel_default_aspect` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'fit',
  `last_itv_id` int(11) NOT NULL DEFAULT '0',
  `units` varchar(20) COLLATE utf8_unicode_ci DEFAULT 'metric',
  `token` varchar(32) COLLATE utf8_unicode_ci DEFAULT '',
  `lock_device` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mag_id`),
  KEY `user_id` (`user_id`),
  KEY `mac` (`mac`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mag_devices`
--

LOCK TABLES `mag_devices` WRITE;
/*!40000 ALTER TABLE `mag_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `mag_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mag_events`
--

DROP TABLE IF EXISTS `mag_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mag_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `mag_device_id` int(11) NOT NULL,
  `event` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `need_confirm` tinyint(3) NOT NULL DEFAULT '0',
  `msg` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `reboot_after_ok` tinyint(3) NOT NULL DEFAULT '0',
  `auto_hide_timeout` tinyint(3) DEFAULT '0',
  `send_time` int(50) NOT NULL,
  `additional_services_on` tinyint(3) NOT NULL DEFAULT '1',
  `anec` tinyint(3) NOT NULL DEFAULT '0',
  `vclub` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `mag_device_id` (`mag_device_id`),
  KEY `event` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mag_events`
--

LOCK TABLES `mag_events` WRITE;
/*!40000 ALTER TABLE `mag_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `mag_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mag_logs`
--

DROP TABLE IF EXISTS `mag_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mag_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mag_id` int(11) DEFAULT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mag_id` (`mag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mag_logs`
--

LOCK TABLES `mag_logs` WRITE;
/*!40000 ALTER TABLE `mag_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `mag_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_groups`
--

DROP TABLE IF EXISTS `member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `group_color` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#000000',
  `is_banned` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `is_reseller` tinyint(4) NOT NULL,
  `total_allowed_gen_trials` int(11) NOT NULL DEFAULT '0',
  `total_allowed_gen_in` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `delete_users` tinyint(4) NOT NULL DEFAULT '0',
  `allowed_pages` text COLLATE utf8_unicode_ci NOT NULL,
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  `reseller_force_server` tinyint(4) NOT NULL DEFAULT '0',
  `create_sub_resellers_price` float NOT NULL DEFAULT '0',
  `create_sub_resellers` tinyint(4) NOT NULL DEFAULT '0',
  `alter_packages_ids` tinyint(4) NOT NULL DEFAULT '0',
  `alter_packages_prices` tinyint(4) NOT NULL DEFAULT '0',
  `reseller_client_connection_logs` tinyint(4) NOT NULL DEFAULT '0',
  `reseller_assign_pass` tinyint(4) NOT NULL DEFAULT '0',
  `allow_change_pass` tinyint(4) NOT NULL DEFAULT '0',
  `allow_import` tinyint(4) NOT NULL DEFAULT '0',
  `allow_export` tinyint(4) NOT NULL DEFAULT '0',
  `reseller_trial_credit_allow` int(11) NOT NULL DEFAULT '0',
  `edit_mac` tinyint(4) NOT NULL DEFAULT '0',
  `edit_isplock` tinyint(4) NOT NULL DEFAULT '0',
  `reset_stb_data` tinyint(4) NOT NULL DEFAULT '0',
  `reseller_bonus_package_inc` tinyint(4) NOT NULL DEFAULT '0',
  `allow_download` tinyint(4) NOT NULL DEFAULT '1',
  `minimum_trial_credits` int(16) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  KEY `is_admin` (`is_admin`),
  KEY `is_banned` (`is_banned`),
  KEY `is_reseller` (`is_reseller`),
  KEY `can_delete` (`can_delete`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_groups`
--

LOCK TABLES `member_groups` WRITE;
/*!40000 ALTER TABLE `member_groups` DISABLE KEYS */;
INSERT INTO `member_groups` (`group_id`, `group_name`, `group_color`, `is_banned`, `is_admin`, `is_reseller`, `total_allowed_gen_trials`, `total_allowed_gen_in`, `delete_users`, `allowed_pages`, `can_delete`, `reseller_force_server`, `create_sub_resellers_price`, `create_sub_resellers`, `alter_packages_ids`, `alter_packages_prices`, `reseller_client_connection_logs`, `reseller_assign_pass`, `allow_change_pass`, `allow_import`, `allow_export`, `reseller_trial_credit_allow`, `edit_mac`, `edit_isplock`, `reset_stb_data`, `reseller_bonus_package_inc`, `allow_download`, `minimum_trial_credits`) VALUES (1,'Channel Admin','#FF0000',0,1,0,0,'day',0,'[\"add_stream\",\"edit_stream\",\"streams\",\"archive\",\"add_movie\",\"edit_movie\",\"import_movies\",\"filexplorer\",\"movies\",\"add_series\",\"series_list\",\"edit_series\",\"add_episode\",\"edit_episode\",\"import_episodes\",\"series\",\"add_radio\",\"edit_radio\",\"radio\",\"create_channel\",\"edit_cchannel\",\"manage_cchannels\",\"mass_sedits\",\"mass_sedits_vod\",\"epg\",\"epg_edit\",\"tprofiles\",\"categories\",\"edit_cat\",\"stream_tools\",\"add_bouquet\",\"edit_bouquet\",\"bouquets\"]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0),(2,'Registered Users','#66FF66',0,0,0,0,'',0,'',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0),(3,'Banned','#194775',1,0,0,0,'',0,'',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0),(4,'Resellers','#FF9933',0,0,1,100000,'month',0,'[]',0,0,0,1,1,0,1,1,1,1,0,1,1,1,1,0,1,0);
/*!40000 ALTER TABLE `member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_containers`
--

DROP TABLE IF EXISTS `movie_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_containers` (
  `container_id` int(11) NOT NULL AUTO_INCREMENT,
  `container_extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `container_header` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`container_id`),
  KEY `container_extension` (`container_extension`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_containers`
--

LOCK TABLES `movie_containers` WRITE;
/*!40000 ALTER TABLE `movie_containers` DISABLE KEYS */;
/*!40000 ALTER TABLE `movie_containers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_trial` tinyint(4) NOT NULL,
  `is_official` tinyint(4) NOT NULL,
  `trial_credits` float NOT NULL,
  `official_credits` float NOT NULL,
  `trial_duration` int(11) NOT NULL,
  `trial_duration_in` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `official_duration` int(11) NOT NULL,
  `official_duration_in` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `groups` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `bouquets` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `can_gen_mag` tinyint(4) NOT NULL DEFAULT '0',
  `only_mag` tinyint(4) NOT NULL DEFAULT '0',
  `output_formats` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `is_isplock` tinyint(4) NOT NULL DEFAULT '0',
  `max_connections` int(11) NOT NULL DEFAULT '1',
  `is_restreamer` tinyint(4) NOT NULL DEFAULT '0',
  `force_server_id` int(11) NOT NULL DEFAULT '0',
  `can_gen_e2` tinyint(4) NOT NULL DEFAULT '0',
  `only_e2` tinyint(4) NOT NULL DEFAULT '0',
  `forced_country` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `lock_device` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_trial` (`is_trial`),
  KEY `is_official` (`is_official`),
  KEY `can_gen_mag` (`can_gen_mag`),
  KEY `can_gen_e2` (`can_gen_e2`),
  KEY `only_e2` (`only_e2`),
  KEY `only_mag` (`only_mag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel_logs`
--

DROP TABLE IF EXISTS `panel_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panel_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel_logs`
--

LOCK TABLES `panel_logs` WRITE;
/*!40000 ALTER TABLE `panel_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reg_userlog`
--

DROP TABLE IF EXISTS `reg_userlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reg_userlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL,
  `username` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `password` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `date` int(30) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reg_userlog`
--

LOCK TABLES `reg_userlog` WRITE;
/*!40000 ALTER TABLE `reg_userlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `reg_userlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reg_users`
--

DROP TABLE IF EXISTS `reg_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reg_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_registered` int(11) NOT NULL,
  `verify_key` mediumtext COLLATE utf8_unicode_ci,
  `last_login` int(11) DEFAULT NULL,
  `member_group_id` int(11) NOT NULL,
  `verified` int(11) NOT NULL DEFAULT '0',
  `credits` float NOT NULL DEFAULT '0',
  `notes` mediumtext COLLATE utf8_unicode_ci,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `default_lang` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `reseller_dns` text COLLATE utf8_unicode_ci NOT NULL,
  `owner_id` int(11) NOT NULL DEFAULT '0',
  `override_packages` text COLLATE utf8_unicode_ci,
  `google_2fa_sec` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dark_mode` int(1) NOT NULL DEFAULT '0',
  `sidebar` int(1) NOT NULL DEFAULT '0',
  `expanded_sidebar` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `member_group_id` (`member_group_id`),
  KEY `username` (`username`),
  KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reg_users`
--

LOCK TABLES `reg_users` WRITE;
/*!40000 ALTER TABLE `reg_users` DISABLE KEYS */;
INSERT INTO `reg_users` (`id`, `username`, `password`, `email`, `ip`, `date_registered`, `verify_key`, `last_login`, `member_group_id`, `verified`, `credits`, `notes`, `status`, `default_lang`, `reseller_dns`, `owner_id`, `override_packages`, `google_2fa_sec`, `dark_mode`, `sidebar`, `expanded_sidebar`) VALUES (1,'admin','$6$rounds=20000$xtreamcodes$XThC5OwfuS0YwS4ahiifzF14vkGbGsFF1w7ETL4sRRC5sOrAWCjWvQJDromZUQoQuwbAXAFdX3h3Cp3vqulpS0','admin@website.com','105.155.54.150',0,NULL,1618024842,1,1,0,NULL,1,'','',0,NULL,'',0,0,0);
/*!40000 ALTER TABLE `reg_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reseller_imex`
--

DROP TABLE IF EXISTS `reseller_imex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reseller_imex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reg_id` int(11) NOT NULL,
  `header` longtext NOT NULL,
  `data` longtext NOT NULL,
  `accepted` tinyint(4) NOT NULL DEFAULT '0',
  `finished` tinyint(4) NOT NULL DEFAULT '0',
  `bouquet_ids` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reg_id` (`reg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reseller_imex`
--

LOCK TABLES `reseller_imex` WRITE;
/*!40000 ALTER TABLE `reseller_imex` DISABLE KEYS */;
/*!40000 ALTER TABLE `reseller_imex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rtmp_ips`
--

DROP TABLE IF EXISTS `rtmp_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rtmp_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rtmp_ips`
--

LOCK TABLES `rtmp_ips` WRITE;
/*!40000 ALTER TABLE `rtmp_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `rtmp_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `series`
--

DROP TABLE IF EXISTS `series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `series` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `cover` varchar(255) NOT NULL,
  `cover_big` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `plot` text NOT NULL,
  `cast` text NOT NULL,
  `rating` int(11) NOT NULL,
  `director` varchar(255) NOT NULL,
  `releaseDate` varchar(255) NOT NULL,
  `last_modified` int(11) NOT NULL,
  `tmdb_id` int(11) NOT NULL,
  `seasons` mediumtext NOT NULL,
  `episode_run_time` int(11) NOT NULL DEFAULT '0',
  `backdrop_path` text NOT NULL,
  `youtube_trailer` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `last_modified` (`last_modified`),
  KEY `tmdb_id` (`tmdb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `series`
--

LOCK TABLES `series` WRITE;
/*!40000 ALTER TABLE `series` DISABLE KEYS */;
/*!40000 ALTER TABLE `series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `series_episodes`
--

DROP TABLE IF EXISTS `series_episodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `series_episodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `season_num` int(11) NOT NULL,
  `series_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `season_num` (`season_num`),
  KEY `series_id` (`series_id`),
  KEY `stream_id` (`stream_id`),
  KEY `sort` (`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `series_episodes`
--

LOCK TABLES `series_episodes` WRITE;
/*!40000 ALTER TABLE `series_episodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `series_episodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_activity`
--

DROP TABLE IF EXISTS `server_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_server_id` int(11) NOT NULL,
  `dest_server_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `bandwidth` int(11) NOT NULL DEFAULT '0',
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `source_server_id` (`source_server_id`),
  KEY `dest_server_id` (`dest_server_id`),
  KEY `stream_id` (`stream_id`),
  KEY `pid` (`pid`),
  KEY `date_end` (`date_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_activity`
--

LOCK TABLES `server_activity` WRITE;
/*!40000 ALTER TABLE `server_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `bouquet_name` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `live_streaming_pass` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `email_verify_sub` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `email_verify_cont` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `email_forgot_sub` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `email_forgot_cont` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `mail_from` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `smtp_host` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `smtp_port` int(11) NOT NULL,
  `min_password` int(11) NOT NULL DEFAULT '5',
  `username_strlen` int(11) NOT NULL DEFAULT '15',
  `username_alpha` int(11) NOT NULL DEFAULT '1',
  `allow_multiple_accs` int(11) NOT NULL DEFAULT '0',
  `allow_registrations` int(11) NOT NULL DEFAULT '0',
  `server_name` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `smtp_username` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `smtp_password` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `email_new_pass_sub` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `logo_url` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `email_new_pass_cont` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `smtp_from_name` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `confirmation_email` int(11) NOT NULL,
  `smtp_encryption` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `unique_id` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `copyrights_removed` tinyint(4) NOT NULL,
  `copyrights_text` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `default_timezone` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Europe/Athens',
  `default_locale` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en_GB.utf8',
  `allowed_stb_types` text COLLATE utf8_unicode_ci NOT NULL,
  `client_prebuffer` int(11) NOT NULL,
  `split_clients` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `stream_max_analyze` int(11) NOT NULL DEFAULT '30',
  `show_not_on_air_video` tinyint(4) NOT NULL,
  `not_on_air_video_path` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `show_banned_video` tinyint(4) NOT NULL,
  `banned_video_path` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `show_expired_video` tinyint(4) NOT NULL,
  `expired_video_path` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `mag_container` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `probesize` int(11) NOT NULL DEFAULT '5000000',
  `allowed_ips_admin` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `block_svp` tinyint(4) NOT NULL DEFAULT '0',
  `allow_countries` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `user_auto_kick_hours` int(11) NOT NULL DEFAULT '0',
  `show_in_red_online` int(11) NOT NULL DEFAULT '0',
  `disallow_empty_user_agents` tinyint(4) DEFAULT '0',
  `show_all_category_mag` tinyint(4) NOT NULL DEFAULT '1',
  `default_lang` mediumtext COLLATE utf8_unicode_ci,
  `autobackup_status` int(11) NOT NULL DEFAULT '0',
  `autobackup_pass` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `flood_limit` int(11) NOT NULL DEFAULT '0',
  `flood_ips_exclude` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `reshare_deny_addon` tinyint(4) NOT NULL DEFAULT '0',
  `restart_http` tinyint(4) NOT NULL DEFAULT '0',
  `css_layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `flood_seconds` int(11) NOT NULL DEFAULT '5',
  `flood_max_attempts` int(11) NOT NULL DEFAULT '1',
  `flood_apply_clients` int(11) NOT NULL DEFAULT '1',
  `flood_apply_restreamers` int(11) NOT NULL DEFAULT '0',
  `backup_source_all` int(11) NOT NULL DEFAULT '0',
  `flood_get_block` int(11) NOT NULL DEFAULT '0',
  `portal_block` int(11) NOT NULL DEFAULT '0',
  `streaming_block` int(11) NOT NULL DEFAULT '0',
  `stream_start_delay` int(11) NOT NULL DEFAULT '20000',
  `hash_lb` tinyint(4) NOT NULL DEFAULT '1',
  `vod_bitrate_plus` int(11) NOT NULL DEFAULT '60',
  `read_buffer_size` int(11) NOT NULL DEFAULT '8192',
  `tv_channel_default_aspect` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'fit',
  `playback_limit` int(11) NOT NULL DEFAULT '3',
  `show_tv_channel_logo` tinyint(4) NOT NULL DEFAULT '1',
  `show_channel_logo_in_preview` tinyint(4) NOT NULL DEFAULT '1',
  `enable_connection_problem_indication` tinyint(4) NOT NULL DEFAULT '1',
  `enable_pseudo_hls` tinyint(4) NOT NULL DEFAULT '1',
  `vod_limit_at` int(11) NOT NULL DEFAULT '0',
  `client_area_plugin` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'flow',
  `persistent_connections` tinyint(4) NOT NULL DEFAULT '0',
  `record_max_length` int(11) NOT NULL DEFAULT '180',
  `total_records_length` int(11) NOT NULL DEFAULT '600',
  `max_local_recordings` int(11) NOT NULL DEFAULT '10',
  `allowed_stb_types_for_local_recording` text COLLATE utf8_unicode_ci NOT NULL,
  `allowed_stb_types_rec` text COLLATE utf8_unicode_ci NOT NULL,
  `show_captcha` int(11) NOT NULL DEFAULT '1',
  `dynamic_timezone` tinyint(4) NOT NULL DEFAULT '1',
  `stalker_theme` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'digital',
  `rtmp_random` tinyint(4) NOT NULL DEFAULT '1',
  `api_ips` text COLLATE utf8_unicode_ci NOT NULL,
  `crypt_load_balancing` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `use_buffer` tinyint(4) NOT NULL DEFAULT '0',
  `restreamer_prebuffer` tinyint(4) NOT NULL DEFAULT '0',
  `audio_restart_loss` tinyint(4) NOT NULL DEFAULT '0',
  `stalker_lock_images` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `channel_number_type` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'bouquet',
  `stb_change_pass` tinyint(4) NOT NULL DEFAULT '0',
  `enable_debug_stalker` tinyint(4) NOT NULL DEFAULT '0',
  `online_capacity_interval` smallint(6) NOT NULL DEFAULT '10',
  `always_enabled_subtitles` tinyint(4) NOT NULL DEFAULT '1',
  `test_download_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `xc_support_allow` tinyint(4) NOT NULL DEFAULT '1',
  `e2_arm7a` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `e2_mipsel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `e2_mips32el` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `e2_sh4` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `e2_arm` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `api_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message_of_day` text COLLATE utf8_unicode_ci NOT NULL,
  `double_auth` tinyint(4) NOT NULL DEFAULT '0',
  `mysql_remote_sec` tinyint(4) NOT NULL DEFAULT '0',
  `enable_isp_lock` tinyint(4) NOT NULL DEFAULT '0',
  `show_isps` tinyint(4) NOT NULL DEFAULT '1',
  `userpanel_mainpage` longtext COLLATE utf8_unicode_ci NOT NULL,
  `save_closed_connection` tinyint(4) NOT NULL DEFAULT '1',
  `client_logs_save` tinyint(4) NOT NULL DEFAULT '1',
  `get_real_ip_client` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `case_sensitive_line` tinyint(4) NOT NULL DEFAULT '1',
  `county_override_1st` tinyint(4) NOT NULL DEFAULT '0',
  `disallow_2nd_ip_con` tinyint(4) NOT NULL DEFAULT '0',
  `firewall` tinyint(4) NOT NULL DEFAULT '0',
  `new_sorting_bouquet` tinyint(4) NOT NULL DEFAULT '1',
  `split_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'con',
  `use_mdomain_in_lists` tinyint(4) NOT NULL DEFAULT '0',
  `use_https` text COLLATE utf8_unicode_ci NOT NULL,
  `priority_backup` tinyint(4) NOT NULL DEFAULT '0',
  `use_buffer_table` tinyint(4) NOT NULL DEFAULT '0',
  `tmdb_api_key` text COLLATE utf8_unicode_ci NOT NULL,
  `toggle_menu` tinyint(4) NOT NULL DEFAULT '0',
  `mobile_apps` tinyint(4) NOT NULL DEFAULT '0',
  `stalker_container_priority` text COLLATE utf8_unicode_ci NOT NULL,
  `gen_container_priority` text COLLATE utf8_unicode_ci NOT NULL,
  `tmdb_default` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `series_custom_name` tinyint(4) NOT NULL DEFAULT '0',
  `mag_security` tinyint(4) NOT NULL DEFAULT '0',
  `crack_users` tinyint(4) NOT NULL,
  `crack_users_times` tinyint(4) NOT NULL,
  `crack_mag` tinyint(4) NOT NULL,
  `crack_mag_times` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `bouquet_name`, `live_streaming_pass`, `email_verify_sub`, `email_verify_cont`, `email_forgot_sub`, `email_forgot_cont`, `mail_from`, `smtp_host`, `smtp_port`, `min_password`, `username_strlen`, `username_alpha`, `allow_multiple_accs`, `allow_registrations`, `server_name`, `smtp_username`, `smtp_password`, `email_new_pass_sub`, `logo_url`, `email_new_pass_cont`, `smtp_from_name`, `confirmation_email`, `smtp_encryption`, `unique_id`, `copyrights_removed`, `copyrights_text`, `default_timezone`, `default_locale`, `allowed_stb_types`, `client_prebuffer`, `split_clients`, `stream_max_analyze`, `show_not_on_air_video`, `not_on_air_video_path`, `show_banned_video`, `banned_video_path`, `show_expired_video`, `expired_video_path`, `mag_container`, `probesize`, `allowed_ips_admin`, `block_svp`, `allow_countries`, `user_auto_kick_hours`, `show_in_red_online`, `disallow_empty_user_agents`, `show_all_category_mag`, `default_lang`, `autobackup_status`, `autobackup_pass`, `flood_limit`, `flood_ips_exclude`, `reshare_deny_addon`, `restart_http`, `css_layout`, `flood_seconds`, `flood_max_attempts`, `flood_apply_clients`, `flood_apply_restreamers`, `backup_source_all`, `flood_get_block`, `portal_block`, `streaming_block`, `stream_start_delay`, `hash_lb`, `vod_bitrate_plus`, `read_buffer_size`, `tv_channel_default_aspect`, `playback_limit`, `show_tv_channel_logo`, `show_channel_logo_in_preview`, `enable_connection_problem_indication`, `enable_pseudo_hls`, `vod_limit_at`, `client_area_plugin`, `persistent_connections`, `record_max_length`, `total_records_length`, `max_local_recordings`, `allowed_stb_types_for_local_recording`, `allowed_stb_types_rec`, `show_captcha`, `dynamic_timezone`, `stalker_theme`, `rtmp_random`, `api_ips`, `crypt_load_balancing`, `use_buffer`, `restreamer_prebuffer`, `audio_restart_loss`, `stalker_lock_images`, `channel_number_type`, `stb_change_pass`, `enable_debug_stalker`, `online_capacity_interval`, `always_enabled_subtitles`, `test_download_url`, `xc_support_allow`, `e2_arm7a`, `e2_mipsel`, `e2_mips32el`, `e2_sh4`, `e2_arm`, `api_pass`, `message_of_day`, `double_auth`, `mysql_remote_sec`, `enable_isp_lock`, `show_isps`, `userpanel_mainpage`, `save_closed_connection`, `client_logs_save`, `get_real_ip_client`, `case_sensitive_line`, `county_override_1st`, `disallow_2nd_ip_con`, `firewall`, `new_sorting_bouquet`, `split_by`, `use_mdomain_in_lists`, `use_https`, `priority_backup`, `use_buffer_table`, `tmdb_api_key`, `toggle_menu`, `mobile_apps`, `stalker_container_priority`, `gen_container_priority`, `tmdb_default`, `series_custom_name`, `mag_security`, `crack_users`, `crack_users_times`, `crack_mag`, `crack_mag_times`) VALUES (1,'Xtream Codes','N7jb4TXQTQwmvKCTPQDs','Verify Registration @ {SERVER_NAME}','','','','','',0,0,0,0,0,0,'Xtream Codes','','','','','','',0,'no','',0,'Xtream Codes','Europe/London','en_GB.utf8','[\"MAG200\",\"MAG322\",\"MAG323\",\"MAG324\",\"MAG325\",\"MAG349\",\"MAG350\",\"MAG351\",\"MAG352\",\"MAG245\",\"MAG245D\",\"MAG250\",\"MAG254\",\"MAG255\",\"MAG256\",\"MAG257\",\"MAG260\",\"MAG270\",\"MAG275\",\"AuraHD\",\"AuraHD2\",\"AuraHD3\",\"AuraHD4\",\"AuraHD5\",\"AuraHD6\",\"AuraHD7\",\"AuraHD8\",\"AuraHD9\",\"WR320\"]',10,'equal',5000000,0,'',0,'',0,'','ts',5000000,'',0,'[\"ALL\",\"O1\",\"AF\",\"AX\",\"AL\",\"DZ\",\"AS\",\"AD\",\"AO\",\"AI\",\"AQ\",\"AG\",\"AR\",\"AM\",\"AW\",\"AU\",\"AT\",\"AZ\",\"BS\",\"BH\",\"BD\",\"BB\",\"BY\",\"BE\",\"BZ\",\"BJ\",\"BM\",\"BT\",\"BO\",\"BA\",\"BW\",\"BV\",\"BR\",\"IO\",\"BN\",\"BG\",\"BF\",\"BI\",\"KH\",\"CM\",\"CA\",\"CV\",\"KY\",\"CF\",\"TD\",\"CL\",\"CN\",\"CX\",\"CC\",\"CO\",\"KM\",\"CG\",\"CD\",\"CK\",\"CR\",\"CI\",\"HR\",\"CU\",\"CY\",\"CZ\",\"DK\",\"DJ\",\"DM\",\"DO\",\"EC\",\"EG\",\"SV\",\"GQ\",\"ER\",\"EE\",\"ET\",\"FK\",\"FO\",\"FJ\",\"FI\",\"FR\",\"GF\",\"PF\",\"TF\",\"MK\",\"GA\",\"GM\",\"GE\",\"DE\",\"GH\",\"GI\",\"GR\",\"GL\",\"GD\",\"GP\",\"GU\",\"GT\",\"GG\",\"GN\",\"GW\",\"GY\",\"HT\",\"HM\",\"VA\",\"HN\",\"HK\",\"HU\",\"IS\",\"IN\",\"ID\",\"IR\",\"IQ\",\"IE\",\"IM\",\"IL\",\"IT\",\"JM\",\"JP\",\"JE\",\"JO\",\"KZ\",\"KE\",\"KI\",\"KR\",\"KW\",\"KG\",\"LA\",\"LV\",\"LB\",\"LS\",\"LR\",\"LY\",\"LI\",\"LT\",\"LU\",\"MO\",\"MG\",\"MW\",\"MY\",\"MV\",\"ML\",\"MT\",\"MH\",\"MQ\",\"MR\",\"MU\",\"YT\",\"MX\",\"FM\",\"MD\",\"MC\",\"MN\",\"ME\",\"MS\",\"MA\",\"MZ\",\"MM\",\"NA\",\"NR\",\"NP\",\"NL\",\"AN\",\"NC\",\"NZ\",\"NI\",\"NE\",\"NG\",\"NU\",\"NF\",\"MP\",\"NO\",\"OM\",\"PK\",\"PW\",\"PS\",\"PA\",\"PG\",\"PY\",\"PE\",\"PH\",\"PN\",\"PL\",\"PT\",\"PR\",\"QA\",\"RE\",\"RO\",\"RU\",\"RW\",\"BL\",\"SH\",\"KN\",\"LC\",\"MF\",\"PM\",\"VC\",\"WS\",\"SM\",\"ST\",\"SA\",\"SN\",\"RS\",\"SC\",\"SL\",\"SG\",\"SK\",\"SI\",\"SB\",\"SO\",\"ZA\",\"GS\",\"ES\",\"LK\",\"SD\",\"SR\",\"SJ\",\"SZ\",\"SE\",\"CH\",\"SY\",\"TW\",\"TJ\",\"TZ\",\"TH\",\"TL\",\"TG\",\"TK\",\"TO\",\"TT\",\"TN\",\"TR\",\"TM\",\"TC\",\"TV\",\"UG\",\"UA\",\"AE\",\"GB\",\"US\",\"UM\",\"UY\",\"UZ\",\"VU\",\"VE\",\"VN\",\"VG\",\"VI\",\"WF\",\"EH\",\"YE\",\"ZM\",\"ZW\"]',0,0,0,1,'English',0,'',0,'',0,0,'light',0,3,0,0,0,0,0,0,0,0,200,8192,'fit',3,1,1,1,1,0,'flow',1,180,600,10,'[\"MAG255\",\"MAG256\",\"MAG257\"]','false',1,1,'default',1,'127.0.0.1,192.99.0.109','r0kd5D9i0JL34BwpgER3',0,0,0,'','bouquet',1,0,10,0,'',0,'','','','','','','Welcome to Xtream Codes Reborn',1,0,0,1,'[]',1,1,'',1,0,0,0,1,'con',0,'false',0,0,'',0,0,'[\"mp4\",\"mkv\",\"avi\"]','[\"mp4\",\"mkv\",\"avi\"]','en',0,1,0,0,0,0);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signals`
--

DROP TABLE IF EXISTS `signals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signals` (
  `signal_id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `rtmp` tinyint(4) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  PRIMARY KEY (`signal_id`),
  KEY `server_id` (`server_id`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signals`
--

LOCK TABLES `signals` WRITE;
/*!40000 ALTER TABLE `signals` DISABLE KEYS */;
/*!40000 ALTER TABLE `signals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_admin`
--

DROP TABLE IF EXISTS `solus_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_admin` (
  `adminid` int(11) NOT NULL AUTO_INCREMENT,
  `main_father` int(11) NOT NULL,
  `father` int(5) NOT NULL,
  `level` int(11) NOT NULL,
  `admin_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adm_username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adm_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `site` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` int(10) NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `brand` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` blob,
  `host` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_group_id` smallint(6) NOT NULL,
  `packages` text COLLATE utf8_unicode_ci,
  `regdate` datetime NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lastlogin` datetime NOT NULL,
  `type` int(2) NOT NULL,
  `super` int(1) NOT NULL,
  `group_id` int(5) NOT NULL,
  `suspend` tinyint(1) NOT NULL,
  `reset` int(1) NOT NULL,
  `postpaid` tinyint(1) NOT NULL,
  `no_invoice` tinyint(1) NOT NULL,
  `cost_1` float NOT NULL,
  `cost_3` float NOT NULL,
  `cost_6` float NOT NULL,
  `cost_12` float NOT NULL,
  `cost_24` float NOT NULL,
  `cost_36` float NOT NULL,
  `balance` float NOT NULL,
  `resel_bouquets` text COLLATE utf8_unicode_ci,
  `can_add_resel` tinyint(4) NOT NULL,
  `can_add_codes` tinyint(1) NOT NULL,
  `can_add_users` tinyint(1) NOT NULL,
  `can_add_mag` tinyint(1) NOT NULL,
  `can_add_e2` tinyint(1) NOT NULL,
  `can_add_free` tinyint(1) NOT NULL,
  `num_free` int(3) NOT NULL,
  `extra_free_days` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `can_add_mac` tinyint(1) NOT NULL,
  `can_add_sn` tinyint(1) NOT NULL,
  `can_delete` tinyint(1) NOT NULL,
  `can_change` tinyint(1) NOT NULL,
  `can_m3u` tinyint(4) NOT NULL,
  `can_m3u_mag` tinyint(1) NOT NULL,
  `can_set_country` tinyint(4) NOT NULL,
  `can_set_pass` tinyint(4) NOT NULL,
  `can_set_mac_opt` tinyint(4) NOT NULL,
  `act_count` tinyint(4) NOT NULL,
  `stb_groups` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `can_add_free_1` tinyint(1) NOT NULL,
  `can_add_free_3` tinyint(1) NOT NULL,
  `can_add_free_7` tinyint(1) NOT NULL,
  `can_add_free_10` tinyint(1) NOT NULL,
  `cost_1_enabled` tinyint(1) NOT NULL,
  `cost_3_enabled` tinyint(1) NOT NULL,
  `cost_6_enabled` tinyint(1) NOT NULL,
  `cost_12_enabled` tinyint(1) NOT NULL,
  `cost_24_enabled` tinyint(1) NOT NULL,
  `cost_36_enabled` tinyint(1) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `allowed_ips` text COLLATE utf8_unicode_ci,
  `msg_welcome` text COLLATE utf8_unicode_ci,
  `manage_vod` tinyint(4) DEFAULT NULL,
  `manage_streams` tinyint(4) DEFAULT NULL,
  `stat_codes` text COLLATE utf8_unicode_ci,
  `manage_bq` tinyint(1) DEFAULT NULL,
  `manage_cats` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`adminid`),
  UNIQUE KEY `user_name` (`adm_username`),
  KEY `adm_password` (`adm_password`),
  KEY `type` (`type`),
  KEY `user_agent` (`user_agent`),
  KEY `member_group_id` (`member_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_admin`
--

LOCK TABLES `solus_admin` WRITE;
/*!40000 ALTER TABLE `solus_admin` DISABLE KEYS */;
INSERT INTO `solus_admin` (`adminid`, `main_father`, `father`, `level`, `admin_name`, `adm_username`, `adm_password`, `email`, `fullname`, `site`, `country`, `city`, `tel`, `brand`, `logo`, `host`, `member_group_id`, `packages`, `regdate`, `ipaddress`, `user_agent`, `lastlogin`, `type`, `super`, `group_id`, `suspend`, `reset`, `postpaid`, `no_invoice`, `cost_1`, `cost_3`, `cost_6`, `cost_12`, `cost_24`, `cost_36`, `balance`, `resel_bouquets`, `can_add_resel`, `can_add_codes`, `can_add_users`, `can_add_mag`, `can_add_e2`, `can_add_free`, `num_free`, `extra_free_days`, `can_add_mac`, `can_add_sn`, `can_delete`, `can_change`, `can_m3u`, `can_m3u_mag`, `can_set_country`, `can_set_pass`, `can_set_mac_opt`, `act_count`, `stb_groups`, `can_add_free_1`, `can_add_free_3`, `can_add_free_7`, `can_add_free_10`, `cost_1_enabled`, `cost_3_enabled`, `cost_6_enabled`, `cost_12_enabled`, `cost_24_enabled`, `cost_36_enabled`, `notes`, `allowed_ips`, `msg_welcome`, `manage_vod`, `manage_streams`, `stat_codes`, `manage_bq`, `manage_cats`) VALUES (1,0,0,1,'admin','admin','3c2235ad0156d423c4f7f89718c54f8a','kulvcfhgc@gmail.com','','',0,'','','','','',0,'[]','2014-03-06 14:11:12','105.155.54.150','f26ee53bbaef58ca86e8042e20782598','2021-04-10 05:20:19',1,1,0,0,0,1,0,0,0.25,0.5,1,2,3,100000,'1',1,1,1,1,1,1,-1,'',1,1,1,1,1,1,1,1,1,0,'',1,1,1,1,0,1,1,1,1,1,'hi admin','','',1,1,NULL,1,1);
/*!40000 ALTER TABLE `solus_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_admin_groups`
--

DROP TABLE IF EXISTS `solus_admin_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_admin_groups` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT,
  `g_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`g_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_admin_groups`
--

LOCK TABLES `solus_admin_groups` WRITE;
/*!40000 ALTER TABLE `solus_admin_groups` DISABLE KEYS */;
INSERT INTO `solus_admin_groups` (`g_id`, `g_name`) VALUES (1,'TEST');
/*!40000 ALTER TABLE `solus_admin_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_bq_col`
--

DROP TABLE IF EXISTS `solus_bq_col`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_bq_col` (
  `bq` int(11) NOT NULL,
  `ch` int(11) NOT NULL,
  KEY `bq` (`bq`),
  KEY `ch` (`ch`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_bq_col`
--

LOCK TABLES `solus_bq_col` WRITE;
/*!40000 ALTER TABLE `solus_bq_col` DISABLE KEYS */;
INSERT INTO `solus_bq_col` (`bq`, `ch`) VALUES (1,106),(1,105),(1,89),(1,83),(1,86),(1,121),(1,122),(1,77),(1,69),(1,103),(1,78),(1,72),(1,120),(1,102),(1,101),(1,116),(1,117),(1,92),(1,114),(1,73),(1,70),(1,74),(1,75),(1,84),(1,95),(1,96),(1,108),(1,109),(1,110),(1,111),(1,113),(1,118),(1,119),(1,107),(1,115),(1,98),(1,87),(1,99),(1,82),(1,100),(1,71),(1,79),(1,80),(1,81),(1,112),(1,85),(1,91),(1,94),(1,97),(1,104),(1,88),(1,76),(1,93),(1,90);
/*!40000 ALTER TABLE `solus_bq_col` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_codes`
--

DROP TABLE IF EXISTS `solus_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `code_replaced` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `bouquets` text COLLATE utf8_unicode_ci NOT NULL,
  `days` int(11) NOT NULL,
  `period` int(3) NOT NULL,
  `pkg` smallint(6) NOT NULL,
  `free_days` int(3) NOT NULL,
  `date_start` int(11) NOT NULL,
  `date_expire` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `adminid` int(11) NOT NULL,
  `subresel` int(11) NOT NULL,
  `transid` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `last_update` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `userid` int(11) NOT NULL,
  `mac` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mac2` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `mac_type` tinyint(1) NOT NULL,
  `serial` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_free` tinyint(1) NOT NULL,
  `forced_country` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_uagent` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `osd_msg` text COLLATE utf8_unicode_ci NOT NULL,
  `osd_stat` tinyint(1) NOT NULL,
  `inputBy` tinyint(1) NOT NULL,
  `mobile` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `StbToIPTV` tinyint(4) NOT NULL,
  `is_mag` tinyint(1) NOT NULL,
  `groupID` int(4) NOT NULL,
  `islam_pkg` tinyint(1) NOT NULL,
  `model` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `output` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `protocol` smallint(6) DEFAULT NULL,
  `act_count` tinyint(4) NOT NULL,
  `act_limit` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `days` (`days`),
  KEY `adminid` (`adminid`),
  KEY `transid` (`transid`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `mac` (`mac`,`serial`),
  KEY `code` (`code`),
  KEY `mac2` (`mac2`),
  KEY `period` (`period`),
  KEY `subresel` (`subresel`),
  KEY `pkg` (`pkg`),
  KEY `date_expire` (`date_expire`)
) ENGINE=MyISAM AUTO_INCREMENT=2747 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_codes`
--

LOCK TABLES `solus_codes` WRITE;
/*!40000 ALTER TABLE `solus_codes` DISABLE KEYS */;
INSERT INTO `solus_codes` (`id`, `fullname`, `code`, `username`, `code_replaced`, `bouquets`, `days`, `period`, `pkg`, `free_days`, `date_start`, `date_expire`, `adminid`, `subresel`, `transid`, `status`, `last_update`, `userid`, `mac`, `mac2`, `mac_type`, `serial`, `is_free`, `forced_country`, `allowed_uagent`, `osd_msg`, `osd_stat`, `inputBy`, `mobile`, `notes`, `StbToIPTV`, `is_mag`, `groupID`, `islam_pkg`, `model`, `output`, `protocol`, `act_count`, `act_limit`) VALUES (2743,'otmano1','334067548682','','','1,2',10,110,0,0,1617643376,'1618507376',1,0,0,1,'',13,'5E:10:3C:AB:2C:51','',0,'5E:10:3C:AB:2C:51',1,'','','',0,0,'867586473','',0,0,0,0,'Samsung SM-G988U1','ts',6,0,0),(2746,'ugyyjgcf','195578039187','','','1,2,3',10,110,0,0,1618022478,'1618886478',1,0,0,1,'',15,'76:C5:F4:3B:6E:90','',0,'76:C5:F4:3B:6E:90',1,'','','',0,0,'867586473','',0,0,0,0,'OnePlus ONEPLUS A5000','ts',6,0,0),(2745,'mahdi','113708708363','','','1,2',3,103,0,0,1617645287,'1617904487',1,0,0,4,'',14,'02:C7:4E:5A:6A:69','',0,'02:C7:4E:5A:6A:69',1,'','','',0,0,'867586473','',0,0,0,0,'Samsung SM-G988B','ts',6,0,0),(2740,'tEST apP','284743215232','','','1,2',3,103,0,0,1617642661,'1617901861',1,0,12,4,'',12,'76:C5:F4:3B:6E:90','',0,'76:C5:F4:3B:6E:90',1,'','','',0,0,'867586473','',0,0,0,0,'OnePlus ONEPLUS A5000','ts',6,0,0),(2739,'otman','104534231985','','','1',7,107,0,0,1617471452,'1618076252',1,0,0,1,'',9,'5E:10:3C:AB:2C:51','',0,'5E:10:3C:AB:2C:51',1,'','','',0,0,'867586473','',0,0,0,0,'Samsung SM-G988U1','ts',6,0,0),(2738,'منيربلجيكا','195516988720','','','1',7,107,0,0,1617470220,'1618075020',1,0,0,1,'',8,'76:C5:F4:3B:6E:90','',0,'76:C5:F4:3B:6E:90',1,'','','',0,0,'867586473','',0,0,0,0,'OnePlus ONEPLUS A5000','ts',6,0,0),(2737,'testapk','1004187187','','','1',3,103,0,0,1617469303,'1617728503',1,0,0,4,'',6,'76:C5:F4:3B:6E:90','',0,'76:C5:F4:3B:6E:90',1,'','','',0,0,'867586473','',0,0,0,0,'OnePlus ONEPLUS A5000','ts',6,0,0),(2736,'testapk','2318069764','','','1',7,107,0,0,1617469111,'1618073911',1,0,0,1,'',5,'76:C5:F4:3B:6E:90','',0,'76:C5:F4:3B:6E:90',1,'','','',0,0,'867586473','',0,0,0,0,'OnePlus ONEPLUS A5000','ts',6,0,0),(2735,'testapk','179706940524','','','1',3,103,0,0,1617468605,'1617727805',1,0,0,4,'',4,'76:C5:F4:3B:6E:90','',0,'76:C5:F4:3B:6E:90',1,'','','',0,0,'867586473','',0,0,0,0,'OnePlus ONEPLUS A5000','ts',6,0,0);
/*!40000 ALTER TABLE `solus_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_codes_change`
--

DROP TABLE IF EXISTS `solus_codes_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_codes_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_id` int(11) NOT NULL,
  `old_code` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `new_code` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `reseller` int(11) NOT NULL,
  `dtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `old_code` (`old_code`),
  KEY `new_code` (`new_code`),
  KEY `reseller` (`reseller`),
  KEY `code_id` (`code_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_codes_change`
--

LOCK TABLES `solus_codes_change` WRITE;
/*!40000 ALTER TABLE `solus_codes_change` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_codes_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_codes_free`
--

DROP TABLE IF EXISTS `solus_codes_free`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_codes_free` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `user` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `bouquets` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `days` int(11) NOT NULL,
  `date_expire` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `mac` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `days` (`days`),
  KEY `status` (`status`),
  KEY `mac` (`mac`,`serial`),
  KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_codes_free`
--

LOCK TABLES `solus_codes_free` WRITE;
/*!40000 ALTER TABLE `solus_codes_free` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_codes_free` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_codes_master`
--

DROP TABLE IF EXISTS `solus_codes_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_codes_master` (
  `master_code` varchar(24) COLLATE utf8_unicode_ci NOT NULL,
  `master_by` tinyint(1) NOT NULL,
  UNIQUE KEY `code_by` (`master_code`,`master_by`) USING BTREE,
  KEY `master_code` (`master_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_codes_master`
--

LOCK TABLES `solus_codes_master` WRITE;
/*!40000 ALTER TABLE `solus_codes_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_codes_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_codes_trans`
--

DROP TABLE IF EXISTS `solus_codes_trans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_codes_trans` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `trans_date` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `trans_period` int(3) NOT NULL,
  `trans_free_days` int(3) NOT NULL,
  `trans_codes` int(11) NOT NULL,
  `trans_codes_length` tinyint(2) NOT NULL,
  `adminid` int(11) NOT NULL,
  PRIMARY KEY (`trans_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_codes_trans`
--

LOCK TABLES `solus_codes_trans` WRITE;
/*!40000 ALTER TABLE `solus_codes_trans` DISABLE KEYS */;
INSERT INTO `solus_codes_trans` (`trans_id`, `trans_name`, `trans_date`, `trans_period`, `trans_free_days`, `trans_codes`, `trans_codes_length`, `adminid`) VALUES (12,'tEST apP','1617641476',103,0,2,12,1);
/*!40000 ALTER TABLE `solus_codes_trans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_comments`
--

DROP TABLE IF EXISTS `solus_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `series_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `dtime` datetime NOT NULL,
  `name` varchar(150) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(30) NOT NULL,
  `theStatus` tinyint(1) NOT NULL,
  `rating_number` int(11) NOT NULL,
  `total_points` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `series_id` (`series_id`),
  KEY `movie_id` (`movie_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_comments`
--

LOCK TABLES `solus_comments` WRITE;
/*!40000 ALTER TABLE `solus_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_data`
--

DROP TABLE IF EXISTS `solus_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_data` (
  `data_id` int(11) NOT NULL AUTO_INCREMENT,
  `data_parent` int(11) NOT NULL,
  `data_type` int(11) NOT NULL,
  `series_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `data_catid` int(11) NOT NULL,
  `data_bqt` int(11) NOT NULL,
  `data_icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data_json` text COLLATE utf8_unicode_ci NOT NULL,
  `data_view_order` int(11) NOT NULL,
  `data_ch` int(11) NOT NULL,
  `data_level` int(11) NOT NULL,
  `codeid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `series_id` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  `token` varchar(265) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`data_id`),
  KEY `data_catid` (`data_catid`),
  KEY `data_bqt` (`data_bqt`),
  KEY `data_ch` (`data_ch`),
  KEY `codeid` (`codeid`),
  KEY `userid` (`userid`),
  KEY `token` (`token`),
  KEY `movie_id` (`movie_id`),
  KEY `series_id` (`series_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_data`
--

LOCK TABLES `solus_data` WRITE;
/*!40000 ALTER TABLE `solus_data` DISABLE KEYS */;
INSERT INTO `solus_data` (`data_id`, `data_parent`, `data_type`, `series_type`, `data_catid`, `data_bqt`, `data_icon`, `data_json`, `data_view_order`, `data_ch`, `data_level`, `codeid`, `userid`, `movie_id`, `series_id`, `likes`, `dislikes`, `token`) VALUES (1,0,0,'',0,0,'','',0,0,0,0,4,0,0,0,0,'2ebcc76ef09ca4faf37336119d93bada113febb12fc0d6535a207f00a79ab55e'),(2,0,1000,'',1000,1000,'bouquets','[{\"id\":\"1\",\"bouquet_name\":\"Bein Package\",\"bouquet_channels\":\"[\\\"126\\\",\\\"124\\\",\\\"123\\\",\\\"122\\\",\\\"121\\\",\\\"120\\\",\\\"119\\\",\\\"118\\\",\\\"117\\\",\\\"116\\\",\\\"115\\\",\\\"114\\\",\\\"106\\\",\\\"105\\\",\\\"104\\\",\\\"113\\\",\\\"112\\\",\\\"381\\\",\\\"84\\\",\\\"96\\\",\\\"94\\\",\\\"93\\\",\\\"95\\\",\\\"92\\\",\\\"382\\\",\\\"79\\\",\\\"91\\\",\\\"86\\\",\\\"88\\\",\\\"87\\\",\\\"129\\\",\\\"128\\\",\\\"125\\\",\\\"90\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"1\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"2\",\"bouquet_name\":\"OSN\",\"bouquet_channels\":\"[\\\"43\\\",\\\"42\\\",\\\"44\\\",\\\"51\\\",\\\"50\\\",\\\"60\\\",\\\"59\\\",\\\"58\\\",\\\"61\\\",\\\"57\\\",\\\"56\\\",\\\"41\\\",\\\"49\\\",\\\"48\\\",\\\"67\\\",\\\"66\\\",\\\"69\\\",\\\"55\\\",\\\"54\\\",\\\"53\\\",\\\"45\\\",\\\"52\\\",\\\"63\\\",\\\"65\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"12\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"3\",\"bouquet_name\":\"MyHD\",\"bouquet_channels\":\"[\\\"40\\\",\\\"39\\\",\\\"38\\\",\\\"37\\\",\\\"31\\\",\\\"32\\\",\\\"29\\\",\\\"34\\\",\\\"33\\\",\\\"36\\\",\\\"35\\\",\\\"30\\\",\\\"1\\\",\\\"12\\\",\\\"18\\\",\\\"17\\\",\\\"16\\\",\\\"23\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"11\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"4\",\"bouquet_name\":\"UK\",\"bouquet_channels\":\"[\\\"213\\\",\\\"212\\\",\\\"183\\\",\\\"182\\\",\\\"181\\\",\\\"185\\\",\\\"184\\\",\\\"203\\\",\\\"207\\\",\\\"206\\\",\\\"204\\\",\\\"205\\\",\\\"200\\\",\\\"199\\\",\\\"198\\\",\\\"197\\\",\\\"196\\\",\\\"180\\\",\\\"179\\\",\\\"178\\\",\\\"177\\\",\\\"176\\\",\\\"175\\\",\\\"195\\\",\\\"194\\\",\\\"174\\\",\\\"187\\\",\\\"211\\\",\\\"210\\\",\\\"209\\\",\\\"208\\\",\\\"186\\\",\\\"189\\\",\\\"173\\\",\\\"172\\\",\\\"188\\\",\\\"192\\\",\\\"191\\\",\\\"190\\\",\\\"193\\\",\\\"202\\\",\\\"201\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"10\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"5\",\"bouquet_name\":\"French\",\"bouquet_channels\":\"[\\\"217\\\",\\\"215\\\",\\\"214\\\",\\\"216\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"9\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"6\",\"bouquet_name\":\"Germany\",\"bouquet_channels\":\"[\\\"252\\\",\\\"253\\\",\\\"254\\\",\\\"257\\\",\\\"255\\\",\\\"256\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"8\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"7\",\"bouquet_name\":\"Turkish\",\"bouquet_channels\":\"[\\\"259\\\",\\\"260\\\",\\\"258\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"7\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"8\",\"bouquet_name\":\"Kurdish\",\"bouquet_channels\":\"[\\\"297\\\",\\\"296\\\",\\\"295\\\",\\\"294\\\",\\\"293\\\",\\\"292\\\",\\\"291\\\",\\\"290\\\",\\\"289\\\",\\\"288\\\",\\\"287\\\",\\\"286\\\",\\\"285\\\",\\\"281\\\",\\\"284\\\",\\\"282\\\",\\\"283\\\",\\\"280\\\",\\\"279\\\",\\\"278\\\",\\\"276\\\",\\\"277\\\",\\\"275\\\",\\\"274\\\",\\\"273\\\",\\\"272\\\",\\\"271\\\",\\\"270\\\",\\\"269\\\",\\\"268\\\",\\\"267\\\",\\\"266\\\",\\\"265\\\",\\\"264\\\",\\\"263\\\",\\\"262\\\",\\\"261\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"6\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"10\",\"bouquet_name\":\"Finland\",\"bouquet_channels\":\"[\\\"299\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"5\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"11\",\"bouquet_name\":\"Arabic\",\"bouquet_channels\":\"[\\\"311\\\",\\\"310\\\",\\\"309\\\",\\\"308\\\",\\\"304\\\",\\\"307\\\",\\\"303\\\",\\\"305\\\",\\\"306\\\",\\\"302\\\",\\\"300\\\",\\\"301\\\",\\\"354\\\",\\\"351\\\",\\\"353\\\",\\\"298\\\",\\\"376\\\",\\\"348\\\",\\\"347\\\",\\\"363\\\",\\\"357\\\",\\\"356\\\",\\\"358\\\",\\\"336\\\",\\\"335\\\",\\\"334\\\",\\\"333\\\",\\\"332\\\",\\\"331\\\",\\\"379\\\",\\\"349\\\",\\\"352\\\",\\\"378\\\",\\\"375\\\",\\\"342\\\",\\\"362\\\",\\\"377\\\",\\\"373\\\",\\\"372\\\",\\\"370\\\",\\\"371\\\",\\\"346\\\",\\\"361\\\",\\\"327\\\",\\\"326\\\",\\\"325\\\",\\\"330\\\",\\\"329\\\",\\\"328\\\",\\\"360\\\",\\\"343\\\",\\\"314\\\",\\\"344\\\",\\\"380\\\",\\\"338\\\",\\\"337\\\",\\\"340\\\",\\\"339\\\",\\\"318\\\",\\\"369\\\",\\\"317\\\",\\\"359\\\",\\\"355\\\",\\\"368\\\",\\\"367\\\",\\\"366\\\",\\\"374\\\",\\\"316\\\",\\\"312\\\",\\\"315\\\",\\\"341\\\",\\\"321\\\",\\\"320\\\",\\\"319\\\",\\\"323\\\",\\\"322\\\",\\\"324\\\",\\\"345\\\",\\\"350\\\",\\\"313\\\",\\\"365\\\",\\\"364\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"4\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"12\",\"bouquet_name\":\"Local Kurdish\",\"bouquet_channels\":\"[\\\"238\\\",\\\"237\\\",\\\"250\\\",\\\"251\\\",\\\"245\\\",\\\"227\\\",\\\"249\\\",\\\"244\\\",\\\"243\\\",\\\"233\\\",\\\"218\\\",\\\"234\\\",\\\"246\\\",\\\"247\\\",\\\"242\\\",\\\"226\\\",\\\"222\\\",\\\"221\\\",\\\"241\\\",\\\"239\\\",\\\"240\\\",\\\"219\\\",\\\"230\\\",\\\"231\\\",\\\"235\\\",\\\"236\\\",\\\"225\\\",\\\"228\\\",\\\"224\\\",\\\"232\\\",\\\"229\\\",\\\"248\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"3\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"13\",\"bouquet_name\":\"VOD 2019\",\"bouquet_channels\":\"[\\\"385\\\",\\\"386\\\",\\\"392\\\",\\\"383\\\",\\\"387\\\",\\\"384\\\",\\\"391\\\",\\\"388\\\",\\\"390\\\",\\\"389\\\"]\",\"bouquet_series\":\"[]\",\"bouquet_icon\":\"\",\"view_order\":\"2\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"},{\"id\":\"14\",\"bouquet_name\":\"Series\",\"bouquet_channels\":\"[]\",\"bouquet_series\":\"[\\\"2\\\",\\\"1\\\"]\",\"bouquet_icon\":\"\",\"view_order\":\"13\",\"bouquet_status\":\"1\",\"isLocked\":\"0\",\"bouquet_for\":\"0\"}]',0,0,0,0,0,0,0,0,0,NULL),(3,0,0,'',0,0,'','',0,0,0,0,11,0,0,0,0,'ca80968ce1d53584dc5d6af2b80bb5a2684d305c79f65d58edcec2252f954876'),(4,0,0,'',0,0,'','',0,0,0,0,6,0,0,0,0,'17f3a20bc35e70ac01319bbcba12fa6869503890a38d71b7c514b9a3f35b67b1');
/*!40000 ALTER TABLE `solus_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_demand`
--

DROP TABLE IF EXISTS `solus_demand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_demand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(25) NOT NULL,
  `dtime` datetime NOT NULL,
  `title` varchar(200) NOT NULL,
  `theStatus` tinyint(4) NOT NULL,
  `ip` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_demand`
--

LOCK TABLES `solus_demand` WRITE;
/*!40000 ALTER TABLE `solus_demand` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_demand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_epg`
--

DROP TABLE IF EXISTS `solus_epg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_epg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ch_local` int(11) NOT NULL,
  `ch_remote` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ch_local` (`ch_local`),
  KEY `ch_remote` (`ch_remote`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_epg`
--

LOCK TABLES `solus_epg` WRITE;
/*!40000 ALTER TABLE `solus_epg` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_epg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_epg_ch`
--

DROP TABLE IF EXISTS `solus_epg_ch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_epg_ch` (
  `chID` int(11) NOT NULL AUTO_INCREMENT,
  `chName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `chTitle` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`chID`),
  UNIQUE KEY `chName` (`chName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_epg_ch`
--

LOCK TABLES `solus_epg_ch` WRITE;
/*!40000 ALTER TABLE `solus_epg_ch` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_epg_ch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_epg_prog`
--

DROP TABLE IF EXISTS `solus_epg_prog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_epg_prog` (
  `progID` int(11) NOT NULL AUTO_INCREMENT,
  `progChID` int(11) NOT NULL,
  `progStart` datetime NOT NULL,
  `progStop` datetime NOT NULL,
  `progTitle` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `progDesc` text COLLATE utf8_unicode_ci NOT NULL,
  `progCat` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `progIcon` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `progEpisode_num` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`progID`),
  UNIQUE KEY `progChID_2` (`progChID`,`progStart`),
  KEY `progChID` (`progChID`),
  KEY `progStart` (`progStart`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_epg_prog`
--

LOCK TABLES `solus_epg_prog` WRITE;
/*!40000 ALTER TABLE `solus_epg_prog` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_epg_prog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_free_code`
--

DROP TABLE IF EXISTS `solus_free_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_free_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `days` tinyint(3) NOT NULL,
  `code_total` int(11) NOT NULL,
  `code_used` int(11) NOT NULL,
  `forced_country` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_free_code`
--

LOCK TABLES `solus_free_code` WRITE;
/*!40000 ALTER TABLE `solus_free_code` DISABLE KEYS */;
INSERT INTO `solus_free_code` (`id`, `code`, `days`, `code_total`, `code_used`, `forced_country`, `status`) VALUES (1,'1234567',3,100,0,NULL,0);
/*!40000 ALTER TABLE `solus_free_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_ips`
--

DROP TABLE IF EXISTS `solus_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `hits` int(11) NOT NULL,
  `file` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uagent` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`) USING BTREE,
  KEY `reason` (`reason`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_ips`
--

LOCK TABLES `solus_ips` WRITE;
/*!40000 ALTER TABLE `solus_ips` DISABLE KEYS */;
INSERT INTO `solus_ips` (`id`, `ip`, `hits`, `file`, `type`, `info`, `uagent`, `reason`) VALUES (1,'105.155.60.126',0,'V6-Box',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `solus_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_login_ips`
--

DROP TABLE IF EXISTS `solus_login_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_login_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(46) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timeDiff` int(11) NOT NULL,
  `tries` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ipuniq` (`ip`) USING BTREE,
  KEY `ip` (`ip`),
  KEY `timeDiff` (`timeDiff`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_login_ips`
--

LOCK TABLES `solus_login_ips` WRITE;
/*!40000 ALTER TABLE `solus_login_ips` DISABLE KEYS */;
INSERT INTO `solus_login_ips` (`id`, `username`, `ip`, `country`, `timeDiff`, `tries`) VALUES (8,'Lynx','127.0.0.1',NULL,1600187834,1),(9,'admin','192.168.1.55',NULL,1617372965,3),(12,'admin','192.168.1.77',NULL,1617373401,1),(13,'adim','160.177.141.26',NULL,1617716890,1);
/*!40000 ALTER TABLE `solus_login_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_logs`
--

DROP TABLE IF EXISTS `solus_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ver` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `dtime` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `thelog` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(24) COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mac` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `adminid` int(11) NOT NULL,
  `uagent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`(14)),
  KEY `ip` (`ip`),
  KEY `serial` (`serial`),
  KEY `mac` (`mac`),
  KEY `thelog` (`thelog`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_logs`
--

LOCK TABLES `solus_logs` WRITE;
/*!40000 ALTER TABLE `solus_logs` DISABLE KEYS */;
INSERT INTO `solus_logs` (`id`, `ver`, `dtime`, `thelog`, `ip`, `country`, `code`, `model`, `serial`, `mac`, `adminid`, `uagent`) VALUES (1,'V6','1617468605','Activate By Code |expire = 2021-04-06 19:50:05','160.177.138.188',NULL,'179706940524','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'179706940524\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(2,'V6','1617468605','Success Code','160.177.138.188',NULL,'179706940524','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'179706940524\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(3,'V6','1617469075','ReActivation','160.177.138.188',NULL,'179706940524','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'179706940524\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(4,'V6','1617469088','ReActivation','160.177.138.188',NULL,'179706940524','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'179706940524\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(5,'V6','1617469091','ReActivation','160.177.138.188',NULL,'179706940524','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'179706940524\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(6,'V6','1617469111','Activate By Code |expire = 2021-04-10 19:58:31','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(7,'V6','1617469111','Success Code','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(8,'V6','1617469303','Activate By Code |expire = 2021-04-06 20:01:43','160.177.138.188',NULL,'1004187187','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'1004187187\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(9,'V6','1617469303','Success Code','160.177.138.188',NULL,'1004187187','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'1004187187\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(10,'V6-LYNX','1617470220','Activate By Code |expire = 2021-04-10 20:17:00','160.177.138.188',NULL,'195516988720','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195516988720\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(11,'V6-LYNX','1617470220','Success Code','160.177.138.188',NULL,'195516988720','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195516988720\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(12,'V6-LYNX','1617470307','ReActivation','160.177.138.188',NULL,'195516988720','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195516988720\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(13,'V6-LYNX','1617471115','ReActivation','160.177.138.188',NULL,'195516988720','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195516988720\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(14,'V6-LYNX','1617471452','Activate By Code |expire = 2021-04-10 20:37:32','96.233.108.137',NULL,'104534231985','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'104534231985\',\n  \'firmware_ver\' => \'27\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(15,'V6-LYNX','1617471452','Success Code','96.233.108.137',NULL,'104534231985','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'104534231985\',\n  \'firmware_ver\' => \'27\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(16,'V6-LYNX','1617471663','ReActivation','96.233.108.137',NULL,'104534231985','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'104534231985\',\n  \'firmware_ver\' => \'27\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(17,'V6-LYNX','1617471710','ReActivation','96.233.108.137',NULL,'104534231985','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'104534231985\',\n  \'firmware_ver\' => \'27\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(18,'V6','1617472352','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(19,'V6','1617472542','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(20,'V6','1617473277','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(21,'V6','1617473379','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(22,'V6','1617473629','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(23,'V6','1617473671','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(24,'V6','1617474101','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(25,'V6','1617474552','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(26,'V6','1617475054','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(27,'V6','1617475416','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(28,'V6','1617475532','ReActivation','160.177.138.188',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(29,'V6','1617638023','ReActivation','105.155.60.126',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(30,'V6-Box','1617638168','ReActivation','105.155.60.126',NULL,'195516988720','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195516988720\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(31,'V6-Box','1617638317','ReActivation','105.155.60.126',NULL,'195516988720','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195516988720\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(32,'V6-Box','1617638333','ReActivation','105.155.60.126',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(33,'V6-Box','1617638623','ReActivation','105.155.60.126',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(34,'V6-Box','1617638630','ReActivation','105.155.60.126',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(35,'V6-Box','1617639482','ReActivation','105.155.60.126',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(36,'V6-Box','1617640097','ReActivation','105.155.60.126',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(37,'V6-Box','1617641525','ReActivation','105.155.60.126',NULL,'2318069764','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'2318069764\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(38,'V6-Box','1617641853','Activate By Code |expire = 2021-04-08 19:57:33','105.155.60.126',NULL,'208685463370','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'208685463370\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(39,'V6-Box','1617641853','Success Code','105.155.60.126',NULL,'208685463370','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'208685463370\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(40,'V6-Box','1617641934','ReActivation','105.155.60.126',NULL,'208685463370','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'208685463370\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(41,'V6-Box','1617642303','Activate By Code |expire = 2021-04-08 20:05:03','94.249.65.116',NULL,'103128968568','OnePlus ONEPLUS A5000','08:00:27:0E:38:B3','08:00:27:0E:38:B3',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'103128968568\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'08:00:27:0E:38:B3\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'08:00:27:0E:38:B3\',\n) '),(42,'V6-Box','1617642303','Success Code','94.249.65.116',NULL,'103128968568','OnePlus ONEPLUS A5000','08:00:27:0E:38:B3','08:00:27:0E:38:B3',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'103128968568\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'08:00:27:0E:38:B3\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'08:00:27:0E:38:B3\',\n) '),(43,'V6-Box','1617642531','ReActivation','105.155.60.126',NULL,'208685463370','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'208685463370\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(44,'V6-Box','1617642644','@Wrong byCode','105.155.60.126',NULL,'208685463370','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'208685463370\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(45,'V6-Box','1617642661','Activate By Code |expire = 2021-04-08 20:11:01','105.155.60.126',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(46,'V6-Box','1617642661','Success Code','105.155.60.126',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(47,'V6-Box','1617642709','ReActivation','105.155.60.126',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(48,'V6-Box','1617643007','ReActivation','105.155.60.126',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(49,'V6-Box','1617643350','ReActivation','105.155.60.126',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(50,'V6-Box','1617643376','Activate By Code |expire = 2021-04-15 20:22:56','96.233.108.137',NULL,'334067548682','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'334067548682\',\n  \'firmware_ver\' => \'29\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(51,'V6-Box','1617643376','Success Code','96.233.108.137',NULL,'334067548682','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'334067548682\',\n  \'firmware_ver\' => \'29\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(52,'V6-Box','1617643450','ReActivation','96.233.108.137',NULL,'334067548682','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'334067548682\',\n  \'firmware_ver\' => \'29\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(53,'V6-Box','1617643865','ReActivation','105.155.60.126',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(54,'V6-Box','1617644306','ReActivation','96.233.108.137',NULL,'334067548682','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'334067548682\',\n  \'firmware_ver\' => \'29\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(55,'V6-Box','1617645287','Activate By Code |expire = 2021-04-08 20:54:47','197.25.226.158',NULL,'113708708363','Samsung SM-G988B','02:C7:4E:5A:6A:69','02:C7:4E:5A:6A:69',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'113708708363\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'02:C7:4E:5A:6A:69\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988B\',\n  \'sn\' => \'02:C7:4E:5A:6A:69\',\n) '),(56,'V6-Box','1617645287','Success Code','197.25.226.158',NULL,'113708708363','Samsung SM-G988B','02:C7:4E:5A:6A:69','02:C7:4E:5A:6A:69',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'113708708363\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'02:C7:4E:5A:6A:69\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988B\',\n  \'sn\' => \'02:C7:4E:5A:6A:69\',\n) '),(57,'V6-Box','1617645382','ReActivation','197.25.226.158',NULL,'113708708363','Samsung SM-G988B','02:C7:4E:5A:6A:69','02:C7:4E:5A:6A:69',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'113708708363\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'02:C7:4E:5A:6A:69\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988B\',\n  \'sn\' => \'02:C7:4E:5A:6A:69\',\n) '),(58,'V6-Box','1617645467','ReActivation','197.25.226.158',NULL,'113708708363','Samsung SM-G988B','02:C7:4E:5A:6A:69','02:C7:4E:5A:6A:69',0,'LYNX IPTV Player BetaV2 | games.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'113708708363\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'02:C7:4E:5A:6A:69\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988B\',\n  \'sn\' => \'02:C7:4E:5A:6A:69\',\n) '),(59,'V6-Box','1617715795','ReActivation','160.177.141.26',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(60,'V6-Box','1617715986','ReActivation','160.177.141.26',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(61,'V6-Box','1617716010','ReActivation','160.177.141.26',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(62,'V6-Box','1617719076','ReActivation','96.233.108.137',NULL,'104534231985','Samsung SM-G988U1','5E:10:3C:AB:2C:51','5E:10:3C:AB:2C:51',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'104534231985\',\n  \'firmware_ver\' => \'29\',\n  \'mac\' => \'5E:10:3C:AB:2C:51\',\n  \'mode\' => \'active\',\n  \'model\' => \'Samsung SM-G988U1\',\n  \'sn\' => \'5E:10:3C:AB:2C:51\',\n) '),(63,'V6-Box','1618022423','@Expired Code','105.155.54.150',NULL,'284743215232','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'284743215232\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(64,'V6-Box','1618022478','Activate By Code |expire = 2021-04-20 05:41:18','105.155.54.150',NULL,'195578039187','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195578039187\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(65,'V6-Box','1618022478','Success Code','105.155.54.150',NULL,'195578039187','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195578039187\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(66,'V6-Box','1618023754','ReActivation','105.155.54.150',NULL,'195578039187','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195578039187\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) '),(67,'V6-Box','1618025309','ReActivation','105.155.54.150',NULL,'195578039187','OnePlus ONEPLUS A5000','76:C5:F4:3B:6E:90','76:C5:F4:3B:6E:90',0,'LYNX IPTV Player BetaV2 | onyx8.ddns.net<hr>array (\n  \'chipid\' => \'\',\n  \'code\' => \'195578039187\',\n  \'firmware_ver\' => \'01\',\n  \'mac\' => \'76:C5:F4:3B:6E:90\',\n  \'mode\' => \'active\',\n  \'model\' => \'OnePlus ONEPLUS A5000\',\n  \'sn\' => \'76:C5:F4:3B:6E:90\',\n) ');
/*!40000 ALTER TABLE `solus_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_logs_sys`
--

DROP TABLE IF EXISTS `solus_logs_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_logs_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dtime` datetime NOT NULL,
  `admin_user` varchar(50) DEFAULT NULL,
  `app` varchar(20) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(3) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `the_log` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_user` (`admin_user`),
  KEY `action` (`action`),
  KEY `ip` (`ip`),
  FULLTEXT KEY `the_log` (`the_log`)
) ENGINE=MyISAM AUTO_INCREMENT=167 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_logs_sys`
--

LOCK TABLES `solus_logs_sys` WRITE;
/*!40000 ALTER TABLE `solus_logs_sys` DISABLE KEYS */;
INSERT INTO `solus_logs_sys` (`id`, `dtime`, `admin_user`, `app`, `ip`, `country`, `action`, `the_log`) VALUES (1,'2020-09-05 16:03:30','admin','login','62.201.240.30',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0'),(2,'2020-09-05 16:03:56','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(3,'2020-09-05 16:03:58','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(4,'2020-09-05 16:04:11','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(5,'2020-09-05 16:04:13','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(6,'2020-09-05 16:05:16','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(7,'2020-09-05 16:05:18','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(8,'2020-09-05 16:05:30','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(9,'2020-09-05 16:05:31','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(10,'2020-09-05 16:09:03','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(11,'2020-09-05 16:09:03','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(12,'2020-09-05 16:09:03','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(13,'2020-09-05 16:09:03','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(14,'2020-09-05 16:09:05','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(15,'2020-09-05 16:09:05','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(16,'2020-09-05 16:09:05','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(17,'2020-09-05 16:09:05','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','[obfuscated]() expects parameter 1 to be mysqli_result, bool given<br/> http://45.148.26.51:8080/dir.php'),(18,'2020-09-06 02:24:25','admin','login','62.201.240.30',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0'),(19,'2020-09-07 00:33:34','admin','login','62.201.240.30',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0'),(20,'2020-09-07 13:07:19','admin','login','62.201.240.30',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0'),(21,'2020-09-07 13:14:37','admin','remote-cmd','62.201.240.30',NULL,'cmd-error','Undefined index: m3u_file<br/> http://45.148.26.51:8080/dir.php'),(22,'2020-09-07 16:04:54','admin','login','62.201.240.30',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0'),(23,'2020-09-07 16:15:04','solus-developer','login','105.104.93.79',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(24,'2020-09-07 16:21:22','solus-developer','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(25,'2020-09-07 16:21:59','solus-developer','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(26,'2020-09-07 16:26:18','solus-developer','login','127.0.0.1',NULL,'logout',''),(27,'2020-09-07 16:26:29','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(28,'2020-09-07 17:46:08','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(29,'2020-09-07 17:46:16','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(30,'2020-09-07 18:37:02','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(31,'2020-09-07 18:37:29','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(32,'2020-09-08 21:06:27','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(33,'2020-09-08 21:06:30','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(34,'2020-09-08 21:14:48','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(35,'2020-09-08 21:15:04','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(36,'2020-09-08 21:36:40','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(37,'0000-00-00 00:00:00','','','',NULL,'',''),(38,'0000-00-00 00:00:00','','','',NULL,'',''),(39,'2020-09-09 00:51:38','DFDF','login','127.0.0.1',NULL,'login_fail','User=DFDF<br/>Pass=SDFSDF'),(40,'2020-09-09 01:17:43','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(41,'2020-09-09 01:17:51','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(42,'0000-00-00 00:00:00','','','',NULL,'',''),(43,'0000-00-00 00:00:00','','','',NULL,'',''),(44,'2020-09-09 19:00:21','admin','login','127.0.0.1',NULL,'login_fail','User=admin<br/>Pass=sdsds'),(45,'2020-09-09 19:01:00','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(46,'2020-09-09 19:01:20','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(47,'0000-00-00 00:00:00','','','',NULL,'',''),(48,'0000-00-00 00:00:00','','','',NULL,'',''),(49,'0000-00-00 00:00:00','','','',NULL,'',''),(50,'2020-09-09 19:10:38','dsfdsf','login','127.0.0.1',NULL,'login_fail','User=dsfdsf<br/>Pass=sss'),(51,'2020-09-09 19:10:44','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(52,'0000-00-00 00:00:00','','','',NULL,'',''),(53,'2020-09-10 14:00:17','sssds','login','127.0.0.1',NULL,'login_fail','User=sssds<br/>Pass=dsfqsfqsd'),(54,'2020-09-10 14:00:41','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'),(55,'0000-00-00 00:00:00','','','',NULL,'',''),(56,'0000-00-00 00:00:00','','','',NULL,'',''),(57,'0000-00-00 00:00:00','','','',NULL,'',''),(58,'0000-00-00 00:00:00','','','',NULL,'',''),(59,'2020-09-11 17:38:34','dds','login','127.0.0.1',NULL,'login_fail','User=dds<br/>Pass=sdqs'),(60,'2020-09-11 17:38:38','admin','login','127.0.0.1',NULL,'login_fail','User=admin<br/>Pass=sdsdsds'),(61,'2020-09-11 17:39:04','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(62,'2020-09-11 17:39:19','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(63,'0000-00-00 00:00:00','','','',NULL,'',''),(64,'0000-00-00 00:00:00','','','',NULL,'',''),(65,'0000-00-00 00:00:00','','','',NULL,'',''),(66,'2020-09-11 18:00:38','ADMKN','login','127.0.0.1',NULL,'login_fail','User=ADMKN<br/>Pass=D?NDFDF'),(67,'2020-09-11 18:00:44','admind','login','127.0.0.1',NULL,'login_fail','User=admind<br/>Pass=dfdfdf'),(68,'0000-00-00 00:00:00','','','',NULL,'',''),(69,'0000-00-00 00:00:00','','','',NULL,'',''),(70,'2020-09-11 18:02:50','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(71,'0000-00-00 00:00:00','','','',NULL,'',''),(72,'0000-00-00 00:00:00','','','',NULL,'',''),(73,'2020-09-11 18:03:48','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(74,'0000-00-00 00:00:00','','','',NULL,'',''),(75,'0000-00-00 00:00:00','','','',NULL,'',''),(76,'0000-00-00 00:00:00','','','',NULL,'',''),(77,'0000-00-00 00:00:00','','','',NULL,'',''),(78,'0000-00-00 00:00:00','','','',NULL,'',''),(79,'0000-00-00 00:00:00','','','',NULL,'',''),(80,'0000-00-00 00:00:00','','','',NULL,'',''),(81,'0000-00-00 00:00:00','','','',NULL,'',''),(82,'0000-00-00 00:00:00','','','',NULL,'',''),(83,'0000-00-00 00:00:00','','','',NULL,'',''),(84,'0000-00-00 00:00:00','','','',NULL,'',''),(85,'2020-09-14 02:47:57','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(86,'2020-09-14 02:48:14','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(87,'2020-09-14 02:48:18','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(88,'2020-09-14 02:51:48','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(89,'2020-09-14 02:52:15','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(90,'0000-00-00 00:00:00','','','',NULL,'',''),(91,'0000-00-00 00:00:00','','','',NULL,'',''),(92,'0000-00-00 00:00:00','','','',NULL,'',''),(93,'0000-00-00 00:00:00','','','',NULL,'',''),(94,'2020-09-14 13:01:02','admin','resellers','127.0.0.1',NULL,'edit_resel','ReselID=2|name=abd|user=abd <hr>{\"adminid\":{\"before\":\"2\",\"after\":\"\"},\"adm_password\":{\"before\":\"a080e36bad227c047e8bcc6c46284d32\",\"after\":\"\"}}'),(95,'2020-09-14 13:17:43','admin','resellers','127.0.0.1',NULL,'edit_resel','ReselID=75|name=abderahmane Djouani|user=test23 <hr>{\"adminid\":{\"before\":\"75\",\"after\":\"\"},\"adm_password\":{\"before\":\"ca8b5b64b1444b6020f140c39c079241\",\"after\":\"\"}}'),(96,'2020-09-14 21:20:49','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(97,'2020-09-15 16:00:49','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(98,'2020-09-15 17:55:05','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(99,'2020-09-15 19:06:42','Lynx','login','127.0.0.1',NULL,'suspended','tried to login to his suspended account'),(100,'2020-09-15 19:07:08','Lynx','login','127.0.0.1',NULL,'suspended','tried to login to his suspended account'),(101,'2020-09-15 19:07:14','Lynx','login','127.0.0.1',NULL,'login_fail','User=Lynx<br/>Pass=szdsds'),(102,'2020-09-15 19:07:21','Lynx','login','127.0.0.1',NULL,'suspended','tried to login to his suspended account'),(103,'2020-09-15 19:08:21','Lynx','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(104,'2020-09-15 20:04:13','Lynx','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(105,'2020-09-15 21:05:14','Lynx','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(106,'2020-09-15 23:42:19','Lynx','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(107,'2020-09-17 20:21:55','admin','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(108,'2020-09-21 19:47:27','Lynx','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(109,'2020-09-22 01:37:22','Lynx','login','127.0.0.1',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'),(110,'2021-04-02 16:41:53','admin','login','192.168.1.55',NULL,'login_fail','User=admin<br/>Pass=admin'),(111,'2021-04-02 16:45:56','admin','login','192.168.1.55',NULL,'login_fail','User=admin<br/>Pass=admin123'),(112,'2021-04-02 16:46:05','admin','login','192.168.1.55',NULL,'login_fail','User=admin<br/>Pass=lolo_1984'),(113,'2021-04-02 16:53:21','admin','login','192.168.1.77',NULL,'login_fail','User=admin<br/>Pass=;o;o_1984'),(114,'2021-04-02 16:55:12','admin','login','192.168.1.77',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(115,'2021-04-02 17:00:51','admin','resellers','192.168.1.77',NULL,'edit_resel','ReselID=1|name=admin|user=admin <hr>{\"adm_password\":{\"before\":\"5dd09d3b278f61c328c1cfa8d80e56f0\",\"after\":\"3c2235ad0156d423c4f7f89718c54f8a\"},\"balance\":{\"before\":\"100000\",\"after\":\"\"},\"resel_bouquets\":{\"before\":\"1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20\",\"after\":\"1\"}}'),(116,'2021-04-02 17:01:04','admin','login','192.168.1.77',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(117,'2021-04-02 17:29:40','admin','login','192.168.1.77',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(118,'2021-04-02 22:26:02','admin','login','105.155.39.86',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(119,'2021-04-02 22:37:06','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:25461/dir.php'),(120,'2021-04-02 22:37:07','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:25461/dir.php'),(121,'2021-04-02 22:37:13','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:25461/dir.php'),(122,'2021-04-02 22:37:13','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:25461/dir.php'),(123,'2021-04-02 22:39:19','admin','resellers','105.155.39.86',NULL,'edit_resel','ReselID=1|name=admin|user=admin <hr>{\"adm_password\":{\"before\":\"3c2235ad0156d423c4f7f89718c54f8a\",\"after\":\"\"},\"email\":{\"before\":\"abdulzh2025@gmail.com\",\"after\":\"kulvcfhgc@gmail.com\"},\"balance\":{\"before\":\"100000\",\"after\":\"\"},\"num_free\":{\"before\":\"197\",\"after\":-1}}'),(124,'2021-04-02 23:14:54','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(125,'2021-04-02 23:14:55','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(126,'2021-04-02 23:57:46','admin','login','105.155.39.86',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(127,'2021-04-02 23:58:17','admin','login','105.155.39.86',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(128,'2021-04-03 04:52:07','admin','login','105.155.39.86',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(129,'2021-04-03 06:00:45','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(130,'2021-04-03 06:00:45','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(131,'2021-04-03 06:01:15','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(132,'2021-04-03 06:01:15','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(133,'2021-04-03 06:01:19','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(134,'2021-04-03 06:01:19','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(135,'2021-04-03 06:16:04','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(136,'2021-04-03 06:16:05','admin','remote-cmd','105.155.39.86',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(137,'2021-04-03 07:22:38','admin','login','105.155.39.86',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(138,'2021-04-03 07:24:11','admin','resellers','105.155.39.86',NULL,'edit_resel','ReselID=1|name=admin|user=admin <hr>{\"adm_password\":{\"before\":\"3c2235ad0156d423c4f7f89718c54f8a\",\"after\":\"\"},\"cost_6\":{\"before\":\"6\",\"after\":0.5},\"cost_12\":{\"before\":\"12\",\"after\":1},\"cost_24\":{\"before\":\"24\",\"after\":2},\"cost_36\":{\"before\":\"36\",\"after\":3},\"balance\":{\"before\":\"100000\",\"after\":\"\"}}'),(139,'2021-04-03 08:16:44','admin','login','160.177.138.188',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(140,'2021-04-03 19:48:57','admin','login','160.177.138.188',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(141,'2021-04-03 20:30:14','admin','remote-cmd','160.177.138.188',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(142,'2021-04-03 20:30:14','admin','remote-cmd','160.177.138.188',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(143,'2021-04-03 20:37:03','admin','login','96.233.108.137',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'),(144,'2021-04-03 20:38:16','admin','login','160.177.138.188',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(145,'2021-04-03 20:39:04','admin','login','160.177.138.188',NULL,'logout',''),(146,'2021-04-03 20:39:21','admin','login','96.233.108.137',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'),(147,'2021-04-03 20:50:37','admin','login','160.177.138.188',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(148,'2021-04-03 20:53:11','Admin','login','96.233.108.137',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'),(149,'2021-04-03 21:03:40','admin','login','160.177.138.188',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(150,'2021-04-03 22:09:24','admin','login','96.233.108.137',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'),(151,'2021-04-03 22:57:03','admin','login','160.177.138.188',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(152,'2021-04-03 23:39:01','Admin','login','96.233.108.137',NULL,'login_success','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'),(153,'2021-04-05 18:53:09','admin','login','105.155.60.126',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(154,'2021-04-05 19:43:09','admin','login','105.155.60.126',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(155,'2021-04-05 20:12:55','admin','login','105.155.60.126',NULL,'logout',''),(156,'2021-04-05 20:16:00','admin','login','105.155.60.126',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(157,'2021-04-06 16:18:10','adim','login','160.177.141.26',NULL,'login_fail','User=adim<br/>Pass=12345678910'),(158,'2021-04-06 16:18:27','admin','login','160.177.141.26',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(159,'2021-04-08 12:31:30','admin','login','41.143.103.169',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(160,'2021-04-09 00:45:29','admin','login','41.143.103.169',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(161,'2021-04-09 01:01:32','admin','login','41.143.103.169',NULL,'logout',''),(162,'2021-04-10 05:20:20','admin','login','105.155.54.150',NULL,'login_success','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'),(163,'2021-04-10 06:11:43','admin','remote-cmd','105.155.54.150',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(164,'2021-04-10 06:11:44','admin','remote-cmd','105.155.54.150',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(165,'2021-04-10 06:11:46','admin','remote-cmd','105.155.54.150',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php'),(166,'2021-04-10 06:11:46','admin','remote-cmd','105.155.54.150',NULL,'cmd-error','Illegal string offset \'for\'<br/> http://192.99.0.109:8880/dir.php');
/*!40000 ALTER TABLE `solus_logs_sys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_model`
--

DROP TABLE IF EXISTS `solus_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_model` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `m_ver` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codeid` int(11) NOT NULL,
  `hits` int(11) NOT NULL,
  `lastdate` datetime DEFAULT NULL,
  `protocol` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`m_id`),
  UNIQUE KEY `name_ver_code` (`m_name`,`m_ver`,`codeid`) USING BTREE,
  KEY `lastdate` (`lastdate`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_model`
--

LOCK TABLES `solus_model` WRITE;
/*!40000 ALTER TABLE `solus_model` DISABLE KEYS */;
INSERT INTO `solus_model` (`m_id`, `m_name`, `m_ver`, `codeid`, `hits`, `lastdate`, `protocol`) VALUES (1,'OnePlus ONEPLUS A5000','01',2735,4,'2021-04-03 19:58:11',NULL),(2,'OnePlus ONEPLUS A5000','01',2736,19,'2021-04-05 19:52:05',NULL),(3,'OnePlus ONEPLUS A5000','01',2737,1,NULL,NULL),(4,'OnePlus ONEPLUS A5000','01',2738,5,'2021-04-05 18:58:37',NULL),(5,'Samsung SM-G988U1','27',2739,3,'2021-04-03 20:41:50',NULL),(6,'OnePlus ONEPLUS A5000','01',2741,3,'2021-04-05 20:08:51',NULL),(7,'OnePlus ONEPLUS A5000','01',2742,1,NULL,NULL),(8,'OnePlus ONEPLUS A5000','01',2740,8,'2021-04-06 16:33:30',NULL),(9,'Samsung SM-G988U1','29',2743,3,'2021-04-05 20:38:26',NULL),(10,'Samsung SM-G988B','01',2745,3,'2021-04-05 20:57:47',NULL),(11,'Samsung SM-G988U1','29',2739,1,NULL,NULL),(12,'OnePlus ONEPLUS A5000','01',2746,3,'2021-04-10 06:28:29',NULL);
/*!40000 ALTER TABLE `solus_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_movies`
--

DROP TABLE IF EXISTS `solus_movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_movies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `movie_type` tinyint(4) NOT NULL,
  `catid` int(10) NOT NULL,
  `title` varchar(150) NOT NULL,
  `view_order` int(10) NOT NULL,
  `stream_id` int(10) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `subtitle` longtext NOT NULL,
  `ep_no` int(4) NOT NULL,
  `featured_flag` int(1) NOT NULL,
  `stream_360p` text NOT NULL,
  `stream_480p` text NOT NULL,
  `stream_720p` text NOT NULL,
  `stream_1080p` text NOT NULL,
  `stream_4k` varchar(255) NOT NULL,
  `imdb_id` varchar(255) NOT NULL,
  `movies_json` longtext NOT NULL,
  `year` int(4) NOT NULL,
  `MPAA_rate` varchar(5) NOT NULL,
  `trailer` varchar(255) NOT NULL,
  `hits` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_movies`
--

LOCK TABLES `solus_movies` WRITE;
/*!40000 ALTER TABLE `solus_movies` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_movies_cat`
--

DROP TABLE IF EXISTS `solus_movies_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_movies_cat` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_for` int(5) NOT NULL,
  `Cat_father` int(10) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `cat_type` int(1) NOT NULL,
  `cat_view_order` int(10) NOT NULL,
  `cat_icon` varchar(255) NOT NULL,
  `Cat_data` text NOT NULL,
  `type2` int(1) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_movies_cat`
--

LOCK TABLES `solus_movies_cat` WRITE;
/*!40000 ALTER TABLE `solus_movies_cat` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_movies_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_movies_genres`
--

DROP TABLE IF EXISTS `solus_movies_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_movies_genres` (
  `movie_id` int(10) NOT NULL,
  `g_id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_movies_genres`
--

LOCK TABLES `solus_movies_genres` WRITE;
/*!40000 ALTER TABLE `solus_movies_genres` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_movies_genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_options`
--

DROP TABLE IF EXISTS `solus_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `val` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_options`
--

LOCK TABLES `solus_options` WRITE;
/*!40000 ALTER TABLE `solus_options` DISABLE KEYS */;
INSERT INTO `solus_options` (`id`, `name`, `val`) VALUES (1,'site_name','PRO IPTV'),(2,'iptv_host','http://onyx8.ddns.net:8880/{type}/{user}/{pass}/{ch}.ts'),(3,'iptv_host_vod','http://onyx8.ddns.net:8880/{type}/{user}/{pass}/{ch}.{container}'),(4,'m3u_host','http://onyx8.ddns.net:8880/get.php'),(5,'iptv_api_url','api.php'),(6,'iptv_api_pass',''),(7,'user_agent',''),(8,'https','0'),(9,'api_key',''),(10,'api_secret',''),(11,'api_allowed_ip',''),(12,'api_code_length',''),(13,'apk_page',''),(14,'multi_code','0'),(15,'enable_mac','0'),(16,'enable_serial','0'),(17,'BouquetsOrder','view_order:asc'),(18,'CategoriesOrder','cat_order:asc'),(19,'MoviesOrder','streams.`order` ASC'),(20,'exclude_movies_pkg',''),(21,'forceAdminUseBouquets','0'),(22,'expire_date_type',''),(23,'EnableKidsPlusSeries','0'),(24,'vod_kids',''),(25,'vod_music',''),(26,'vod_series',''),(27,'capture_ip',''),(28,'remote_movies_use','0'),(29,'remote_movies_api',''),(30,'remote_series_use','0'),(31,'remote_series_api',''),(32,'cache_time',''),(33,'enable_sat2iptv','0'),(34,'enable_groups','0'),(35,'hide_login_logo','1'),(36,'hide_introtech_copy','1'),(37,'copyright',''),(38,'bad_stb_limit_trans',''),(39,'bad_stb_tot_vod',''),(40,'bad_stb_tot_series',''),(41,'global_msg',''),(42,'global_msg_expiry',''),(43,'sql_root','dkJkXxFBNlMTZ1hY'),(44,'sql_lb_user','WFdVVgFXCBApUEU='),(45,'sql_lb_pass','dkJkXxFBNlMTZ1hY'),(46,'db_ver','238'),(47,'iptv_api_player',''),(48,'imdb_proxy',''),(49,'min_topup_credit',''),(50,'master_code_geo_block',''),(51,'master_code_geo_transid',''),(52,'block_mac',''),(53,'vod_netflix',''),(54,'VodRemoteServer','0'),(55,'VodRemoteServerAPI',''),(56,'VodRemoteUloadPath',''),(57,'VodRemoteDefaultCover',''),(58,'BlockAddFree','0'),(59,'day1_period',''),(60,'AllowReseToSeeLogs','0'),(61,'SuperResellSeeAllPays','0'),(62,'SuperResellSeeAllCodes','0'),(63,'default_users_acct','0'),(64,'DisableStatForCodes','0'),(65,'play_strm_user',''),(66,'play_strm_pass',''),(67,'CreditSystem','oversell');
/*!40000 ALTER TABLE `solus_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_series`
--

DROP TABLE IF EXISTS `solus_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_series` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(10) NOT NULL,
  `s_title` varchar(200) NOT NULL,
  `s_photo` varchar(255) NOT NULL,
  `s_year` int(4) NOT NULL,
  `s_jsondata` text NOT NULL,
  `num_season` int(10) NOT NULL,
  `w` int(10) NOT NULL,
  `imdb_id` varchar(255) NOT NULL,
  `trailer` varchar(255) NOT NULL,
  `stream_4k` varchar(255) NOT NULL,
  `hits` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  PRIMARY KEY (`sid`),
  KEY `year` (`s_year`),
  FULLTEXT KEY `title` (`s_title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_series`
--

LOCK TABLES `solus_series` WRITE;
/*!40000 ALTER TABLE `solus_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_series_cat`
--

DROP TABLE IF EXISTS `solus_series_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_series_cat` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `cat_for` int(5) NOT NULL,
  `catname` varchar(255) NOT NULL,
  `father` int(11) NOT NULL,
  `catimage` varchar(255) NOT NULL,
  `catinfo` varchar(255) NOT NULL,
  `catorder` varchar(50) NOT NULL,
  `w` int(5) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_series_cat`
--

LOCK TABLES `solus_series_cat` WRITE;
/*!40000 ALTER TABLE `solus_series_cat` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_series_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_series_seasons`
--

DROP TABLE IF EXISTS `solus_series_seasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_series_seasons` (
  `seasonid` int(10) NOT NULL AUTO_INCREMENT,
  `season_name` varchar(200) NOT NULL,
  `seriesid` int(10) NOT NULL,
  `year` int(4) NOT NULL,
  `s_num` int(10) NOT NULL,
  `hits` int(11) NOT NULL,
  PRIMARY KEY (`seasonid`),
  KEY `sid` (`seriesid`),
  KEY `year` (`year`),
  FULLTEXT KEY `season name` (`season_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_series_seasons`
--

LOCK TABLES `solus_series_seasons` WRITE;
/*!40000 ALTER TABLE `solus_series_seasons` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_series_seasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_seriesepisodes`
--

DROP TABLE IF EXISTS `solus_seriesepisodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_seriesepisodes` (
  `epid` int(11) NOT NULL AUTO_INCREMENT,
  `epnum` int(10) NOT NULL,
  `sid` int(11) NOT NULL,
  `seasonid` int(11) NOT NULL,
  `stream_480p` text NOT NULL,
  `stream_720p` text NOT NULL,
  `stream_1080p` text NOT NULL,
  `stream_4k` text NOT NULL,
  `hits` int(11) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `epname` varchar(200) NOT NULL,
  PRIMARY KEY (`epid`),
  KEY `sid` (`sid`),
  KEY `seasonid` (`seasonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_seriesepisodes`
--

LOCK TABLES `solus_seriesepisodes` WRITE;
/*!40000 ALTER TABLE `solus_seriesepisodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_seriesepisodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_session_data`
--

DROP TABLE IF EXISTS `solus_session_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_session_data` (
  `session_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `session_data` blob NOT NULL,
  `session_expire` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `uagent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `page` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_session_data`
--

LOCK TABLES `solus_session_data` WRITE;
/*!40000 ALTER TABLE `solus_session_data` DISABLE KEYS */;
INSERT INTO `solus_session_data` (`session_id`, `hash`, `session_data`, `session_expire`, `ip`, `uagent`, `page`) VALUES ('0vbb3gd19ou178tbet0ilt1e95','2f9b3bc2c66e513df0a4f5faef124f9a',_binary 'cokl|a:2:{i:0;s:32:\"b74e62aa3d3a939e65182fddc5dfd275\";i:1;s:32:\"71e842864bc4ede3f5bdd378322156fe\";}',1617483750,'35.185.241.102','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('1iagt0mjfouqrorrldsmh6eoqi','d8d0b623f1737c7ba90be0a02481a6ef',_binary 'cokl|a:2:{i:0;s:32:\"c1821319c6b4b90795049cb10fb7f036\";i:1;s:32:\"69ac6355986e4904d893dcc28c6cd006\";}',1617717581,'52.114.77.236','Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5',''),('4fi3ie32e8h5kqs6nla5026o5o','ac80297320fabf0b3f2884f54fcf99d9',_binary 'cokl|a:2:{i:0;s:32:\"b4184be1b3ff49699623f1c9f6723660\";i:1;s:32:\"c28dd3fdfced9011de7a33bf6389f6b1\";}',1617473436,'35.245.188.175','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('4lgctetipkdpnasu8dv08ai439','ac80297320fabf0b3f2884f54fcf99d9',_binary 'cokl|a:2:{i:0;s:32:\"7ae4553ac9556ccac07337785f8a70bc\";i:1;s:32:\"317d8e81a79a03d8036239bce78a7bc3\";}',1617473439,'35.245.188.175','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('604pocchkbl8ohvr67r3pqonqm','7aa60878a6cfa4e118fa3293ab033f49',_binary 'admin|a:13:{s:2:\"x1\";s:1:\"\0\";s:2:\"x2\";s:5:\"PRXQW\";s:2:\"x3\";s:32:\"U\n\n\0 \0R	\\]4XS@i6X=		VtP\0\";s:2:\"x4\";s:14:\"\0\n\noUR\0GZc[\";s:2:\"x5\";s:19:\"	uIRIYcVRJ^m`\";s:2:\"x6\";s:1:\"\0\";s:2:\"x7\";s:1:\"\0\";s:2:\"x8\";s:1:\"\0\";s:2:\"x9\";s:1:\"\0\";s:3:\"x10\";s:2:\"\";s:10:\"ResellerID\";i:1617637988;s:12:\"ResellerPASS\";s:13:\"606b326443b96\";s:12:\"SessionValid\";s:19:\"2021-04-05 23:59:59\";}',1617641932,'105.155.60.126','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0','/home/dashNH=1&refresh=ok'),('64vmp7qfqlokg2tt834ucepqf3','9ed9c36fe04dd4904367fb1625baf668',_binary 'cokl|a:2:{i:0;s:32:\"609ddcac6fdbfe56a42e398462cfe618\";i:1;s:32:\"90ddfe36e12db43060593c94c4edb03b\";}',1617646984,'96.233.108.137','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',''),('7kd1cu06fniooje2ulpn9mff08','ac80297320fabf0b3f2884f54fcf99d9',_binary 'cokl|a:2:{i:0;s:32:\"4e82343a8b16d6a8c24650614c39609c\";i:1;s:32:\"cf65759fcdb0a21b3c3e8e9fd37210c0\";}',1617473471,'35.245.188.175','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('7smeau5lnof4ksgpc8rsiupeit','8eb7bf15c48e8b83d39f35eaf726e3e9',_binary 'cokl|a:2:{i:0;s:32:\"5ead6d14f6ca527cd04cfd15c7652f26\";i:1;s:32:\"451bbeb266b48926f1ebf7a6510ea0f0\";}',1617640099,'105.155.60.126','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36',''),('94h1t4qhcginm8v9vjbrah5r94','ac80297320fabf0b3f2884f54fcf99d9',_binary 'cokl|a:2:{i:0;s:32:\"e27364586e761c93e4d32155561af718\";i:1;s:32:\"4dbe56232d4de46cf9e1df6c3f2996b2\";}',1617473418,'35.245.188.175','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('kebhcoo2t62bn4m2atseor96sl','ac80297320fabf0b3f2884f54fcf99d9',_binary 'cokl|a:2:{i:0;s:32:\"a921d633a599a9be5ac6125d89715e38\";i:1;s:32:\"1508cef63679a896dd0c8202f1f564d2\";}',1617473429,'35.245.188.175','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('mc0g1dus5agegeq992n8ptfris','2f9b3bc2c66e513df0a4f5faef124f9a',_binary 'cokl|a:2:{i:0;s:32:\"cd585f5197470795f6f3f731d2a00b2e\";i:1;s:32:\"ad07626887537b6d79db74d07ce6fa53\";}',1617478388,'35.185.241.102','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('me4anp93bfho95roo35514fqn8','2f9b3bc2c66e513df0a4f5faef124f9a',_binary 'cokl|a:2:{i:0;s:32:\"02f574f75bb4daf063146d2c28fb2d96\";i:1;s:32:\"ae287df5aafcd9ee622285ef7a0c1be5\";}',1617483750,'35.185.241.102','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('os4oibtq7i1f8g5spnmjaca3sc','2f9b3bc2c66e513df0a4f5faef124f9a',_binary 'cokl|a:2:{i:0;s:32:\"a5e3be1565b2568326a4d7f72a50ba86\";i:1;s:32:\"120426caa234b8c1abf15a45c3cc1c25\";}',1617473815,'35.185.241.102','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('q4luj7bqo89s6pl1ieitksa3mu','31eda4884a2172faa50c130036732fd6',_binary 'admin|a:13:{s:2:\"x1\";s:1:\"\0\";s:2:\"x2\";s:5:\"PRXQW\";s:2:\"x3\";s:32:\"U\n\n\0 \0R	\\]4XS@i6X=		VtP\0\";s:2:\"x4\";s:14:\"	\roURGZfU\";s:2:\"x5\";s:19:\"	uIRI[`VUF^oh\";s:2:\"x6\";s:1:\"\0\";s:2:\"x7\";s:1:\"\0\";s:2:\"x8\";s:1:\"\0\";s:2:\"x9\";s:1:\"\0\";s:3:\"x10\";s:2:\"\";s:10:\"ResellerID\";i:1618021219;s:12:\"ResellerPASS\";s:13:\"60710b63adc5f\";s:12:\"SessionValid\";s:19:\"2021-04-10 23:59:59\";}',1618026742,'105.155.54.150','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0','/codes/index'),('qpmidku9k6mqt2jvrhm9jeci0s','7aa60878a6cfa4e118fa3293ab033f49',_binary 'admin|a:13:{s:2:\"x1\";s:1:\"\0\";s:2:\"x2\";s:5:\"PRXQW\";s:2:\"x3\";s:32:\"U\n\n\0 \0R	\\]4XS@i6X=		VtP\0\";s:2:\"x4\";s:14:\"\0\0\0tJTGZbZ\";s:2:\"x5\";s:19:\"	uIR\rIZiVU@^mh\";s:2:\"x6\";s:1:\"\0\";s:2:\"x7\";s:1:\"\0\";s:2:\"x8\";s:1:\"\0\";s:2:\"x9\";s:1:\"\0\";s:3:\"x10\";s:2:\"\";s:10:\"ResellerID\";i:1617642959;s:12:\"ResellerPASS\";s:13:\"606b45cf3ce05\";s:12:\"SessionValid\";s:19:\"2021-04-05 23:59:59\";}',1617647535,'105.155.60.126','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0','/home/dashNH=1&refresh=ok'),('r50jp72lpm3j4h9qtvm9eene7q','2f9b3bc2c66e513df0a4f5faef124f9a',_binary 'cokl|a:2:{i:0;s:32:\"a1237fbf2844631279f13a20f1e37aa1\";i:1;s:32:\"085520797e162589c4307206d8ac3b59\";}',1617478388,'35.185.241.102','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',''),('v661h18s1cstnkjovmt89f822f','ac80297320fabf0b3f2884f54fcf99d9',_binary 'cokl|a:2:{i:0;s:32:\"9e6d07caaa39becd8a820cf1d89494d6\";i:1;s:32:\"ce401c573dd93cf2267533063528f005\";}',1617473471,'35.245.188.175','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko','');
/*!40000 ALTER TABLE `solus_session_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_stb_groups`
--

DROP TABLE IF EXISTS `solus_stb_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_stb_groups` (
  `stb_gid` int(5) NOT NULL AUTO_INCREMENT,
  `stb_gname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`stb_gid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_stb_groups`
--

LOCK TABLES `solus_stb_groups` WRITE;
/*!40000 ALTER TABLE `solus_stb_groups` DISABLE KEYS */;
INSERT INTO `solus_stb_groups` (`stb_gid`, `stb_gname`) VALUES (1,'NILESAT');
/*!40000 ALTER TABLE `solus_stb_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_stb_to_iptv`
--

DROP TABLE IF EXISTS `solus_stb_to_iptv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_stb_to_iptv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stb_group` int(5) NOT NULL,
  `ch_id` int(11) NOT NULL,
  `stb_ch_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tp` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sid` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sh_type` tinyint(4) NOT NULL,
  `angle` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `channel` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pol` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ch_id` (`ch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_stb_to_iptv`
--

LOCK TABLES `solus_stb_to_iptv` WRITE;
/*!40000 ALTER TABLE `solus_stb_to_iptv` DISABLE KEYS */;
INSERT INTO `solus_stb_to_iptv` (`id`, `stb_group`, `ch_id`, `stb_ch_name`, `tp`, `sid`, `sh_type`, `angle`, `channel`, `pol`) VALUES (1,1,1120,'BEIN BARAEM NILESAT',NULL,NULL,0,'7.00','','');
/*!40000 ALTER TABLE `solus_stb_to_iptv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_tasks`
--

DROP TABLE IF EXISTS `solus_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_for` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `task_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `task_table` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `task_keyid` int(11) NOT NULL,
  `task_date` datetime NOT NULL,
  `cmd_start` tinyint(4) DEFAULT NULL,
  `cmd_start_status` tinyint(4) DEFAULT NULL,
  `cmd_stop` tinyint(4) DEFAULT NULL,
  `cmd_stop_status` tinyint(4) DEFAULT NULL,
  `cmd_restart` tinyint(4) DEFAULT NULL,
  `cmd_restart_status` tinyint(4) DEFAULT NULL,
  `cmd_fetch` tinyint(4) DEFAULT NULL,
  `cmd_fetch_status` tinyint(4) DEFAULT NULL,
  `task_status` int(11) NOT NULL,
  `task_reply` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`task_id`),
  KEY `task_type` (`task_name`),
  KEY `task_date` (`task_date`),
  KEY `task_status` (`task_status`),
  KEY `task_keyid` (`task_keyid`),
  KEY `task_for` (`task_for`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_tasks`
--

LOCK TABLES `solus_tasks` WRITE;
/*!40000 ALTER TABLE `solus_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `solus_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_trans`
--

DROP TABLE IF EXISTS `solus_trans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_trans` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL,
  `method` tinyint(4) NOT NULL,
  `userid` int(10) NOT NULL,
  `code_id` int(11) NOT NULL,
  `code_trans` int(11) NOT NULL,
  `isSub` tinyint(1) NOT NULL,
  `admin` int(10) NOT NULL,
  `admin_father` int(11) NOT NULL,
  `depit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `credit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateadded` datetime NOT NULL,
  `period` int(10) NOT NULL,
  `pkg` smallint(6) DEFAULT NULL,
  `Notes` text COLLATE utf8_unicode_ci NOT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `all_data` longtext COLLATE utf8_unicode_ci,
  `admin_add` int(11) NOT NULL,
  `admin_edit` int(11) NOT NULL,
  `time_add` datetime DEFAULT NULL,
  `time_edit` datetime DEFAULT NULL,
  `edit_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edit_log` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`trans_id`),
  KEY `pkg` (`pkg`),
  KEY `dateadded` (`dateadded`),
  KEY `userid` (`userid`),
  KEY `admin` (`admin`),
  KEY `admin_father` (`admin_father`),
  KEY `period` (`period`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_trans`
--

LOCK TABLES `solus_trans` WRITE;
/*!40000 ALTER TABLE `solus_trans` DISABLE KEYS */;
INSERT INTO `solus_trans` (`trans_id`, `type`, `method`, `userid`, `code_id`, `code_trans`, `isSub`, `admin`, `admin_father`, `depit`, `credit`, `dateadded`, `period`, `pkg`, `Notes`, `amount`, `all_data`, `admin_add`, `admin_edit`, `time_add`, `time_edit`, `edit_reason`, `edit_log`) VALUES (5,1,0,11,0,0,0,1,0,'36','10000','2020-03-03 16:48:55',36,NULL,'Renew user: speedway Days:3 Years','36','',0,0,NULL,NULL,NULL,NULL),(6,1,0,12,0,0,0,1,0,'3','10000','2020-03-03 16:49:46',3,NULL,'add user: testtest Days:3 months','3','',0,0,NULL,NULL,NULL,NULL),(7,1,0,1,0,0,0,1,0,'1','1000','2020-08-29 15:03:32',1,NULL,'add user: abdulrahman Days:1 month','1','',0,0,NULL,NULL,NULL,NULL),(8,1,0,2,0,0,0,1,0,'1','','2020-08-30 00:48:51',1,NULL,'add user: abdi88 Days:1 month','1','',0,0,NULL,NULL,NULL,NULL),(9,1,0,3,0,0,0,1,0,'3','','2020-08-30 01:32:37',3,NULL,'add user: oxptv2 Days:3 months','3','',0,0,NULL,NULL,NULL,NULL),(10,1,0,5,0,0,0,1,0,'1','','2020-08-30 15:28:47',1,NULL,'add user: OSN-WWE Days:1 month','1','',0,0,NULL,NULL,NULL,NULL),(11,1,0,12,0,0,0,1,0,'1','','2020-09-14 01:55:05',1,NULL,'add user: 2020zzzz Days:1 month','1','',0,0,NULL,NULL,NULL,NULL),(12,1,0,0,0,4,0,1,0,'300','','2020-09-14 01:56:04',3,NULL,'Add 100 codes(s) Days:3 months','300','45207466984056\n33688795121020\n42208996214320\n23074144594644\n7542578019496\n34143205845996\n42586605126624\n1972846563012\n43914636470744\n30399117478236\n4768112536720\n11899480850868\n1948845996552\n33925600710092\n25421399994432\n51215608787876\n17635616234808\n29976707508540\n17709217971952\n39637735527572\n43460225745768\n30021508565932\n25869410568352\n27957459850372\n5692934364312\n19314055849244\n15494765706576\n40751361811316\n14109133002952\n9323420050828\n30823127485696\n23950965289316\n47409118947320\n37733690588412\n37447283828656\n2132850339412\n5648133306920\n11153863252844\n27175041383776\n26088615742020\n24816585719640\n19698064912604\n18029225524752\n15534766650676\n4969717294984\n22405328809292\n1817642899904\n21262901845796\n29667900220088\n4529706909884\n48993156333680\n15419563931668\n51396413055208\n29970307357484\n46503497572896\n48796351688708\n48855553085976\n31551144668316\n12371491991248\n41109770270452\n26960636323400\n20741289534732\n43265021138560\n43151418457316\n16841997503864\n35224831374460\n52346835487024\n27067838853588\n23414952638376\n34040803429100\n31424741684960\n43650630239684\n25379799012568\n2443257665628\n50951602556816\n12616297769140\n27651852637448\n4331302227148\n50305187300160\n37186477673124\n8931410798648\n24958989080636\n47508321288688\n37077675105172\n26563826957928\n23365351467692\n34368811170720\n10651451394948\n6819360950168\n37234478806044\n28909482319952\n34914424048244\n7043366237128\n25605404337292\n22938141384704\n3368079493220\n5936140104440\n26162217479164\n34477613738672\n45449072686420\n',0,0,NULL,NULL,NULL,NULL),(13,2,1,0,0,0,0,1,0,'','114','2020-09-14 02:35:40',0,NULL,'','114',NULL,1,1,'2020-09-14 02:35:28','2020-09-14 02:35:53','hhh',' \n <li>2020-09-14 02:35:53 Amount from (0) to (114) hhh</li>\n<li>2020-09-14 02:35:53 Amount from (1) to () hhh</li>\n'),(14,1,0,0,0,5,0,1,0,'2400','','2020-09-14 12:39:51',12,NULL,'Add 200 codes(s) Days:12 months','2400','38067417394490\n8185990811240\n50186395972350\n39672294013660\n36473741310050\n47477466644080\n23759534315110\n19927351361060\n50343203458570\n42018006001400\n48023092693070\n20151362055660\n38713848256050\n36046520913920\n16475986587830\n19044109193780\n39270674839770\n47586271838600\n6126692497310\n21521027445500\n11051727625730\n16013564511120\n15336732198150\n6281899907140\n44173308898730\n11782962535960\n16251975893230\n30673464396300\n45242159927250\n26702074796320\n7233945359190\n20964200861780\n51943279848570\n26362858601640\n12859813946430\n34500847121180\n23314713078690\n2572922835120\n31491103431590\n49983186270820\n49472761902410\n25786831101240\n35273684017550\n19895349833260\n37024167588210\n35380889135680\n22569077480950\n27799727199860\n23653929273370\n49378357395400\n17954457172190\n26180449893180\n20831394521410\n7155541616080\n19791344867910\n46168604157060\n13810259322090\n31598308549720\n225610770990\n40248321514060\n14059871238930\n9651660784480\n10050079805590\n39550688208020\n6833926261690\n11770161924840\n21410622174590\n48991138909020\n3601771953890\n29761420854000\n32668759654630\n47269456713380\n42048407452810\n29217394881400\n15970362448590\n39301076291180\n28780574026930\n1945692890240\n22108255480630\n3785780738740\n1483270813530\n18400878485000\n23228308953630\n50501611021180\n24057148523650\n17959257401360\n17692044644230\n854440792260\n29324599999530\n18644090096280\n30076635902830\n17053614164620\n28754972804690\n12262985452960\n6312301358550\n25367611087060\n7601962928890\n16839203928360\n23407517509310\n30711866229660\n29766221101773\n24180354420792\n27292503001287\n11786162696106\n28070140127313\n52309697374572\n42544431160299\n25937238298110\n13983067580949\n40603538498016\n15093520596303\n51864876137874\n25190002623513\n7085138259348\n21948247855347\n42053207708262\n20728989645405\n48424711897224\n9038831532759\n27633319272570\n38285027807457\n25351610339004\n942444994299\n13520645503950\n36896161500069\n34536048823344\n48451913195871\n30846272665698\n1816086703785\n41569984638180\n18850499962371\n32094332250678\n49376757349869\n38261026661592\n15362333429991\n48395910522186\n7537959878001\n42632435361804\n10133283784203\n32235138973086\n45062951399733\n46491819616896\n1524872800623\n14743103866674\n42342821535033\n15431136714804\n14114273845011\n835239876102\n10846917854589\n46120601894184\n46263008692983\n21642633264666\n40691542699521\n51720869262684\n17685644349723\n29649415525230\n38483437279941\n24039547698384\n31606308951423\n3555369740802\n41907600756681\n33531200849796\n7739569503267\n707233764822\n10002077520141\n19572134414712\n49309554141447\n52236093860586\n32883169911441\n185608861356\n23599526690859\n5763475160382\n17157619140693\n19610536248096\n33833615287695\n49714373468370\n510424368729\n43438873862868\n52157690117427\n31710313916838\n46842236346525\n11046927403464\n24501969775383\n35313685949370\n36544144694049\n45320563698684\n27874930807611\n13008621058830\n33516800162277\n33204785266032\n8206791809439\n48357508688802\n23013898731753\n45154155754020\n42506029326915\n41413177151862\n16504787973165\n20544980860440\n24271558775079\n23306712711306\n',0,0,NULL,NULL,NULL,NULL),(15,1,0,3,0,0,0,1,0,'12','','2021-04-03 07:23:11',12,NULL,'add user: hilukyjktf Days:12 months','12','',0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `solus_trans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solus_users_data`
--

DROP TABLE IF EXISTS `solus_users_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solus_users_data` (
  `userid` int(11) NOT NULL,
  `fullname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `period` smallint(6) NOT NULL,
  `free_days` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `fullname` (`fullname`),
  KEY `mobile` (`mobile`),
  KEY `period` (`period`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solus_users_data`
--

LOCK TABLES `solus_users_data` WRITE;
/*!40000 ALTER TABLE `solus_users_data` DISABLE KEYS */;
INSERT INTO `solus_users_data` (`userid`, `fullname`, `mobile`, `period`, `free_days`) VALUES (2,'Test','',6,0),(10,'aram','',-1,32767),(11,'speedway','',-1,0),(12,'test','',3,0),(1,'abd','009',1,0),(3,'Foxiptv','0770000000',3,0),(4,'kak aram','0770000000',-1,0),(5,'OSN WWE','0770000000',1,0),(6,'adi','iptv',-1,0),(7,'WENA','0770000000',-1,0),(8,'abdul','0770000000',-1,0),(0,'','',0,0),(13,'abderahmane Djouani','0671929909',107,0),(14,'abderahmane Djouani','0671929909',103,0),(15,'abderahmane Djouani','0671929909',101,0),(9,'Otman','',107,0);
/*!40000 ALTER TABLE `solus_users_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_categories`
--

DROP TABLE IF EXISTS `stream_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `cat_order` int(11) NOT NULL DEFAULT '0',
  `isLocked` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_type` (`category_type`),
  KEY `cat_order` (`cat_order`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_categories`
--

LOCK TABLES `stream_categories` WRITE;
/*!40000 ALTER TABLE `stream_categories` DISABLE KEYS */;
INSERT INTO `stream_categories` (`id`, `category_type`, `category_name`, `category_icon`, `parent_id`, `cat_order`, `isLocked`) VALUES (1,'live','TEST','',0,1,0),(2,'live','TEST2','',0,0,0),(3,'movie','ARABIC','',0,99,0);
/*!40000 ALTER TABLE `stream_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_logs`
--

DROP TABLE IF EXISTS `stream_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `error` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_id` (`stream_id`),
  KEY `server_id` (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18110 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_logs`
--

LOCK TABLES `stream_logs` WRITE;
/*!40000 ALTER TABLE `stream_logs` DISABLE KEYS */;
INSERT INTO `stream_logs` (`id`, `stream_id`, `server_id`, `date`, `error`) VALUES (1,309255,16,1570285389,'[tcp @ 0x520c540] Connection to tcp://127.0.0.1:83 failed: Connection refused'),(2,309255,16,1570285389,'Failed to open progress URL \"http://127.0.0.1:83/progress.php?stream_id=309255\": Connection refused'),(3,309255,16,1570285389,'[tcp @ 0x5212600] Connection to tcp://127.0.0.1:83 failed: Connection refused'),(4,309255,16,1570285389,'[tcp @ 0x522b2c0] Connection to tcp://127.0.0.1:83 failed: Connection refused'),(5,21112,16,1570285389,'[tcp @ 0x554a940] Connection to tcp://127.0.0.1:83 failed: Connection refused'),(6,21112,16,1570285389,'Failed to open progress URL \"http://127.0.0.1:83/progress.php?stream_id=21112\": Connection refused'),(7,21112,16,1570285389,'[http @ 0x55162c0] HTTP error 403 Forbidden'),(8,21112,16,1570285389,'[hls,applehttp @ 0x5510c00] keepalive request failed for \'http://50.7.198.106:80/uk_bbc_2_hd/tracks-v1a1/mono.m3u8?token=djIubG9jYWwuQzJlS2o5ck0xcEJaTF8tOGhHcnJqbkV3RWZsS28tSm9vSWt5V1g4bkJSSGMwYU5hLUR5SThCZ0twbDhnbXZYNlZ0S1gwLVc3NWFfc2I5RkNTYnpQR1RmZHI4QW1xN3VNZDlEaF9xenFUQlVLRG5wOVhmZ0JVc0c0YnUyamktbHVSaWM%3D\', retrying with new connection: Server returned 403 Forbidden (access denied)'),(9,21112,16,1570285389,'[http @ 0x567a300] HTTP error 403 Forbidden'),(10,21112,16,1570285389,'[hls,applehttp @ 0x5510c00] Failed to reload playlist 0'),(11,21112,16,1570285389,'[http @ 0x5679bc0] HTTP error 403 Forbidden'),(12,321974,16,1570285389,'[tcp @ 0x429a7c0] Connection to tcp://127.0.0.1:83 failed: Connection refused'),(13,321974,16,1570285389,'Failed to open progress URL \"http://127.0.0.1:83/progress.php?stream_id=321974\": Connection refused'),(14,321974,16,1570285389,'[http @ 0x4282080] HTTP error 403 Forbidden'),(15,321974,16,1570285389,'[hls,applehttp @ 0x427cb40] keepalive request failed for \'http://50.7.198.106:80/uk_virgin_media_1_hd/tracks-v1a1/mono.m3u8?token=djIubG9jYWwub3FDYktRRFo0Zzl3TjBtZFFzTmNqdDBxNEhnSzlEa2N3M0EycDN4ZFNEeUplSVJwU2FJaWw2c3VOMWtBcFBtb2VNWXVmSWVGY1VXNmd3THlVQXZVa2FRaVBkbzV6d1cwVFVKNWh6VGhYVFlIRnktUnpuaGwwSUlWalR4Zk94ZEZ6U2c%3D\', retrying with new connection: Server returned 403 Forbidden (access denied)'),(16,321974,16,1570285390,'[http @ 0x44cf880] HTTP error 403 Forbidden'),(17,321974,16,1570285390,'[hls,applehttp @ 0x427cb40] Failed to reload playlist 0'),(18,321974,16,1570285390,'[http @ 0x42fed40] HTTP error 403 Forbidden'),(18090,2,1,1618023541,'http://xxx.com:8880/22222h46/343434/39447: Invalid data found when processing input'),(18091,2,1,1618023541,'[http @ 0x3c944c0] HTTP error 403 Forbidden'),(18092,2,1,1618023541,'http://xxxxxx.com:8880/xxddfh46/343434/39447: Server returned 403 Forbidden (access denied)'),(18093,1,1,1618023541,'http://xxxx.com:8880/dffrrrrr46/343434/39447: Invalid data found when processing input'),(18094,1,1,1618023541,'[http @ 0x4d114c0] HTTP error 403 Forbidden'),(18095,1,1,1618023541,'http://xxxx.com:8880/dffrrrrr46/343434/39447: Server returned 403 Forbidden (access denied)'),(18096,2,1,1618023601,'[mpegts @ 0x48f5e80] frame size not set'),(18097,1,1,1618023601,'[http @ 0x39b64c0] HTTP error 403 Forbidden'),(18098,1,1,1618023601,'http://xxxx.com:8880/dffrrrrr46/343434/39447: Server returned 403 Forbidden (access denied)'),(18099,2,1,1618024261,'[mpegts @ 0x44268c0] frame size not set'),(18100,1,1,1618024261,'[mpegts @ 0x5721000] frame size not set'),(18101,2,1,1618024321,'[mpegts @ 0x4faaa40] frame size not set'),(18102,2,1,1618024441,'[mpegts @ 0x5745cc0] DTS 0 < 4896000 out of order'),(18103,2,1,1618024981,'http://xxxx.com:8880/dffrrrrr46/343434/9249: Invalid data found when processing input'),(18104,2,1,1618025041,'[mpegts @ 0x3b88cc0] DTS 0 < 12106800 out of order'),(18105,2,1,1618025221,'[mpegts @ 0x515fcc0] DTS 0 < 16588800 out of order'),(18106,2,1,1618025281,'[mpegts @ 0x552acc0] DTS 0 < 11480400 out of order'),(18107,2,1,1618025341,'[http @ 0x4dd84c0] HTTP error 403 Forbidden'),(18108,2,1,1618025341,'http://xxxx.com:8880/dffrrrrr46/343434/9249: Server returned 403 Forbidden (access denied)'),(18109,2,1,1618025341,'[http @ 0x4b6f4c0] HTTP error 403 Forbidden');
/*!40000 ALTER TABLE `stream_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_subcategories`
--

DROP TABLE IF EXISTS `stream_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_subcategories` (
  `sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `subcategory_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`sub_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_subcategories`
--

LOCK TABLES `stream_subcategories` WRITE;
/*!40000 ALTER TABLE `stream_subcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `stream_subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streaming_servers`
--

DROP TABLE IF EXISTS `streaming_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streaming_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `domain_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `server_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `server_ip6` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vpn_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ssh_password` mediumtext COLLATE utf8_unicode_ci,
  `ssh_port` int(11) DEFAULT NULL,
  `diff_time_main` int(11) NOT NULL DEFAULT '0',
  `http_broadcast_port` int(11) NOT NULL,
  `total_clients` int(11) NOT NULL DEFAULT '0',
  `system_os` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `network_interface` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latency` float NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '-1',
  `enable_geoip` int(11) NOT NULL DEFAULT '0',
  `geoip_countries` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `last_check_ago` int(11) NOT NULL DEFAULT '0',
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  `server_hardware` text COLLATE utf8_unicode_ci NOT NULL,
  `total_services` int(11) NOT NULL DEFAULT '3',
  `persistent_connections` tinyint(4) NOT NULL DEFAULT '0',
  `rtmp_port` int(11) NOT NULL DEFAULT '8001',
  `geoip_type` varchar(13) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'low_priority',
  `isp_names` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `isp_type` varchar(13) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'low_priority',
  `enable_isp` tinyint(4) NOT NULL DEFAULT '0',
  `boost_fpm` tinyint(4) NOT NULL DEFAULT '0',
  `http_ports_add` text COLLATE utf8_unicode_ci NOT NULL,
  `network_guaranteed_speed` int(11) NOT NULL DEFAULT '0',
  `https_broadcast_port` int(11) NOT NULL DEFAULT '25463',
  `https_ports_add` text COLLATE utf8_unicode_ci NOT NULL,
  `whitelist_ips` text COLLATE utf8_unicode_ci NOT NULL,
  `watchdog_data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `timeshift_only` tinyint(4) NOT NULL DEFAULT '0',
  `view_order` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `server_ip` (`server_ip`,`http_broadcast_port`),
  KEY `total_clients` (`total_clients`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streaming_servers`
--

LOCK TABLES `streaming_servers` WRITE;
/*!40000 ALTER TABLE `streaming_servers` DISABLE KEYS */;
INSERT INTO `streaming_servers` (`id`, `server_name`, `domain_name`, `server_ip`, `server_ip6`, `vpn_ip`, `ssh_password`, `ssh_port`, `diff_time_main`, `http_broadcast_port`, `total_clients`, `system_os`, `network_interface`, `latency`, `status`, `enable_geoip`, `geoip_countries`, `last_check_ago`, `can_delete`, `server_hardware`, `total_services`, `persistent_connections`, `rtmp_port`, `geoip_type`, `isp_names`, `isp_type`, `enable_isp`, `boost_fpm`, `http_ports_add`, `network_guaranteed_speed`, `https_broadcast_port`, `https_ports_add`, `whitelist_ips`, `watchdog_data`, `timeshift_only`, `view_order`) VALUES (1,'Main Server','','192.99.0.109','','','DAEDBBFfAA88YH5s',22,0,8880,1000,'Ubuntu 18.04.5 LTS','eno1',0,1,0,'[]',0,0,'{\"total_ram\":32837352,\"total_used\":1797668,\"cores\":0,\"threads\":8,\"kernel\":\"4.15.0-140-generic\",\"total_running_streams\":\"2\\n\",\"cpu_name\":\"Intel(R) Xeon(R) CPU E3-1245 V2 @ 3.40GHz\",\"cpu_usage\":1,\"network_speed\":\"1000\\n\",\"bytes_sent\":0.05,\"bytes_received\":4.19}',3,0,25462,'low_priority','[]','low_priority',0,1,'',1000,25463,'','[\"127.0.0.1\",\"192.99.0.109\",\"\"]','{\"cpu\":0,\"cpu_cores\":8,\"cpu_avg\":10,\"total_mem\":32837352,\"total_mem_free\":31064596,\"total_mem_used\":1772756,\"total_mem_used_percent\":5.398596086554116,\"total_disk_space\":1967814131712,\"uptime\":\"4d 11h 43m 15s\",\"total_running_streams\":\"2\\n\",\"bytes_sent\":0.06,\"bytes_received\":4.2,\"cpu_load_average\":0.84}',0,0);
/*!40000 ALTER TABLE `streaming_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams`
--

DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `stream_display_name` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `stream_source` mediumtext COLLATE utf8_unicode_ci,
  `stream_icon` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `notes` mediumtext COLLATE utf8_unicode_ci,
  `created_channel_location` int(11) DEFAULT NULL,
  `enable_transcode` tinyint(4) NOT NULL DEFAULT '0',
  `transcode_attributes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `custom_ffmpeg` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `movie_propeties` mediumtext COLLATE utf8_unicode_ci,
  `movie_subtitles` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `read_native` tinyint(4) NOT NULL DEFAULT '1',
  `target_container` text COLLATE utf8_unicode_ci,
  `stream_all` tinyint(4) NOT NULL DEFAULT '0',
  `remove_subtitles` tinyint(4) NOT NULL DEFAULT '0',
  `custom_sid` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `epg_id` int(11) DEFAULT NULL,
  `channel_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `epg_lang` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `auto_restart` text COLLATE utf8_unicode_ci NOT NULL,
  `transcode_profile_id` int(11) NOT NULL DEFAULT '0',
  `pids_create_channel` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `cchannel_rsources` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `gen_timestamps` tinyint(4) NOT NULL DEFAULT '1',
  `added` int(11) NOT NULL,
  `series_no` int(11) NOT NULL DEFAULT '0',
  `direct_source` tinyint(4) NOT NULL DEFAULT '0',
  `tv_archive_duration` int(11) NOT NULL DEFAULT '0',
  `tv_archive_server_id` int(11) NOT NULL DEFAULT '0',
  `tv_archive_pid` int(11) NOT NULL DEFAULT '0',
  `movie_symlink` tinyint(4) NOT NULL DEFAULT '0',
  `redirect_stream` tinyint(4) NOT NULL DEFAULT '0',
  `rtmp_output` tinyint(4) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL,
  `allow_record` tinyint(4) NOT NULL DEFAULT '0',
  `probesize_ondemand` int(11) NOT NULL DEFAULT '128000',
  `custom_map` text COLLATE utf8_unicode_ci NOT NULL,
  `external_push` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `delay_minutes` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `category_id` (`category_id`),
  KEY `created_channel_location` (`created_channel_location`),
  KEY `enable_transcode` (`enable_transcode`),
  KEY `read_native` (`read_native`),
  KEY `epg_id` (`epg_id`),
  KEY `channel_id` (`channel_id`),
  KEY `transcode_profile_id` (`transcode_profile_id`),
  KEY `order` (`order`),
  KEY `direct_source` (`direct_source`),
  KEY `rtmp_output` (`rtmp_output`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams`
--

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
INSERT INTO `streams` (`id`, `type`, `category_id`, `stream_display_name`, `stream_source`, `stream_icon`, `notes`, `created_channel_location`, `enable_transcode`, `transcode_attributes`, `custom_ffmpeg`, `movie_propeties`, `movie_subtitles`, `read_native`, `target_container`, `stream_all`, `remove_subtitles`, `custom_sid`, `epg_id`, `channel_id`, `epg_lang`, `order`, `auto_restart`, `transcode_profile_id`, `pids_create_channel`, `cchannel_rsources`, `gen_timestamps`, `added`, `series_no`, `direct_source`, `tv_archive_duration`, `tv_archive_server_id`, `tv_archive_pid`, `movie_symlink`, `redirect_stream`, `rtmp_output`, `number`, `allow_record`, `probesize_ondemand`, `custom_map`, `external_push`, `delay_minutes`) VALUES (1,1,1,'beIN Sport Premium 1 HD','[\"http:\\/\\/xxxx.com:8880\\/dffrrrrr46\\/343434\\/9251\"]','','',NULL,0,'','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,'',0,'','',0,1617392217,0,0,0,0,0,0,0,0,0,0,128000,'','',0),(2,1,1,'beIN Sport Premium 2 HD','[\"http:\\/\\/xxxx.com:8880\\/dffrrrrr46\\/343434\\/9249\"]','','',NULL,0,'','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,'',0,'','',0,1617471002,0,0,0,0,0,0,0,0,0,0,128000,'','',0),(3,2,3,'زنزانه','[\"http:\\/\\/xxxx.com:8880\\/movie\\/dffrrrrr46\\/343434\\/114990.mp4\"]','','',NULL,0,'[]','','{\"kinopoisk_url\":\"\",\"tmdb_id\":\"\",\"name\":\"\\u0632\\u0646\\u0632\\u0627\\u0646\\u0647\",\"o_name\":\"\\u0632\\u0646\\u0632\\u0627\\u0646\\u0647\",\"cover_big\":\"\",\"movie_image\":\"\",\"releasedate\":\"\",\"episode_run_time\":\"\",\"youtube_trailer\":\"\",\"director\":\"\",\"actors\":\"\",\"cast\":\"\",\"description\":\"\",\"plot\":\"\",\"age\":\"\",\"mpaa_rating\":\"\",\"rating_count_kinopoisk\":0,\"country\":\"\",\"genre\":\"\",\"duration_secs\":5495,\"duration\":\"01:31:35\",\"video\":{\"index\":0,\"codec_name\":\"h264\",\"codec_long_name\":\"H.264 \\/ AVC \\/ MPEG-4 AVC \\/ MPEG-4 part 10\",\"profile\":\"High\",\"codec_type\":\"video\",\"codec_time_base\":\"1\\/50\",\"codec_tag_string\":\"avc1\",\"codec_tag\":\"0x31637661\",\"width\":1280,\"height\":568,\"coded_width\":1280,\"coded_height\":576,\"has_b_frames\":2,\"pix_fmt\":\"yuv420p\",\"level\":31,\"chroma_location\":\"left\",\"refs\":1,\"is_avc\":\"true\",\"nal_length_size\":\"4\",\"r_frame_rate\":\"25\\/1\",\"avg_frame_rate\":\"25\\/1\",\"time_base\":\"1\\/12800\",\"start_pts\":0,\"start_time\":\"0.000000\",\"duration_ts\":70341120,\"duration\":\"5495.400000\",\"bit_rate\":\"790223\",\"bits_per_raw_sample\":\"8\",\"nb_frames\":\"137385\",\"disposition\":{\"default\":1,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0},\"tags\":{\"language\":\"und\",\"handler_name\":\"Eih.Youm.La.2020.720p.HD.ArbLionZ.TV.BY.KOKO_out.h264#video@GPAC0.7.2-DEV-rev79-geb669f9-master\"}},\"audio\":{\"index\":1,\"codec_name\":\"aac\",\"codec_long_name\":\"AAC (Advanced Audio Coding)\",\"profile\":\"LC\",\"codec_type\":\"audio\",\"codec_time_base\":\"1\\/48000\",\"codec_tag_string\":\"mp4a\",\"codec_tag\":\"0x6134706d\",\"sample_fmt\":\"fltp\",\"sample_rate\":\"48000\",\"channels\":2,\"channel_layout\":\"stereo\",\"bits_per_sample\":0,\"r_frame_rate\":\"0\\/0\",\"avg_frame_rate\":\"0\\/0\",\"time_base\":\"1\\/48000\",\"start_pts\":0,\"start_time\":\"0.000000\",\"duration_ts\":263784448,\"duration\":\"5495.509333\",\"bit_rate\":\"121883\",\"max_bit_rate\":\"121883\",\"nb_frames\":\"257602\",\"disposition\":{\"default\":1,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0},\"tags\":{\"language\":\"ara\",\"handler_name\":\"SoundHandler\"}},\"bitrate\":918,\"rating\":\"\"}','[]',0,'[\"mp4\"]',0,0,'',NULL,NULL,NULL,1,'[]',0,'','',1,1618025093,0,0,0,0,0,1,1,0,0,0,128000,'','[]',0);
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_arguments`
--

DROP TABLE IF EXISTS `streams_arguments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_arguments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `argument_cat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `argument_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `argument_description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `argument_wprotocol` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `argument_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `argument_cmd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `argument_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `argument_default_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_arguments`
--

LOCK TABLES `streams_arguments` WRITE;
/*!40000 ALTER TABLE `streams_arguments` DISABLE KEYS */;
INSERT INTO `streams_arguments` (`id`, `argument_cat`, `argument_name`, `argument_description`, `argument_wprotocol`, `argument_key`, `argument_cmd`, `argument_type`, `argument_default_value`) VALUES (1,'fetch','User Agent','Set a Custom User Agent','http','user_agent','-user-agent \"%s\"','text','Xtream-Codes IPTV Panel Pro'),(2,'fetch','HTTP Proxy','Set an HTTP Proxy in this format: ip:port','http','proxy','-http_proxy \"%s\"','text',NULL),(3,'transcode','Average Video Bit Rate','With this you can change the bitrate of the target video. It is very useful in case you want your video to be playable on slow internet connections',NULL,'bitrate','-b:v %dk','text',NULL),(4,'transcode','Average Audio Bitrate','Change Audio Bitrate',NULL,'audio_bitrate','-b:a %dk','text',NULL),(5,'transcode','Minimum Bitrate Tolerance','-minrate FFmpeg argument. Specify the minimum bitrate tolerance here. Specify in kbps. Enter INT number.',NULL,'minimum_bitrate','-minrate %dk','text',NULL),(6,'transcode','Maximum Bitrate Tolerance','-maxrate FFmpeg argument. Specify the maximum bitrate tolerance here.Specify in kbps. Enter INT number. ',NULL,'maximum_bitrate','-maxrate %dk','text',NULL),(7,'transcode','Buffer Size','-bufsize is the rate control buffer. Basically it is assumed that the receiver/end player will buffer that much data so its ok to fluctuate within that much. Specify in kbps. Enter INT number.',NULL,'bufsize','-bufsize %dk','text',NULL),(8,'transcode','CRF Value','The range of the quantizer scale is 0-51: where 0 is lossless, 23 is default, and 51 is worst possible. A lower value is a higher quality and a subjectively sane range is 18-28. Consider 18 to be visually lossless or nearly so: it should look the same or ',NULL,'crf','-crf %d','text',NULL),(9,'transcode','Scaling','Change the Width & Height of the target Video. (Eg. 320:240 ) .  If we\'d like to keep the aspect ratio, we need to specify only one component, either width or height, and set the other component to -1. (eg 320:-1)',NULL,'scaling','-filter_complex \"scale=%s\"','text',NULL),(10,'transcode','Aspect','Change the target Video Aspect. (eg 16:9)',NULL,'aspect','-aspect %s','text',NULL),(11,'transcode','Target Video FrameRate','Set the frame rate',NULL,'video_frame_rate','-r %d','text',NULL),(12,'transcode','Audio Sample Rate','Set the Audio Sample rate in Hz',NULL,'audio_sample_rate','-ar %d','text',NULL),(13,'transcode','Audio Channels','Specify Audio Channels',NULL,'audio_channels','-ac %d','text',NULL),(14,'transcode','Remove Sensitive Parts (delogo filter)','With this filter you can remove sensitive parts in your video. You will just specifiy the x & y pixels where there is a sensitive area and the width and height that will be removed. Example Use: x=0:y=0:w=100:h=77:band=10 ',NULL,'delogo','-filter_complex \"delogo=%s\"','text',NULL),(15,'transcode','Threads','Specify the number of threads you want to use for the transcoding process. Entering 0 as value will make FFmpeg to choose the most optimal settings',NULL,'threads','-threads %d','text',NULL),(16,'transcode','Logo Path','Add your Own Logo to the stream. The logo will be placed in the upper left. Please be sure that you have selected H.264 as codec otherwise this option won\'t work. Note that adding your own logo will consume A LOT of cpu power',NULL,'logo','-i \"%s\" -filter_complex \"overlay\"','text',NULL),(17,'fetch','Cookie','Set an HTTP Cookie that might be useful to fetch your INPUT Source.','http','cookie','-cookies \'%s\'','text',NULL),(18,'transcode','DeInterlacing Filter','It check pixels of previous, current and next frames to re-create the missed field by some local adaptive method (edge-directed interpolation) and uses spatial check to prevent most artifacts. ',NULL,'','-filter_complex \"yadif\"','radio','0'),(19,'fetch','Headers','Set Custom Headers','http','headers','-headers \"%s\"','text',NULL);
/*!40000 ALTER TABLE `streams_arguments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_options`
--

DROP TABLE IF EXISTS `streams_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `argument_id` int(11) NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `stream_id` (`stream_id`),
  KEY `argument_id` (`argument_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_options`
--

LOCK TABLES `streams_options` WRITE;
/*!40000 ALTER TABLE `streams_options` DISABLE KEYS */;
INSERT INTO `streams_options` (`id`, `stream_id`, `argument_id`, `value`) VALUES (1,1,1,'Xtream-Codes IPTV Panel Pro'),(2,2,1,'Xtream-Codes IPTV Panel Pro');
/*!40000 ALTER TABLE `streams_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_seasons`
--

DROP TABLE IF EXISTS `streams_seasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_seasons` (
  `season_id` int(11) NOT NULL AUTO_INCREMENT,
  `season_name` varchar(255) NOT NULL,
  `stream_id` int(11) NOT NULL,
  PRIMARY KEY (`season_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_seasons`
--

LOCK TABLES `streams_seasons` WRITE;
/*!40000 ALTER TABLE `streams_seasons` DISABLE KEYS */;
/*!40000 ALTER TABLE `streams_seasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_sys`
--

DROP TABLE IF EXISTS `streams_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_sys` (
  `server_stream_id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `to_analyze` tinyint(4) NOT NULL DEFAULT '0',
  `stream_status` int(11) NOT NULL DEFAULT '0',
  `stream_started` int(11) DEFAULT NULL,
  `stream_info` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `monitor_pid` int(11) DEFAULT NULL,
  `current_source` mediumtext COLLATE utf8_unicode_ci,
  `bitrate` int(11) DEFAULT NULL,
  `progress_info` text COLLATE utf8_unicode_ci NOT NULL,
  `on_demand` tinyint(4) NOT NULL DEFAULT '0',
  `delay_pid` int(11) DEFAULT NULL,
  `delay_available_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`server_stream_id`),
  UNIQUE KEY `stream_id_2` (`stream_id`,`server_id`),
  KEY `stream_id` (`stream_id`),
  KEY `pid` (`pid`),
  KEY `server_id` (`server_id`),
  KEY `stream_status` (`stream_status`),
  KEY `stream_started` (`stream_started`),
  KEY `parent_id` (`parent_id`),
  KEY `to_analyze` (`to_analyze`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_sys`
--

LOCK TABLES `streams_sys` WRITE;
/*!40000 ALTER TABLE `streams_sys` DISABLE KEYS */;
INSERT INTO `streams_sys` (`server_stream_id`, `stream_id`, `server_id`, `parent_id`, `pid`, `to_analyze`, `stream_status`, `stream_started`, `stream_info`, `monitor_pid`, `current_source`, `bitrate`, `progress_info`, `on_demand`, `delay_pid`, `delay_available_at`) VALUES (1,1,1,NULL,7321,0,0,1618024903,'{\"codecs\":{\"video\":{\"index\":0,\"codec_name\":\"h264\",\"codec_long_name\":\"H.264 \\/ AVC \\/ MPEG-4 AVC \\/ MPEG-4 part 10\",\"profile\":\"High\",\"codec_type\":\"video\",\"codec_time_base\":\"1\\/50\",\"codec_tag_string\":\"[27][0][0][0]\",\"codec_tag\":\"0x001b\",\"width\":1280,\"height\":720,\"coded_width\":1280,\"coded_height\":720,\"has_b_frames\":0,\"sample_aspect_ratio\":\"1:1\",\"display_aspect_ratio\":\"16:9\",\"pix_fmt\":\"yuv420p\",\"level\":31,\"chroma_location\":\"left\",\"field_order\":\"progressive\",\"refs\":1,\"is_avc\":\"false\",\"nal_length_size\":\"0\",\"id\":\"0x100\",\"r_frame_rate\":\"25\\/1\",\"avg_frame_rate\":\"25\\/1\",\"time_base\":\"1\\/90000\",\"start_pts\":45000000,\"start_time\":\"500.000000\",\"bits_per_raw_sample\":\"8\",\"disposition\":{\"default\":0,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0}},\"audio\":{\"index\":1,\"codec_name\":\"aac\",\"codec_long_name\":\"AAC (Advanced Audio Coding)\",\"profile\":\"LC\",\"codec_type\":\"audio\",\"codec_time_base\":\"1\\/44100\",\"codec_tag_string\":\"[15][0][0][0]\",\"codec_tag\":\"0x000f\",\"sample_fmt\":\"fltp\",\"sample_rate\":\"44100\",\"channels\":2,\"channel_layout\":\"stereo\",\"bits_per_sample\":0,\"id\":\"0x101\",\"r_frame_rate\":\"0\\/0\",\"avg_frame_rate\":\"0\\/0\",\"time_base\":\"1\\/90000\",\"start_pts\":45001311,\"start_time\":\"500.014567\",\"bit_rate\":\"130577\",\"disposition\":{\"default\":0,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0}}},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/xxxx.com:8880\\/dffrrrrr46\\/343434\\/9251\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',32749,'http://xxxx.com:8880/dffrrrrr46/343434/9251',1451,'{\"frame\":\"19500\",\"fps\":\"27.05\",\"stream_0_0_q\":\"-1.0\",\"bitrate\":\"N\\/A\",\"total_size\":\"N\\/A\",\"out_time_us\":\"779989333\",\"out_time_ms\":\"779989333\",\"out_time\":\"00:12:59.989333\",\"dup_frames\":\"0\",\"drop_frames\":\"0\",\"speed\":\"1.08x\",\"progress\":\"continue\"}',0,NULL,0),(2,2,1,NULL,12487,0,0,1618025349,'{\"codecs\":{\"video\":{\"index\":0,\"codec_name\":\"h264\",\"codec_long_name\":\"H.264 \\/ AVC \\/ MPEG-4 AVC \\/ MPEG-4 part 10\",\"profile\":\"High\",\"codec_type\":\"video\",\"codec_time_base\":\"1\\/50\",\"codec_tag_string\":\"[27][0][0][0]\",\"codec_tag\":\"0x001b\",\"width\":1280,\"height\":720,\"coded_width\":1280,\"coded_height\":720,\"has_b_frames\":0,\"sample_aspect_ratio\":\"1:1\",\"display_aspect_ratio\":\"16:9\",\"pix_fmt\":\"yuv420p\",\"level\":31,\"chroma_location\":\"left\",\"field_order\":\"progressive\",\"refs\":1,\"is_avc\":\"false\",\"nal_length_size\":\"0\",\"id\":\"0x100\",\"r_frame_rate\":\"25\\/1\",\"avg_frame_rate\":\"25\\/1\",\"time_base\":\"1\\/90000\",\"start_pts\":0,\"start_time\":\"0.000000\",\"bits_per_raw_sample\":\"8\",\"disposition\":{\"default\":0,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0}},\"audio\":{\"index\":1,\"codec_name\":\"aac\",\"codec_long_name\":\"AAC (Advanced Audio Coding)\",\"profile\":\"LC\",\"codec_type\":\"audio\",\"codec_time_base\":\"1\\/44100\",\"codec_tag_string\":\"[15][0][0][0]\",\"codec_tag\":\"0x000f\",\"sample_fmt\":\"fltp\",\"sample_rate\":\"44100\",\"channels\":2,\"channel_layout\":\"stereo\",\"bits_per_sample\":0,\"id\":\"0x101\",\"r_frame_rate\":\"0\\/0\",\"avg_frame_rate\":\"0\\/0\",\"time_base\":\"1\\/90000\",\"start_pts\":143,\"start_time\":\"0.001589\",\"bit_rate\":\"141602\",\"disposition\":{\"default\":0,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0}}},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/xxxx.com:8880\\/dffrrrrr46\\/343434\\/9249\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',321,'http://xxxx.com:8880/dffrrrrr46/343434/9249',1466,'{\"frame\":\"7500\",\"fps\":\"27.71\",\"stream_0_0_q\":\"-1.0\",\"bitrate\":\"N\\/A\",\"total_size\":\"N\\/A\",\"out_time_us\":\"299977278\",\"out_time_ms\":\"299977278\",\"out_time\":\"00:04:59.977278\",\"dup_frames\":\"0\",\"drop_frames\":\"0\",\"speed\":\"1.11x\",\"progress\":\"continue\"}',0,NULL,0),(3,3,1,NULL,9429,0,0,1618025093,'{\"codecs\":{\"video\":{\"index\":0,\"codec_name\":\"h264\",\"codec_long_name\":\"H.264 \\/ AVC \\/ MPEG-4 AVC \\/ MPEG-4 part 10\",\"profile\":\"High\",\"codec_type\":\"video\",\"codec_time_base\":\"1\\/50\",\"codec_tag_string\":\"avc1\",\"codec_tag\":\"0x31637661\",\"width\":1280,\"height\":568,\"coded_width\":1280,\"coded_height\":576,\"has_b_frames\":2,\"pix_fmt\":\"yuv420p\",\"level\":31,\"chroma_location\":\"left\",\"refs\":1,\"is_avc\":\"true\",\"nal_length_size\":\"4\",\"r_frame_rate\":\"25\\/1\",\"avg_frame_rate\":\"25\\/1\",\"time_base\":\"1\\/12800\",\"start_pts\":0,\"start_time\":\"0.000000\",\"duration_ts\":70341120,\"duration\":\"5495.400000\",\"bit_rate\":\"790223\",\"bits_per_raw_sample\":\"8\",\"nb_frames\":\"137385\",\"disposition\":{\"default\":1,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0},\"tags\":{\"language\":\"und\",\"handler_name\":\"Eih.Youm.La.2020.720p.HD.ArbLionZ.TV.BY.KOKO_out.h264#video@GPAC0.7.2-DEV-rev79-geb669f9-master\"}},\"audio\":{\"index\":1,\"codec_name\":\"aac\",\"codec_long_name\":\"AAC (Advanced Audio Coding)\",\"profile\":\"LC\",\"codec_type\":\"audio\",\"codec_time_base\":\"1\\/48000\",\"codec_tag_string\":\"mp4a\",\"codec_tag\":\"0x6134706d\",\"sample_fmt\":\"fltp\",\"sample_rate\":\"48000\",\"channels\":2,\"channel_layout\":\"stereo\",\"bits_per_sample\":0,\"r_frame_rate\":\"0\\/0\",\"avg_frame_rate\":\"0\\/0\",\"time_base\":\"1\\/48000\",\"start_pts\":0,\"start_time\":\"0.000000\",\"duration_ts\":263784448,\"duration\":\"5495.509333\",\"bit_rate\":\"121883\",\"max_bit_rate\":\"121883\",\"nb_frames\":\"257602\",\"disposition\":{\"default\":1,\"dub\":0,\"original\":0,\"comment\":0,\"lyrics\":0,\"karaoke\":0,\"forced\":0,\"hearing_impaired\":0,\"visual_impaired\":0,\"clean_effects\":0,\"attached_pic\":0,\"timed_thumbnails\":0},\"tags\":{\"language\":\"ara\",\"handler_name\":\"SoundHandler\"}}},\"container\":\"mov,mp4,m4a,3gp,3g2,mj2\",\"filename\":\"\\/home\\/xtreamcodes\\/iptv_xtream_codes\\/movies\\/3.mp4\",\"bitrate\":\"918170\",\"of_duration\":\"5495.510000\",\"duration\":\"01:31:35\"}',NULL,NULL,918,'',0,NULL,NULL);
/*!40000 ALTER TABLE `streams_sys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_types`
--

DROP TABLE IF EXISTS `streams_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_types` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type_output` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `live` tinyint(4) NOT NULL,
  PRIMARY KEY (`type_id`),
  KEY `type_key` (`type_key`),
  KEY `type_output` (`type_output`),
  KEY `live` (`live`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_types`
--

LOCK TABLES `streams_types` WRITE;
/*!40000 ALTER TABLE `streams_types` DISABLE KEYS */;
INSERT INTO `streams_types` (`type_id`, `type_name`, `type_key`, `type_output`, `live`) VALUES (1,'Live Streams','live','live',1),(2,'Movies','movie','movie',0),(3,'Created Live Channels','created_live','live',1),(4,'Radio','radio_streams','live',1),(5,'TV Series','series','series',0);
/*!40000 ALTER TABLE `streams_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subreseller_setup`
--

DROP TABLE IF EXISTS `subreseller_setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subreseller_setup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reseller` int(8) NOT NULL DEFAULT '0',
  `subreseller` int(8) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subreseller_setup`
--

LOCK TABLES `subreseller_setup` WRITE;
/*!40000 ALTER TABLE `subreseller_setup` DISABLE KEYS */;
/*!40000 ALTER TABLE `subreseller_setup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suspicious_logs`
--

DROP TABLE IF EXISTS `suspicious_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suspicious_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `data` mediumtext NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suspicious_logs`
--

LOCK TABLES `suspicious_logs` WRITE;
/*!40000 ALTER TABLE `suspicious_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `suspicious_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `admin_read` tinyint(4) NOT NULL,
  `user_read` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `status` (`status`),
  KEY `admin_read` (`admin_read`),
  KEY `user_read` (`user_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_replies`
--

DROP TABLE IF EXISTS `tickets_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `admin_reply` tinyint(4) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_replies`
--

LOCK TABLES `tickets_replies` WRITE;
/*!40000 ALTER TABLE `tickets_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmdb_async`
--

DROP TABLE IF EXISTS `tmdb_async`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmdb_async` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL DEFAULT '0',
  `stream_id` int(16) NOT NULL DEFAULT '0',
  `status` int(8) NOT NULL DEFAULT '0',
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmdb_async`
--

LOCK TABLES `tmdb_async` WRITE;
/*!40000 ALTER TABLE `tmdb_async` DISABLE KEYS */;
/*!40000 ALTER TABLE `tmdb_async` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transcoding_profiles`
--

DROP TABLE IF EXISTS `transcoding_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transcoding_profiles` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `profile_options` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transcoding_profiles`
--

LOCK TABLES `transcoding_profiles` WRITE;
/*!40000 ALTER TABLE `transcoding_profiles` DISABLE KEYS */;
INSERT INTO `transcoding_profiles` (`profile_id`, `profile_name`, `profile_options`) VALUES (1,'Standard H264 AAC','{\"-vcodec\":\"h264\",\"-acodec\":\"aac\"}');
/*!40000 ALTER TABLE `transcoding_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity`
--

DROP TABLE IF EXISTS `user_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `container` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  `geoip_country_code` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `isp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `external_device` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `divergence` int(11) DEFAULT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `user_id` (`user_id`),
  KEY `stream_id` (`stream_id`),
  KEY `server_id` (`server_id`),
  KEY `date_end` (`date_end`),
  KEY `container` (`container`),
  KEY `geoip_country_code` (`geoip_country_code`),
  KEY `date_start` (`date_start`),
  KEY `date_start_2` (`date_start`,`date_end`),
  KEY `user_ip` (`user_ip`),
  KEY `user_agent` (`user_agent`),
  KEY `isp` (`isp`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity`
--

LOCK TABLES `user_activity` WRITE;
/*!40000 ALTER TABLE `user_activity` DISABLE KEYS */;
INSERT INTO `user_activity` (`activity_id`, `user_id`, `stream_id`, `server_id`, `user_agent`, `user_ip`, `container`, `date_start`, `date_end`, `geoip_country_code`, `isp`, `external_device`, `divergence`) VALUES (1,2,1,1,'VLC/3.0.12 LibVLC/3.0.12','105.155.39.86','ts',1617418816,1617418826,'MA','','',NULL),(2,2,1,1,'VLC/3.0.12 LibVLC/3.0.12','105.155.39.86','ts',1617419777,1617419779,'MA','','',NULL),(3,2,1,1,'VLC/3.0.12 LibVLC/3.0.12','105.155.39.86','ts',1617419788,1617419791,'MA','','',NULL),(4,1,1,1,'VLC/3.0.12 LibVLC/3.0.12','105.155.39.86','ts',1617419797,1617419804,'MA','','',NULL),(5,3,1,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617426927,1617426942,'MA','','',NULL),(6,3,1,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617426942,1617426949,'MA','','',NULL),(7,3,1,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617427069,1617427096,'MA','','',NULL),(8,4,1,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617468985,1617468993,'MA','','',NULL),(9,4,1,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617468985,1617469021,'MA','','',NULL),(10,7,1,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617469445,1617469456,'MA','','',NULL),(11,6,2,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617474199,1617474204,'MA','','',NULL),(12,6,1,1,'VLC/3.0.12 LibVLC/3.0.12','160.177.138.188','ts',1617474204,1617474208,'MA','','',NULL),(13,11,1,1,'VLC/3.0.12 LibVLC/3.0.12','105.155.60.126','ts',1617642414,1617642418,'MA','','',NULL),(14,10,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617642539,1617642588,'MA','','',NULL),(15,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617642715,1617642723,'MA','','',NULL),(16,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617642723,1617642752,'MA','','',NULL),(17,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617642752,1617642904,'MA','','',NULL),(18,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643022,1617643029,'MA','','',NULL),(19,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643029,1617643066,'MA','','',NULL),(20,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643066,1617643083,'MA','','',NULL),(21,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643083,1617643086,'MA','','',NULL),(22,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643090,1617643096,'MA','','',NULL),(23,13,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643386,1617643393,'US','','',NULL),(24,13,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643393,1617643413,'US','','',NULL),(25,13,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643413,1617643419,'US','','',NULL),(26,13,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643419,1617643422,'US','','',NULL),(27,13,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643422,1617643429,'US','','',NULL),(28,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643363,1617643468,'MA','','',NULL),(29,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643468,1617643489,'MA','','',NULL),(30,13,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643484,1617643495,'US','','',NULL),(31,13,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643500,1617643514,'US','','',NULL),(32,13,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617643514,1617643529,'US','','',NULL),(33,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643874,1617643896,'MA','','',NULL),(34,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643896,1617643915,'MA','','',NULL),(35,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643916,1617643929,'MA','','',NULL),(36,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643929,1617643934,'MA','','',NULL),(37,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643935,1617643965,'MA','','',NULL),(38,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617643966,1617644003,'MA','','',NULL),(39,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617644003,1617644005,'MA','','',NULL),(40,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.60.126','ts',1617644006,1617644037,'MA','','',NULL),(41,13,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617644311,1617644368,'US','','',NULL),(42,14,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','197.25.226.158','ts',1617645305,1617645309,'TN','','',NULL),(43,14,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','197.25.226.158','ts',1617645310,1617645322,'TN','','',NULL),(44,14,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','197.25.226.158','ts',1617645322,1617645335,'TN','','',NULL),(45,14,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','197.25.226.158','ts',1617645335,1617645344,'TN','','',NULL),(46,14,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','197.25.226.158','ts',1617645481,1617645489,'TN','','',NULL),(47,14,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','197.25.226.158','ts',1617645490,1617645971,'TN','','',NULL),(48,12,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','160.177.141.26','ts',1617716015,1617716024,'MA','','',NULL),(49,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','160.177.141.26','ts',1617716024,1617716047,'MA','','',NULL),(50,12,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','160.177.141.26','ts',1617716052,1617716106,'MA','','',NULL),(51,9,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 11) ExoPlayerLib/2.12.3','96.233.108.137','ts',1617719084,1617719180,'US','','',NULL),(52,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618022484,1618022488,'MA','','',NULL),(53,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618022484,1618022488,'MA','','',NULL),(54,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618022488,1618022497,'MA','','',NULL),(55,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618022488,1618022521,'MA','','',NULL),(56,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023772,1618023781,'MA','','',NULL),(57,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023781,1618023790,'MA','','',NULL),(58,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023789,1618023793,'MA','','',NULL),(59,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023793,1618023845,'MA','','',NULL),(60,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023845,1618023848,'MA','','',NULL),(61,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023848,1618023856,'MA','','',NULL),(62,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023857,1618023867,'MA','','',NULL),(63,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023867,1618023877,'MA','','',NULL),(64,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023887,1618023899,'MA','','',NULL),(65,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023906,1618023919,'MA','','',NULL),(66,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023926,1618023939,'MA','','',NULL),(67,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023946,1618023958,'MA','','',NULL),(68,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023966,1618023978,'MA','','',NULL),(69,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023986,1618023995,'MA','','',NULL),(70,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618023995,1618024111,'MA','','',NULL),(71,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024111,1618024113,'MA','','',NULL),(72,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024113,1618024134,'MA','','',NULL),(73,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024134,1618024135,'MA','','',NULL),(74,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024135,1618024311,'MA','','',NULL),(75,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024311,1618024316,'MA','','',NULL),(76,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024316,1618024331,'MA','','',NULL),(77,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024331,1618024343,'MA','','',NULL),(78,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618024343,1618024371,'MA','','',NULL),(79,15,3,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','VOD',1618025323,1618025350,'MA','','',NULL),(80,15,3,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','VOD',1618025443,1618025453,'MA','','',NULL),(81,15,3,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','VOD',1618025453,1618025465,'MA','','',NULL),(82,15,1,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618025473,1618025476,'MA','','',NULL),(83,15,2,1,'ExoPlayerLib/2.12.3 (Linux;Android 7.1.1) ExoPlayerLib/2.12.3','105.155.54.150','ts',1618025476,1618025489,'MA','','',NULL);
/*!40000 ALTER TABLE `user_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity_now`
--

DROP TABLE IF EXISTS `user_activity_now`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity_now` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `container` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  `geoip_country_code` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `isp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `external_device` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `divergence` int(11) DEFAULT NULL,
  `hls_last_read` int(11) DEFAULT NULL,
  `hls_end` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`activity_id`),
  KEY `user_agent` (`user_agent`),
  KEY `user_ip` (`user_ip`),
  KEY `container` (`container`),
  KEY `pid` (`pid`),
  KEY `geoip_country_code` (`geoip_country_code`),
  KEY `user_id` (`user_id`),
  KEY `stream_id` (`stream_id`),
  KEY `server_id` (`server_id`),
  KEY `date_start` (`date_start`),
  KEY `date_end` (`date_end`),
  KEY `hls_end` (`hls_end`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_now`
--

LOCK TABLES `user_activity_now` WRITE;
/*!40000 ALTER TABLE `user_activity_now` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_activity_now` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_output`
--

DROP TABLE IF EXISTS `user_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_output` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `access_output_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `access_output_id` (`access_output_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_output`
--

LOCK TABLES `user_output` WRITE;
/*!40000 ALTER TABLE `user_output` DISABLE KEYS */;
INSERT INTO `user_output` (`id`, `user_id`, `access_output_id`) VALUES (1,1,1),(2,1,2),(3,1,3),(4,2,1),(5,2,2),(6,2,3),(7,3,1),(8,3,2),(9,3,3),(10,4,2),(11,5,2),(12,6,2),(13,7,1),(14,7,2),(15,7,3),(16,8,2),(17,9,2),(18,10,2),(19,11,2),(20,12,2),(21,13,2),(22,14,2),(23,15,2);
/*!40000 ALTER TABLE `user_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exp_date` int(11) DEFAULT NULL,
  `admin_enabled` int(11) NOT NULL DEFAULT '1',
  `enabled` int(11) NOT NULL DEFAULT '1',
  `admin_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `reseller_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `bouquet` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `max_connections` int(11) NOT NULL DEFAULT '1',
  `is_restreamer` tinyint(4) NOT NULL DEFAULT '0',
  `allowed_ips` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `allowed_ua` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `is_trial` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `pair_id` int(11) DEFAULT NULL,
  `is_mag` tinyint(4) NOT NULL DEFAULT '0',
  `is_e2` tinyint(4) NOT NULL DEFAULT '0',
  `force_server_id` int(11) NOT NULL DEFAULT '0',
  `is_isplock` tinyint(4) NOT NULL DEFAULT '0',
  `as_number` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isp_desc` mediumtext COLLATE utf8_unicode_ci,
  `forced_country` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `is_stalker` tinyint(4) NOT NULL DEFAULT '0',
  `bypass_ua` tinyint(4) NOT NULL DEFAULT '0',
  `play_token` text COLLATE utf8_unicode_ci NOT NULL,
  `pkg` int(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `exp_date` (`exp_date`),
  KEY `is_restreamer` (`is_restreamer`),
  KEY `admin_enabled` (`admin_enabled`),
  KEY `enabled` (`enabled`),
  KEY `is_trial` (`is_trial`),
  KEY `created_at` (`created_at`),
  KEY `created_by` (`created_by`),
  KEY `pair_id` (`pair_id`),
  KEY `is_mag` (`is_mag`),
  KEY `username` (`username`),
  KEY `password` (`password`),
  KEY `is_e2` (`is_e2`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `member_id`, `username`, `password`, `exp_date`, `admin_enabled`, `enabled`, `admin_notes`, `reseller_notes`, `bouquet`, `max_connections`, `is_restreamer`, `allowed_ips`, `allowed_ua`, `is_trial`, `created_at`, `created_by`, `pair_id`, `is_mag`, `is_e2`, `force_server_id`, `is_isplock`, `as_number`, `isp_desc`, `forced_country`, `is_stalker`, `bypass_ua`, `play_token`, `pkg`) VALUES (1,1,'dffrrrrr46','qBcUgZTfP6',1617676104,1,1,'','','[1]',1,0,'','',1,1617416904,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(2,1,'liugyftr','jhgjfhfgdh',1618441200,1,1,'','','[1]',1,0,'[]','[]',1,1617417412,1,NULL,0,0,0,0,NULL,'','',0,0,'',0),(3,1,'hilukyjktf','Ca09dC9CBA',1648959791,1,1,'','','[1]',1,0,'','',0,1617423791,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(4,1,'179706940524','95237952060689cbd9f716',1617727805,1,1,'testapk','','[1]',1,0,'','',0,1617468605,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(5,1,'2318069764','110947934860689eb75c616',1618073911,1,1,'testapk','','[1]',1,0,'','',0,1617469111,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(6,1,'1004187187','51233162460689f777d564',1617728503,1,1,'testapk','','[1]',1,0,'','',0,1617469303,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(7,1,'faisal3','jVcC0t7vK5',1617555779,1,1,'','','[1]',1,0,'','',1,1617469379,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(8,1,'195516988720','15421927336068a30c27cdf',1618075020,1,1,'??????????','','[1]',1,0,'','',0,1617470220,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(9,1,'104534231985','64728303',1618076252,1,1,'otman','','[1]',2,0,'','',1,1617471452,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(12,1,'284743215232','1459170604606b44a520f4c',1617901861,1,1,'tEST apP','','[1,2]',1,0,'','',0,1617642661,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(13,1,'334067548682','1531964998606b4770967b7',1618507376,1,1,'otmano1','','[1,2]',1,0,'','',0,1617643376,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(14,1,'113708708363','1282544608606b4ee7f3087',1617904487,1,1,'mahdi','','[1,2]',1,0,'','',0,1617645287,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0),(15,1,'195578039187','9943622746071104ee4706',1618886478,1,1,'ugyyjgcf','','[1,2,3]',1,0,'','',0,1618022478,1,NULL,0,0,0,0,NULL,NULL,'',0,0,'',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watch_categories`
--

DROP TABLE IF EXISTS `watch_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watch_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL DEFAULT '0',
  `genre_id` int(8) NOT NULL DEFAULT '0',
  `genre` varchar(64) NOT NULL DEFAULT '',
  `category_id` int(8) NOT NULL DEFAULT '0',
  `bouquets` varchar(4096) NOT NULL DEFAULT '[]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watch_categories`
--

LOCK TABLES `watch_categories` WRITE;
/*!40000 ALTER TABLE `watch_categories` DISABLE KEYS */;
INSERT INTO `watch_categories` (`id`, `type`, `genre_id`, `genre`, `category_id`, `bouquets`) VALUES (1,1,28,'Action',0,'[]'),(2,1,12,'Adventure',0,'[]'),(3,1,16,'Animation',0,'[]'),(4,1,35,'Comedy',0,'[]'),(5,1,80,'Crime',0,'[]'),(6,1,99,'Documentary',0,'[]'),(7,1,18,'Drama',0,'[]'),(8,1,10751,'Family',0,'[]'),(9,1,14,'Fantasy',0,'[]'),(10,1,36,'History',0,'[]'),(11,1,27,'Horror',0,'[]'),(12,1,10402,'Music',0,'[]'),(13,1,9648,'Mystery',0,'[]'),(14,1,10749,'Romance',0,'[]'),(15,1,878,'Science Fiction',0,'[]'),(16,1,10770,'TV Movie',0,'[]'),(17,1,53,'Thriller',0,'[]'),(18,1,10752,'War',0,'[]'),(19,1,37,'Western',0,'[]');
/*!40000 ALTER TABLE `watch_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watch_folders`
--

DROP TABLE IF EXISTS `watch_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watch_folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL DEFAULT '',
  `directory` varchar(2048) NOT NULL DEFAULT '',
  `server_id` int(8) NOT NULL DEFAULT '0',
  `category_id` int(8) NOT NULL DEFAULT '0',
  `bouquets` varchar(4096) NOT NULL DEFAULT '[]',
  `last_run` int(32) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '1',
  `disable_tmdb` int(1) NOT NULL DEFAULT '0',
  `ignore_no_match` int(1) NOT NULL DEFAULT '0',
  `auto_subtitles` int(1) NOT NULL DEFAULT '0',
  `fb_bouquets` varchar(4096) NOT NULL DEFAULT '[]',
  `fb_category_id` int(8) NOT NULL DEFAULT '0',
  `allowed_extensions` varchar(4096) NOT NULL DEFAULT '[]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watch_folders`
--

LOCK TABLES `watch_folders` WRITE;
/*!40000 ALTER TABLE `watch_folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `watch_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watch_output`
--

DROP TABLE IF EXISTS `watch_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watch_output` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL DEFAULT '0',
  `server_id` int(8) NOT NULL DEFAULT '0',
  `filename` varchar(4096) NOT NULL DEFAULT '',
  `status` int(1) NOT NULL DEFAULT '0',
  `stream_id` int(8) NOT NULL DEFAULT '0',
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watch_output`
--

LOCK TABLES `watch_output` WRITE;
/*!40000 ALTER TABLE `watch_output` DISABLE KEYS */;
/*!40000 ALTER TABLE `watch_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watch_settings`
--

DROP TABLE IF EXISTS `watch_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watch_settings` (
  `read_native` int(1) NOT NULL DEFAULT '1',
  `movie_symlink` int(1) NOT NULL DEFAULT '1',
  `auto_encode` int(1) NOT NULL DEFAULT '0',
  `transcode_profile_id` int(8) NOT NULL DEFAULT '0',
  `scan_seconds` int(8) NOT NULL DEFAULT '3600',
  `percentage_match` int(3) NOT NULL DEFAULT '80',
  `ffprobe_input` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watch_settings`
--

LOCK TABLES `watch_settings` WRITE;
/*!40000 ALTER TABLE `watch_settings` DISABLE KEYS */;
INSERT INTO `watch_settings` (`read_native`, `movie_symlink`, `auto_encode`, `transcode_profile_id`, `scan_seconds`, `percentage_match`, `ffprobe_input`) VALUES (1,1,0,0,3600,80,0);
/*!40000 ALTER TABLE `watch_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xtream_main`
--

DROP TABLE IF EXISTS `xtream_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xtream_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `update_available` int(11) NOT NULL DEFAULT '0',
  `root_ip` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xtream_main`
--

LOCK TABLES `xtream_main` WRITE;
/*!40000 ALTER TABLE `xtream_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `xtream_main` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-10  3:34:28
