<?php 
echo '﻿';
class Resellers_packages_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        if( $this->admin['level'] != 1 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $intro->lang['package_name'] = 'Package Name';
        $intro->lang['is_trial'] = 'Is Trial';
        $intro->lang['is_official'] = 'Is Official';
        $intro->lang['trial_credits'] = 'Trial Credits';
        $intro->lang['official_credits'] = 'Official Credits';
        $intro->lang['trial_duration'] = 'Trial Duration';
        $intro->lang['trial_duration_in'] = 'Trial Duration In';
        $intro->lang['official_duration'] = ' Official Duration';
        $intro->lang['official_duration_in'] = 'Official Duration In';
        $intro->lang['can_gen_mag'] = 'Can add MAG';
        $intro->lang['only_mag'] = 'Only MAG';
        $intro->lang['output_formats'] = 'Output Formats';
        $intro->lang['max_connections'] = 'Max Connections';
        $intro->lang['is_restreamer'] = 'Restreamer?';
        $intro->lang['force_server_id'] = 'Force connect to Server';
        $intro->lang['can_gen_e2'] = 'Can Add Enigma2';
        $intro->lang['only_e2'] = 'Only Enigma2';
        $intro->lang['lock_device'] = 'Allow Lock Device';
        $intro->lang['groups'] = 'Groups';
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\"></icon>Packages</a> \r\n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . "/Form?t=add\"><icon class=\"icon-plus-squared\"></icon>Add New Package</a>  \t\t \t\t \r\n\t\t\r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = '';
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('search_txt'), '.');
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry = ' where package_name  LIKE \'%' . $search_txt . '%\' ';
        }
        if( $order == '' ) 
        {
            $order = 'id:ASC';
        }
        $order = str_replace(':', ' ', $order);
        $result = $intro->db->query('SELECT * from packages ' . $qry . ' order by ' . $order . ' ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> Packages (' . $totalrows . ')', 'info');
        echo "\r\n\t\t\r\n\t\t<fieldset>\r\n\t\t\r\n\t\t\t\r\n\t\t\t<form class=\"form-inline\" method=post action=\"\">\r\n\t\t\t  <div class=\"form-group\">\r\n\t\t\t\t<label for=\"email\">Package Name:</label>\r\n\t\t\t\t<input type=\"text\" class=\"form-control\" name='search_txt' value=\"" . $search_txt . "\">\r\n\t\t\t  </div>\r\n\t\t\t \r\n\t\t\t  <button type=\"submit\" class=\"btn btn-default\">" . $intro->lang['search'] . ("</button>\r\n\t\t\t</form>\r\n\r\n\r\n\t\t</fieldset>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID </th>\r\n\t\t\t<th>" . $intro->lang['package_name'] . ' ') . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('package_name', 'index') . "</th>\r\n\t\t\t<th>Trial/Official " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('is_official', 'index') . "</th>\r\n\t\t\t<th>Credit " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('official_credits', 'index') . "</th>\r\n\t\t\t<th>Duration " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('official_duration_in', 'index') . "</th>\r\n\t\t\t<th>Conns. " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('max_connections', 'index') . ("</th>\r\n\t\t\t<th>" . $intro->lang['groups'] . " </th>\r\n\t\t\t<th>") . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"c\">" . $id . "</td>\r\n\t\t\t\t<td>" . $package_name . "</td>\r\n\t\t\t\t<td class=\"c\">") . (($is_official == 1 ? '<span class=\'label label-success\'>Official</span>' : '<span class=\'label label-danger\'>Trial</span>')) . "</td>\r\n\t\t\t\t<td class=\"c\">" . (($is_official == 1 ? (string)$official_credits : (string)$trial_credits)) . "</td>\r\n\t\t\t\t<td class=\"c\">" . (($is_official == 1 ? $official_duration . ' ' . $official_duration_in : $trial_duration . ' ' . $trial_duration_in)) . ("</td>\r\n\t\t\t\t<td class=\"c\">" . $max_connections . "</td>\r\n\t\t\t\t<td class=\"c\">") . $this->getMemberGroups($groups) . ("</td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $id . '" OnClick="return false;" title="') . $intro->lang['del'] . ("\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t\t<br/>\r\n\t\t\t\t\t<a class=\"btnX btnX-info p_edit\" href=\"" . $this->base . '/Form?t=add&amp;copy_id=' . $id . '" title="') . $intro->lang['edit'] . "\"><i class=\"icon-clone\"></i> Copy </a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function getMemberGroups($groups)
    {
        global $intro;
        $err = '<span style="color:red">Error: No Groups Set.</span>';
        if( $groups == '' ) 
        {
            return $err;
        }
        $html = '';
        $g = json_decode($groups, true);
        if( is_array($g) && count($g) > 0 ) 
        {
            $sql2 = $intro->db->query('SELECT * FROM member_groups where group_id in (' . implode(',', $g) . ') order by group_id asc;');
            while( $row2 = $intro->db->fetch_assoc($sql2) ) 
            {
                $html .= ('<div ' . (($row2['group_color'] != '' ? 'style=\'color:' . $row2['group_color'] . ';\'' : '')) . ('>' . $row2['group_name'] . '</div>'));
            }
        }
        else
        {
            return $err;
        }
        return $html;
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $package_name;
        global $is_trial;
        global $is_official;
        global $trial_credits;
        global $official_credits;
        global $official_duration_in;
        global $trial_duration;
        global $trial_duration_in;
        global $official_duration;
        global $only_e2;
        global $forced_country;
        global $bouquets;
        global $can_gen_mag;
        global $only_mag;
        global $output_formats;
        global $is_isplock;
        global $max_connections;
        global $is_restreamer;
        global $force_server_id;
        global $can_gen_e2;
        global $lock_device;
        global $can_add_codes;
        global $can_add_users;
        global $can_add_mag;
        global $can_add_e2;
        global $groups;
        global $can_set_country;
        global $can_set_pass;
        global $can_set_mac_opt;
        global $can_set_act_count;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM packages WHERE id=' . $id . ';');
            $row = $intro->db->fetch_assoc($sql);
            if( isset($_POST['package_name']) && isset($_POST['official_duration_in']) ) 
            {
                $row = $_POST;
                @extract($row);
                $bouquets = json_encode($row['bouquets']);
                $groups = (isset($row['groups']) ? json_encode($row['groups']) : '[]');
                $output_formats = (isset($row['output_formats']) ? json_encode($row['output_formats']) : '[]');
            }
            else
            {
                @extract($row);
            }
            $btn['legend_name'] = 'Edit <b>' . $id . '</b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $bouquets = json_decode($bouquets, true);
            $groups = json_decode($groups, true);
            $output_formats = json_decode($output_formats, true);
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
            $copy_id = intval($intro->input->get_post('copy_id'));
            if( $copy_id > 0 ) 
            {
                $sql = $intro->db->query('SELECT * FROM packages WHERE id=' . $copy_id . ';');
                $row = $intro->db->fetch_assoc($sql);
                extract($row);
                $package_name = $package_name . ' Copy';
                $bouquets = json_decode($bouquets, true);
                $groups = json_decode($groups, true);
                $output_formats = json_decode($output_formats, true);
            }
            $output_formats = ($output_formats == '' ? [] : $output_formats);
            $groups = ($groups == '' ? [] : $groups);
            $bouquets = ($bouquets == '' ? [] : $bouquets);
            $is_trial = ($is_trial == '' ? 0 : $is_trial);
            $is_official = ($is_official == '' ? 0 : $is_official);
        }
        else
        {
            exit( 'error:no t' );
        }
        echo "\t\t\r\n\t\t<script >\r\n\t\t\$(function(){\r\n\t\t\t\r\n\t\t\tvar is_trial=";
        echo $is_trial;
        echo ";\r\n\t\t\tvar is_official=";
        echo $is_official;
        echo ";\r\n\t\t\t\r\n\t\t\tif(is_trial==1){\r\n\t\t\t\t\$(\".is_official\").hide();\r\n\t\t\t\t\$(\".is_trial\").show();\r\n\t\t\t\r\n\t\t\t}else{\r\n\t\t\t\t\$(\".is_official\").show();\r\n\t\t\t\t\$(\".is_trial\").hide();\r\n\t\t\t}\r\n\t\t\t\$(\"input[name='is_trial']\").change(function() {\r\n\t\t\t\tvar fromval =\$(this).val();\r\n\t\t\t\t\tif(fromval==1){\r\n\t\t\t\t\t\$(\".is_official\").hide();\r\n\t\t\t\t\t\$(\".is_trial\").show();\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t}else{\r\n\t\t\t\t\t\$(\".is_official\").show();\r\n\t\t\t\t\t\$(\".is_trial\").hide();\r\n\t\t\t\t}\r\n\t\t\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$(\"input[name='is_official']\").change(function() {\r\n\t\t\t\tvar fromval =\$(this).val();\r\n\t\t\t\tif(fromval==1){\r\n\t\t\t\t\t\$(\".is_official\").show();\r\n\t\t\t\t\t\$(\".is_trial\").hide(); \r\n\t\t\t\t\t\t\t\r\n\t\t\t\t}else{\r\n\t\t\t\t\t\$(\".is_official\").hide();\r\n\t\t\t\t\t\$(\".is_trial\").show();\r\n\t\t\t\t}\r\n\t\t\r\n\t\t\t});\r\n\r\n\t\t\t\$(\"#checkAll\").change(function () {\r\n\t\t\t\t\$(\"#tdBouquets input:checkbox\").prop('checked', \$(this).prop(\"checked\"));\r\n\t\t\t});\r\n\t\t});\r\n\t\r\n\t</script>\r\n\t\t\r\n\t\t";
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\" >\r\n\t\t\r\n\t\t<table class=\"table table-bordered table-hover table-striped\" >\r\n\t\t<tr>\r\n\t\t\t<td style='width:20%;'>" . $intro->lang['package_name'] . " : </td>\r\n\t\t\t<td ><input  type=\"text\" name=\"package_name\" value=\"" . $package_name . '" class=\'form-control\'  style=\'width:70%;\' > ' . $this->error('package_name') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class='is_trialXX'>\r\n\t\t\t<td>" . $intro->lang['is_trial'] . " : </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('is_trial', $is_trial, 'yes') . (' ' . $this->error('is_official') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class='is_officialXX'>\r\n\t\t\t<td>" . $intro->lang['is_official'] . " : </td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('is_official', $is_official, 'yes') . (' ' . $this->error('is_official') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class='is_trial'>\r\n\t\t\t<td>" . $intro->lang['trial_credits'] . ": </td>\r\n\t\t\t<td><input  type=\"text\" name=\"trial_credits\" value=\"" . $trial_credits . "\" class='form-control'  style='width:70%;' > </td>\r\n\t\t</tr>\r\n\t\t<tr class='is_official'>\r\n\t\t\t<td>" . $intro->lang['official_credits'] . "  : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"official_credits\" value=\"" . $official_credits . "\" class='form-control'  style='width:70%;' >\r\n\t\t\t\t" . $this->error('official_credits') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class='is_trial'>\r\n\t\t\t<td>" . $intro->lang['trial_duration'] . "   : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"trial_duration\" value=\"" . $trial_duration . "\" >\r\n\t\t\t\t") . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('trial_duration_in', $array['packeges_duration'], $trial_duration_in, '', '') . (" \r\n\t\t\t\t" . $this->error('trial_duration') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class='is_official'>\r\n\t\t\t<td>" . $intro->lang['official_duration'] . ": </td>\r\n\t\t\t<td><input  type=\"text\" name=\"official_duration\" value=\"" . $official_duration . "\" > \r\n\t\t\t") . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('official_duration_in', $array['packeges_duration'], $official_duration_in, '', '') . (" \r\n\t\t\t" . $this->error('official_duration') . " </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>Groups: " . $this->error('groups') . "</td>\r\n\t\t\t<td>");
        $sql2 = $intro->db->query('SELECT * FROM member_groups order by group_id asc;');
        while( $row2 = $intro->db->fetch_assoc($sql2) ) 
        {
            if( is_array($groups) && in_array($row2['group_id'], $groups) ) 
            {
                $check = 'checked';
            }
            else
            {
                $check = '';
            }
            echo '<input type="checkbox" name=\'groups[]\' value=\'' . $row2['group_id'] . '\' ' . $check . '>  ' . $row2['group_name'] . " &nbsp;\t";
        }
        echo "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Bouquets: " . $this->error('bouquets') . " <span style='color:#ff0000'>*</span>\r\n\t\t\t\t<div style=\"float:right;\">\r\n\t\t\t\t\t   <input type=\"checkbox\" id=\"checkAll\"/> <b>Check All</b>\r\n\t\t\t\t</div>\r\n\t\t\t</td>\r\n\t\t\t<td id=\"tdBouquets\">" . bouquets($bouquets, 'all', true) . "</td>\r\n\t\t</tr>" . ("<tr>\r\n\t\t\t<td>" . $intro->lang['output_formats'] . ' : ' . $this->error('output_formats') . "</td>\r\n\t\t\t<td>") . $this->output_formats($output_formats) . (" </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['max_connections'] . "  : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"max_connections\" value=\"" . $max_connections . "\" class='form-control'  style='width:70%;' > </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['is_restreamer'] . "  : </td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('is_restreamer', $is_restreamer, 'yes') . ("  </td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['force_server_id'] . " : </td>\r\n\t\t\t<td>") . _obf_0D311A13371B215B013B112303362D1032353D2E344022('force_server_id', 'Default', 'streaming_servers', $force_server_id, 'id', 'server_name') . " </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Override General Country Restriction:  </td>\r\n\t\t\t<td> " . forced_country($forced_country) . ' ' . (($t == 'edit' ? '(' . $forced_country . ')' : '')) . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Allow ISP Lock: </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('is_isplock', $is_isplock, 'yes') . ("  </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['lock_device'] . "  : </td>\r\n\t\t\t<td>") . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('lock_device', $lock_device, 'yes') . "  </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<th colspan=2>Service :</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Add Codes : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_codes', $can_add_codes, 1, 'Yes', 'No', 'primary') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Add Users : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_users', $can_add_users, 1, 'Yes', 'No', 'primary') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Add MAG : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_mag', $can_add_mag, 1, 'Yes', 'No', 'primary') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Add Enigma2 : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_add_e2', $can_add_e2, 1, 'Yes', 'No', 'primary') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Set Country : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_set_country', $can_set_country, 1, 'Yes', 'No', 'primary') . " \r\n\t\t\t(Enable/Disable Override General Country Restriction)</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Set Passwords : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_set_pass', $can_set_pass, 1, 'Yes', 'No', 'primary') . "\r\n\t\t\t\t(Enable Resller to set password for created users) </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Set MAC Options for Code : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_set_mac_opt', $can_set_mac_opt, 1, 'Yes', 'No', 'primary') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Reset Code Login Limits : </td>\r\n\t\t\t<td>" . _obf_0D0E0C021E271714230F1135191C022F35343836305C01('can_set_act_count', $can_set_act_count, 1, 'Yes', 'No', 'primary') . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $data = $members = [];
        $t = trim($intro->input->post('t'));
        $package_name = trim($intro->input->post('package_name'));
        $is_trial = intval($intro->input->post('is_trial'));
        $is_official = intval($intro->input->post('is_official'));
        $trial_credits = floatval($intro->input->post('trial_credits'));
        $official_credits = floatval($intro->input->post('official_credits'));
        $trial_duration = intval($intro->input->post('trial_duration'));
        $trial_duration_in = trim($intro->input->post('trial_duration_in'));
        $official_duration = intval($intro->input->post('official_duration'));
        $official_duration_in = trim($intro->input->post('official_duration_in'));
        $groups = $intro->input->post('groups');
        $bouquets = $intro->input->post('bouquets');
        $can_gen_mag = trim($intro->input->post('can_gen_mag'));
        $only_mag = trim($intro->input->post('only_mag'));
        $output_formats = $intro->input->post('output_formats');
        $is_isplock = intval($intro->input->post('is_isplock'));
        $max_connections = trim($intro->input->post('max_connections'));
        $is_restreamer = intval($intro->input->post('is_restreamer'));
        $force_server_id = trim($intro->input->post('force_server_id'));
        $can_gen_e2 = trim($intro->input->post('can_gen_e2'));
        $only_e2 = trim($intro->input->post('only_e2'));
        $forced_country = trim($intro->input->post('forced_country'));
        $lock_device = trim($intro->input->post('lock_device'));
        if( $package_name == '' || !isset($bouquets[0]) || !isset($output_formats[0]) || !isset($groups[0]) || $is_official == $is_trial || $is_official == 1 && $official_credits <= 0 || $is_official == 1 && $official_duration <= 0 ) 
        {
            if( $package_name == '' ) 
            {
                $error['package_name'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( !isset($bouquets[0]) ) 
            {
                $error['bouquets'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( !isset($output_formats[0]) ) 
            {
                $error['output_formats'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( !isset($groups[0]) ) 
            {
                $error['groups'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $is_official == $is_trial ) 
            {
                $error['is_official'] = '<span class=error>Error: you can\'t use both Trail + Official</span>';
            }
            if( $is_official == 1 && $official_credits <= 0 ) 
            {
                $error['official_credits'] = '<span class=error>Error: Official creadit must be > 0</span>';
            }
            if( $is_official == 1 && $official_duration <= 0 ) 
            {
                $error['official_credits'] = '<span class=error>Error: Please input Official Duration.</span>';
            }
            $this->Form($t);
            exit();
        }
        $data['bouquets'] = '[' . implode(',', $bouquets) . ']';
        $data['groups'] = '[' . implode(',', $groups) . ']';
        $data['package_name'] = $package_name;
        $data['is_trial'] = $is_trial;
        $data['is_official'] = $is_official;
        $data['trial_credits'] = $trial_credits;
        $data['official_credits'] = $official_credits;
        $data['trial_duration'] = $trial_duration;
        $data['trial_duration_in'] = $trial_duration_in;
        $data['official_duration_in'] = $official_duration_in;
        $data['can_gen_mag'] = $can_gen_mag;
        $data['official_duration'] = $official_duration;
        $data['only_mag'] = $only_mag;
        $data['output_formats'] = '[' . implode(',', $output_formats) . ']';
        $data['is_isplock'] = $is_isplock;
        $data['max_connections'] = $max_connections;
        $data['is_restreamer'] = $is_restreamer;
        $data['force_server_id'] = $force_server_id;
        $data['can_gen_e2'] = $can_gen_e2;
        $data['only_e2'] = $only_e2;
        $data['forced_country'] = $forced_country;
        $data['lock_device'] = $lock_device;
        $data['can_add_codes'] = intval($intro->input->post('can_add_codes'));
        $data['can_add_users'] = intval($intro->input->post('can_add_users'));
        $data['can_add_mag'] = intval($intro->input->post('can_add_mag'));
        $data['can_add_e2'] = intval($intro->input->post('can_add_e2'));
        $data['can_set_country'] = intval($intro->input->post('can_set_country'));
        $data['can_set_pass'] = intval($intro->input->post('can_set_pass'));
        $data['can_set_mac_opt'] = intval($intro->input->post('can_set_mac_opt'));
        $data['can_set_act_count'] = intval($intro->input->post('can_set_act_count'));
        if( $t == 'add' ) 
        {
            $intro->db->insert('packages', $data);
        }
        if( $t == 'edit' ) 
        {
            $id = intval($intro->input->post('id'));
            $intro->db->update('packages', $data, 'id=' . $id);
        }
        $intro->redirect($this->appname);
    }
    public function output_formats($comp)
    {
        global $intro;
        $html = '';
        $outputs = [
            '1' => 'HLS', 
            '2' => 'MPEGTS', 
            '3' => 'RTMP'
        ];
        foreach( $outputs as $key => $val ) 
        {
            $html .= ("<label class=\"checkbox-inline\">\r\n\t\t\t\t<input type=\"checkbox\" name=\"output_formats[]\" value=\"" . $key . '" ' . ((is_array($comp) && in_array($key, $comp) ? 'checked' : '')) . ('> ' . $val . "\r\n\t\t\t\t</label>"));
        }
        return $html;
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $_POST['t'] = 'edit';
        $this->doAdd();
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('DELETE FROM packages WHERE id=' . $id . '; ');
        $intro->redirect($this->appname);
    }
}
