<?php 
class Auth
{
    public $db = null;
    public $flag = null;
    public function __construct($db)
    {
        $this->db = $db;
    }
    public function check_admin_and_login($user_name, $password)
    {
        global $intro;
        $ip = $intro->input->ip_address();
        $result = $this->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adm_username=\'' . $user_name . '\' AND adm_password=\'' . $password . '\''));
        if( $this->db->returned_rows == 1 ) 
        {
            $row = $this->db->fetch_assoc($result);
            if( intval($row['level']) == 4 ) 
            {
                $row['level'] = 0;
                define('RESET_CODES', true);
                _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('login', 'reset_codes', '', $user_name);
                $_SESSION['reset'] = [
                    'x1' => $this->_xor($row['adminid']), 
                    'x2' => $this->_xor($row['adm_username'])
                ];
                include('style/reset.php');
                exit();
            }
            if( intval($row['suspend']) == 1 ) 
            {
                unset($row);
                unset($_SESSION);
                _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('login', 'suspended', 'tried to login to his suspended account', $user_name);
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h1 style=\'color:red\'> Sorry: your account has been suspended. </h1>', 'danger');
                exit();
            }
            if( strlen($row['allowed_ips']) > 5 ) 
            {
                $x = explode("\n", $row['allowed_ips']);
                if( !in_array($ip, $x) ) 
                {
                    unset($row);
                    unset($_SESSION);
                    _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('login', 'not_allowed_ip', 'tried to login from ip: ' . $ip, $user_name);
                    echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h1 style=\'color:red\'> Sorry: your IP (' . $ip . ') is not allowed to login. </h1>', 'danger');
                    exit();
                }
            }
            $_SESSION[$this->flag] = [
                'x1' => $this->_xor($row['adminid']), 
                'x2' => $this->_xor($row['adm_username']), 
                'x3' => $this->_xor($row['adm_password']), 
                'x4' => $this->_xor($row['ipaddress']), 
                'x5' => $this->_xor($row['lastlogin']), 
                'x6' => $this->_xor($row['level']), 
                'x7' => $this->_xor($row['resel_bouquets']), 
                'x8' => $this->_xor($row['can_delete']), 
                'x9' => $this->_xor($row['can_change']), 
                'x10' => $this->_xor($row['num_free']), 
                'ResellerID' => time(), 
                'ResellerPASS' => uniqid(), 
                'SessionValid' => Date('Y-m-d') . ' 23:59:59'
            ];
            $date = Date('Y-m-d H:i:s');
            $user_agent = $this->user_agent();
            $this->db->query('UPDATE ' . PREFIX . '_admin SET ' . (' ipaddress=\'' . $ip . '\',user_agent=\'' . $user_agent . '\', ') . (' lastlogin=\'' . $date . '\' WHERE adminid=') . intval($row['adminid']) . ';');
            $this->db->_optimize_db('solus_admin', 'solus_logs', 'solus_logs_sys');
            return true;
        }
        return false;
    }
    public function logout()
    {
        if( isset($_COOKIE[$this->flag]) ) 
        {
            setcookie($this->flag, null, -1);
            unset($_COOKIE[$this->flag]);
        }
        if( isset($_SESSION[$this->flag]) ) 
        {
            $_SESSION[$this->flag] = '';
            unset($_SESSION[$this->flag]);
        }
        $this->clearCookies(true);
    }
    public function clearCookies($clearSession = false)
    {
        $past = time() - 3600;
        if( $clearSession === false ) 
        {
            $sessionId = session_id();
        }
        foreach( $_COOKIE as $key => $value ) 
        {
            if( $clearSession !== false || $value !== $sessionId ) 
            {
                setcookie($key, $value, $past, '/');
            }
        }
    }
    public function auth_admin()
    {
        if( isset($_SESSION[$this->flag]) && is_array($_SESSION[$this->flag]) ) 
        {
            $sess = $_SESSION[$this->flag];
        }
        if( isset($sess) ) 
        {
            $adminid = $this->_xor($sess['x1']);
            $adm_username = $this->_xor($sess['x2']);
            $cookie_passwd = $this->_xor($sess['x3']);
            $adminid = addslashes($adminid);
            $adminid = intval($adminid);
            $user_agent = $this->user_agent();
            if( $adminid != '' && $cookie_passwd != '' ) 
            {
                $result = $this->db->query('SELECT adm_password,user_agent FROM ' . PREFIX . '_admin ' . (' WHERE adminid=\'' . $adminid . '\' AND adm_username=\'' . $adm_username . '\' AND suspend=0;'));
                $row = $this->db->fetch_assoc($result);
                $db_pass = $row['adm_password'];
                $row['ipaddress'] = getUserIP();
                if( $db_pass == $cookie_passwd && $db_pass != '' && $user_agent == $row['user_agent'] && $row['ipaddress'] ) 
                {
                    return 1;
                }
            }
        }
        return 0;
    }
    public function sess_admin()
    {
        if( isset($_SESSION[$this->flag]) ) 
        {
            return [
                'adminid' => $this->_xor($_SESSION[$this->flag]['x1']), 
                'admin_name' => $this->_xor($_SESSION[$this->flag]['x2']), 
                'ip' => $this->_xor($_SESSION[$this->flag]['x4']), 
                'lastlogin' => $this->_xor($_SESSION[$this->flag]['x5']), 
                'level' => $this->_xor($_SESSION[$this->flag]['x6']), 
                'resel_bouquets' => $this->_xor($_SESSION[$this->flag]['x7']), 
                'can_delete' => $this->_xor($_SESSION[$this->flag]['x8']), 
                'can_change' => $this->_xor($_SESSION[$this->flag]['x9']), 
                'num_free' => $this->_xor($_SESSION[$this->flag]['x10'])
            ];
        }
        else
        {
            exit( 'error in session' );
        }
    }
    public function sess_reset()
    {
        if( isset($_SESSION['reset']) ) 
        {
            return [
                'adminid' => $this->_xor($_SESSION['reset']['x1']), 
                'admin_name' => $this->_xor($_SESSION['reset']['x2'])
            ];
        }
        else
        {
            return [
                'adminid' => 0, 
                'admin_name' => 0
            ];
        }
    }
    public function _xor($InputString, $KeyPhrase = '165895Adb8ikPlasd]Po[')
    {
        $retString = '';
        $KeyPhraseLength = strlen($KeyPhrase);
        for( $i = 0; $i < strlen($InputString); $i++ ) 
        {
            $rPos = $i % $KeyPhraseLength;
            $r = ord($InputString[$i]) ^ ord($KeyPhrase[$rPos]);
            $InputString[$i] = chr($r);
        }
        return $InputString;
        return $retString;
    }
    public function user_agent()
    {
        return md5(((isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '')) . 'zZ9xX5Vv_SoSo');
    }
    public function auth_module($module_name)
    {
        return false;
    }
    public function get_Admin($user_name, $password)
    {
        $result = $this->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adm_username=\'' . $user_name . '\' AND adm_password=\'' . $password . '\''));
        $row = $this->db->fetch_assoc($result);
        return $row;
    }
    public function admin_data($adminid = 0)
    {
        if( isset($_SESSION[$this->flag]) && is_array($_SESSION[$this->flag]) ) 
        {
            $sess = $_SESSION[$this->flag];
        }
        if( $adminid == 0 ) 
        {
            $adminid = $this->_xor((isset($sess['x1']) ? $sess['x1'] : 0));
        }
        if( $adminid == 0 ) 
        {
            unset($_SESSION);
            exit( 'Erro: invalid session.' );
        }
        $result = $this->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adminid=\'' . $adminid . '\''));
        $row = $this->db->fetch_assoc($result);
        $father = intval($row['father']);
        if( $father > 0 ) 
        {
            $result2 = $this->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adminid=\'' . $father . '\''));
            $row2 = $this->db->fetch_assoc($result2);
            $row['father_data'] = $row2;
        }
        return $row;
    }
    public function adminRow($adminid)
    {
        $adminid = intval($adminid);
        if( $adminid == 0 ) 
        {
            exit( 'ResellerID is 0!!!!' );
        }
        $result = $this->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adminid=\'' . $adminid . '\''));
        $row = $this->db->fetch_assoc($result);
        $father = intval($row['father']);
        if( $father > 0 ) 
        {
            $result2 = $this->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adminid=\'' . $father . '\''));
            $row2 = $this->db->fetch_assoc($result2);
            $row['father_data'] = $row2;
        }
        return $row;
    }
    public function adminid()
    {
        if( isset($_SESSION[$this->flag]) && is_array($_SESSION[$this->flag]) ) 
        {
            $sess = $_SESSION[$this->flag];
        }
        $adminid = intval($this->_xor($sess['x1']));
        if( $adminid == 0 ) 
        {
            unset($_SESSION);
            exit( 'Erro: invalid session.' );
        }
        return $adminid;
    }
}
