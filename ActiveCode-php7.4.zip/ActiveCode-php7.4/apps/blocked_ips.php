<?php 
echo '﻿';
class Blocked_ips_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $intro->lang['blocked_ips_appname'] = 'Blocked IP';
        $intro->lang['blocked_ips_add'] = 'Blocked IP';
        $intro->lang['blocked_ips_edit'] = 'Blocked IP';
        $intro->lang['blocked_ips_cur'] = 'Blocked IP';
        $intro->lang['blocked_ips_ip'] = 'IP';
        $intro->lang['blocked_ips_date'] = 'Date';
        $intro->lang['blocked_ips_notes'] = 'Notes';
        $intro->lang['blocked_ips_attempts_blocked '] = 'Attempts';
        $this->admin = $intro->auth->sess_admin();
        if( $this->admin['level'] != 1 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . '/index"><icon class="icon-list"></icon>') . $intro->lang['blocked_ips_appname'] . "</a> \r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . "/Form?t=add\"><icon class=\"icon-plus-squared\"></icon>Add IP to block</a>  \t\t \t\t \r\n\t\t<a class=\"btn btn-success\" href=\"" . $this->base . "/Unlock\" OnClick=\"return confirm('This will remove all ips. you still need to run: iptables -F on main server ssh.');\"><icon class=\"icon-edit\"></icon>Unlock All</a>  \t\t \t\t \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = '';
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('search_txt'), '.');
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry = ' where ip  LIKE \'%' . $search_txt . '%\' ';
        }
        if( $order == '' ) 
        {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 30;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from blocked_ips ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page);
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from blocked_ips ' . $qry . ' ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> ' . $intro->lang['blocked_ips_cur'] . (' (' . $totalrows . ')'), 'info');
        echo "\r\n\t\t\r\n\t\t<fieldset>\r\n\t\t\t<form action=\"\" method=\"post\">\r\n\t\t\t\t<input type=\"text\" name=\"search_txt\" value=\"" . $search_txt . "\" placeholder=\"IP\" size=\"20\">\r\n\t\t\t\t<input name=\"name\" value=\"" . $intro->lang['search'] . "\" type=\"submit\">\r\n\t\t\t</form>\r\n\t\t</fieldset>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th> </th>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . "</th>\r\n\t\t\t<th>" . $intro->lang['blocked_ips_ip'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('ip', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['blocked_ips_date'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('date', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['blocked_ips_notes'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('notes', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['blocked_ips_attempts_blocked '] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('attempts_blocked ', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\"><input type=\"checkbox\" value=\"" . $id . "\" name=\"selected_fld[]\"></td>\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td>" . $ip . "</td>\r\n\t\t\t\t<td>") . date('Y-m-d H:i:s', $date) . ("</td>\r\n\t\t\t\t<td>" . $notes . "</td>\r\n\t\t\t\t<td>" . $attempts_blocked . " </td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>\r\n\t\t</div>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?search_txt=' . $search_txt . '&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</div>');
    }
    public function Unlock()
    {
        global $intro;
        $this->nav();
        $intro->db->query('DELETE FROM blocked_ips WHERE true;');
        $aff = $intro->db->affected_rows;
        $intro->db->query('TRUNCATE blocked_ips;');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Unblock Flood IPs', 'info');
        echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('<h4>Success. Total unblocked IPs: ' . $aff . " <br/>\r\n\t\t<br/>\r\n\t\tYou still need to run: <pre>iptables -F</pre> in the main server ssh terminal using Putty or so.\r\n\t\t</h4>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $ip;
        global $date;
        global $notes;
        global $attempts_blocked;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM blocked_ips WHERE id=' . $id . ';');
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = 'Edit <b>' . $id . '</b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t<tr>\r\n\t\t\t<td>IP : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"ip\" value=\"" . $ip . '" size="30"> ' . $this->error('user_agent') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Notes : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"notes\" value=\"" . $notes . "\" size=\"30\"></td>\r\n\t\t</tr>";
        if( $t == 'edit' ) 
        {
            echo "\r\n\t\t<tr>\r\n\t\t\t<td>Attempts Blocked : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"attempts_blocked\" value=\"" . $attempts_blocked . '" size="10"> ' . $this->error('attempts_blocked') . "</td>\r\n\t\t</tr>";
        }
        echo "\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</div>\r\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $ip = trim($intro->input->post('ip'));
        $notes = trim($intro->input->post('notes'));
        if( $ip == '' ) 
        {
            $error['ip'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            $this->Form('add');
            exit();
        }
        $data['ip'] = $ip;
        $data['`date`'] = TIME();
        $data['notes'] = $notes;
        $intro->db->insert('blocked_ips', $data);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $ip = trim($intro->input->post('ip'));
        $notes = trim($intro->input->post('notes'));
        $attempts_blocked = trim($intro->input->post('attempts_blocked'));
        $data['ip'] = $ip;
        $data['notes'] = $notes;
        $data['attempts_blocked'] = $attempts_blocked;
        $id = intval($intro->input->post('id'));
        $intro->db->update('blocked_ips', $data, 'id=' . $id);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('DELETE FROM blocked_ips WHERE id=' . $id . '; ');
        $intro->redirect($this->appname);
    }
}
