<?php 
class Tasks_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $msg = null;
    public $success = false;
    public function __construct($appname, $base, $img_path = '')
    {
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "\r\n\t\t<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-tasks\"></icon>Tasks</a> \r\n\t\t \t\t \r\n\t\t</div>");
        $result = $intro->db->query('SELECT `task_id` FROM `solus_tasks` WHERE `task_for`=\'streams\';');
        $totrows = $intro->db->returned_rows;
        if( $totrows > 0 ) 
        {
            echo "<div class=\"app_nav\">\r\n\t\t\t\t<a class=\"btn btn-success btn-lg blinking\" href=\"" . $this->base . "/StartTask\">\r\n\t\t\t\t\t<icon class=\"icon-run\"></icon>\r\n\t\t\t\t\tYou have (" . $totrows . ") Streams waiting to run Task, click here \r\n\t\t\t\t</a>  \t\t \t\t \r\n\t\t\t</div>";
        }
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = $params = '';
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-tasks"></i> Tasks', 'info');
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function StartTask()
    {
        global $intro;
        $XtreamApi = new XtreamApi('EmptyFunc');
        $intro->db->query('DELETE from `solus_tasks` where task_for=\'streams\' AND task_status=1;');
        $this->nav();
        $page = intval($intro->input->get_post('page'));
        $rows_per_page = 10;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $query = 'SELECT * FROM `solus_tasks` task  LEFT JOIN `streams` st ON task.task_keyid=st.id  LEFT JOIN `streams_sys` sys ON task.task_keyid=sys.stream_id  WHERE task_for=\'streams\'';
        $result = $intro->db->query($query . ' limit ' . $nexlimit . ',' . $rows_per_page);
        $intro->db->query(' ' . $query . ' ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> Streams Tasks (' . $totalrows . ')', 'info');
        echo "\r\n\t\t<h4>Note: Please don't refresh page , Page will auto refresh.</h4>\r\n\t\t<table class=\" table table-bordered table-hover table-striped\"   >\r\n        <thead>\r\n\t    <tr >\r\n\t\t\t<th>#</th>\r\n\t\t\t<th>ID</th>\r\n\t\t\t<th>Task Name</th>\r\n\t\t\t<th>Task Date</th>\r\n\t\t\t\r\n\t\t\t<th>Stream Name</th>\r\n\t\t\t<th>Commands</th>\r\n\t\t\t<th>Reuslt</th>\r\n\t\t\t<th></th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = $server_id = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"center\">" . $i . "</td>\r\n\t\t\t\t<td class=\"center\">" . $task_id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $task_name . "</td>\r\n\t\t\t\t<td class=\"center\">" . $task_date . "</td>\r\n\t\t\t\t<td class=\"center\">" . $stream_display_name . "</td>\r\n\t\t\t\t<td class=\"center\">for</td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\">" . $task_status;
            if( $task_status == -1 ) 
            {
                $this->run($XtreamApi, $task_id, $task_keyid, $cmd_start, $cmd_stop, $cmd_restart);
            }
            echo "</td>\r\n\t\t\t\t<td class=\"center\"> \t\t\t\t\t\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/DelTask?id=' . $task_id . "\" OnClick=\"return false;\" title=\"Delete Task\"><i class=\"icon-trash\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>";
        $maxPage = ceil($totalrows / $rows_per_page);
        $pageNum = $page;
        if( $pageNum > 1 ) 
        {
            $page = $pageNum - 1;
        }
        if( $pageNum < $maxPage ) 
        {
            $page = $pageNum + 1;
            $url = '?&page=' . $page;
            $next = ' <a href="' . $url . "\"> Run Next </a>\r\n\t\t\t<meta http-equiv=Refresh content=10;url=\"" . $url . '">';
        }
        else
        {
            $next = ' <h2 style="color:#004000"> All tasks Completed. <h2>';
        }
        echo '<center>Completed: <strong>' . $pageNum . '</strong> From <strong>' . $maxPage . '</strong>  ' . $next . ' </center>';
    }
    public function run($XtreamApi, $task_id, $stream_id, $start, $stop, $restart)
    {
        global $intro;
        global $sess_admin;
        global $array;
        if( $start == 1 ) 
        {
            $rep = $XtreamApi->Start($stream_id);
        }
        if( $stop == 1 ) 
        {
            $rep = $XtreamApi->Stop($stream_id);
        }
        if( $restart == 1 ) 
        {
            $rep = $XtreamApi->Restart($stream_id);
        }
        if( $rep == 'success' ) 
        {
            echo '<span clas="label label-success">Success</span>';
            $intro->db->query('DELETE FROM `solus_tasks` WHERE task_id=' . $task_id . '; ');
        }
        else
        {
            echo $rep;
        }
    }
    public function DelTask()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('DELETE FROM `solus_tasks` WHERE task_id=' . $id . '; ');
    }
}
