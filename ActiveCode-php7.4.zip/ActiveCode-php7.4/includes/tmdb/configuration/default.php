<?php 
$cnf["apikey"] = "";
$cnf["lang"] = "en";
$cnf["timezone"] = "Europe/Berlin";
$cnf["adult"] = false;
$cnf["debug"] = false;
$cnf["appender"]["movie"] = [ "trailers", "images", "credits", "translations", "reviews", "release_dates" ];
$cnf["appender"]["tvshow"] = [ "trailers", "images", "credits", "translations", "keywords" ];
$cnf["appender"]["season"] = [ "trailers", "images", "credits", "translations" ];
$cnf["appender"]["episode"] = [ "trailers", "images", "credits", "translations" ];
$cnf["appender"]["person"] = [ "movie_credits", "tv_credits", "images" ];
$cnf["appender"]["collection"] = [ "images" ];
$cnf["appender"]["company"] = [ "movies" ];

