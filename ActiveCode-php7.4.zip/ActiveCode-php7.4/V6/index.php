<?php 
echo "<html>\n<head>\n    <title>403 Forbidden</title>\n</head>\n<body>\n    <p>Directory access is forbidden.</p>\n</body>\n</html>";
