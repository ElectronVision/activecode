<?php 
class Backup_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        if( $this->admin['level'] != 1 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function nav()
    {
        global $cur_file;
        echo "<div class=\"app_nav\">\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-hdd\"> Remote Backup</icon> </a> \n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('options') . ('" href="' . $this->base . "/options\"><icon class=\"icon-cog\"> Options </icon> </a> \n\t\t</div>");
        echo '<h1>Comming Soon ... </h1>';
    }
    public function index()
    {
        global $intro;
        global $array;
        $sql = $intro->db->query('select * from ' . PREFIX . '_options');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $op_name = trim($row['name']);
            $options[$op_name] = trim($row['val']);
        }
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-star"></i> Backup Status ');
        echo "\n\t\t<form method=\"GET\" name=\"form_add\" action=\"" . $this->base . "/run_backup\" enctype=\"multipart/form-data\">\n\t\t<table cellspacing=\"2\" style=\"margin:auto;width:95%\">\n\t\t<tr>\n\t\t\t<td> Status:</td>\n\t\t\t<td>" . $options['backup_ftp_status'] . "</td>\n\t\t</tr>\n\n\t\t</table>\n\t\t<br/>\n\t\t<br/>\n\t\t<input class=\"btn btn-primary\" type=\"submit\" value=\" Run Backup Now\" />\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function run_backup()
    {
        global $intro;
        global $array;
        global $config;
        $this->nav();
        $username = $config['db']['username'];
        $password = $config['db']['password'];
        $database = $config['db']['database'];
        $port = $config['db']['port'];
        $file = date('Y-m-d_H_i_s');
        $command = 'mysqldump -u' . $username . ' -p' . $password . ' ' . $database . ' > /var/www/html/' . $file . '.sql';
        exec('(mysqldump -u' . $username . ' -p' . $password . ' ' . $database . ' | gzip > /var/www/b/' . $file . '.gz) 2>&1', $output, $result);
        var_dump($result);
        echo '<br />';
        var_dump($output);
        echo '<br />';
    }
    public function options()
    {
        global $intro;
        global $array;
        $sql = $intro->db->query('select * from ' . PREFIX . '_options');
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $op_name = trim($row['name']);
            $options[$op_name] = trim($row['val']);
        }
        $this->nav();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-cog"></i> Remote FTP Backup Options');
        echo "\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . "/Save\" enctype=\"multipart/form-data\">\n\t\t<table class=\"table table-bordered table-condensed\">\n\t\t<tr>\n\t\t\t<td>FTP Host:</td>\n\t\t\t<td><input type=\"text\" name=\"ftp_host\" value=\"" . $options['ftp_host'] . "\" size=\"30\" /> like: www.example.com</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td>FTP Username;</td>\n\t\t\t<td><input type=\"text\" name=\"ftp_user\" value=\"" . $options['ftp_user'] . "\" size=\"20\" /></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td>FTP Password:</td>\n\t\t\t<td><input type=\"text\" name=\"ftp_pass\" value=\"" . $options['ftp_pass'] . "\" size=\"20\" /></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td>FTP Folder:</td>\n\t\t\t<td><input type=\"text\" name=\"ftp_folder\" value=\"" . $options['ftp_folder'] . "\" size=\"20\" /> Default is /</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"center\" colspan=\"2\">\n\t\t\t\t<button type=\"submit\" class=\"btn btn-success\"><i class=\"icon-floppy\"></i> Save Options </button>\t\t\t\t\n\t\t\t</td>\n\t\t</tr>\n\t\t</table>\n\t\t<input type=\"hidden\" name=\"backup_ftp_status\" value=\"\" />\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function Save()
    {
        global $intro;
        global $array;
        foreach( $_POST as $key => $val ) 
        {
            if( $key != 'maa' && $key != 'B1' && $key != 'app_name' && $key != 'app_action' ) 
            {
                $val = $intro->input->post($key);
                $val = addslashes($val);
                $this->OptionsCheckNew($key);
                $intro->db->query('update ' . PREFIX . ('_options set val=\'' . $val . '\' where name=\'' . $key . '\''));
            }
        }
        $intro->redirect($this->appname, 'options');
    }
    public function OptionsCheckNew($name)
    {
        global $intro;
        $sql = $intro->db->query('select * from ' . PREFIX . ('_options where name=\'' . $name . '\''));
        if( mysqli_num_rows($sql) == 0 ) 
        {
            $intro->db->insert(PREFIX . '_options', ['name' => $name]);
        }
    }
}
