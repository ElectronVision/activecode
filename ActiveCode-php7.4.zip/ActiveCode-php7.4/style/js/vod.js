$(document).ready(function() {

	$("#PickFile").on('click',function(){
		
		$('#myModal').modal({show:true});
		var server = $("#movie_location").val();
		$('.modal-title').html('Files from :' + $("#movie_location option:selected").text());
		/*
		if(type == 'multi')
		{*/
		
			var jstreeInstance = $.jstree.create('.modal-body', {
				/*'plugins': ['search', 'checkbox', 'wholerow'],*/
				'core' : {
					'data' : {
						'cache':false,
						'url' : base + "?NH=1&server="+server,
						'data' : function (node) { return { 'id' : node.id }; }
					},
					'force_text' : true,
					'themes' : {
						'name': 'proton',
						'responsive': true
					}
				}
			});	
		/*}else{
			var jstreeInstance = $.jstree.create('.modal-body', {
				'core' : {
					'data' : {
						'cache':false,
						'url' : base + "?NH=1&server="+server,
						'data' : function (node) { return { 'id' : node.id }; }
					},
					'force_text' : true,
					'themes' : {
						'name': 'proton',
						'responsive': true
					}
				}
			});	
		}*/
	});
	
	$('.modal-body').on('changed.jstree', function (e, data) {
		if(data && data.selected && data.selected.length) {
			$("#stream_source").val(data.selected);
			
			var lines = $("#stream_source").val().split(',');
			
			$("#total_selected_from_tree").html('Total: '+lines.length);
			
			if(type == 'created'){
				$("#stream_source").val(lines.join("\n"));
			}

		}
		
	});	
	
	$('.modal-body').on("dblclick.jstree", function (e, data) {
		$('#myModal').modal('hide');
		
		
		var vodSrc = $("#stream_source").val();
		var ext = vodSrc.split('.').pop();
		
		var values = [];
		values.push(ext);

		$("#target_container").val(values).trigger("chosen:updated");
		/*\bS[\d.]+E(\d+)\b*/
		var parts = vodSrc.split('/');
		var lastSegment = parts.pop() || parts.pop();
		$('.series_js_episode_name').val(lastSegment.replace(/\.[^/.]+$/, ''));
		
		
		
	});
	/*
    $('#transcode_profile_id').change(function() {
        var value_transcode = $("#transcode_profile_id").val();
        if (value_transcode == -1)
            $('#transcode_form').fadeIn();
        else
            $('#transcode_form').fadeOut();
    });*/


    $('#subtitles_location').click(function() {
        var value = $(this).val();
        if ($.isNumeric(value)) {
            $('#movie_subtitles_form').fadeIn();
        } else {
            $('#movie_subtitles_form').fadeOut();
        }
    });

	$('#stream_source').change(function() {
		var source = $(this).val();
		var vod_location =  $('#movie_location').val();
		var movie_symlink =  $("input[name='movie_symlink']:checked").val();
		if(vod_location == 'remote'){
			var ext = source.split('.').pop();
			var values = [];
			values.push(ext);
			$("#target_container").val(values).trigger("chosen:updated");
		}
		if(vod_location == 'remote' && movie_symlink == 1){
			$("input[name='direct_source']").filter('[value="1"]').attr('checked', true);
		}
		
		
	});
    $('#movie_location').change(function() {
		
        $('#movie_source_form').fadeIn();
        var value = $(this).val();
		
		if(value === '') return false;

        if ($.isNumeric(value)) {
            $('#local').fadeIn();
            $('#fetch_options').fadeOut();
            $('.direct_source').fadeOut();

            $('.read_native').fadeIn();
            $('#load_balancer').fadeIn();
            $('.movie_symlink').fadeIn();
            $('#movie_container').fadeIn();
            $('.subtitles').fadeIn();
  
            $('input:radio[name=direct_source][value=0]').click();
            $('#select_servers').prop('required', true);

			$("#load_balancer_servers").addClass('chosen').chosen({search_contains: true});
			
			var values = [];
			values.push(value);

			$("#load_balancer_servers,#server").val(values).trigger("chosen:updated");
		
        } else {
            $('#local').fadeOut();
            $('#fetch_options').fadeIn();
            $('.direct_source').fadeIn();
            $('.movie_symlink').fadeIn();

        }
    });

    $('input[type=radio][name=direct_source]').change(function() {
        if (this.value == '1') {
            $('.read_native').fadeOut();
            $('.redirect_stream').fadeIn();
            $('#load_balancer').fadeOut();
            $('.movie_symlink').fadeOut();
            $('#fetch_options').fadeOut();
            $('#custom_map').fadeOut();
            $('#movie_container').fadeOut();
            $('.subtitles').fadeOut();
            $('#select_servers').prop('required', false);
            $('#target_container').prop('required', false);
        } else if (this.value == '0') {
            $('.read_native').fadeIn();
            $('.redirect_stream').fadeOut();
            $('#load_balancer').show();
            $('.movie_symlink').fadeIn();
            $('#movie_container').fadeIn();
            $('#custom_map').fadeIn();
            $('.subtitles').fadeIn();
            $('#fetch_options').fadeIn();
            $('#select_servers').prop('required', true);
            $('#target_container').prop('required', true);
        }
    });

    $('input[type=radio][name=movie_symlink]').change(function() {
        if (this.value == '1') {
            $('.read_native').fadeOut();
            //$('.movie_symlink').fadeOut();
            $('#movie_container').fadeOut();
            $('#custom_map').fadeOut();
            $('.subtitles').fadeOut();
            $('#target_container').prop('required', false);
        } else if (this.value == '0') {
            $('.read_native').fadeIn();
           // $('.movie_symlink').fadeIn();
            $('#movie_container').fadeIn();
            $('#custom_map').fadeIn();
            $('.subtitles').fadeIn();
            $('#target_container').prop('required', true);
        }
    });
});