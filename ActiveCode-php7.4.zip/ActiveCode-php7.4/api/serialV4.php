<?php 
class Serial
{
    private $link = null;
    private $code = null;
    private $sn = null;
    private $mac = null;
    private $api = null;
    private $inputBy = 2;
    public function __construct($link, $code, $sn, $mac, $api)
    {
        $this->link = $link;
        $this->code = $code;
        $this->sn = $sn;
        $this->mac = $mac;
        $this->api = $api;
        $sql_code = mysqli_query($this->link, 'SELECT * from solus_codes ' . (' where code=\'' . $code . '\' AND serial=\'' . $sn . '\' and inputBy=2;'));
        if( mysqli_num_rows($sql_code) == 1 ) 
        {
            $row = mysqli_fetch_array($sql_code);
            @extract($row);
            if( $status == 0 ) 
            {
                $this->activate_new_code($row);
                exit();
            }
            else if( $status == 2 ) 
            {
                $array = [
                    'status' => 2, 
                    'message' => 'The Code is Suspended', 
                    'expire' => '', 
                    'username' => '', 
                    'password' => ''
                ];
                $this->api->msg($array, '@Suspended');
            }
            else if( $status == 3 ) 
            {
                $array = [
                    'status' => 3, 
                    'message' => 'The Code is Not Found', 
                    'expire' => '', 
                    'username' => '', 
                    'password' => ''
                ];
                $this->api->msg($array, '@NotFound');
            }
        }
        $qry = 'SELECT c.id,c.code,c.date_expire,c.status,u.username, u.password FROM solus_codes c, users u ' . (' WHERE c.username=u.username AND c.code = \'' . $code . '\' AND c.serial=\'' . $sn . '\' AND c.mac=\'' . $mac . '\';');
        $result = mysqli_query($this->link, $qry) or         exit( mysqli_error($this->link) );
        if( mysqli_num_rows($result) == 0 ) 
        {
            $array = [
                'status' => 3, 
                'message' => 'The Code is not Not valid for this device.', 
                'expire' => '', 
                'username' => '', 
                'password' => ''
            ];
            $this->api->msg($array, '@Wrong Code');
        }
        $row = mysqli_fetch_array($result);
        $username = $row['username'];
        $password = $row['password'];
        $status = $row['status'];
        $expire = date('Y-m-d', $row['date_expire']);
        if( $expire < date('Y-m-d') ) 
        {
            $status = 4;
        }
        switch( $status ) 
        {
            case 1:
                $array = [
                    'status' => 100, 
                    'message' => 'The Code is active', 
                    'osd' => 'OSD Message like: test message.', 
                    'expire' => $this->api->expire_date($row['date_expire']), 
                    'user_agent' => trim($this->api->conf['user_agent']), 
                    'code_id' => $row['id']
                ];
                $this->api->msg($array, 'ReActivation');
                break;
            case 2:
                $array = [
                    'status' => 102, 
                    'message' => 'The Code is suspended', 
                    'expire' => (string)$expire, 
                    'username' => (string)$username, 
                    'password' => (string)$password
                ];
                $this->api->msg($array, 'Suspended');
                break;
            case 3:
                $array = [
                    'status' => 103, 
                    'message' => 'The Code is not found', 
                    'expire' => '', 
                    'username' => '', 
                    'password' => ''
                ];
                $this->api->msg($array, '@Wrong Code');
                break;
            case 4:
                $array = [
                    'status' => 105, 
                    'message' => 'The Code is Expired', 
                    'expire' => '', 
                    'username' => '', 
                    'password' => ''
                ];
                $this->api->msg($array, '@Expired Code');
                break;
        }
    }
    public function activate_new_code($row)
    {
        $days = intval($row['days']);
        $period = intval($row['period']);
        $code = trim($row['code']);
        $username = trim($row['username']);
        $fullname = trim($row['fullname']);
        $forced_country = trim($row['forced_country']);
        $id = intval($row['id']);
        if( $period > 0 ) 
        {
            if( in_array($period, $this->api->free) ) 
            {
                $dd = $period - 100;
                $exp_date = strtotime('+' . $dd . ' days');
            }
            else
            {
                $exp_date = strtotime('+' . $period . ' month');
            }
        }
        if( $code == '' ) 
        {
            $this->api->log(' error: code is empty ');
            exit( 'error: code is empty' );
        }
        $data['member_id'] = 1;
        $data['username'] = $username;
        $data['password'] = uniqid();
        $data['exp_date'] = $exp_date;
        $data['admin_notes'] = (string)$fullname;
        $data['admin_enabled'] = 1;
        $data['enabled'] = 1;
        $data['bouquet'] = '[' . $row['bouquets'] . ']';
        $data['max_connections'] = 1;
        $data['created_at'] = time();
        $data['created_by'] = 1;
        $data['forced_country'] = $forced_country;
        $data['reseller_notes'] = 'byMAC: ' . $this->mac;
        $sql = mysqli_query($this->link, 'SELECT id,username from users where username = \'' . $username . '\';');
        if( mysqli_num_rows($sql) == 0 ) 
        {
            $id = $this->api->insert('users', $data);
            $this->api->insert('user_output', [
                'user_id' => $id, 
                'access_output_id' => 1
            ]);
            $this->api->insert('user_output', [
                'user_id' => $id, 
                'access_output_id' => 2
            ]);
        }
        else
        {
            $xrow = mysqli_fetch_array($sql);
            $id = $xrow['id'];
        }
        $code_id = intval($row['id']);
        $up = mysqli_query($this->link, 'update solus_codes set ' . (' status=1,mac=\'' . $this->mac . '\',date_expire=\'' . $exp_date . '\',userid=\'' . $id . '\' ') . (' where id=' . $code_id . ';'));
        $array = [
            'status' => 100, 
            'message' => 'The Code has been activated successfully', 
            'osd' => 'OSD Message like: test message.', 
            'expire' => $this->api->expire_date($row['date_expire']), 
            'user_agent' => trim($this->api->conf['user_agent']), 
            'code_id' => $code_id
        ];
        $this->api->msg($array, 'Success');
    }
}
