<?php 
class Series_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $cat_for = [
        'All', 
        '10' => 'All'
    ];
    public function __construct($appname, $base, $img_path = '')
    {
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\"></icon>Series</a> \r\n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('episodes') . ('" href="' . $this->base . "/episodes\"><icon class=\"icon-list\"></icon>All Episodes</a> \r\n\t\t<a class=\"btn btn-") . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . "/Form?t=add\"><icon class=\"icon-plus-squared\"></icon>Add New Series</a>           \r\n\t\t</div>");
        $result = $intro->db->query('SELECT `task_id` FROM `solus_tasks` WHERE `task_for`=\'series\';');
        $totrows = $intro->db->returned_rows;
        if( $totrows > 0 ) 
        {
            echo "<div class=\"app_nav\">\r\n\t\t\t\t<a class=\"btn btn-success btn-lg blinking\" href=\"" . $this->base . "/StartTask\">\r\n\t\t\t\t\t<icon class=\"icon-run\"></icon>\r\n\t\t\t\t\tYou have (" . $totrows . ") Episode waiting to run Task, click here \r\n\t\t\t\t</a>  \r\n\t\t\t\t<a class=\"btn btn-danger btn-lg\" href=\"" . $this->base . "/ClearTask\" OnClick=\"return confirm('Are yuo sure?');\">\r\n\t\t\t\t\t<icon class=\"icon-run\"></icon>\r\n\t\t\t\t\tClear Task\r\n\t\t\t\t</a>\t\t\t\t\r\n\t\t\t</div>";
        }
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = $params = '';
        $category_id_s = intval($intro->input->get_post('category_id_s'));
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry .= (' and title  LIKE \'%' . $search_txt . '%\' ');
        }
        if( $category_id_s != 0 ) 
        {
            $qry .= (' and category_id=\'' . $category_id_s . '\' ');
            $params .= ('&category_id_s=' . $category_id_s);
        }
        if( $order == '' ) 
        {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 50;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * ,(select category_name from stream_categories where id=series.category_id) AS  category_name ' . (' from series where true  ' . $qry . ' order by id desc  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from series where true ' . $qry . ' ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i>Current Series (' . $totalrows . ')', 'info');
        echo "\r\n\t\t\r\n\t\t<form class=\"form-horizontal\" action=\"\" method=\"post\" >\r\n\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t<label class=\"control-label col-sm-2\"  align=left> Searies Name:</label>\r\n\t\t\t\t\t<div class=\"col-sm-2\">\r\n\t\t\t\t\t <input type=\"text\" class=\"form-control\"  name=\"search_txt\" value=\"" . $search_txt . "\" >\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<label class=\"control-label col-sm-1\"  align=left>Category : </label>\r\n\t\t\t\t\t<div class=\"col-sm-2\">\r\n\t\t\t\t\t\t" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('category_id_s', 'Choose ctegory', 'stream_categories', $category_id_s, 'id', 'category_name', ' where category_type="series" ', $order = '') . "\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t\r\n\t\t\t\t\t<div class=\"col-sm-2\">\r\n\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-info\">" . $intro->lang['search'] . "</button>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</form>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t\t<table class=\"table table-bordered table-hover table-striped\" id=\"table-1\"  >\r\n\t\t\t\t<thead>\r\n\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t<th>ID </th>\r\n\t\t\t\t\t\t<th>Category </th>\r\n\t\t\t\t\t\t<th>Title  </th>\r\n\t\t\t\t\t\t<th>Total Seasons</th>\r\n\t\t\t\t\t\t<th>Cover</th>\r\n\t\t\t\t\t\t<th>Options</th>\r\n\t\t\t\t\t</tr>\r\n\t\t\t\t</thead>\r\n\t\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $sql_s = $intro->db->query('SELECT id from series_episodes where series_id=\'' . $id . '\' group by season_num');
            $tot_seasons = $intro->db->returned_rows;
            echo '<tr class="' . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ('" id=\'' . $id . "'>\r\n\t\t\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t\t\t<td>" . $category_name . "</td>\r\n\t\t\t\t\t\t<td><span>" . $title . "</span></td>\r\n\t\t\t\t\t\t<td class=\"center\">" . $tot_seasons . "  </span></td>\r\n\t\t\t\t\t\t<td  class=\"center\"><img src=\"" . $cover . "\" style=\"max-height:50px;\" alt=\"\" /></td>\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t<td class=\"center\">\r\n\t\t\t\t\t\t\t<a class='btn btn-default' href='" . $this->base . '/episodes?id=' . $id . "' title=\"View All Episodes\"><i class=\"icon-zoom-in\"></i>  </a>\r\n\t\t\t\t\t\t\t<a class=' btn btn-success' href='" . $this->base . '/FormEpisode?t=add&sid=' . $id . "' title=\"Add New Episode\"><i class=\"icon-plus\"></i></a>\r\n\t\t\t\t\t\t\t<a class=' btn btn-success' href='" . $this->base . '/MassAdd?sid=' . $id . "' title=\"Mass Add Episodes\"><i class=\"icon-magic\"></i></a>\r\n\t\t\t\t\t\t\t<a class=\"btn btn-info\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-trash\"></i></a>\r\n\t\t\t\t\t\t</td>\r\n\t\t\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>\r\n\t\t</div>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?search_txt=' . $search_txt . $params . '&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</div>');
    }
    public function backdrop_path($backdrop_path)
    {
        if( $backdrop_path == '' ) 
        {
            return [];
        }
        $x = explode("\n", $backdrop_path);
        if( count($x) > 0 ) 
        {
            return $x;
        }
        return [];
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $title;
        global $bouqet_id;
        global $cast;
        global $seasons;
        global $youtube_trailer;
        global $backdrop_path;
        global $episode_run_time;
        global $category_id;
        global $tmdb_id;
        global $releaseDate;
        global $director;
        global $rating;
        global $cover;
        global $plot;
        global $cover_big;
        global $genre;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM series WHERE id=' . $id . ';');
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = 'Edit Series Number  <b>' . $id . '</b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
            $backImgs = json_decode($backdrop_path, true);
            if( is_array($backImgs) && count($backImgs) > 0 ) 
            {
                $backdrop_path = implode("\n", $backImgs);
            }
            else
            {
                $backdrop_path = '';
            }
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add New';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t" . _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911() . ("\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td style='width:20%;'>Category  : </td>\r\n\t\t\t<td  colspan=2>") . _obf_0D311A13371B215B013B112303362D1032353D2E344022('category_id', 'Choose ctegory', 'stream_categories', $category_id, 'id', 'category_name', 'where category_type=\'series\'', $order = '') . ($this->error('category_id') . "</td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>TMDB ID or Title: </td>\r\n\t\t\t<td colspan=2>\r\n\t\t\t\t") . _obf_0D303E153F1434130E373D01173C280D3E14021B012832('tmdb_lang', _obf_0D303E153F1434130E373D01173C280D3E14021B012832('tmdb_default')) . (" \r\n\t\t\t\t<input type=\"text\" placeholder=\"id like: 1399 or title like: Game of Thrones\" name=\"tmdb_id\" value=\"" . $tmdb_id . "\" size=\"50\"> \r\n\t\t\t\t<button type='button' id='re_fetch_btn'>Fech from TMDB</button> \r\n\t\t\t\t<div id=\"fetchStatus\" class=\"loading_style\" /></div>\r\n\t\t\t\t" . $this->error('icon') . "\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t\r\n\t\r\n\t\t<tr>\r\n\t\t\t<td>Title:<span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input class='form-control'  type=\"text\" name=\"title\" id=\"stream_display_name\"  value=\"" . $title . '" size="30"> ' . $this->error('title') . "</td>\r\n\t\t\t<td rowspan=3 style=\"max-width:150px;\"><a id='image1href' class=\"AjaxModal\" data-img=\"true\" href=\"" . $cover . '"><img id=\'image1\' src=\'' . $cover . "' style=\"max-height:200px;\"></a></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Cover:<span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input class='form-control'  type=\"text\" name=\"cover\" id=\"stream_icon\" value=\"" . $cover . '" size="30"> ' . $this->error('cover') . "</td>\r\n\t\t\t\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Cover big:<span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input class='form-control'  type=\"text\" id=\"cover_big\" name=\"cover_big\" value=\"" . $cover_big . '" size="30"> ' . $this->error('cover_big') . "</td>\r\n\t\t\t\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>Backdrop Images:</td>\r\n\t\t\t<td><textarea  class=\"form-control\" style=\"height:90px;\" name=\"backdrop_path\" id=\"backdrop_path\">" . $backdrop_path . '</textarea> ' . $this->error('backdrop_path') . "</td>\r\n\t\t\t<td  rowspan=2 style=\"max-width:150px;\"><a id='image2href' class=\"AjaxModal\" data-img=\"true\" href=\"" . $backdrop_path . '"><img id=\'image2\' src=\'' . $backdrop_path . "' style=\"max-height:150px;\"></a></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t\t<td>Genre: </td>\r\n\t\t\t\t<td><input name=\"genre\" class='form-control' id=\"genre\" value=\"" . $genre . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t\t<td>Plot: </td>\r\n\t\t\t\t<td colspan=2><textarea class='form-control' name='plot' id=\"plot\" value=\"" . $plot . '" >' . $plot . "</textarea></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t\t<td>Cast: </td>\r\n\t\t\t\t<td colspan=2><input class='form-control' name='cast'  id=\"cast\" value=\"" . $cast . "\" ></td>\r\n\t\t</tr>\r\n\t\r\n\t\t<tr>\r\n\t\t\t\t<td>Rating: </td>\r\n\t\t\t\t<td colspan=2><input class='form-control' name='rating' id=\"rating\" value=\"" . $rating . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t\t<td>Director: </td>\r\n\t\t\t\t<td colspan=2><input class='form-control' name='director' id=\"director\" value=\"" . $director . "\" ></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t\t<td>Release Date: </td>\r\n\t\t\t\t<td colspan=2><input class='form-control' id=\"releasedate\"  name=\"releasedate\" value=\"" . $releaseDate . "\" ></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t\t<td>Episode run time: </td>\r\n\t\t\t\t<td colspan=2><input class='form-control' name='episode_run_time' id=\"episode_run_time\" value=\"" . $episode_run_time . "\" ></td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t\t<td>youtube trailer: </td>\r\n\t\t\t\t<td colspan=2><input class='form-control' name='youtube_trailer' id=\"youtube_trailer\" value=\"" . $youtube_trailer . "\" ></td>\r\n\t\t</tr>");
        if( $t == 'add' ) 
        {
            echo "\r\n\t\t<tr>\r\n\t\t\t\t<td>Optional: Add Bouquets: </td>\r\n\t\t\t\t<td colspan=2>\r\n\t\t\t\t" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('bouqet_id', 'Choose bouquet', 'bouquets', 0, 'id', 'bouquet_name', ' where bouquet_status=1', ' order by bouquet_name asc') . "\r\n\t\t\t\t</td>\r\n\t\t</tr>";
        }
        echo "\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td colspan=2>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"year\"  id=\"year\"  value=\"\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\r\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\tfunction cleanString(input) {\r\n\t\t\tvar output = '';\r\n\t\t\tfor (var i=0; i<input.length; i++) {\r\n\t\t\t\tif (input.charCodeAt(i) <= 127) {\r\n\t\t\t\t\toutput += input.charAt(i);\r\n\t\t\t\t}\r\n\t\t\t}\r\n\t\t\treturn output;\r\n\t\t}\r\n\t\t\$(function(){\r\n\r\n\t\t\t\r\n\t\t\t\$(\"#re_fetch_btn\").on( \"click\", function( event ) {\r\n\t\t\t\t\r\n\t\t\t\tvar MovieID = \$(\"input[name='tmdb_id']\").val();\r\n\t\t\t\tvar tmdb_lang = \$(\"select[name='tmdb_lang']\").val();\r\n\t\t\t\t\r\n\t\t\t\t\$('#fetchStatus').addClass('loading');\r\n\t\t\t\t\r\n\t\t\t\t  \r\n\t\t\t\t\$.ajax({\r\n\t\t\t\t\turl: '" . $intro->app_url('movies', 'tmdb') . "/?tmdb_id='+encodeURIComponent(MovieID)+'&ser=1&NH=1&tmdb_lang='+tmdb_lang,\r\n\t\t\t\t\tcache: false,\r\n\t\t\t\t\ttimeout: 5000\r\n\t\t\t\t})\r\n\t\t\t\t.done(function( data ,status ) {\r\n\t\t\t\t\t\t\r\n\t\t\t\t\tvar json = jQuery.parseJSON(cleanString(data));\r\n\t\t\t\t\t/*var json = JSON.parse(data);*/\r\n\t\t\t\t\t\$.each(json, function(key, value) {\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\tif(key == 'error'){\r\n\t\t\t\t\t\t\talert(value);\r\n\r\n\t\t\t\t\t\t\treturn false;\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\tif(key == 'movie_image' && value != ''){\r\n\t\t\t\t\t\t\t\$(\"input[name='cover']\").val(value);\r\n\t\t\t\t\t\t\t\$('#image1').attr('src', value);\r\n\t\t\t\t\t\t\t\$('#image1href').attr('href', value);\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\telse if(key == 'backdrop_path' && value != ''){\r\n\r\n\t\t\t\t\t\t\t\t\$('#backdrop_path').val(value);\r\n\t\t\t\t\t\t\t\t\$('#image2').attr('src', value);\r\n\t\t\t\t\t\t\t\t\$('#image2href').attr('href', value);\r\n\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t}else{\r\n\t\t\t\t\t\t\t\$(\"#\"+key).val(value);\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t console.log(key +' = '+value);\r\n\r\n\t\t\t\t\t});\r\n\t\t\t\t\t\r\n\t\t\t\t}).fail(function(xhr, textStatus, errorThrown) {\r\n\t\t\t\t\talert( \"error: \" + xhr.statusText );\r\n\t\t\t\t\t\r\n\t\t\t\t}).always(function() {\r\n\t\t\t\t\t\$('#fetchStatus').removeClass('loading');\r\n\t\t\t\t});\r\n\t\t\t\t/*\r\n\t\t\t\tvar movie = \$('#stream_display_name').val();\r\n\t\t\t\tvar year = \$('#year').val();\r\n\t\t\t\tif( movie != '' ){\r\n\t\t\t\t\t\r\n\t\t\t\t\t\$.ajax({\r\n\t\t\t\t\t   url: '" . $intro->app_url('movies', 'youtube') . "/?NH=1&movie='+movie+'&year='+year,\r\n\t\t\t\t\t   success: function(data){\r\n\t\t\t\t\t\t\t\$('#youtube_trailer').val(data);\r\n\t\t\t\t\t   }//,\r\n\t\t\t\t\t   //timeout: 4000\r\n\t\t\t\t\t});\r\n\t\t\t\t}*/\r\n\t\t\t\t\r\n\t\t\t});\r\n\t\t\t\r\n\t\t });\r\n\t\t</script>";
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $msg = '';
        $category_id = intval($intro->input->post('category_id'));
        $title = trim($intro->input->post('title'));
        $cover = trim($intro->input->post('cover'));
        $cover_big = trim($intro->input->post('cover_big'));
        $genre = trim($intro->input->post('genre'));
        $plot = trim($intro->input->post('plot'));
        $cast = trim($intro->input->post('cast'));
        $rating = trim($intro->input->post('rating'));
        $director = trim($intro->input->post('director'));
        $releasedate = trim($intro->input->post('releasedate'));
        $tmdb_id = trim($intro->input->post('tmdb_id'));
        $seasons = trim($intro->input->post('seasons'));
        $backdrop_path = trim($intro->input->post('backdrop_path'));
        $bouqet_id = intval($intro->input->post('bouqet_id'));
        $episode_run_time = intval($intro->input->post('episode_run_time'));
        $youtube_trailer = trim($intro->input->post('youtube_trailer'));
        if( $title == '' ) 
        {
            if( $title == '' ) 
            {
                $msg .= '<li>Title is required </li>';
            }
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011($msg, 'danger');
            $this->Form('add');
            exit();
        }
        $data = [];
        $data['category_id'] = $category_id;
        $data['title'] = $title;
        $data['cover'] = $cover;
        $data['cover_big'] = $cover_big;
        $data['genre'] = $genre;
        $data['plot'] = $plot;
        $data['cast'] = $cast;
        $data['rating'] = $rating;
        $data['director'] = $director;
        $data['releaseDate'] = $releasedate;
        $data['tmdb_id'] = $tmdb_id;
        $data['seasons'] = '[]';
        $data['backdrop_path'] = json_encode($this->backdrop_path($backdrop_path));
        $data['episode_run_time'] = $episode_run_time;
        $data['youtube_trailer'] = $youtube_trailer;
        $data['last_modified'] = time();
        $intro->db->insert('series', $data);
        $id = $intro->db->insert_id();
        if( $bouqet_id != 0 ) 
        {
            $sql = $intro->db->query('SELECT * FROM bouquets WHERE id=' . $bouqet_id . ';');
            $row = $intro->db->fetch_assoc($sql);
            $bouquet_series = json_decode($row['bouquet_series'], true);
            array_unshift($bouquet_series, (string)$id);
            $data2 = [];
            $data2['bouquet_series'] = json_encode($bouquet_series);
            $intro->db->update('bouquets', $data2, 'id=' . $bouqet_id);
        }
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        global $s_title;
        $msg = '';
        $id = intval($intro->input->post('id'));
        $category_id = intval($intro->input->post('category_id'));
        $title = trim($intro->input->post('title'));
        $cover = trim($intro->input->post('cover'));
        $cover_big = trim($intro->input->post('cover_big'));
        $genre = trim($intro->input->post('genre'));
        $plot = trim($intro->input->post('plot'));
        $cast = trim($intro->input->post('cast'));
        $rating = trim($intro->input->post('rating'));
        $director = trim($intro->input->post('director'));
        $genres = trim($intro->input->post('genres'));
        $releasedate = trim($intro->input->post('releasedate'));
        $tmdb_id = trim($intro->input->post('tmdb_id'));
        $seasons = trim($intro->input->post('seasons'));
        $backdrop_path = trim($intro->input->post('backdrop_path'));
        $episode_run_time = intval($intro->input->post('episode_run_time'));
        $bouqet_id = intval($intro->input->post('bouqet_id'));
        $youtube_trailer = trim($intro->input->post('youtube_trailer'));
        if( $title == '' ) 
        {
            if( $title == '' ) 
            {
                $msg .= '<li>Title is required </li>';
            }
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011($msg, 'danger');
            $this->Form('edit');
            exit();
        }
        $data = [];
        $data['category_id'] = $category_id;
        $data['title'] = $title;
        $data['cover'] = $cover;
        $data['cover_big'] = $cover_big;
        $data['genre'] = $genre;
        $data['plot'] = $plot;
        $data['cast'] = $cast;
        $data['rating'] = $rating;
        $data['director'] = $director;
        $data['releaseDate'] = $releasedate;
        $data['tmdb_id'] = $tmdb_id;
        $data['seasons'] = '[]';
        $data['backdrop_path'] = json_encode($this->backdrop_path($backdrop_path));
        $data['episode_run_time'] = $episode_run_time;
        $data['youtube_trailer'] = $youtube_trailer;
        $data['last_modified'] = time();
        $intro->db->update('series', $data, 'id=' . $id);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('DELETE FROM streams WHERE id in (select stream_id from series_episodes where series_id=' . $id . ') ');
        $sql = $intro->db->query('DELETE FROM series_episodes WHERE series_id=' . $id . '; ');
        $sql = $intro->db->query('DELETE FROM series WHERE id=' . $id . '; ');
        $intro->redirect($this->appname);
    }
    public function get_serieas($id)
    {
        global $intro;
        global $sess_admin;
        global $array;
        $result = $intro->db->query('SELECT * from series where id=' . $id . ' ');
        if( $intro->db->returned_rows > 0 ) 
        {
            return $intro->db->fetch_assoc($result);
        }
        else
        {
            return false;
        }
    }
    public function form_select_category($html_name, $cat_value)
    {
        global $intro;
        $dyn_menu = "\r\n\t\t<select name=\"" . $html_name . "\" class=\"chosen searchable\">\n";
        $dyn_menu .= "\r\n\t\t\t<option value=\"0\" selected> Choose Category </option>\n";
        $result = $intro->db->query('SELECT * from `stream_categories` where category_type=\'movie\' AND parent_id=0  order by category_name ASC');
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            $cat_name = $row['category_name'];
            $dyn_menu .= ("\r\n\t\t\t<option " . (($cat_value == $row['id'] ? 'selected ' : '')) . (' value="' . $row['id'] . '" style=\'background-color: #CEDEFB\'>') . $cat_name . '</option>');
            $dyn_menu .= $this->form_select_sub($row['id'], $cat_value);
        }
        $dyn_menu .= "\r\n\t\t</select>\n\n ";
        return (string)$dyn_menu;
    }
    public function form_select_sub($father, $cat_value, $bar = '')
    {
        global $intro;
        $father = intval($father);
        $dyn_menu = '';
        $result = $intro->db->query('SELECT * from `stream_categories` where parent_id=' . $father . ' order by category_name ASC');
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            $dyn_menu .= ("\r\n\t\t\t<option " . (($cat_value == $row['id'] ? 'selected ' : '')) . (' value="' . $row['id'] . '" style=\'background-color: #CEDEFB\'>' . $bar . '--------|' . $row['category_name'] . '</option>'));
            $dyn_menu .= $this->form_select_sub($row['id'], $cat_value, '--------');
        }
        return ' ' . $dyn_menu;
    }
    public function episodes()
    {
        global $intro;
        global $array;
        $qry = $params = '';
        $stitle = trim($intro->db->escape($intro->input->get_post('stitle')));
        $epname = trim($intro->db->escape($intro->input->get_post('epname')));
        $id = $ser_id = intval($intro->input->get_post('id'));
        $page = intval($intro->input->get_post('page'));
        $status = intval($intro->input->get_post('status'));
        $epid = intval($intro->input->get_post('epid'));
        $search_txt = trim($intro->db->escape($intro->input->get_post('search_txt')));
        $get_seriea = $this->get_serieas($id);
        $title = trim($intro->db->escape($intro->input->get_post('title')));
        $category_id = intval($intro->input->get_post('category_id'));
        $server = intval($intro->input->get_post('server'));
        $colspan = 9;
        if( $id != 0 ) 
        {
            $qry .= (' AND ep.series_id=' . $id . ' ');
            $params .= ('&id=' . $id);
        }
        else
        {
            $colspan = 10;
        }
        if( $status != 0 ) 
        {
            $qry .= $array['encode_status_qry'][$status];
            $params .= ('&status=' . $status);
        }
        if( $title != '' ) 
        {
            $qry .= (' and  ser.title  LIKE \'%' . $title . '%\' ');
            $params .= ('&title=' . $title);
        }
        if( $server != 0 ) 
        {
            $qry .= (' and sys.server_id=' . $server . ' ');
            $params .= ('&server=' . $server);
        }
        if( $category_id != 0 ) 
        {
            $qry .= (' and s.category_id=' . $category_id . ' ');
            $params .= ('&category_id=' . $category_id);
        }
        if( $epname != '' ) 
        {
            $qry .= (' and s.stream_display_name LIKE \'%' . $epname . '%\' ');
            $params .= ('&epname=' . $epname);
        }
        if( $epid != 0 ) 
        {
            $qry .= (' and ep.id = ' . $epid . ' ');
        }
        if( $epid == 0 ) 
        {
            $epid = '';
        }
        $this->nav();
        $rows_per_page = 100;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT *,ep.id as seid,ser.id as sid,s.id as stid ,(SELECT GROUP_CONCAT(server_name SEPARATOR ", ") FROM streaming_servers WHERE id=sys.server_id LIMIT 1) as server_name  FROM series_episodes ep  LEFT JOIN series ser ON ep.series_id=ser.id  LEFT JOIN streams s ON ep.stream_id=s.id  LEFT JOIN streams_sys sys ON s.id=sys.stream_id ' . (' WHERE true ' . $qry . '  order by ser.id DESC, ep.season_num ASC,ep.sort ASC  limit ' . $nexlimit . ',' . $rows_per_page));
        $intro->db->query('SELECT ep.id FROM series_episodes ep  LEFT JOIN series ser ON ep.series_id=ser.id  LEFT JOIN streams s ON ep.stream_id=s.id  LEFT JOIN streams_sys sys ON s.id=sys.stream_id WHERE true  ' . (' ' . $qry . '  '));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i>Current Series (' . $totalrows . ')', 'info');
        if( $id != 0 ) 
        {
            echo "\r\n\t\t\t<div class=\"text-center\"><h3 style='margin:0;'> Series Name : " . $get_seriea['title'] . ("  <h3></div>\r\n\t\t\t<div class=\"text-center\">\r\n\t\t\t\t<a class='btn btn-default' href='" . $this->base . '/episodes?id=' . $id . "' title=\"View All Episodes\"><i class=\"icon-zoom-in\"></i> Episodes </a>\r\n\t\t\t\t<a class='btn btn-success' href='" . $this->base . '/FormEpisode?t=add&sid=' . $id . "' title=\"Add New Episode\"><i class=\"icon-plus\"></i> Add</a>\r\n\t\t\t\t<a class='btn btn-success' href='" . $this->base . '/MassAdd?sid=' . $id . "' title=\"Mass Add Episodes\"><i class=\"icon-magic\"></i> Mass Add</a>\r\n\t\t\t\t\t\t\t\t\r\n\t\t\t</div><br\t/>");
        }
        echo "\r\n\t\t<fieldset>\r\n\t\t\t\r\n\t\t\t<form class=\"form-inline\" action=\"\" method=\"post\">";
        if( $id == 0 ) 
        {
            echo "\r\n\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t<input type=\"text\" class=\"form-control\"  name=\"epid\" value=\"" . $epid . "\" placeholder=\"Episode ID\" style=\"width:70px;\">\r\n\t\t\t  </div>\r\n\t\t\t  <div class=\"form-group\">\r\n\t\t\t\t<input type=\"text\" class=\"form-control\"  name=\"title\" value=\"" . $title . "\" placeholder=\"Series Title\">\r\n\t\t\t  </div>\r\n\t\t\t  <div class=\"form-group\">\r\n\t\t\t\t<input type=\"text\" class=\"form-control\"  name=\"epname\" value=\"" . $epname . "\" placeholder=\"Episode Name\">\r\n\t\t\t  </div>\r\n\t\t\t  <div class=\"form-group\">\r\n\t\t\t\t<label >Category:</label>\r\n\t\t\t\t" . $this->form_select_category('category_id', $category_id) . "\r\n\t\t\t  </div>";
        }
        echo "\r\n\t\t\t<div class=\"form-group\">\r\n\t\t\t<label >Server:</label>\r\n\t\t\t\t" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('server', 'All Servers', 'streaming_servers', 0, 'id', 'server_name', 'bouquet_status', 'where `status`=1', 'order by server_name asc') . "\r\n\t\t\t  </div>\r\n\t\t\t<div class=\"form-group\">\r\n\t\t\t\t<label >Encoding Status:</label>\r\n\t\t\t\t" . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('status', $array['encode_status'], $status, 'All', 0) . "\r\n\t\t\t  </div>\r\n\t\t\t  <button type=\"submit\" class=\"btn btn-info\">" . $intro->lang['search'] . "</button>\r\n\t\t\t</form>\r\n\r\n\t\t</fieldset>\r\n\t\t<form method=\"post\" name=\"VodsForm\"  id=\"VodsForm\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\" id=\"table-1\"  >\r\n\t\t\t<thead>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<th><input type='checkbox' class='checkAll' /></th>\r\n\t\t\t\t\t<th>ID </th>\r\n\t\t\t\t\t<th>Status</th>";
        if( $id == 0 ) 
        {
            echo '<th>Serie</th>';
        }
        echo "\r\n\t\t\t\t\t<th>Title</th>\r\n\t\t\t\t\t<th>Season Number</th>\r\n\t\t\t\t\t<th>Episode Number</th>\r\n\t\t\t\t\t<th>Server</th>\r\n\t\t\t\t\t<th>Bitrate</th>\r\n\t\t\t\t\t<th>Options</th>\r\n\t\t\t\t</tr>\r\n\t\t\t</thead>\r\n\t\t<tbody>";
        $i = 0;
        $season_numold = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            if( $season_numold != $season_num ) 
            {
                echo "\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<th colspan=\"" . $colspan . '" class="center"><font color=white size=3>Season ' . $season_num . " </font></th>\r\n\t\t\t\t</tr>";
            }
            echo "\r\n\t\t\t<tr  id=\"" . $seid . "\" >\r\n\t\t\t\t<td class=\"center\"><input type=\"checkbox\" class=\"checkAllIds\" value=\"" . $stid . "\" name=\"ids[]\"></td>\r\n\t\t\t\t<td class=\"center\">" . $seid . "  </td>\r\n\t\t\t\t<td class=\"center\" id=\"vod_" . $id . '"><span id=\'loadvod_' . $id . '\'></span> ' . _obf_0D01250828283822072939021F5B09051E1F2B2A073411($stid, $myrow) . '</td>';
            if( intval($intro->input->get_post('id')) == 0 ) 
            {
                echo '<td>' . $title . '</td>';
            }
            echo "\r\n\t\t\t\t<td>" . $stream_display_name . "</td>\r\n\t\t\t\t<td class=\"center\">" . $season_num . "</td>\r\n\t\t\t\t<td class=\"center\"><apan class=\"editable\" data-type=\"text\" data-pk=\"" . $seid . '" data-name="sort"> ' . $sort . " </span></td>\r\n\t\t\t\t<td class=\"center\">" . $server_name . "</td>\r\n\t\t\t\t<td class=\"center\">" . $bitrate . " Kbps</td>\r\n\t\t\t\t<td class=\"center\">\r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/FormEpisode?t=edit&amp;sid=' . $sid . '&stid=' . $stid . '&seid=' . $seid . '" title="' . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Delepisode?NH=1&stid=' . $stid . '&seid=' . $seid . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
            $season_numold = $season_num;
        }
        echo "</tbody>\r\n\t\t<tr>\r\n\t\t\t\t<td class=\"center\"><input type='checkbox' class='checkAll' /></td>\r\n\t\t\t\t<td class=\"center\"><div id='checked_count'></div></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t</tr>\r\n\t\t</table>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/episodes?id=' . $ser_id . $params, $totalrows, $rows_per_page, $page) . '</div>');
        echo "\r\n\t\t<script>\r\n\t\t/* inline */\r\n\t\t\$.fn.editable.defaults.mode = 'inline';     \r\n\t\t\$('.editable').editable({\r\n\t\t\turl: '" . $this->base . "/EditInPlace?NH=1',\r\n\t\t\tsuccess: function(response) {\r\n\t\t\t/*alert(response);*/\r\n\t\t\t}\r\n\t\t});\r\n\t\t</script>";
        echo "<script>\r\n\t\t\$(function(){\r\n\t\t\t\r\n\t\t\t\$(\"#encode,#delete\").on( \"click\", function( event ) {\r\n\t\t\t\tif(!confirm('Are You sure?'))\r\n\t\t\t\treturn false;\r\n\t\t\t});\r\n\t\t\t\$(\".triggerEncode\").on( \"click\", function( event ) {\r\n\t\t\t\t\r\n\t\t\t\tvar a_obj = \$(this);\r\n\t\t\t\tvar vodID = \$(this).data('id');\r\n\t\t\t\tvar url_start = \$(this).attr('href');\r\n\t\t\t\tvar vodTdObj = \$('#'+vodID);\r\n\t\t\t\tvar vodStatusObj = \$('#load'+vodID);\r\n\t\t\t\tvodStatusObj.addClass('loading_style').addClass('loading');\r\n\t\t\t\t\r\n\t\t\t\t\$.ajax({\r\n\t\t\t\t\turl: url_start,\r\n\t\t\t\t\tcache: false,\r\n\t\t\t\t\ttimeout: 3000\r\n\t\t\t\t})\r\n\t\t\t\t.done(function( data ,status ) {\r\n\t\t\t\t\t\t\r\n\t\t\t\t\tif(data == 'success'){\r\n\t\t\t\t\t\ta_obj.html('Started').addClass('btn btn-success');\r\n\t\t\t\t\t}else{\r\n\t\t\t\t\t\ta_obj.html(data);\r\n\t\t\t\t\t}\r\n\t\t\t\t\t\r\n\t\t\t\t}).fail(function(xhr, textStatus, errorThrown) {\r\n\t\t\t\t\talert( \"error: \" + xhr.statusText );\r\n\t\t\t\t\t\r\n\t\t\t\t}).always(function() {\r\n\t\t\t\t\tvodStatusObj.removeClass('loading').removeClass('loading_style');\r\n\t\t\t\t});\r\n\t\t\t\t\r\n\t\t\t\treturn false;\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\tvar checkboxes = \$('.checkAllIds');\r\n\t\t\t\t\r\n\t\t\t\$(\".checkAll\").change(function () {\r\n\t\t\t\t\$(\".checkAllIds\").prop('checked', \$(this).prop(\"checked\"));\r\n\t\t\t\tvar c = checkboxes.filter(':checked').length;\r\n\t\t\t\t\$('#checked_count').html(c);\r\n\t\t\t\t\r\n\t\t\t\tif(c > 0)\r\n\t\t\t\t\t\$('#VodsFormButtons').show();\r\n\t\t\t\telse\r\n\t\t\t\t\t\$('#VodsFormButtons').hide();\r\n\t\t\t});\r\n\r\n\t\t\tcheckboxes.change(function()\r\n\t\t\t{\r\n\t\t\t\tvar c = checkboxes.filter(':checked').length;\r\n\t\t\t\t\$('#checked_count').html(c);\r\n\t\t\t\t\r\n\t\t\t\tif(c > 0)\r\n\t\t\t\t\t\$('#VodsFormButtons').show();\r\n\t\t\t\telse\r\n\t\t\t\t\t\$('#VodsFormButtons').hide();\r\n\t\t\t\t\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$(\"#VodsForm\").submit( function () {   \r\n\t\t\t\t\$('#resultCMD').html('loading...');\r\n\t\t\t\t\$.post('" . $intro->app_url('movies', 'doCMD') . "?NH=1',\$(this).serialize(),function(data){\r\n\t\t\t\t\t\r\n\t\t\t\t\t\$(\"#resultCMD\").html(data)\r\n\t\t\t\t}\r\n\t\t\t  );\r\n\t\t\t  return false;   \r\n\t\t\t});\r\n\t\t\t\r\n\t\t });\r\n\t\t</script>";
    }
    public function export()
    {
        global $intro;
        global $array;
        $host_port = '';
        $id = $ser_id = intval($intro->input->get_post('id'));
        $rowSer = $this->get_serieas($id);
        $user = intval($intro->input->get_post('user'));
        $titleRename = trim($intro->input->get_post('titleRename'));
        if( $titleRename == '' ) 
        {
            $titleRename = preg_replace('/[^\p{L}\p{N}.]/u', '', str_replace(' ', '.', $rowSer['title']));
        }
        if( $user > 0 ) 
        {
            $host_port = _obf_0D30011C3F2A2E3F22302707253C09162F3D0E082D0E11('host_port');
            $sql = $intro->db->query('SELECT * from users WHERE id=' . $user . ';');
            $r = $intro->db->fetch_assoc($sql);
            $host_port = $host_port . ('series/' . $r['username'] . '/' . $r['password']);
        }
        $time = strtotime('+1 day');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Options', 'info');
        echo "<form action=\"\" method=\"GET\">\r\n\t\t<table class='table'>\r\n\t\t<tr>\r\n\t\t\t<td>User:</td>\r\n\t\t\t<td>" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('user', 'User to download by ', 'users', $user, 'id', 'username', 'WHERE id NOT IN (select userid from solus_codes) AND (exp_date > \'' . $time . '\' OR exp_date=\'\' OR exp_date IS NULL)', 'order by id DESC limit 100') . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Rename To:</td>\r\n\t\t\t<td><input class=\"form-control\" type=\"text\" name=\"titleRename\" value=\"" . $titleRename . "\" size=\"20\" placeholder='Rename series'></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"submit\" class=\"btn btn-success\" value=\" Go \" class='btn btn-default'>\r\n\t\t\t\t<input type=\"hidden\" name=\"id\" value=\"" . $id . "\">\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</form>");
        $qry = ' AND ep.series_id=' . $id . ' ';
        $result = $intro->db->query('SELECT *,ep.id as seid,ser.id as sid,s.id as stid ,(SELECT GROUP_CONCAT(server_name SEPARATOR ", ") FROM streaming_servers WHERE id=sys.server_id LIMIT 1) as server_name  FROM series_episodes ep  LEFT JOIN series ser ON ep.series_id=ser.id  LEFT JOIN streams s ON ep.stream_id=s.id  LEFT JOIN streams_sys sys ON s.id=sys.stream_id ' . (' WHERE true ' . $qry . '  order by ser.id DESC, ep.season_num ASC,ep.sort ASC'));
        $i = 0;
        echo '<textarea style=\'width:100%;height:300px;\'>';
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $ext = json_decode($target_container, true);
            if( !isset($ext[0]) ) 
            {
                $ext[0] = 'mkv';
            }
            $season_num = str_pad($season_num, 2, '0', STR_PAD_LEFT);
            $sort = str_pad($sort, 2, '0', STR_PAD_LEFT);
            if( $titleRename != '' ) 
            {
                $title = $titleRename;
            }
            else
            {
                $title = str_replace(' ', '.', $title);
                $title = preg_replace('/[^\p{L}\p{N}.]/u', '', $title);
            }
            echo 'wget -c --tries=5 --read-timeout=10 -O "' . $title . '.S' . $season_num . '.E' . $sort . '.' . $ext[0] . '" ' . (($host_port != '' ? $host_port : '{http}')) . ('/' . $stid . '.' . $ext[0] . " \n");
        }
        echo '</textarea>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function EditInPlace()
    {
        global $intro;
        $id = intval($intro->input->get_post('pk'));
        $name = trim($intro->input->get_post('name'));
        $value = trim($intro->input->get_post('value'));
        $data = [];
        $data[$name] = $value;
        $intro->db->update('series_episodes', $data, 'id=' . $id . ' ');
    }
    public function FormEpisode($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $stid;
        global $redirect_stream;
        global $sort;
        global $target_container;
        global $direct_source;
        global $season_num;
        global $stream_icon;
        global $stream_display_name;
        global $stream_source;
        global $movie_location;
        global $movie_symlink;
        global $load_balancer_servers;
        global $transcode_profile_id;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $sid = intval($intro->input->get_post('sid'));
        $seid = intval($intro->input->get_post('seid'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $get_seriea = $this->get_serieas($sid);
        $btn = [];
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT *,s.id as stid FROM series_episodes ep' . (' LEFT JOIN streams s on ep.stream_id=s.id WHERE ep.id=' . $seid . ';'));
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = 'Edit Series Episode Number  <b>' . $seid . '</b>';
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEditEpisode';
            $target_container = json_decode($target_container);
            $sys = _obf_0D1E2701171B3D1C36152B2D2512305C1003175B1E3E11($stream_source, $stid);
            $movie_location = $sys['movie_location'];
            $stream_source = $sys['stream_source'];
            $load_balancer_servers = $sys['load_balancer_servers'];
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = 'Add New Episode';
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $btn['legend_name'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAddEpisode';
            if( !is_array($target_container) ) 
            {
                $target_container = [];
            }
        }
        $star = '<span style=\'color:#ff0000\'>*</span>';
        echo "\r\n\t\t<script>var base = '" . $intro->app_url('movies', 'brws') . "/'; var type='single';</script>\r\n\t\t<link rel=\"stylesheet\" href=\"" . admin_path . "style/tree/proton/proton.min.css\">\r\n\t\t<script src=\"" . admin_path . "style/tree/jstree.min.js\"></script>\r\n\t\t<script src=\"" . admin_path . 'style/js/vod.js?v=1"></script>';
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t\t<div><h3> Series Name : " . $get_seriea['title'] . " <h3></div>\r\n\t\t\t" . _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911() . ("\r\n\t\t\t\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t<tr>\r\n\t\t\t<td>Episode Location: " . $star . "</td>\r\n\t\t\t<td>\r\n\t\t\t\t") . _obf_0D12262623113F1D022A011A3E1D1B253D294027090E01('movie_location', $movie_location) . (' ' . $this->error('movie_location') . " \r\n\t\t\t\t<span id=\"local\" style=\"display: none;\">\r\n\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" id=\"PickFile\">Pick</button>\r\n\t\t\t\t</span>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t<tr id=\"movie_source_form\">\r\n\t\t\t<td>Episode Source : " . $star . "</td>\r\n\t\t\t<td><input  type=\"text\" name=\"stream_source\" id=\"stream_source\" value=\"" . $stream_source . '" class=\'form-control\'>' . $this->error('stream_source') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class=\"direct_source\" style=\"display: none;\">\r\n\t\t\t<td>") . tooltip('tooltip_streams', 'direct_source') . " Use Direct Source & don't restream it: </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('direct_source', $direct_source, 'yes') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class=\"redirect_stream\" style=\"display: none;\">\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'redirect_stream') . " Redirect Stream to the Original Source:  </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('redirect_stream', $redirect_stream, 'yes') . "</td>\r\n\t\t</tr>\r\n\t\t<tr id=\"load_balancer\">\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'load_balancer_servers') . ('Select Load Balancer Servers : ' . $star . "</td>\r\n\t\t\t<td><div>") . _obf_0D31033702041D1F0B1015180339183714070C36032811('load_balancer_servers[]', $load_balancer_servers) . ($this->error('load_balancer_servers') . "</div></td>\r\n\t\t</tr>\r\n\t\t<tr class=\"movie_symlink\" style=\"display: none;\">\r\n\t\t\t<td>") . tooltip('tooltip_streams', 'movie_symlink') . " Do not encode the VOD, use the source: </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('movie_symlink', $movie_symlink, 'yes') . ("</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td style='width:20%;'>Season number: " . $star . "</td>\r\n\t\t\t<td><input  class='form-control'  type=\"text\" name=\"season_num\" value=\"" . $season_num . '" size="30"> ' . $this->error('season_num') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Episode Number: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  class='form-control'  type=\"text\" name=\"sort\" value=\"" . $sort . '" size="30"> ' . $this->error('sort') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Episode Name:</td>\r\n\t\t\t<td><input  class='form-control series_js_episode_name'  type=\"text\" name=\"stream_display_name\" value=\"" . $stream_display_name . '" size="30"> ' . $this->error('stream_display_name') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Episode icon:</td>\r\n\t\t\t<td><input  class='form-control'  type=\"text\" name=\"stream_icon\" value=\"" . $stream_icon . '" size="30"> ' . $this->error('stream_icon') . "</td>\r\n\t\t</tr>\r\n\r\n\t\t<tr>\r\n\t\t\t<td>Target containers:  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td>") . _obf_0D042827394002382E07271E152934171C2F1B331B0C11('target_container[]', $array['target_container'], $target_container, $txt = '') . ($this->error('target_container') . "</td>\r\n\t\t</tr>");
        echo "\r\n\t\t<tr class='transcode'>\r\n\t\t\t<th colspan=\"2\">Transcode Movie</th>\r\n\t\t</tr>\r\n\t\t<tr class='transcode'>\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'transcode_profile_id') . " Select Transcode Profile: </td>\r\n\t\t\t<td>" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('transcode_profile_id', 'No Transcode', 'transcoding_profiles', $transcode_profile_id, 'profile_id', 'profile_name', '', ' order by profile_name ASC') . " \r\n\t\t\t\t<a href=\"" . $intro->app_url('transcode_profiles', 'index') . "\" target=\"_blank\" class=\"btn btn-default\">Manage</a>\r\n\t\t\t</td>\r\n\t\t</tr>";
        if( $t == 'edit' ) 
        {
            echo "\r\n\t\t<tr>\r\n\t\t\t<td> </td>\r\n\t\t\t<td><input  type=\"checkbox\" name=\"reEncode\" value=\"1\"> Re-Encode after edit? </td>\r\n\t\t</tr>";
        }
        echo "\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"sid\"  value=\"" . $sid . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"seid\"  value=\"" . $seid . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"stid\"  value=\"" . $stid . "\">\r\n\t\t\t\t<button type=\"submit\" class=\"btn btn-success\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        if( $movie_location == 'remote' ) 
        {
            $js = "\$('#local').hide();\r\n            \$('#fetch_options').hide();\r\n            \$('.direct_source').show();\r\n            \$('.movie_symlink').hide();\r\n\t\t\t\$('#load_balancer_servers').prop('required', false);";
        }
        else if( is_numeric($movie_location) ) 
        {
            $js = "\$('#local').show();\r\n            \$('#fetch_options').hide();\r\n            \$('.direct_source').hide();\r\n\r\n            \$('#read_native').show();\r\n            \$('#load_balancer').show();\r\n            \$('.movie_symlink').show();\r\n            \$('#movie_container').show();\r\n            \$('#subtitles').show();\r\n  \r\n            \$('input:radio[name=direct_source][value=0]').click();\r\n            \$('#load_balancer_servers').prop('required', true);\r\n\r\n\t\t\t\$('#firstChosenSelect').chosen();\r\n\t\t\t\$('#load_balancer_servers').addClass('chosen').chosen({search_contains: true});";
        }
        else
        {
            $js = '';
        }
        echo "<script>\r\n\t\tfunction cleanString(input) {\r\n\t\t\tvar output = '';\r\n\t\t\tfor (var i=0; i<input.length; i++) {\r\n\t\t\t\tif (input.charCodeAt(i) <= 127) {\r\n\t\t\t\t\toutput += input.charAt(i);\r\n\t\t\t\t}\r\n\t\t\t}\r\n\t\t\treturn output;\r\n\t\t}\r\n\t\t\$(function(){\r\n\r\n\t\t\t" . $js . "\r\n\t\t });\r\n\t\t</script>";
    }
    public function doAddEpisode()
    {
        global $intro;
        global $error;
        $msg = '';
        $movie_location = trim($intro->input->post('movie_location'));
        $t = trim($intro->input->post('t'));
        $stream_display_name = trim($intro->input->post('stream_display_name'));
        $target_container = $intro->input->post('target_container');
        $stream_icon = $intro->input->post('stream_icon');
        $stream_source = $intro->input->post('stream_source');
        $redirect_stream = intval($intro->input->post('redirect_stream'));
        $season_num = intval($intro->input->post('season_num'));
        $direct_source = intval($intro->input->post('direct_source'));
        $sid = intval($intro->input->get_post('sid'));
        $seid = intval($intro->input->get_post('seid'));
        $stid = intval($intro->input->get_post('stid'));
        $stitle = trim($intro->input->post('stitle'));
        $sort = intval($intro->input->post('sort'));
        $load_balancer_servers = $intro->input->post('load_balancer_servers');
        if( $movie_location == '' || $sort <= 0 || $season_num <= 0 || $stream_source == '' || $direct_source == 0 && !isset($load_balancer_servers) || is_numeric($movie_location) && !isset($load_balancer_servers) || !isset($target_container[0]) || $sid == 0 ) 
        {
            if( $movie_location == '' ) 
            {
                $error['movie_location'] = '<span class=error>Please choose Episode Location!</span>';
            }
            if( $stream_source == '' ) 
            {
                $error['stream_source'] = '<span class=error>Episode Source is Required!</span>';
            }
            if( $direct_source == 0 && !isset($load_balancer_servers[0]) || is_numeric($movie_location) && !isset($load_balancer_servers[0]) ) 
            {
                $error['load_balancer_servers'] = '<span class=error>Please choose LB server</span>';
            }
            if( $season_num <= 0 ) 
            {
                $error['season_num'] = '<span class=error>Season Number is Required!</span>';
            }
            if( $sort <= 0 ) 
            {
                $error['sort'] = '<span class=error>Episode Number is Required!</span>';
            }
            if( !isset($target_container[0]) ) 
            {
                $error['target_container'] = '<span class=error>Please choose Traget Container</span>';
            }
            if( $sid <= 0 ) 
            {
                $error['target_container'] = '<span class=error>Error: Unknown Series ID</span>';
            }
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011(implode('<li>', $error), 'danger');
            $this->FormEpisode($t);
            exit();
        }
        $data = [];
        $data['stream_display_name'] = $stream_display_name;
        $data['stream_icon'] = $stream_icon;
        $data['redirect_stream'] = $redirect_stream;
        $data['type'] = 5;
        $data['added'] = time();
        $data['target_container'] = json_encode($target_container);
        if( $movie_location == 'remote' ) 
        {
            $data['direct_source'] = $direct_source;
            $data['redirect_stream'] = $redirect_stream;
        }
        else if( intval($movie_location) > 0 ) 
        {
            $stream_source = 's:' . $movie_location . ':' . $stream_source;
            $data['movie_symlink'] = intval($intro->input->post('movie_symlink'));
            $data['read_native'] = intval($intro->input->post('read_native'));
        }
        $data['stream_source'] = json_encode([$stream_source], JSON_UNESCAPED_SLASHES);
        $data['transcode_profile_id'] = intval($intro->input->post('transcode_profile_id'));
        $dataEp = [];
        $dataEp['series_id'] = $sid;
        $dataEp['season_num'] = $season_num;
        $dataEp['sort'] = $sort;
        if( $direct_source == 1 ) 
        {
            $load_balancer_servers[0] = 0;
        }
        if( $t == 'add' ) 
        {
            $intro->db->insert('streams', $data);
            $stream_id = $intro->db->insert_id();
            $dataEp['stream_id'] = $stream_id;
            $intro->db->insert('series_episodes', $dataEp);
            _obf_0D1E2701171B3D1C36152B2D2512305C1003175B1E3E11($t, $stream_id, $load_balancer_servers[0], $direct_source);
            $intro->db->query('UPDATE `series` set last_modified=\'' . time() . ('\' WHERE id=' . $sid . '; '));
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Episode added successfully.', 'success');
        }
        else if( $t == 'edit' ) 
        {
            _obf_0D1E2701171B3D1C36152B2D2512305C1003175B1E3E11($t, $stid, $load_balancer_servers[0], $direct_source);
            $intro->db->update('streams', $data, 'id=' . $stid);
            $intro->db->update('series_episodes', $dataEp, 'id=' . $seid . ';');
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Episode changes saved! If you changed source then you must Re-Encode this Episode', 'success');
        }
        $intro->redirect($this->appname, 'Episodes', '?id=' . $sid);
    }
    public function doEditEpisode()
    {
        global $intro;
        global $array;
        $_POST['t'] = 'edit';
        $this->doAddEpisode();
    }
    public function doEditEpisodeOLDXXX()
    {
        global $intro;
        global $array;
        global $s_title;
        $msg = '';
        $stream_display_name = trim($intro->input->post('stream_display_name'));
        $stream_icon = $intro->input->post('stream_icon');
        $stream_source = $intro->input->post('stream_source');
        $redirect_stream = intval($intro->input->post('redirect_stream'));
        $direct_source = intval($intro->input->post('direct_source'));
        $season_num = intval($intro->input->post('season_num'));
        $target_container = $intro->input->post('target_container');
        $stitle = trim($intro->input->post('stitle'));
        $sid = intval($intro->input->get_post('sid'));
        $seid = intval($intro->input->get_post('seid'));
        $stid = intval($intro->input->get_post('stid'));
        $sort = intval($intro->input->get_post('sort'));
        if( $stream_display_name == '' ) 
        {
            if( $stream_display_name == '' ) 
            {
                $msg .= '<li>Title is required </li>';
            }
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011($msg, 'danger');
            $this->FormEpisode('add');
            exit();
        }
        $data = [];
        $data['stream_display_name'] = $stream_display_name;
        $data['stream_icon'] = $stream_icon;
        $data['redirect_stream'] = $redirect_stream;
        $data['target_container'] = json_encode($target_container);
        $data['direct_source'] = $direct_source;
        $data['stream_source'] = json_encode($stream_source);
        $intro->db->update('streams', $data, 'id=' . $stid);
        $data2 = [];
        $data2['season_num'] = $season_num;
        $data2['sort'] = $sort;
        $intro->db->update('series_episodes', $data2, 'id=' . $seid . ' ');
        $intro->redirect($this->appname, 'Episodes', '?id=' . $sid);
    }
    public function Delepisode()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $seid = intval($intro->input->get_post('seid'));
        $stid = intval($intro->input->get_post('stid'));
        $stitle = intval($intro->input->get_post('stitle'));
        $x = new XtreamApi('EmptyFunc');
        $x->DelVod($stid);
        $sql = $intro->db->query('DELETE FROM streams WHERE id in (select stream_id from series_episodes where stream_id=' . $stid . ') ');
        $sql = $intro->db->query('DELETE FROM series_episodes WHERE id=' . $seid . '; ');
        $sql = $intro->db->query('DELETE FROM `streams_sys` WHERE stream_id NOT IN (select id from streams); ');
        echo 'success';
    }
    public function MassAdd()
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $stream_source;
        global $stream_720p;
        global $stream_480p;
        global $stream_360p;
        global $stream_1080p;
        global $stream_4k;
        global $category_id;
        global $youtube_trailer;
        global $stream_display_name;
        global $movie_subtitles;
        global $youtube_trailer;
        global $genre;
        global $plot;
        global $cast;
        global $rating;
        global $director;
        global $releasedate;
        global $duration_secs;
        global $duration;
        global $bitrate;
        global $movie_image;
        global $backdrop_path;
        global $tmdb_id;
        global $order;
        global $stream_icon;
        global $year;
        global $mpaa;
        global $target_container;
        global $direct_source;
        global $redirect_stream;
        global $movie_location;
        global $movie_symlink;
        global $season_num;
        global $load_balancer_servers;
        global $read_native;
        global $transcode_profile_id;
        global $bouqet_id;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $this->nav();
        $sid = intval($intro->input->get_post('sid'));
        echo "\r\n\t\t<script>var base = '" . $intro->app_url('movies', 'brws') . "/'; var type='multi';</script>\r\n\t\t<link rel=\"stylesheet\" href=\"" . admin_path . "style/tree/proton/proton.min.css\">\r\n\t\t<script src=\"" . admin_path . "style/tree/jstree.min.js\"></script>\r\n\t\t<script src=\"" . admin_path . 'style/js/vod.js?v=1"></script>';
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-magic"></i> Mass add Episodes ', 'info');
        echo _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911();
        $star = '<span style="color:red">*</span>';
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . "/doMassAdd\" enctype=\"multipart/form-data\">\r\n\t\tNote: Currently support adding Episodes from local server. Don't use Remote in other server now.<br/>\r\n\t\tto select multiple files use Shift Key for range select or Keep pressing Ctrl Key and click on files. \r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t<tr>\r\n\t\t\t<td style='width:30%;'>Episodes Location:</td>\r\n\t\t\t<td>\r\n\t\t\t\t" . _obf_0D12262623113F1D022A011A3E1D1B253D294027090E01('movie_location', $movie_location) . (' ' . $this->error('movie_location') . " \r\n\t\t\t\t<span id=\"local\">\r\n\t\t\t\t\t<button type=\"button\" class=\"btn btn-danger\" id=\"PickFile\">Pick Files</button>\r\n\t\t\t\t</span>\r\n\t\t\t</td>\r\n\t\t</tr>");
        echo "\r\n\t\t<tr>\r\n\t\t\t<td>Note:</td>\r\n\t\t\t<td>Episodes Must be like: <span class='red'>Lost.S02E13.720p.mkv</span> or <span class='red'>Lost.S02.E13.720p.mkv</span> | it should contain <span class='red'>S02E13</span> the <span class='red'>S</span> is capital and <span class='red'>E</span> is capital.</td>\r\n\t\t</tr>\r\n\t\t<tr id=\"movie_source_form\">\r\n\t\t\t<td>Episodes Source : " . $star . " <span id='total_selected_from_tree'></span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"stream_source\" id=\"stream_source\" value=\"" . $stream_source . '" class=\'form-control\'>' . $this->error('stream_source') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Season number: " . $star . "</td>\r\n\t\t\t<td><input  class='form-control'  type=\"text\" name=\"season_num\" value=\"" . $season_num . '" style="width:30%"> ' . $this->error('season_num') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class=\"movie_symlink\" style=\"display: none;\">\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'movie_symlink') . " Do not encode the VOD, use the source: </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('movie_symlink', $movie_symlink, 'yes') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class=\"direct_source\" style=\"display: none;\">\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'direct_source') . " Use Direct Source & don't restream it: </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('direct_source', $direct_source, 'yes') . "</td>\r\n\t\t</tr>\r\n\t\t<tr class=\"redirect_stream\" style=\"display: none;\">\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'redirect_stream') . " Redirect Stream to the Original Source:  </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('redirect_stream', $redirect_stream, 'yes') . "</td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr id=\"load_balancer\">\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'load_balancer_servers') . ('Select Load Balancer Servers : ' . $star . "</td>\r\n\t\t\t<td><div>") . _obf_0D31033702041D1F0B1015180339183714070C36032811('load_balancer_servers[]', $load_balancer_servers) . ($this->error('load_balancer_servers') . "</div></td>\r\n\t\t</tr>\r\n\t\t<tr class=\"read_native\" style=\"display: none;\">\r\n\t\t\t<td>") . tooltip('tooltip_streams', 'read_native') . " Read Input Source in Native Frames:  </td>\r\n\t\t\t<td>" . _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22('read_native', $read_native, 'yes') . "</td>\r\n\t\t</tr>";
        echo "\r\n\t\t<tr class='transcode'>\r\n\t\t\t<th colspan=\"2\">Transcode Movie</th>\r\n\t\t</tr>\r\n\t\t<tr class='transcode'>\r\n\t\t\t<td>" . tooltip('tooltip_streams', 'transcode_profile_id') . " Select Transcode Profile: </td>\r\n\t\t\t<td>" . _obf_0D311A13371B215B013B112303362D1032353D2E344022('transcode_profile_id', 'No Transcode', 'transcoding_profiles', $transcode_profile_id, 'profile_id', 'profile_name', '', ' order by profile_name ASC') . "\r\n\t\t\t\t<a href=\"" . $intro->app_url('transcode_profiles', 'index') . "\" target=\"_blank\" class=\"btn btn-default\">Manage</a>\r\n\t\t\t</td>\r\n\t\t</tr>";
        echo "\t\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td><input type=\"hidden\" name=\"sid\"  value=\"" . $sid . "\">\r\n\t\t\t\t<button class=\"btn btn-success\" type=\"submit\">\r\n\t\t\t\t\t<i class=\"icon-plus-squared\"></i> Mass add Episodes\r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</form>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        if( $movie_location == 'remote' ) 
        {
            $js = "\$('#local').hide();\r\n            \$('#fetch_options').hide();\r\n            \$('.direct_source').show();\r\n            \$('.movie_symlink').hide();\r\n\t\t\t\$('#load_balancer_servers').prop('required', false);";
        }
        else if( is_numeric($movie_location) ) 
        {
            $js = "\$('#local').show();\r\n            \$('#fetch_options').hide();\r\n            \$('.direct_source').hide();\r\n\r\n            \$('#read_native').show();\r\n            \$('#load_balancer').show();\r\n            \$('.movie_symlink').show();\r\n            \$('#movie_container').show();\r\n            \$('#subtitles').show();\r\n  \r\n            \$('input:radio[name=direct_source][value=0]').click();\r\n            \$('#load_balancer_servers').prop('required', true);\r\n\r\n\t\t\t\$('#firstChosenSelect').chosen();\r\n\t\t\t\$('#load_balancer_servers').addClass('chosen').chosen({search_contains: true});";
        }
        else
        {
            $js = '';
        }
        echo "<script>\r\n\t\tfunction cleanString(input) {\r\n\t\t\tvar output = '';\r\n\t\t\tfor (var i=0; i<input.length; i++) {\r\n\t\t\t\tif (input.charCodeAt(i) <= 127) {\r\n\t\t\t\t\toutput += input.charAt(i);\r\n\t\t\t\t}\r\n\t\t\t}\r\n\t\t\treturn output;\r\n\t\t}\r\n\t\t\$(function(){\r\n\t\t\t\r\n\t\t\t\$('select[name=category_id]').addClass('chosen').chosen({search_contains: true,width:335});\r\n\t\t\t" . $js . "\r\n\t\t });\r\n\t\t</script>";
    }
    public function doMassAdd()
    {
        global $intro;
        global $error;
        $sid = intval($intro->input->post('sid'));
        $movie_location = intval($intro->input->post('movie_location'));
        $season_num = intval($intro->input->post('season_num'));
        $redirect_stream = intval($intro->input->post('redirect_stream'));
        $direct_source = intval($intro->input->post('direct_source'));
        $movie_symlink = intval($intro->input->post('movie_symlink'));
        $read_native = intval($intro->input->post('read_native'));
        $transcode_profile_id = trim($intro->input->post('transcode_profile_id'));
        $stream_source = trim($intro->input->post('stream_source'));
        $load_balancer_servers = $intro->input->post('load_balancer_servers');
        $added = time();
        if( $sid == 0 || $movie_location == 0 || $season_num == 0 || $stream_source == '' || !isset($load_balancer_servers[0]) ) 
        {
            if( $movie_location == 0 ) 
            {
                $error['movie_location'] = '<span class=error>Please choose files from LB server. Don\'t use remote.</span>';
            }
            if( $season_num == 0 ) 
            {
                $error['season_num'] = '<span class=error>Please input season Number.</span>';
            }
            if( $sid == 0 ) 
            {
                $error['stream_source'] = '<span class=error>Error: Unknown Series ID!!!.</span>';
            }
            if( $stream_source == '' ) 
            {
                $error['stream_source'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( !isset($load_balancer_servers[0]) ) 
            {
                $error['load_balancer_servers'] = '<span class=error>Please choose LB server</span>';
            }
            $this->MassAdd();
            exit();
        }
        $date = date('Y-m-d H:i:s');
        $VodNames = [];
        $ex = explode(',', $stream_source);
        foreach( $ex as $file ) 
        {
            $fileName = pathinfo($file, PATHINFO_FILENAME);
            $file_ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            $regex = '\'^(.+)\.Se?([0-9]+).?Ep?([0-9]+).*$\'i';
            if( preg_match($regex, $fileName, $n) ) 
            {
                $movie_name = preg_replace('\'\.\'', ' ', $n[1]);
                $season = intval($n[2], 10);
                $episode = intval($n[3], 10);
                $VodNames[] = [
                    'type' => 5, 
                    'added' => $added, 
                    'stream_display_name' => $movie_name . ('.S' . $n[2] . '.E' . $n[3]), 
                    'stream_source' => json_encode(['s:' . $movie_location . ':' . $file], JSON_UNESCAPED_SLASHES), 
                    'target_container' => json_encode([$file_ext]), 
                    'movie_symlink' => $movie_symlink, 
                    'read_native' => $read_native, 
                    'season' => $season, 
                    'episode' => $episode
                ];
            }
        }
        $data = [];
        $i = 0;
        foreach( $VodNames as $key => $data ) 
        {
            $i++;
            $season = intval($data['season']);
            $episode = intval($data['episode']);
            unset($data['season']);
            unset($data['episode']);
            $data['added'] = $added;
            $intro->db->insert('streams', $data);
            $stream_id = $intro->db->insert_id();
            _obf_0D15132B233C152840360D0A271F3C223C23242C103101('add', $stream_id, $load_balancer_servers[0], $direct_source);
            $dataEp = [];
            $dataEp['series_id'] = $sid;
            $dataEp['season_num'] = ($season == 0 ? $season_num : $season);
            $dataEp['sort'] = $episode;
            $dataEp['stream_id'] = $stream_id;
            $intro->db->insert('series_episodes', $dataEp);
            $task = [];
            $task['task_for'] = 'series';
            $task['task_name'] = 'Add New Episode';
            $task['task_table'] = 'streams';
            $task['task_keyid'] = $stream_id;
            $task['task_date'] = $date;
            $task['cmd_start'] = 1;
            $task['cmd_fetch'] = 0;
            $task['task_status'] = -1;
            $task['task_reply'] = '';
            $intro->db->insert('' . PREFIX . '_tasks', $task);
        }
        if( $i == 0 ) 
        {
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Nothing has been added!!!', 'warning');
        }
        else
        {
            _obf_0D103C08311F24242D2F281F0B3E28333032320A031011('Success : Total added Episodes (' . $i . ')', 'success');
            $intro->db->query('UPDATE `series` set last_modified=\'' . time() . ('\' WHERE id=' . $sid . '; '));
        }
        $intro->redirect($this->appname, 'episodes', '/?id=' . $sid . '&addStatus=' . $i);
    }
    public function StartTask()
    {
        global $intro;
        $intro->db->query('DELETE from `solus_tasks` where task_for=\'series\' AND cmd_start_status=1 /*AND cmd_fetch_status=1*/;');
        $this->nav();
        $page = intval($intro->input->get_post('page'));
        $rows_per_page = 10;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $query = 'SELECT * FROM `solus_tasks` task  LEFT JOIN `streams` st ON task.task_keyid=st.id  LEFT JOIN `streams_sys` sys ON task.task_keyid=sys.stream_id  WHERE task_for=\'series\'';
        $result = $intro->db->query($query . ' limit ' . $nexlimit . ',' . $rows_per_page);
        $intro->db->query(' ' . $query . ' ');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D0713255B04072D042B135C2E233E1902393B0C1B2911();
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> Mass Add Movies Task (' . $totalrows . ')', 'info');
        echo "\r\n\t\t<h4>Note: Please don't refresh page , Page will auto refresh.</h4>\r\n\t\t<table class=\" table table-bordered table-hover table-striped\"   >\r\n        <thead>\r\n\t    <tr >\r\n\t\t\t<th>#</th>\r\n\t\t\t<th>ID</th>\r\n\t\t\t<th>Task Name</th>\r\n\t\t\t<th>Task Date</th>\r\n\t\t\t\r\n\t\t\t<th>Title</th>\r\n\t\t\t<th>Commands</th>\r\n\t\t\t<th>TMDB Reuslt</th>\r\n\t\t\t<th>Encode</th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = $server_id = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"center\">" . $i . "</td>\r\n\t\t\t\t<td class=\"center\">" . $task_id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $task_name . "</td>\r\n\t\t\t\t<td class=\"center\">" . $task_date . "</td>\r\n\t\t\t\t<td class=\"center\">" . $stream_display_name . "</td>\r\n\t\t\t\t<td class=\"center\">" . (($cmd_start == 1 ? 'Encode' : '')) . ' ' . (($cmd_fetch == 1 ? '| Fetch TMDB' : '')) . "</td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\">";
            if( $cmd_start == 1 && $cmd_start_status == 0 ) 
            {
                echo $this->TaskStratEncode('start', $task_keyid, $server_id, $task_id, 'cmd_start_status');
            }
            echo "</td>\r\n\t\t\t\t<td class=\"center\"> \t\t\t\t\t\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $intro->app_url('movies', 'DelTask') . ('?id=' . $task_id . "\" OnClick=\"return false;\" title=\"Delete Task\"><i class=\"icon-trash\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>");
        }
        echo "</tbody>\r\n\t\t</table>";
        $maxPage = ceil($totalrows / $rows_per_page);
        $pageNum = $page;
        if( $pageNum > 1 ) 
        {
            $page = $pageNum - 1;
        }
        $done = 0;
        if( $pageNum < $maxPage ) 
        {
            $page = $pageNum + 1;
            $url = '?&page=' . $page;
            $next = ' <a href="' . $url . "\"> Run Next </a>\r\n\t\t\t<meta http-equiv=Refresh content=30;url=\"" . $url . '">';
        }
        else
        {
            $next = ' <h2 style="color:#004000"  class="blinking"> All tasks Completed. <h2>';
            $done = 1;
        }
        echo '<center>Completed: <strong>' . $pageNum . '</strong> From <strong>' . $maxPage . '</strong>  ' . $next . ' </center>';
        if( $done == 0 ) 
        {
            echo "<div class='row'>\r\n\t\t\t<div class='col-md3 text-center'>\r\n\t\t\t\t<progress value=\"0\" max=\"30\" id=\"progressBar\"></progress>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<script>\r\n\t\tvar timeleft = 30;\r\n\t\tvar downloadTimer = setInterval(function(){\r\n\t\t  document.getElementById(\"progressBar\").value = 30 - timeleft;\r\n\t\t  timeleft -= 1;\r\n\t\t  if(timeleft <= 0){\r\n\t\t\tclearInterval(downloadTimer);\r\n\t\t  }\r\n\t\t}, 1000);\r\n\t\t</script>";
        }
    }
    public function TaskStratEncode($vodStratStopEncode, $stream_id, $server_id, $task_id, $field)
    {
        global $intro;
        global $error;
        $XC = new XtreamApi('EmptyFunc');
        $reply = $XC->StartVod($vodStratStopEncode, $stream_id, $server_id);
        if( $reply == 'success' ) 
        {
            $intro->db->query('update solus_tasks set ' . $field . '=1 WHERE task_id=' . $task_id . ';');
            return 'success';
        }
        else
        {
            return 'faild: (' . $reply . ')';
        }
    }
    public function ClearTask()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $sql = $intro->db->query('DELETE FROM `solus_tasks` WHERE task_for=\'series\'; ');
        $intro->redirect($this->appname, 'index');
    }
    public function copy_img()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $result = $intro->db->query('SELECT *  from series where cover NOT LIKE \'%img.paliptv.com%\' order by id desc;');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> Copy Series images to Remote Server', 'info');
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $extension = end(explode('.', $cover));
            $title2 = str_replace([
                ' ', 
                ',', 
                '"', 
                '\'', 
                '`', 
                '~'
            ], '_', $title);
            $fileName = 'series_' . $id . '_' . $title2 . '_.' . $extension;
            $curl = new IntroCurl($intro->option['VodRemoteServerAPI']);
            $rep = $curl->post('', [
                'fileName' => $fileName, 
                'fileData' => $cover
            ]);
            echo '<li>((' . $rep . ')) ' . $id . ' ' . $title . ' (' . $title2 . ') (' . $extension . ') ' . $cover . '</li>';
            $newcover = 'http://img.paliptv.com/images/' . $fileName;
            $intro->db->query('UPDATE `series` set cover=\'' . $newcover . '\' WHERE id=' . $id . ' ');
        }
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        $result = $intro->db->query('SELECT *  from streams where type=2  AND stream_icon NOT LIKE \'%img.paliptv.com%\' order by id desc;');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> Movies ', 'info');
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            if( $stream_icon != '' ) 
            {
                $cover = $stream_icon;
                $title = $stream_display_name;
                $extension = end(explode('.', $cover));
                $title2 = str_replace([
                    ' ', 
                    ',', 
                    '"', 
                    '\'', 
                    '`', 
                    '~'
                ], '_', $title);
                $fileName = 'vod_' . $id . '_' . $title2 . '_.' . $extension;
                $curl = new IntroCurl($intro->option['VodRemoteServerAPI']);
                $rep = $curl->post('', [
                    'fileName' => $fileName, 
                    'fileData' => $cover
                ]);
                echo '<li>((' . $rep . ')) ' . $id . ' ' . $title . ' (' . $title2 . ') (' . $extension . ') ' . $cover . '</li>';
                $newcover = 'http://img.paliptv.com/images/' . $fileName;
                $intro->db->query('UPDATE `streams` set stream_icon=\'' . $newcover . '\' WHERE id=' . $id . ' ');
                continue;
            }
            $x = 'http://img.paliptv.com/images/vod.jpg';
            $x = $intro->option['VodRemoteDefaultCover'];
            $intro->db->query('UPDATE `streams` set stream_icon=\'' . $x . '\' WHERE id=' . $id . ' ');
        }
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
}
