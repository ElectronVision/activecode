<?php 
define('_GET_URL', 'get.php');
