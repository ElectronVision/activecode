<?php 
class FormsSelect
{
    private $html_name = '';
    private $html_id = '';
    private $html_title = '';
    private $table = '';
    private $where = '';
    private $order = '';
    private $css_class = '';
    private $the_id = '';
    private $the_name = '';
    private $compair = '';
    private $arrib = '';
    public function __construct()
    {
    }
    public function db_table()
    {
        global $intro;
        if( $this->html_id == '' ) 
        {
            $this->html_id = $this->html_name;
        }
        $html = "\n\n<select name=\"" . $this->html_name . '" id="' . $this->html_id . '" class="' . $this->css_class . '" ' . $this->arrib . ">\n\n";
        $sql = $intro->db->query('select ' . $this->the_id . ',' . $this->the_name . ' from ' . $this->table . ' ' . $this->where . ' ' . $this->order);
        $html .= ('<option value="0"> ' . $this->html_title . " </option>\n");
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            $html .= ('<option value="' . $row[$this->the_id] . '" ' . (($row[$this->the_id] == $this->compair ? 'selected' : '')) . ('>' . $row[$this->the_name] . "</option>\n"));
        }
        $html .= "</select>\n\n";
        return $html;
    }
    public function set($str, $val)
    {
        $this->$str = $val;
    }
}
