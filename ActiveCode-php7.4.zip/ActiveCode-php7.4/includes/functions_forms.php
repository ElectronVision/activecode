<?php 
namespace 
{
    function _obf_0D192231031F101D183B5B3E051D5C1F5B011111280E01($html_name, $cat_value, $txt = '')
    {
        global $intro;
        $dyn_menu = "\n\t<select name=\"" . $html_name . '" id="' . $html_name . "\" class='searchable' style='min-width:300px'>\n";
        $dyn_menu .= ("\n\t\t<option value=\"0\" selected> " . ($txt = ('' ? $intro->lang['choose'] : $txt)) . " </option>\n");
        $result = $intro->db->query('SELECT * from stream_categories order by category_type ASC,category_name ASC');
        $type = '';
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            if( $type != $row['category_type'] ) 
            {
                $dyn_menu .= (' <optgroup label="' . ucfirst($row['category_type']) . '">');
            }
            $type = $row['category_type'];
            $dyn_menu .= ('<option ' . (($cat_value == $row['id'] ? 'selected ' : '')) . (' value="' . $row['id'] . '">' . $row['category_name'] . '</option>'));
        }
        $dyn_menu .= "\n\t</select>\n\n ";
        return (string)$dyn_menu;
    }
    function _obf_0D0C0E0C0D2F36060B143B3B213D100D2D210C5B100501($html_name, $cat_value, $sql_table, $where = '', $sub = '')
    {
        global $intro;
        $dyn_menu = "\n\t<select name=\"" . $html_name . "\" class='form-control searchable'>\n";
        $dyn_menu .= ("\n\t\t<option value=\"0\" selected> " . $intro->lang['choose'] . " </option>\n");
        $result = $intro->db->query('SELECT * from ' . PREFIX . '_' . $sql_table . (' where father=0 ' . $where . ' order by catid ASC'));
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            $catname = ($sql_table == 'products_cat' ? $row['catname_' . $lang] : $row['catname']);
            $dyn_menu .= ("\n\t\t<option " . (($cat_value == $row['catid'] ? 'selected ' : '')) . (' value="' . $row['catid'] . '" style=\'background-color: #CEDEFB\'>') . $catname . '</option>');
            if( $sub == 'show_sub' ) 
            {
                $dyn_menu .= form_select_sub($row['catid'], $cat_value, $sql_table);
            }
        }
        $dyn_menu .= "\n\t</select>\n\n ";
        return (string)$dyn_menu;
    }
    function form_select_sub($father, $cat_value, $sql_table, $bar = '')
    {
        global $intro;
        $father = intval($father);
        $dyn_menu = '';
        $result = $intro->db->query('SELECT * from ' . PREFIX . '_' . $sql_table . (' where father=' . $father . ' order by catid ASC'));
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            $dyn_menu .= ("\n\t\t<option " . (($cat_value == $row['catid'] ? 'selected ' : '')) . (' value="' . $row['catid'] . '" style=\'background-color: #CEDEFB\'>' . $bar . '--------|' . $row['catname'] . '</option>'));
            $dyn_menu .= form_select_sub($row['catid'], $cat_value, $sql_table, '--------');
        }
        return ' ' . $dyn_menu;
    }
    function _obf_0D312C22263726180408322D1B0C363E320C351C1B0B32($comp = 0, $where = '')
    {
        global $intro;
        global $error;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_admin ' . $where . ' order by admin_name asc;'));
        $html = "<select name='adminid' id='adminid' class='searchable' style='min-width:200px'>\n\t<option value=\"\"> Choose </option>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $html .= ('<option value="' . $adminid . '" ' . (($adminid == $comp ? 'selected="selected"' : '')) . ('>' . $admin_name . ' </option>'));
        }
        $html .= '</select>';
        return $html;
    }
    function form_resellers($html_name, $adminid, $txt = 'Reseller', $where = '', $view_bal = '')
    {
        global $intro;
        $html = '<select name="' . $html_name . "\" class='searchable chosen' >\n\n       <option value='0' selected>" . $txt . "</option>\n";
        $sql_q = $intro->db->query('select * from ' . PREFIX . ('_admin ' . $where . ' order by admin_name ASC'));
        while( $row = $intro->db->fetch_assoc($sql_q) ) 
        {
            $db_adminid = $row['adminid'];
            $db_modname = $row['admin_name'];
            $html .= ('<option ' . (($db_adminid == $adminid ? 'selected' : '')) . (' value="' . $db_adminid . '">' . $db_modname . ' ') . (($view_bal == 'view_bal' ? ' (' . $row['balance'] . ')' : '')) . "</option>\n");
            $sql2 = $intro->db->query('select * from ' . PREFIX . ('_admin where father=' . $db_adminid . ' order by admin_name ASC'));
            if( $intro->db->returned_rows > 0 ) 
            {
                while( $row2 = $intro->db->fetch_assoc($sql2) ) 
                {
                    $db2_adminid = $row2['adminid'];
                    $db2_modname = $row2['admin_name'];
                    $html .= ('<option ' . (($db2_adminid == $adminid ? 'selected' : '')) . (' value="' . $db2_adminid . '">' . $db_modname . ' -> ' . $db2_modname . ' ') . (($view_bal == 'view_bal' ? ' (' . $row2['balance'] . ')' : '')) . "</option>\n");
                    $html .= "<option " . ($db2_adminid == $adminid ? "selected" : "") . " value=\"" . $db2_adminid . "\">" . $db_modname . " -> " . $db2_modname . " -> " . $view_bal . " </option>\n";
                }
            }
        }
        $html .= "</select>\n\n\n";
        return $html;
    }
    function _obf_0D0D2C30250935222A3740360F14123C1703060E1B1011($father, $adminid, $db_modname, $father_name, $view_bal)
    {
        global $intro;
        global $array;
        $html = '';
        $sql2 = $intro->db->query('select * from ' . PREFIX . ('_admin where father=' . $father . ' order by admin_name ASC'));
        if( $intro->db->returned_rows > 0 ) 
        {
            while( $row2 = $intro->db->fetch_assoc($sql2) ) 
            {
                $db2_adminid = $row2['adminid'];
                $db2_modname = $row2['admin_name'];
                $html .= ('<option ' . (($db2_adminid == $adminid ? 'selected' : '')) . (' value="' . $db2_adminid . '">' . $father_name . ' ' . $db_modname . ' -> ' . $db2_modname . ' ') . (($view_bal == 'view_bal' ? ' (' . $row2['balance'] . ')' : '')) . "</option>\n");
            }
        }
        return $html;
    }
    function _obf_0D3F250A173507191B5B0B3704142C252A3607262A3101($sel_name, $array, $comp, $txt = 'Choose')
    {
        global $intro;
        global $array;
        $html = '<select dir=ltr name="' . $sel_name . "\" multiple size=10>\n";
        $html .= ('<option ' . $def_sel . ' value="all">' . $txt . "</option>\n");
        $result = $intro->db->query('SELECT dvb_id,dvb_name,dvb_adminid from ' . PREFIX . '_dvb order by dvb_adminid,dvb_name', '', true);
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            if( is_array($comp) && in_array($row[dvb_id], $comp) ) 
            {
                $sel = 'selected';
            }
            $admin = $array['admins'][$row[dvb_adminid]];
            $html .= ('<option ' . $sel . ' value="' . $row['dvb_id'] . '">' . $admin . ' -> ' . $row['dvb_name'] . "</option>\n");
            $sel = '';
        }
        $html .= "</select>\n\n";
        return $html;
    }
    function _obf_0D311A13371B215B013B112303362D1032353D2E344022($html_name, $html_title, $table, $compair, $the_id, $the_name, $where = '', $order = '', $class = '', $attrib = '')
    {
        global $db;
        global $prefix;
        global $intro;
        $sel = '';
        $html = "\n\n<select name=\"" . $html_name . '" id="' . $html_name . '" class=\'searchable ' . $class . '\' ' . $attrib . ">\n\n";
        $sql = $intro->db->query('select ' . $the_id . ',' . $the_name . ' from ' . $table . ' ' . $where . ' ' . $order);
        $html .= ('<option value="0"> ' . $html_title . " </option>\n");
        while( $row = $intro->db->fetch_assoc($sql) ) 
        {
            if( $row[$the_id] == $compair ) 
            {
                $sel = 'selected ';
            }
            $html .= ('<option ' . $sel . ' value="' . $row[$the_id] . '">' . $row[$the_name] . "</option>\n");
            $sel = '';
        }
        $html .= "</select>\n\n";
        return $html;
    }
    function extra_free_days($extra_free_days, $free_days)
    {
        if( $extra_free_days == '' ) 
        {
            return null;
        }
        $ex = explode(',', $extra_free_days);
        if( !is_array($ex) ) 
        {
            return null;
        }
        if( count($ex) < 1 ) 
        {
            return null;
        }
        $array = [];
        foreach( $ex as $day ) 
        {
            $array[$day] = $day . ' Days';
        }
        return '<span id="span_free_days" style="display:none">Free Extra Days: ' . _obf_0D1029270D2B062E351F39253F1B39061037400E130401('free_days', $array, $free_days, 'N/A', 0) . " </span>\n\t<script>\n\t\$(document).ready(function() {\n\t\t\$('#free_days').chosen('destroy');\n\t});\n\t</script>";
    }
    function _obf_0D042827394002382E07271E152934171C2F1B331B0C11($sel_name, $array, $comp, $txt = '', $first_value = 0)
    {
        global $intro;
        $sel = '';
        $html = "\n<select multiple=\"multiple\"  name=\"" . $sel_name . '" id="' . str_replace('[]', '', $sel_name) . "\" class='form-control searchable chosen '>\n";
        if( is_array($array) ) 
        {
            $i = -1;
            foreach( $array as $key => $val ) 
            {
                $i++;
                $html .= ("\t<option " . ((is_array($comp) && in_array($key, $comp) ? 'selected' : '')) . (' value="' . $key . '">' . $val . "   </option>\n"));
            }
        }
        else
        {
            return '<span class=\'label label-danger\'>BadArray</span>';
        }
        $html .= "</select>\n\n";
        return $html;
    }
    function _obf_0D182C25111E19341D351701193E051435032F27102311($sel_name, $array, $comp, $txt = '', $first_value = 0)
    {
        global $intro;
        $sel = '';
        $html = "\n<select multiple=\"multiple\"  name=\"" . $sel_name . '" id="' . str_replace('[]', '', $sel_name) . "\" class='form-control searchable chosen '>\n";
        if( is_array($array) ) 
        {
            $i = -1;
            foreach( $array as $varname ) 
            {
                $i++;
                $html .= ("\t<option " . ((is_array($comp) && in_array($varname, $comp) ? 'selected' : '')) . (' value="' . $varname . '">' . $varname . "   </option>\n"));
            }
        }
        else
        {
            return '<span class=\'label label-danger\'>BadArray</span>';
        }
        $html .= "</select>\n\n";
        return $html;
    }
    function _obf_0D1029270D2B062E351F39253F1B39061037400E130401($sel_name, $array, $comp, $txt = '', $first_value = 0)
    {
        global $intro;
        $sel = '';
        $html = "\n<select name=\"" . $sel_name . '" id="' . $sel_name . "\" class='searchable'>\n";
        $html .= ("\t<option value=\"" . $first_value . '" selected>' . (($txt == '' ? $intro->lang['choose'] : $txt)) . "</option>\n");
        if( is_array($array) ) 
        {
            foreach( $array as $key => $val ) 
            {
                $html .= ("\t<option " . (($comp == $key ? 'selected' : '')) . (' value="' . $key . '">' . $val . "</option>\n"));
            }
        }
        else
        {
            return '<span class=\'label label-danger\'>BadArray</span>';
        }
        $html .= "</select>\n\n";
        return $html;
    }
    function _obf_0D25032D2B210E1538102515291B2D08111A1816070622($sel_name, $array, $comp, $txt = '')
    {
        global $intro;
        $html = '<select name="' . $sel_name . '" id="' . $sel_name . "\" class='searchable'> \n";
        $html .= ('<option selected value="">' . (($txt == '' ? $intro->lang['choose'] : $txt)) . "</option>\n");
        foreach( $array as $key => $val ) 
        {
            $html .= ('<option ' . (($comp == $key && $comp != '' ? 'selected ' : '')) . (' value="' . $key . '">' . $val . "</option>\n"));
            $sel = '';
        }
        $html .= "</select>\n\n";
        return $html;
    }
    function _obf_0D282D3708280221011E043117082204131B1A2B400622($fld_name, $array, $comp)
    {
        $html = $sel = '';
        if( !is_array($array) ) 
        {
            return 'Empty array';
        }
        foreach( $array as $key => $val ) 
        {
            if( $comp == $key ) 
            {
                $sel = 'checked';
            }
            $html .= ('<input type="radio" name="' . $fld_name . '" value="' . $key . '" ' . $sel . '> ' . $val . " \n");
            $sel = '';
        }
        return $html;
    }
    function _obf_0D0E0C021E271714230F1135191C022F35343836305C01($fld_name, $comp, $val, $txtOn, $txtOff, $onStyle = '', $offStyle = '')
    {
        $html = $sel = '';
        $html .= ('<input type="checkbox" id="' . $fld_name . '" name="' . $fld_name . '" value="' . $val . '" ');
        $html .= (' data-toggle="toggle" data-on="' . $txtOn . '" data-off="' . $txtOff . '" ');
        $html .= (' data-onstyle="' . $onStyle . '" ');
        if( $offStyle != '' ) 
        {
            $html .= (' data-offstyle="' . $onStyle . '" ');
        }
        $html .= (' ' . (($comp == $val ? 'checked' : '')) . ' ');
        $html .= ' />';
        return $html;
    }
    function _obf_0D363B0530401A36170C40253C1B2D5C2B1D340A0D3D22($name, $value, $type = 'yes')
    {
        $sel1 = $sel2 = '';
        if( $value == 0 || $value == '' ) 
        {
            $sel1 = '';
            $sel2 = 'checked';
        }
        if( $value == 1 ) 
        {
            $sel1 = 'checked';
            $sel2 = '';
        }
        if( $type == 'yes' ) 
        {
            return '<input type="radio" name="' . $name . '" value="1" ' . $sel1 . "> Yes\n           <input type=\"radio\" name=\"" . $name . '" value="0" ' . $sel2 . '> No  ';
        }
        else if( $type == 'active' ) 
        {
            return '<input type="radio" name="' . $name . '" value="1" ' . $sel1 . "> Enabled\n           <input type=\"radio\" name=\"" . $name . '" value="0" ' . $sel2 . '> Disabled ';
        }
    }
    function _obf_0D40243B224001310E2A340B330829030F123413042811($name, $value)
    {
        global $intro;
        if( $value == 0 || $value == '' ) 
        {
            $sel1 = '';
            $sel2 = 'checked';
        }
        if( $value == 1 ) 
        {
            $sel1 = 'checked';
            $sel2 = '';
        }
        return '<input type="radio" name="' . $name . '" value="1" ' . $sel1 . "> Enabled\n           <input type=\"radio\" name=\"" . $name . '" value="0" ' . $sel2 . '> Disabled ';
    }
    function _obf_0D192107040A1D2A031C033725325B09190E3D34050511($html_name, $json_array)
    {
        global $intro;
        $html = '<input type="text" placeholder="Search.." id="strmSearch" onkeyup="IntroFilterInput(\'strmSearch\',\'allStreams\');" style="width: 400px;">';
        $html .= "\n\t\t<div id=\"allStreams\" style=\"width: 400px; height: 300px; overflow-y: auto;border:1px solid #777777;padding:5px; \">";
        foreach( $intro->country as $cc => $name ) 
        {
            $html .= ('<li> <input type="checkbox" name="' . $html_name . ('" value="' . $cc . '" ') . ((is_array($json_array) && in_array($cc, $json_array) ? 'checked=\'checked\'' : '')) . ('> ' . $name . ' </li>'));
        }
        $html .= "\n\t\t</div>\n\n\t\t<div class='row'>\n\t\t\t<div class='col-md-12'>\n\t\t\t\t<button type=\"button\" id=\"strmCheckALL\">Select all</button>\n\t\t\t\t<button type=\"button\" id=\"strmUnCheckALL\">Deselect all</button>\n\t\t\t</div>\n\t\t</div>";
        $html .= "\n\t\t<script>\n\t\t\$(document).ready(function() {\n\t\t\t\n\t\t\t\$('#strmCheckALL').on('click', function(){\n\t\t\t\t\t\n\t\t\t\t\$(\"#allStreams input:checkbox\").each(function() {\n\t\t\t\t\tif (\$(this).parent(\"li:visible\").length == 1) {\n \n\t\t\t\t\t\tthis.checked=true;\n\t\t\t\t\t}\n\t\t\t\t});\n\t\t\t});\n\t\t\t\n\t\t\t\$('#strmUnCheckALL').on('click', function(){\n\t\t\t\t\t\n\t\t\t\t\$(\"#allStreams input:checkbox\").each(function() {\n\t\t\t\t\tthis.checked=false;\n\t\t\t\t});\n\t\t\t});\n\n\t\t\t\n\t\t});\n\t\t</script>";
        return $html;
    }
    function _obf_0D121115021E2F112D152B220538232718040E3D0E3301($html_name, $selected = '')
    {
        $OptionsArray = [
            'Africa/Abidjan' => 'Africa/Abidjan [GMT  00:00]', 
            'Africa/Accra' => 'Africa/Accra [GMT  00:00]', 
            'Africa/Addis_Ababa' => 'Africa/Addis_Ababa [EAT +03:00]', 
            'Africa/Algiers' => 'Africa/Algiers [CET +01:00]', 
            'Africa/Asmara' => 'Africa/Asmara [EAT +03:00]', 
            'Africa/Bamako' => 'Africa/Bamako [GMT  00:00]', 
            'Africa/Bangui' => 'Africa/Bangui [WAT +01:00]', 
            'Africa/Banjul' => 'Africa/Banjul [GMT  00:00]', 
            'Africa/Bissau' => 'Africa/Bissau [GMT  00:00]', 
            'Africa/Blantyre' => 'Africa/Blantyre [CAT +02:00]', 
            'Africa/Brazzaville' => 'Africa/Brazzaville [WAT +01:00]', 
            'Africa/Bujumbura' => 'Africa/Bujumbura [CAT +02:00]', 
            'Africa/Cairo' => 'Africa/Cairo [EET +02:00]', 
            'Africa/Casablanca' => 'Africa/Casablanca [WEST +01:00]', 
            'Africa/Ceuta' => 'Africa/Ceuta [CEST +02:00]', 
            'Africa/Conakry' => 'Africa/Conakry [GMT  00:00]', 
            'Africa/Dakar' => 'Africa/Dakar [GMT  00:00]', 
            'Africa/Dar_es_Salaam' => 'Africa/Dar_es_Salaam [EAT +03:00]', 
            'Africa/Djibouti' => 'Africa/Djibouti [EAT +03:00]', 
            'Africa/Douala' => 'Africa/Douala [WAT +01:00]', 
            'Africa/El_Aaiun' => 'Africa/El_Aaiun [WEST +01:00]', 
            'Africa/Freetown' => 'Africa/Freetown [GMT  00:00]', 
            'Africa/Gaborone' => 'Africa/Gaborone [CAT +02:00]', 
            'Africa/Harare' => 'Africa/Harare [CAT +02:00]', 
            'Africa/Johannesburg' => 'Africa/Johannesburg [SAST +02:00]', 
            'Africa/Juba' => 'Africa/Juba [EAT +03:00]', 
            'Africa/Kampala' => 'Africa/Kampala [EAT +03:00]', 
            'Africa/Khartoum' => 'Africa/Khartoum [EAT +03:00]', 
            'Africa/Kigali' => 'Africa/Kigali [CAT +02:00]', 
            'Africa/Kinshasa' => 'Africa/Kinshasa [WAT +01:00]', 
            'Africa/Lagos' => 'Africa/Lagos [WAT +01:00]', 
            'Africa/Libreville' => 'Africa/Libreville [WAT +01:00]', 
            'Africa/Lome' => 'Africa/Lome [GMT  00:00]', 
            'Africa/Luanda' => 'Africa/Luanda [WAT +01:00]', 
            'Africa/Lubumbashi' => 'Africa/Lubumbashi [CAT +02:00]', 
            'Africa/Lusaka' => 'Africa/Lusaka [CAT +02:00]', 
            'Africa/Malabo' => 'Africa/Malabo [WAT +01:00]', 
            'Africa/Maputo' => 'Africa/Maputo [CAT +02:00]', 
            'Africa/Maseru' => 'Africa/Maseru [SAST +02:00]', 
            'Africa/Mbabane' => 'Africa/Mbabane [SAST +02:00]', 
            'Africa/Mogadishu' => 'Africa/Mogadishu [EAT +03:00]', 
            'Africa/Monrovia' => 'Africa/Monrovia [GMT  00:00]', 
            'Africa/Nairobi' => 'Africa/Nairobi [EAT +03:00]', 
            'Africa/Ndjamena' => 'Africa/Ndjamena [WAT +01:00]', 
            'Africa/Niamey' => 'Africa/Niamey [WAT +01:00]', 
            'Africa/Nouakchott' => 'Africa/Nouakchott [GMT  00:00]', 
            'Africa/Ouagadougou' => 'Africa/Ouagadougou [GMT  00:00]', 
            'Africa/Porto-Novo' => 'Africa/Porto-Novo [WAT +01:00]', 
            'Africa/Sao_Tome' => 'Africa/Sao_Tome [GMT  00:00]', 
            'Africa/Tripoli' => 'Africa/Tripoli [EET +02:00]', 
            'Africa/Tunis' => 'Africa/Tunis [CET +01:00]', 
            'Africa/Windhoek' => 'Africa/Windhoek [WAST +02:00]', 
            'America/Adak' => 'America/Adak [HADT -09:00]', 
            'America/Anchorage' => 'America/Anchorage [AKDT -08:00]', 
            'America/Anguilla' => 'America/Anguilla [AST -04:00]', 
            'America/Antigua' => 'America/Antigua [AST -04:00]', 
            'America/Araguaina' => 'America/Araguaina [BRT -03:00]', 
            'America/Argentina/Buenos_Aires' => 'America/Argentina/Buenos_Aires [ART -03:00]', 
            'America/Argentina/Catamarca' => 'America/Argentina/Catamarca [ART -03:00]', 
            'America/Argentina/Cordoba' => 'America/Argentina/Cordoba [ART -03:00]', 
            'America/Argentina/Jujuy' => 'America/Argentina/Jujuy [ART -03:00]', 
            'America/Argentina/La_Rioja' => 'America/Argentina/La_Rioja [ART -03:00]', 
            'America/Argentina/Mendoza' => 'America/Argentina/Mendoza [ART -03:00]', 
            'America/Argentina/Rio_Gallegos' => 'America/Argentina/Rio_Gallegos [ART -03:00]', 
            'America/Argentina/Salta' => 'America/Argentina/Salta [ART -03:00]', 
            'America/Argentina/San_Juan' => 'America/Argentina/San_Juan [ART -03:00]', 
            'America/Argentina/San_Luis' => 'America/Argentina/San_Luis [ART -03:00]', 
            'America/Argentina/Tucuman' => 'America/Argentina/Tucuman [ART -03:00]', 
            'America/Argentina/Ushuaia' => 'America/Argentina/Ushuaia [ART -03:00]', 
            'America/Aruba' => 'America/Aruba [AST -04:00]', 
            'America/Asuncion' => 'America/Asuncion [PYT -04:00]', 
            'America/Atikokan' => 'America/Atikokan [EST -05:00]', 
            'America/Bahia' => 'America/Bahia [BRT -03:00]', 
            'America/Bahia_Banderas' => 'America/Bahia_Banderas [CDT -05:00]', 
            'America/Barbados' => 'America/Barbados [AST -04:00]', 
            'America/Belem' => 'America/Belem [BRT -03:00]', 
            'America/Belize' => 'America/Belize [CST -06:00]', 
            'America/Blanc-Sablon' => 'America/Blanc-Sablon [AST -04:00]', 
            'America/Boa_Vista' => 'America/Boa_Vista [AMT -04:00]', 
            'America/Bogota' => 'America/Bogota [COT -05:00]', 
            'America/Boise' => 'America/Boise [MDT -06:00]', 
            'America/Cambridge_Bay' => 'America/Cambridge_Bay [MDT -06:00]', 
            'America/Campo_Grande' => 'America/Campo_Grande [AMT -04:00]', 
            'America/Cancun' => 'America/Cancun [CDT -05:00]', 
            'America/Caracas' => 'America/Caracas [VET -04:30]', 
            'America/Cayenne' => 'America/Cayenne [GFT -03:00]', 
            'America/Cayman' => 'America/Cayman [EST -05:00]', 
            'America/Chicago' => 'America/Chicago [CDT -05:00]', 
            'America/Chihuahua' => 'America/Chihuahua [MDT -06:00]', 
            'America/Costa_Rica' => 'America/Costa_Rica [CST -06:00]', 
            'America/Creston' => 'America/Creston [MST -07:00]', 
            'America/Cuiaba' => 'America/Cuiaba [AMT -04:00]', 
            'America/Curacao' => 'America/Curacao [AST -04:00]', 
            'America/Danmarkshavn' => 'America/Danmarkshavn [GMT  00:00]', 
            'America/Dawson' => 'America/Dawson [PDT -07:00]', 
            'America/Dawson_Creek' => 'America/Dawson_Creek [MST -07:00]', 
            'America/Denver' => 'America/Denver [MDT -06:00]', 
            'America/Detroit' => 'America/Detroit [EDT -04:00]', 
            'America/Dominica' => 'America/Dominica [AST -04:00]', 
            'America/Edmonton' => 'America/Edmonton [MDT -06:00]', 
            'America/Eirunepe' => 'America/Eirunepe [ACT -05:00]', 
            'America/El_Salvador' => 'America/El_Salvador [CST -06:00]', 
            'America/Fortaleza' => 'America/Fortaleza [BRT -03:00]', 
            'America/Glace_Bay' => 'America/Glace_Bay [ADT -03:00]', 
            'America/Godthab' => 'America/Godthab [WGST -02:00]', 
            'America/Goose_Bay' => 'America/Goose_Bay [ADT -03:00]', 
            'America/Grand_Turk' => 'America/Grand_Turk [AST -04:00]', 
            'America/Grenada' => 'America/Grenada [AST -04:00]', 
            'America/Guadeloupe' => 'America/Guadeloupe [AST -04:00]', 
            'America/Guatemala' => 'America/Guatemala [CST -06:00]', 
            'America/Guayaquil' => 'America/Guayaquil [ECT -05:00]', 
            'America/Guyana' => 'America/Guyana [GYT -04:00]', 
            'America/Halifax' => 'America/Halifax [ADT -03:00]', 
            'America/Havana' => 'America/Havana [CDT -04:00]', 
            'America/Hermosillo' => 'America/Hermosillo [MST -07:00]', 
            'America/Indiana/Indianapolis' => 'America/Indiana/Indianapolis [EDT -04:00]', 
            'America/Indiana/Knox' => 'America/Indiana/Knox [CDT -05:00]', 
            'America/Indiana/Marengo' => 'America/Indiana/Marengo [EDT -04:00]', 
            'America/Indiana/Petersburg' => 'America/Indiana/Petersburg [EDT -04:00]', 
            'America/Indiana/Tell_City' => 'America/Indiana/Tell_City [CDT -05:00]', 
            'America/Indiana/Vevay' => 'America/Indiana/Vevay [EDT -04:00]', 
            'America/Indiana/Vincennes' => 'America/Indiana/Vincennes [EDT -04:00]', 
            'America/Indiana/Winamac' => 'America/Indiana/Winamac [EDT -04:00]', 
            'America/Inuvik' => 'America/Inuvik [MDT -06:00]', 
            'America/Iqaluit' => 'America/Iqaluit [EDT -04:00]', 
            'America/Jamaica' => 'America/Jamaica [EST -05:00]', 
            'America/Juneau' => 'America/Juneau [AKDT -08:00]', 
            'America/Kentucky/Louisville' => 'America/Kentucky/Louisville [EDT -04:00]', 
            'America/Kentucky/Monticello' => 'America/Kentucky/Monticello [EDT -04:00]', 
            'America/Kralendijk' => 'America/Kralendijk [AST -04:00]', 
            'America/La_Paz' => 'America/La_Paz [BOT -04:00]', 
            'America/Lima' => 'America/Lima [PET -05:00]', 
            'America/Los_Angeles' => 'America/Los_Angeles [PDT -07:00]', 
            'America/Lower_Princes' => 'America/Lower_Princes [AST -04:00]', 
            'America/Maceio' => 'America/Maceio [BRT -03:00]', 
            'America/Managua' => 'America/Managua [CST -06:00]', 
            'America/Manaus' => 'America/Manaus [AMT -04:00]', 
            'America/Marigot' => 'America/Marigot [AST -04:00]', 
            'America/Martinique' => 'America/Martinique [AST -04:00]', 
            'America/Matamoros' => 'America/Matamoros [CDT -05:00]', 
            'America/Mazatlan' => 'America/Mazatlan [MDT -06:00]', 
            'America/Menominee' => 'America/Menominee [CDT -05:00]', 
            'America/Merida' => 'America/Merida [CDT -05:00]', 
            'America/Metlakatla' => 'America/Metlakatla [PST -08:00]', 
            'America/Mexico_City' => 'America/Mexico_City [CDT -05:00]', 
            'America/Miquelon' => 'America/Miquelon [PMDT -02:00]', 
            'America/Moncton' => 'America/Moncton [ADT -03:00]', 
            'America/Monterrey' => 'America/Monterrey [CDT -05:00]', 
            'America/Montevideo' => 'America/Montevideo [UYT -03:00]', 
            'America/Montserrat' => 'America/Montserrat [AST -04:00]', 
            'America/Nassau' => 'America/Nassau [EDT -04:00]', 
            'America/New_York' => 'America/New_York [EDT -04:00]', 
            'America/Nipigon' => 'America/Nipigon [EDT -04:00]', 
            'America/Nome' => 'America/Nome [AKDT -08:00]', 
            'America/Noronha' => 'America/Noronha [FNT -02:00]', 
            'America/North_Dakota/Beulah' => 'America/North_Dakota/Beulah [CDT -05:00]', 
            'America/North_Dakota/Center' => 'America/North_Dakota/Center [CDT -05:00]', 
            'America/North_Dakota/New_Salem' => 'America/North_Dakota/New_Salem [CDT -05:00]', 
            'America/Ojinaga' => 'America/Ojinaga [MDT -06:00]', 
            'America/Panama' => 'America/Panama [EST -05:00]', 
            'America/Pangnirtung' => 'America/Pangnirtung [EDT -04:00]', 
            'America/Paramaribo' => 'America/Paramaribo [SRT -03:00]', 
            'America/Phoenix' => 'America/Phoenix [MST -07:00]', 
            'America/Port-au-Prince' => 'America/Port-au-Prince [EDT -04:00]', 
            'America/Port_of_Spain' => 'America/Port_of_Spain [AST -04:00]', 
            'America/Porto_Velho' => 'America/Porto_Velho [AMT -04:00]', 
            'America/Puerto_Rico' => 'America/Puerto_Rico [AST -04:00]', 
            'America/Rainy_River' => 'America/Rainy_River [CDT -05:00]', 
            'America/Rankin_Inlet' => 'America/Rankin_Inlet [CDT -05:00]', 
            'America/Recife' => 'America/Recife [BRT -03:00]', 
            'America/Regina' => 'America/Regina [CST -06:00]', 
            'America/Resolute' => 'America/Resolute [CDT -05:00]', 
            'America/Rio_Branco' => 'America/Rio_Branco [ACT -05:00]', 
            'America/Santa_Isabel' => 'America/Santa_Isabel [PDT -07:00]', 
            'America/Santarem' => 'America/Santarem [BRT -03:00]', 
            'America/Santiago' => 'America/Santiago [CLST -03:00]', 
            'America/Santo_Domingo' => 'America/Santo_Domingo [AST -04:00]', 
            'America/Sao_Paulo' => 'America/Sao_Paulo [BRT -03:00]', 
            'America/Scoresbysund' => 'America/Scoresbysund [EGST  00:00]', 
            'America/Sitka' => 'America/Sitka [AKDT -08:00]', 
            'America/St_Barthelemy' => 'America/St_Barthelemy [AST -04:00]', 
            'America/St_Johns' => 'America/St_Johns [NDT -02:30]', 
            'America/St_Kitts' => 'America/St_Kitts [AST -04:00]', 
            'America/St_Lucia' => 'America/St_Lucia [AST -04:00]', 
            'America/St_Thomas' => 'America/St_Thomas [AST -04:00]', 
            'America/St_Vincent' => 'America/St_Vincent [AST -04:00]', 
            'America/Swift_Current' => 'America/Swift_Current [CST -06:00]', 
            'America/Tegucigalpa' => 'America/Tegucigalpa [CST -06:00]', 
            'America/Thule' => 'America/Thule [ADT -03:00]', 
            'America/Thunder_Bay' => 'America/Thunder_Bay [EDT -04:00]', 
            'America/Tijuana' => 'America/Tijuana [PDT -07:00]', 
            'America/Toronto' => 'America/Toronto [EDT -04:00]', 
            'America/Tortola' => 'America/Tortola [AST -04:00]', 
            'America/Vancouver' => 'America/Vancouver [PDT -07:00]', 
            'America/Whitehorse' => 'America/Whitehorse [PDT -07:00]', 
            'America/Winnipeg' => 'America/Winnipeg [CDT -05:00]', 
            'America/Yakutat' => 'America/Yakutat [AKDT -08:00]', 
            'America/Yellowknife' => 'America/Yellowknife [MDT -06:00]', 
            'Antarctica/Casey' => 'Antarctica/Casey [AWST +08:00]', 
            'Antarctica/Davis' => 'Antarctica/Davis [DAVT +07:00]', 
            'Antarctica/DumontDUrville' => 'Antarctica/DumontDUrville [DDUT +10:00]', 
            'Antarctica/Macquarie' => 'Antarctica/Macquarie [MIST +11:00]', 
            'Antarctica/Mawson' => 'Antarctica/Mawson [MAWT +05:00]', 
            'Antarctica/McMurdo' => 'Antarctica/McMurdo [NZDT +13:00]', 
            'Antarctica/Palmer' => 'Antarctica/Palmer [CLST -03:00]', 
            'Antarctica/Rothera' => 'Antarctica/Rothera [ROTT -03:00]', 
            'Antarctica/Syowa' => 'Antarctica/Syowa [SYOT +03:00]', 
            'Antarctica/Troll' => 'Antarctica/Troll [CEST +02:00]', 
            'Antarctica/Vostok' => 'Antarctica/Vostok [VOST +06:00]', 
            'Arctic/Longyearbyen' => 'Arctic/Longyearbyen [CEST +02:00]', 
            'Asia/Aden' => 'Asia/Aden [AST +03:00]', 
            'Asia/Almaty' => 'Asia/Almaty [ALMT +06:00]', 
            'Asia/Amman' => 'Asia/Amman [EEST +03:00]', 
            'Asia/Anadyr' => 'Asia/Anadyr [ANAT +12:00]', 
            'Asia/Aqtau' => 'Asia/Aqtau [AQTT +05:00]', 
            'Asia/Aqtobe' => 'Asia/Aqtobe [AQTT +05:00]', 
            'Asia/Ashgabat' => 'Asia/Ashgabat [TMT +05:00]', 
            'Asia/Baghdad' => 'Asia/Baghdad [AST +03:00]', 
            'Asia/Bahrain' => 'Asia/Bahrain [AST +03:00]', 
            'Asia/Baku' => 'Asia/Baku [AZST +05:00]', 
            'Asia/Bangkok' => 'Asia/Bangkok [ICT +07:00]', 
            'Asia/Beirut' => 'Asia/Beirut [EEST +03:00]', 
            'Asia/Bishkek' => 'Asia/Bishkek [KGT +06:00]', 
            'Asia/Brunei' => 'Asia/Brunei [BNT +08:00]', 
            'Asia/Chita' => 'Asia/Chita [IRKT +08:00]', 
            'Asia/Choibalsan' => 'Asia/Choibalsan [CHOT +08:00]', 
            'Asia/Colombo' => 'Asia/Colombo [IST +05:30]', 
            'Asia/Damascus' => 'Asia/Damascus [EEST +03:00]', 
            'Asia/Dhaka' => 'Asia/Dhaka [BDT +06:00]', 
            'Asia/Dili' => 'Asia/Dili [TLT +09:00]', 
            'Asia/Dubai' => 'Asia/Dubai [GST +04:00]', 
            'Asia/Dushanbe' => 'Asia/Dushanbe [TJT +05:00]', 
            'Asia/Gaza' => 'Asia/Gaza [EET +02:00]', 
            'Asia/Hebron' => 'Asia/Hebron [EET +02:00]', 
            'Asia/Ho_Chi_Minh' => 'Asia/Ho_Chi_Minh [ICT +07:00]', 
            'Asia/Hong_Kong' => 'Asia/Hong_Kong [HKT +08:00]', 
            'Asia/Hovd' => 'Asia/Hovd [HOVT +07:00]', 
            'Asia/Irkutsk' => 'Asia/Irkutsk [IRKT +08:00]', 
            'Asia/Jakarta' => 'Asia/Jakarta [WIB +07:00]', 
            'Asia/Jayapura' => 'Asia/Jayapura [WIT +09:00]', 
            'Asia/Jerusalem' => 'Asia/Jerusalem [IDT +03:00]', 
            'Asia/Kabul' => 'Asia/Kabul [AFT +04:30]', 
            'Asia/Kamchatka' => 'Asia/Kamchatka [PETT +12:00]', 
            'Asia/Karachi' => 'Asia/Karachi [PKT +05:00]', 
            'Asia/Kathmandu' => 'Asia/Kathmandu [NPT +05:45]', 
            'Asia/Khandyga' => 'Asia/Khandyga [YAKT +09:00]', 
            'Asia/Kolkata' => 'Asia/Kolkata [IST +05:30]', 
            'Asia/Krasnoyarsk' => 'Asia/Krasnoyarsk [KRAT +07:00]', 
            'Asia/Kuala_Lumpur' => 'Asia/Kuala_Lumpur [MYT +08:00]', 
            'Asia/Kuching' => 'Asia/Kuching [MYT +08:00]', 
            'Asia/Kuwait' => 'Asia/Kuwait [AST +03:00]', 
            'Asia/Macau' => 'Asia/Macau [CST +08:00]', 
            'Asia/Magadan' => 'Asia/Magadan [MAGT +10:00]', 
            'Asia/Makassar' => 'Asia/Makassar [WITA +08:00]', 
            'Asia/Manila' => 'Asia/Manila [PHT +08:00]', 
            'Asia/Muscat' => 'Asia/Muscat [GST +04:00]', 
            'Asia/Nicosia' => 'Asia/Nicosia [EEST +03:00]', 
            'Asia/Novokuznetsk' => 'Asia/Novokuznetsk [KRAT +07:00]', 
            'Asia/Novosibirsk' => 'Asia/Novosibirsk [NOVT +06:00]', 
            'Asia/Omsk' => 'Asia/Omsk [OMST +06:00]', 
            'Asia/Oral' => 'Asia/Oral [ORAT +05:00]', 
            'Asia/Phnom_Penh' => 'Asia/Phnom_Penh [ICT +07:00]', 
            'Asia/Pontianak' => 'Asia/Pontianak [WIB +07:00]', 
            'Asia/Pyongyang' => 'Asia/Pyongyang [KST +09:00]', 
            'Asia/Qatar' => 'Asia/Qatar [AST +03:00]', 
            'Asia/Qyzylorda' => 'Asia/Qyzylorda [QYZT +06:00]', 
            'Asia/Rangoon' => 'Asia/Rangoon [MMT +06:30]', 
            'Asia/Riyadh' => 'Asia/Riyadh [AST +03:00]', 
            'Asia/Sakhalin' => 'Asia/Sakhalin [SAKT +10:00]', 
            'Asia/Samarkand' => 'Asia/Samarkand [UZT +05:00]', 
            'Asia/Seoul' => 'Asia/Seoul [KST +09:00]', 
            'Asia/Shanghai' => 'Asia/Shanghai [CST +08:00]', 
            'Asia/Singapore' => 'Asia/Singapore [SGT +08:00]', 
            'Asia/Srednekolymsk' => 'Asia/Srednekolymsk [SRET +11:00]', 
            'Asia/Taipei' => 'Asia/Taipei [CST +08:00]', 
            'Asia/Tashkent' => 'Asia/Tashkent [UZT +05:00]', 
            'Asia/Tbilisi' => 'Asia/Tbilisi [GET +04:00]', 
            'Asia/Tehran' => 'Asia/Tehran [IRST +03:30]', 
            'Asia/Thimphu' => 'Asia/Thimphu [BTT +06:00]', 
            'Asia/Tokyo' => 'Asia/Tokyo [JST +09:00]', 
            'Asia/Ulaanbaatar' => 'Asia/Ulaanbaatar [ULAT +08:00]', 
            'Asia/Urumqi' => 'Asia/Urumqi [XJT +06:00]', 
            'Asia/Ust-Nera' => 'Asia/Ust-Nera [VLAT +10:00]', 
            'Asia/Vientiane' => 'Asia/Vientiane [ICT +07:00]', 
            'Asia/Vladivostok' => 'Asia/Vladivostok [VLAT +10:00]', 
            'Asia/Yakutsk' => 'Asia/Yakutsk [YAKT +09:00]', 
            'Asia/Yekaterinburg' => 'Asia/Yekaterinburg [YEKT +05:00]', 
            'Asia/Yerevan' => 'Asia/Yerevan [AMT +04:00]', 
            'Atlantic/Azores' => 'Atlantic/Azores [AZOST  00:00]', 
            'Atlantic/Bermuda' => 'Atlantic/Bermuda [ADT -03:00]', 
            'Atlantic/Canary' => 'Atlantic/Canary [WEST +01:00]', 
            'Atlantic/Cape_Verde' => 'Atlantic/Cape_Verde [CVT -01:00]', 
            'Atlantic/Faroe' => 'Atlantic/Faroe [WEST +01:00]', 
            'Atlantic/Madeira' => 'Atlantic/Madeira [WEST +01:00]', 
            'Atlantic/Reykjavik' => 'Atlantic/Reykjavik [GMT  00:00]', 
            'Atlantic/South_Georgia' => 'Atlantic/South_Georgia [GST -02:00]', 
            'Atlantic/St_Helena' => 'Atlantic/St_Helena [GMT  00:00]', 
            'Atlantic/Stanley' => 'Atlantic/Stanley [FKST -03:00]', 
            'Australia/Adelaide' => 'Australia/Adelaide [ACDT +10:30]', 
            'Australia/Brisbane' => 'Australia/Brisbane [AEST +10:00]', 
            'Australia/Broken_Hill' => 'Australia/Broken_Hill [ACDT +10:30]', 
            'Australia/Currie' => 'Australia/Currie [AEDT +11:00]', 
            'Australia/Darwin' => 'Australia/Darwin [ACST +09:30]', 
            'Australia/Eucla' => 'Australia/Eucla [ACWST +08:45]', 
            'Australia/Hobart' => 'Australia/Hobart [AEDT +11:00]', 
            'Australia/Lindeman' => 'Australia/Lindeman [AEST +10:00]', 
            'Australia/Lord_Howe' => 'Australia/Lord_Howe [LHDT +11:00]', 
            'Australia/Melbourne' => 'Australia/Melbourne [AEDT +11:00]', 
            'Australia/Perth' => 'Australia/Perth [AWST +08:00]', 
            'Australia/Sydney' => 'Australia/Sydney [AEDT +11:00]', 
            'Europe/Amsterdam' => 'Europe/Amsterdam [CEST +02:00]', 
            'Europe/Andorra' => 'Europe/Andorra [CEST +02:00]', 
            'Europe/Athens' => 'Europe/Athens [EEST +03:00]', 
            'Europe/Belgrade' => 'Europe/Belgrade [CEST +02:00]', 
            'Europe/Berlin' => 'Europe/Berlin [CEST +02:00]', 
            'Europe/Bratislava' => 'Europe/Bratislava [CEST +02:00]', 
            'Europe/Brussels' => 'Europe/Brussels [CEST +02:00]', 
            'Europe/Bucharest' => 'Europe/Bucharest [EEST +03:00]', 
            'Europe/Budapest' => 'Europe/Budapest [CEST +02:00]', 
            'Europe/Busingen' => 'Europe/Busingen [CEST +02:00]', 
            'Europe/Chisinau' => 'Europe/Chisinau [EEST +03:00]', 
            'Europe/Copenhagen' => 'Europe/Copenhagen [CEST +02:00]', 
            'Europe/Dublin' => 'Europe/Dublin [IST +01:00]', 
            'Europe/Gibraltar' => 'Europe/Gibraltar [CEST +02:00]', 
            'Europe/Guernsey' => 'Europe/Guernsey [BST +01:00]', 
            'Europe/Helsinki' => 'Europe/Helsinki [EEST +03:00]', 
            'Europe/Isle_of_Man' => 'Europe/Isle_of_Man [BST +01:00]', 
            'Europe/Istanbul' => 'Europe/Istanbul [EEST +03:00]', 
            'Europe/Jersey' => 'Europe/Jersey [BST +01:00]', 
            'Europe/Kaliningrad' => 'Europe/Kaliningrad [EET +02:00]', 
            'Europe/Kiev' => 'Europe/Kiev [EEST +03:00]', 
            'Europe/Lisbon' => 'Europe/Lisbon [WEST +01:00]', 
            'Europe/Ljubljana' => 'Europe/Ljubljana [CEST +02:00]', 
            'Europe/London' => 'Europe/London [BST +01:00]', 
            'Europe/Luxembourg' => 'Europe/Luxembourg [CEST +02:00]', 
            'Europe/Madrid' => 'Europe/Madrid [CEST +02:00]', 
            'Europe/Malta' => 'Europe/Malta [CEST +02:00]', 
            'Europe/Mariehamn' => 'Europe/Mariehamn [EEST +03:00]', 
            'Europe/Minsk' => 'Europe/Minsk [MSK +03:00]', 
            'Europe/Monaco' => 'Europe/Monaco [CEST +02:00]', 
            'Europe/Moscow' => 'Europe/Moscow [MSK +03:00]', 
            'Europe/Oslo' => 'Europe/Oslo [CEST +02:00]', 
            'Europe/Paris' => 'Europe/Paris [CEST +02:00]', 
            'Europe/Podgorica' => 'Europe/Podgorica [CEST +02:00]', 
            'Europe/Prague' => 'Europe/Prague [CEST +02:00]', 
            'Europe/Riga' => 'Europe/Riga [EEST +03:00]', 
            'Europe/Rome' => 'Europe/Rome [CEST +02:00]', 
            'Europe/Samara' => 'Europe/Samara [SAMT +04:00]', 
            'Europe/San_Marino' => 'Europe/San_Marino [CEST +02:00]', 
            'Europe/Sarajevo' => 'Europe/Sarajevo [CEST +02:00]', 
            'Europe/Simferopol' => 'Europe/Simferopol [MSK +03:00]', 
            'Europe/Skopje' => 'Europe/Skopje [CEST +02:00]', 
            'Europe/Sofia' => 'Europe/Sofia [EEST +03:00]', 
            'Europe/Stockholm' => 'Europe/Stockholm [CEST +02:00]', 
            'Europe/Tallinn' => 'Europe/Tallinn [EEST +03:00]', 
            'Europe/Tirane' => 'Europe/Tirane [CEST +02:00]', 
            'Europe/Uzhgorod' => 'Europe/Uzhgorod [EEST +03:00]', 
            'Europe/Vaduz' => 'Europe/Vaduz [CEST +02:00]', 
            'Europe/Vatican' => 'Europe/Vatican [CEST +02:00]', 
            'Europe/Vienna' => 'Europe/Vienna [CEST +02:00]', 
            'Europe/Vilnius' => 'Europe/Vilnius [EEST +03:00]', 
            'Europe/Volgograd' => 'Europe/Volgograd [MSK +03:00]', 
            'Europe/Warsaw' => 'Europe/Warsaw [CEST +02:00]', 
            'Europe/Zagreb' => 'Europe/Zagreb [CEST +02:00]', 
            'Europe/Zaporozhye' => 'Europe/Zaporozhye [EEST +03:00]', 
            'Europe/Zurich' => 'Europe/Zurich [CEST +02:00]', 
            'Indian/Antananarivo' => 'Indian/Antananarivo [EAT +03:00]', 
            'Indian/Chagos' => 'Indian/Chagos [IOT +06:00]', 
            'Indian/Christmas' => 'Indian/Christmas [CXT +07:00]', 
            'Indian/Cocos' => 'Indian/Cocos [CCT +06:30]', 
            'Indian/Comoro' => 'Indian/Comoro [EAT +03:00]', 
            'Indian/Kerguelen' => 'Indian/Kerguelen [TFT +05:00]', 
            'Indian/Mahe' => 'Indian/Mahe [SCT +04:00]', 
            'Indian/Maldives' => 'Indian/Maldives [MVT +05:00]', 
            'Indian/Mauritius' => 'Indian/Mauritius [MUT +04:00]', 
            'Indian/Mayotte' => 'Indian/Mayotte [EAT +03:00]', 
            'Indian/Reunion' => 'Indian/Reunion [RET +04:00]', 
            'Pacific/Apia' => 'Pacific/Apia [WSDT +14:00]', 
            'Pacific/Auckland' => 'Pacific/Auckland [NZDT +13:00]', 
            'Pacific/Bougainville' => 'Pacific/Bougainville [BST +11:00]', 
            'Pacific/Chatham' => 'Pacific/Chatham [CHADT +13:45]', 
            'Pacific/Chuuk' => 'Pacific/Chuuk [CHUT +10:00]', 
            'Pacific/Easter' => 'Pacific/Easter [EASST -05:00]', 
            'Pacific/Efate' => 'Pacific/Efate [VUT +11:00]', 
            'Pacific/Enderbury' => 'Pacific/Enderbury [PHOT +13:00]', 
            'Pacific/Fakaofo' => 'Pacific/Fakaofo [TKT +13:00]', 
            'Pacific/Fiji' => 'Pacific/Fiji [FJT +12:00]', 
            'Pacific/Funafuti' => 'Pacific/Funafuti [TVT +12:00]', 
            'Pacific/Galapagos' => 'Pacific/Galapagos [GALT -06:00]', 
            'Pacific/Gambier' => 'Pacific/Gambier [GAMT -09:00]', 
            'Pacific/Guadalcanal' => 'Pacific/Guadalcanal [SBT +11:00]', 
            'Pacific/Guam' => 'Pacific/Guam [ChST +10:00]', 
            'Pacific/Honolulu' => 'Pacific/Honolulu [HST -10:00]', 
            'Pacific/Johnston' => 'Pacific/Johnston [HST -10:00]', 
            'Pacific/Kiritimati' => 'Pacific/Kiritimati [LINT +14:00]', 
            'Pacific/Kosrae' => 'Pacific/Kosrae [KOST +11:00]', 
            'Pacific/Kwajalein' => 'Pacific/Kwajalein [MHT +12:00]', 
            'Pacific/Majuro' => 'Pacific/Majuro [MHT +12:00]', 
            'Pacific/Marquesas' => 'Pacific/Marquesas [MART -09:30]', 
            'Pacific/Midway' => 'Pacific/Midway [SST -11:00]', 
            'Pacific/Nauru' => 'Pacific/Nauru [NRT +12:00]', 
            'Pacific/Niue' => 'Pacific/Niue [NUT -11:00]', 
            'Pacific/Norfolk' => 'Pacific/Norfolk [NFT +11:30]', 
            'Pacific/Noumea' => 'Pacific/Noumea [NCT +11:00]', 
            'Pacific/Pago_Pago' => 'Pacific/Pago_Pago [SST -11:00]', 
            'Pacific/Palau' => 'Pacific/Palau [PWT +09:00]', 
            'Pacific/Pitcairn' => 'Pacific/Pitcairn [PST -08:00]', 
            'Pacific/Pohnpei' => 'Pacific/Pohnpei [PONT +11:00]', 
            'Pacific/Port_Moresby' => 'Pacific/Port_Moresby [PGT +10:00]', 
            'Pacific/Rarotonga' => 'Pacific/Rarotonga [CKT -10:00]', 
            'Pacific/Saipan' => 'Pacific/Saipan [ChST +10:00]', 
            'Pacific/Tahiti' => 'Pacific/Tahiti [TAHT -10:00]', 
            'Pacific/Tarawa' => 'Pacific/Tarawa [GILT +12:00]', 
            'Pacific/Tongatapu' => 'Pacific/Tongatapu [TOT +13:00]', 
            'Pacific/Wake' => 'Pacific/Wake [WAKT +12:00]', 
            'Pacific/Wallis' => 'Pacific/Wallis [WFT +12:00]', 
            'UTC' => 'UTC [UTC  00:00]'
        ];
        $select = '<select name="' . $html_name . '" class="searchable chosen">';
        foreach( $OptionsArray as $key => $val ) 
        {
            $select .= ('<option value="' . $key . '"');
            $select .= ($key == $selected ? ' selected' : '');
            $select .= ('>' . $val . '</option>');
        }
        $select .= '</select>';
        return $select;
    }
    function _obf_0D303E153F1434130E373D01173C280D3E14021B012832($html_name, $selected = '')
    {
        $OptionsArray = [
            'en' => 'English', 
            'ar' => 'Arabic', 
            'aa' => 'Afar', 
            'af' => 'Afrikaans', 
            'ak' => 'Akan', 
            'an' => 'Aragonese', 
            'as' => 'Assamese', 
            'av' => 'Avaric', 
            'ae' => 'Avestan', 
            'ay' => 'Aymara', 
            'az' => 'Azerbaijani', 
            'ba' => 'Bashkir', 
            'bm' => 'Bambara', 
            'bi' => 'Bislama', 
            'bo' => 'Tibetan', 
            'br' => 'Breton', 
            'ca' => 'Catalan', 
            'cs' => 'Czech', 
            'ce' => 'Chechen', 
            'cu' => 'Slavic', 
            'cv' => 'Chuvash', 
            'kw' => 'Cornish', 
            'co' => 'Corsican', 
            'cr' => 'Cree', 
            'cy' => 'Welsh', 
            'da' => 'Danish', 
            'de' => 'German', 
            'dv' => 'Divehi', 
            'dz' => 'Dzongkha', 
            'eo' => 'Esperanto', 
            'et' => 'Estonian', 
            'eu' => 'Basque', 
            'fo' => 'Faroese', 
            'fj' => 'Fijian', 
            'fi' => 'Finnish', 
            'fr' => 'French', 
            'fy' => 'Frisian', 
            'ff' => 'Fulah', 
            'gd' => 'Gaelic', 
            'ga' => 'Irish', 
            'gl' => 'Galician', 
            'gv' => 'Manx', 
            'gn' => 'Guarani', 
            'gu' => 'Gujarati', 
            'ht' => 'Haitian', 
            'ha' => 'Hausa', 
            'sh' => 'Serbo-Croatian', 
            'hz' => 'Herero', 
            'ho' => 'Hiri Motu', 
            'hr' => 'Croatian', 
            'hu' => 'Hungarian', 
            'ig' => 'Igbo', 
            'io' => 'Ido', 
            'ii' => 'Yi', 
            'iu' => 'Inuktitut', 
            'ie' => 'Interlingue', 
            'ia' => 'Interlingua', 
            'id' => 'Indonesian', 
            'ik' => 'Inupiaq', 
            'is' => 'Icelandic', 
            'it' => 'Italian', 
            'ja' => 'Japanese', 
            'kl' => 'Kalaallisut', 
            'kn' => 'Kannada', 
            'ks' => 'Kashmiri', 
            'kr' => 'Kanuri', 
            'kk' => 'Kazakh', 
            'km' => 'Khmer', 
            'ki' => 'Kikuyu', 
            'rw' => 'Kinyarwanda', 
            'ky' => 'Kirghiz', 
            'kv' => 'Komi', 
            'kg' => 'Kongo', 
            'ko' => 'Korean', 
            'kj' => 'Kuanyama', 
            'ku' => 'Kurdish', 
            'lo' => 'Lao', 
            'la' => 'Latin', 
            'lv' => 'Latvian', 
            'li' => 'Limburgish', 
            'ln' => 'Lingala', 
            'lt' => 'Lithuanian', 
            'lb' => 'Letzeburgesch', 
            'lu' => 'Luba-Katanga', 
            'lg' => 'Ganda', 
            'mh' => 'Marshall', 
            'ml' => 'Malayalam', 
            'mr' => 'Marathi', 
            'mg' => 'Malagasy', 
            'mt' => 'Maltese', 
            'mo' => 'Moldavian', 
            'mn' => 'Mongolian', 
            'mi' => 'Maori', 
            'ms' => 'Malay', 
            'my' => 'Burmese', 
            'na' => 'Nauru', 
            'nv' => 'Navajo', 
            'nr' => 'Ndebele', 
            'nd' => 'Ndebele', 
            'ng' => 'Ndonga', 
            'ne' => 'Nepali', 
            'nl' => 'Dutch', 
            'nn' => 'Norwegian Nynorsk', 
            'nb' => 'Norwegian Bokmal', 
            'no' => 'Norwegian', 
            'ny' => 'Chichewa', 
            'oc' => 'Occitan', 
            'oj' => 'Ojibwa', 
            'or' => 'Oriya', 
            'om' => 'Oromo', 
            'os' => 'Ossetian; Ossetic', 
            'pi' => 'Pali', 
            'pl' => 'Polish', 
            'pt' => 'Portuguese', 
            'pt-BR' => 'Portuguese - Brazil', 
            'qu' => 'Quechua', 
            'rm' => 'Raeto-Romance', 
            'ro' => 'Romanian', 
            'rn' => 'Rundi', 
            'ru' => 'Russian', 
            'sg' => 'Sango', 
            'sa' => 'Sanskrit', 
            'si' => 'Sinhalese', 
            'sk' => 'Slovak', 
            'sl' => 'Slovenian', 
            'se' => 'Northern Sami', 
            'sm' => 'Samoan', 
            'sn' => 'Shona', 
            'sd' => 'Sindhi', 
            'so' => 'Somali', 
            'st' => 'Sotho', 
            'es' => 'Spanish', 
            'sq' => 'Albanian', 
            'sc' => 'Sardinian', 
            'sr' => 'Serbian', 
            'ss' => 'Swati', 
            'su' => 'Sundanese', 
            'sw' => 'Swahili', 
            'sv' => 'Swedish', 
            'ty' => 'Tahitian', 
            'ta' => 'Tamil', 
            'tt' => 'Tatar', 
            'te' => 'Telugu', 
            'tg' => 'Tajik', 
            'tl' => 'Tagalog', 
            'th' => 'Thai', 
            'ti' => 'Tigrinya', 
            'to' => 'Tonga', 
            'tn' => 'Tswana', 
            'ts' => 'Tsonga', 
            'tk' => 'Turkmen', 
            'tr' => 'Turkish', 
            'tw' => 'Twi', 
            'ug' => 'Uighur', 
            'uk' => 'Ukrainian', 
            'ur' => 'Urdu', 
            'uz' => 'Uzbek', 
            've' => 'Venda', 
            'vi' => 'Vietnamese', 
            'vo' => 'Volapük', 
            'wa' => 'Walloon', 
            'wo' => 'Wolof', 
            'xh' => 'Xhosa', 
            'yi' => 'Yiddish', 
            'za' => 'Zhuang', 
            'zu' => 'Zulu', 
            'ab' => 'Abkhazian', 
            'zh' => 'Mandarin', 
            'ps' => 'Pushto', 
            'am' => 'Amharic', 
            'bg' => 'Bulgarian', 
            'cn' => 'Cantonese', 
            'mk' => 'Macedonian', 
            'el' => 'Greek', 
            'fa' => 'Persian', 
            'he' => 'Hebrew', 
            'hi' => 'Hindi', 
            'hy' => 'Armenian', 
            'ee' => 'Ewe', 
            'ka' => 'Georgian', 
            'pa' => 'Punjabi', 
            'bn' => 'Bengali', 
            'bs' => 'Bosnian', 
            'ch' => 'Chamorro', 
            'be' => 'Belarusian', 
            'yo' => 'Yoruba'
        ];
        $select = '<select name="' . $html_name . '" class="searchable chosen">';
        foreach( $OptionsArray as $key => $val ) 
        {
            $select .= ('<option value="' . $key . '"');
            $select .= ($key == $selected ? ' selected' : '');
            $select .= ('>' . $val . '</option>');
        }
        $select .= '</select>';
        return $select;
    }

}
