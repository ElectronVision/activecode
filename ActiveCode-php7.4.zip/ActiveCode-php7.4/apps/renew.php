<?php 
class Renew_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $admin = [];
    public $adminRow = [];
    public $inputBy = [
        'Code', 
        'MAC', 
        'Serial'
    ];
    public $free = [
        101, 
        103, 
        107, 
        110
    ];
    public $time = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $array;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $adminid = intval($this->admin['adminid']);
        $this->adminRow = $intro->auth->admin_data($adminid);
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = '';
            $this->qry_admin_where = '';
        }
        else
        {
            $the_admin_qry = '(member_id=' . $adminid . ' OR member_id IN (SELECT adminid FROM solus_admin WHERE father=' . $adminid . ' OR main_father=' . $adminid . '))';
            $this->qry_admin = ' and ' . $the_admin_qry;
            $this->qry_admin_where = ' where ' . $the_admin_qry;
        }
        $this->time = time();
        $this->free = $array['free'];
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function RenewCode()
    {
        global $intro;
        global $array;
        $adminid = intval($this->admin['adminid']);
        if( $this->admin['level'] != 1 ) 
        {
            $this->qry_admin = ' and ( adminid=' . $adminid . ' OR adminid IN (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adminid . ' OR main_father=' . $adminid . '))');
            $this->qry_admin_where = ' where adminid=' . $adminid . ' OR adminid IN (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adminid . ' OR main_father=' . $adminid . ')');
        }
        if( $this->admin['level'] != 1 ) 
        {
            $intro->option['BlockAddFree'] = 1;
        }
        if( $this->admin['level'] == 9 ) 
        {
            $this->qry_admin = '';
        }
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if( !$row ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you cannot change this code:\r\n\t\t\t\t<li>The code may not found or is deleted.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit();
        }
        if( $status == 0 ) 
        {
            $label = 'default';
        }
        else if( $status == 1 ) 
        {
            $label = 'success';
        }
        else if( $status == 2 ) 
        {
            $label = 'info';
        }
        else if( $status == 3 ) 
        {
            $label = 'danger';
        }
        else if( $status == 4 ) 
        {
            $label = 'default';
        }
        else if( $status == 5 ) 
        {
            $label = 'warning';
        }
        else
        {
            $label = 'danger';
        }
        $date_expire = ($date_expire != '' ? date('Y-m-d', $date_expire) : '-');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Renew: ' . $code, 'success');
        echo "<table class=\"table table-striped table-bordered\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='info'>Fullname:</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='info'>Adminid:</td>\r\n\t\t\t\t<td>" . $array['admins'][$adminid] . ("</td>\r\n\t\t\t\t<td class='info'>TransID:</td>\r\n\t\t\t\t<td>" . $transid . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\r\n\t\t\t\t<td class='info'>Days:</td>\r\n\t\t\t\t<td>" . $days . "</td>\r\n\t\t\t\t<td class='info'>Date Expire</td>\r\n\t\t\t\t<td>" . $date_expire . "</td>\t\r\n\t\t\t\t<td class='info'>Status:</td>\r\n\t\t\t\t<td><span class='label label-" . $label . '\'>' . $intro->status[$status] . ' ') . (($code_replaced != '' ? '<br/>' . $code_replaced : '')) . ("</span></td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\t\t\r\n\t\t\t\t<td class='info'>MAC</td>\r\n\t\t\t\t<td>" . $mac . "</td>\r\n\t\t\t\t<td class='info'>Serial</td>\r\n\t\t\t\t<td>" . $serial . "</td>\r\n\t\t\t\t<td class='info'>Last Update</td>\r\n\t\t\t\t<td>" . $last_update . "</td>\r\n\t\t\t</tr>\r\n\t\t</table>");
        $new_end = $this->getEndDate($date_expire, $period);
        echo "\r\n\t\t<form name=\"renew\" id=\"frmRenew\" method=\"post\" action=\"" . $this->base . "/doRenewCode\">\r\n\t\t<table class=\"table table-striped table-bordered\">";
        if( $this->adminRow['member_group_id'] > 0 ) 
        {
            $pkg = new Packages($this->adminRow);
            $pkg->set('OfficialOnly', true);
            $pkg->OfficialOnly = true;
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Package: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td>";
            echo $pkg->FormDropDown();
            echo "\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        else
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"tr_bg2\" width=\"150\"> Period :</td>\r\n\t\t\t\t<td class=\"tr_bg1\">" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', _obf_0D322A5B141A102E2824032B03230A35140306272F2F11(), $period) . (' ' . $this->error('period') . "</td>\r\n\t\t\t</tr>");
        }
        echo "\r\n\t\t<tr>\r\n\t\t\t<td>Reseller: </td>\r\n\t\t\t<td><b>" . $array['admins'][$adminid] . ("</td>\r\n\t\t</tr>\r\n\t\t\r\n\t\t<tr>\r\n\t\t\t<td>New Start Date: </td>\r\n\t\t\t<td><font color=red><b>" . $this->cur_date . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Expire Date: </td>\r\n\t\t\t<td><font color=red><b><span id='calc_div'>" . $new_end . "</span> <span id=\"spin\" class='icon-spin5'></span> </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Cost: </td>\r\n\t\t\t<td><font color='red'><b><span id='cost_cost'>");
        $this->calcCost($adminid, $period);
        echo "</span> </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> </td>\r\n\t\t\t<td> <input type=\"submit\" value=\" Renew Now\" class=\"btn btn-success\" OnClick=\"return confirm('Are you sure?')\" /> </td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t<input type=\"hidden\" name=\"code\" value=\"" . $code . "\" />\r\n\t\t<input type=\"hidden\" name=\"codeID\" value=\"" . $id . "\" />\r\n\t\t\r\n\t\t</form>";
        echo '<div id=\'result\'>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$('documnet').ready(function(){\r\n\t\t\t\$(\"#frmRenew\").submit(function(event){\r\n\t\t\t\tevent.preventDefault();\r\n\r\n\t\t\t\t\$.ajax({\r\n\t\t\t\t\turl:'" . $this->base . "/doRenewCode/?NH=1',\r\n\t\t\t\t\ttype:'POST',\r\n\t\t\t\t\tdata:\$(this).serialize(),\r\n\t\t\t\t\tsuccess:function(result){\r\n\t\t\t\t\t\t\$('#result').html(result);\r\n\t\t\t\t\t}\r\n\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$(\"select[name=period],select[name=package]\").change(function(){\r\n\t\t\t\tvar val = \$(this).val();\r\n\t\t\t\t\r\n\t\t\t\tif(val == 0){\r\n\t\t\t\t\talert('Error: you can\\'t renew Free.');\r\n\t\t\t\t\treturn false;\r\n\t\t\t\t}\r\n\t\t\t\t\r\n\t\t\t\t\$('#spin').addClass('animate-spin');\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\$.get(\"" . $this->base . '/calc/?cur_date=' . $this->cur_date . "&NH=1&period=\"+val+\"\", function( data ) {\r\n\t\t\t\t\t\$(\"#calc_div\" ).html( data );\r\n\t\t\t\t\t\$('#spin').removeClass('animate-spin');\r\n\t\t\t\t});\r\n\t\t\t\t\r\n\t\t\t\t\$(\"#cost_cost\").load('" . $this->base . '/calcCost/?NH=1&resel=' . $adminid . "&period='+val);\r\n\t\t\t\t\r\n\t\t\t});\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function doRenewCode()
    {
        global $intro;
        global $error;
        global $array;
        $adminid = intval($this->admin['adminid']);
        if( $this->admin['level'] != 1 ) 
        {
            $this->qry_admin = ' and adminid=' . intval($this->admin['adminid']);
            $this->qry_admin_where = ' where adminid=' . intval($this->admin['adminid']);
        }
        if( $this->adminRow['level'] == 6 ) 
        {
            $this->qry_admin = ' and ( adminid=' . $adminid . ' OR adminid IN (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adminid . '))');
            $this->qry_admin_where = ' where adminid=' . $adminid . ' OR adminid IN (select adminid from ' . PREFIX . ('_admin WHERE father=' . $adminid . ')');
        }
        if( $this->admin['level'] == 9 ) 
        {
            $this->qry_admin = '';
        }
        $cost = 0;
        $id = intval($intro->input->post('codeID'));
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes where id=' . $id . ' ' . $this->qry_admin . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $adminid = intval($row['adminid']);
        $period = intval($intro->input->post('period'));
        $package = intval($intro->input->post('package'));
        $adm = $intro->auth->adminRow($adminid);
        if( empty($adm) || !is_array($adm) ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Reseller ID (' . $adminid . ') not found!!! ', 'danger');
            exit();
        }
        if( $adm['member_group_id'] > 0 && $package == 0 ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Please choose Package. ', 'danger');
            exit();
        }
        if( $code == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you can not Renew this code:\r\n\t\t\t\t<li>The code may not found or is deleted.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this code.", 'danger');
            exit();
        }
        if( $package > 0 ) 
        {
            $pkg = _obf_0D0E122A21280A14271F3B1D1727291E290A0A2A092E11($package, 'calc_expire', $date_expire);
            if( $pkg['new_expire_date'] < time() ) 
            {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Wrong date calculations.', 'danger');
                exit();
            }
        }
        $date_expire = ($date_expire != '' ? date('Y-m-d', $date_expire) : '-');
        $new_end = $this->getEndDate($date_expire, $period);
        $new_end = strtotime($new_end);
        $qry = '';
        $data = [];
        if( $package > 0 ) 
        {
            $data['exp_date'] = $new_end = $pkg['new_expire_date'];
            $data['is_trial'] = $pkg['is_trial'];
            $data['pkg'] = $package;
        }
        else
        {
            $data['exp_date'] = $new_end;
            $data['is_trial'] = 0;
        }
        $data['enabled'] = 1;
        $intro->db->update('users', $data, ' id=' . intval($userid));
        $af = $intro->db->affected_rows;
        if( $af == 0 ) 
        {
            $af = $this->InsertNewUser($id, $new_end);
        }
        if( $af > 0 ) 
        {
            $data = [];
            $data['period'] = $period;
            $data['date_expire'] = $new_end;
            $data['status'] = 1;
            $data['is_free'] = 0;
            if( $package > 0 ) 
            {
                $inv = new IntroInvoice();
                $inv->set('isPackage', true);
                $inv->set('adminid', $adminid);
                $inv->set('package', $package);
                $inv->set('period', $package);
                $inv->set('num', 1);
                $inv->set('code_trans', 0);
                $inv->set('all_data', '');
                $inv->set('userid', $userid);
                $inv->set('code_id', $id);
                $inv->set('notes', 'Renew Code: ' . $code . ' Days:' . $pkg['inv_notes']);
                $inv_id = $inv->Save();
                $data['period'] = $package;
                $data['pkg'] = $package;
            }
            else
            {
                $inv = new IntroInvoice();
                $inv->set('adminid', $adminid);
                $inv->set('period', $period);
                $inv->set('num', 1);
                $inv->set('userid', $userid);
                $inv->set('notes', 'Renew Code: ' . $code . ' Days:' . $array['period'][$period]);
                $inv->Save();
            }
            $intro->db->update(PREFIX . '_codes', $data, 'id=' . $id . ' ' . $qry);
            echo "<script>\r\n\t\t\t\r\n\t\t\t\t\$('#expire_" . $id . '\').html(\'<span class="label label-success label-lg">' . date('Y-m-d', $new_end) . ("</span>');\r\n\t\t\t\talert('Success! (" . $af . ")'); \r\n\t\t\t\t\t\r\n\t\t\t\t\$('#m3u-modal').modal('hide'); \r\n\t\t\t\t\r\n\t\t\t</script>");
        }
        else
        {
            exit( 'error: failed to renew code with xtream. code maybe deleted!!!' );
        }
    }
    public function InsertNewUser($id, $date_expire)
    {
        global $intro;
        if( intval($id) == 0 ) 
        {
            exit( 'error: no code id.' );
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_codes WHERE id=' . $id . ';'));
        $row = $intro->db->fetch_assoc($sql);
        if( $date_expire != '' ) 
        {
            $row['date_expire'] = $date_expire;
        }
        $data = [];
        $data['member_id'] = 1;
        $data['username'] = ($row['inputBy'] == 0 ? $row['code'] : $row['username']);
        $data['password'] = uniqid();
        $data['exp_date'] = $row['date_expire'];
        $data['admin_notes'] = $row['fullname'];
        $data['admin_enabled'] = 1;
        $data['enabled'] = 1;
        $data['bouquet'] = '[' . $row['bouquets'] . ']';
        $data['max_connections'] = 1;
        $data['created_at'] = time();
        $data['created_by'] = 1;
        $data['is_code'] = 1;
        $data['forced_country'] = $row['forced_country'] . '';
        $intro->db->insert('users', $data);
        $userID = $intro->db->insert_id();
        $intro->db->insert('user_output', [
            'user_id' => $userID, 
            'access_output_id' => 2
        ]);
        $intro->db->query('UPDATE ' . PREFIX . ('_codes set userid=' . $userID . ' WHERE id=' . $id . ';'));
        return $userID;
    }
    public function RenewMag()
    {
        global $intro;
        global $array;
        $username = '';
        if( $this->admin['level'] != 1 ) 
        {
            $intro->option['BlockAddFree'] = 1;
        }
        if( $this->admin['level'] == 9 ) 
        {
            $this->qry_admin = '';
        }
        $id = intval($intro->input->get_post('id'));
        $sql = $intro->db->query('SELECT * FROM mag_devices where mag_id=' . $id . ';');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $user_id = intval($row['user_id']);
        $sql = $intro->db->query('SELECT * FROM users where id=' . $user_id . ' ' . $this->qry_admin . ';');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if( $username == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: you can't change this MAG.\r\n\t\t\t\t<li>The MAG may not found.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this MAG.", 'danger');
            exit();
        }
        $fullname = $free_days = '';
        $period = 0;
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_users_data where userid=' . $user_id . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $mac = base64_decode($mac);
        $date_expire = ($exp_date != '' ? date('Y-m-d H:i', $exp_date) : '-');
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Renew MAG: ' . $mac, 'success');
        echo "<table class=\"table table-striped table-bordered\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='info'>Fullname:</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='info'>Reseller:</td>\r\n\t\t\t\t<td>";
        if( isset($array['admins'][$created_by]) ) 
        {
            echo $array['admins'][$created_by];
        }
        else
        {
            echo '<span class="label label-danger">this reseller id (' . $created_by . ') is not found.</span>';
        }
        if( isset($array['admins'][$member_id]) ) 
        {
            echo $array['admins'][$member_id];
        }
        else
        {
            echo '<span class="label label-danger">this reseller id (' . $member_id . ') is not found.</span>';
        }
        echo "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\r\n\t\t\t\t<td class='info'>Period:</td>\r\n\t\t\t\t<td>" . period($period, $free_days) . ("</td>\r\n\t\t\t\t<td class='info'>Date Expire:</td>\r\n\t\t\t\t<td>" . $date_expire . "</td>\t\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\t\t\r\n\t\t\t\t<td class='info'>MAC:</td>\r\n\t\t\t\t<td><strong>" . $mac . "</strong></td>\r\n\t\t\t\t<td class='info'> </td>\r\n\t\t\t\t<td></td>\r\n\t\t\t</tr>\r\n\t\t</table>");
        $new_end = $this->getEndDate($date_expire, $period);
        echo "\r\n\t\t<form name=\"renew\" id='frmRenew' method=\"post\" action=\"" . $this->base . "/doRenewMag\">\r\n\t\t<table class=\"table table-striped table-bordered\">\r\n\t\t";
        if( $this->adminRow['member_group_id'] > 0 ) 
        {
            $pkg = new Packages($this->adminRow);
            $pkg->OfficialOnly = true;
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Package: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td>";
            echo $pkg->FormDropDown();
            echo "\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        else
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"tr_bg2\" width=\"150\"> Period :</td>\r\n\t\t\t\t<td class=\"tr_bg1\">" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', _obf_0D322A5B141A102E2824032B03230A35140306272F2F11(), $period) . (' ' . $this->error('period') . "</td>\r\n\t\t\t</tr>");
        }
        echo "\t\t\r\n\t\t<tr>\r\n\t\t\t<td>New Start Date: </td>\r\n\t\t\t<td><font color=red><b>" . $this->cur_date . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Expire Date: </td>\r\n\t\t\t<td><font color=red><b><span id='calc_div'>" . $new_end . "</span> <span id=\"spin\" class='icon-spin5'></span> </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Cost: </td>\r\n\t\t\t<td><font color=red><b><span id='cost_cost'>";
        $this->calcCost($created_by, $period);
        echo "</span> </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> </td>\r\n\t\t\t<td> <input type=\"submit\" value=\" Renew Now\" class=\"btn btn-success\" OnClick=\"return confirm('Are you sure?')\" /> </td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t<input type=\"hidden\" name=\"mag_id\" value=\"" . $mag_id . "\" />\r\n\t\t<input type=\"hidden\" name=\"user_id\" value=\"" . $user_id . "\" />\r\n\t\t<input type=\"hidden\" name=\"mac\" value=\"" . $mac . "\" />\r\n\t\t\r\n\t\t</form>";
        echo '<div id=\'result\'>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$('documnet').ready(function(){\r\n\t\t\t\r\n\t\t\t\$(\"#frmRenew\").submit(function(event){\r\n\t\t\t\tevent.preventDefault();\r\n\r\n\t\t\t\t\$.ajax({\r\n\t\t\t\t\turl:'" . $this->base . "/doRenewMag/?NH=1',\r\n\t\t\t\t\ttype:'POST',\r\n\t\t\t\t\tdata:\$(this).serialize(),\r\n\t\t\t\t\tsuccess:function(result){\r\n\t\t\t\t\t\t\$('#result').html(result);\r\n\t\t\t\t\t}\r\n\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$(\"select[name=period],select[name=package]\").change(function(){\r\n\t\t\t\tvar val = \$(this).val();\r\n\t\t\t\t\r\n\t\t\t\tif(val == 0){\r\n\t\t\t\t\talert('Error: you can\\'t renew Free.');\r\n\t\t\t\t\treturn false;\r\n\t\t\t\t}\r\n\t\t\t\t\r\n\t\t\t\t\$('#spin').addClass('animate-spin');\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\$.get(\"" . $this->base . '/calc/?cur_date=' . $this->cur_date . "&NH=1&period=\"+val+\"\", function( data ) {\r\n\t\t\t\t\t\$(\"#calc_div\" ).html( data );\r\n\t\t\t\t\t\$('#spin').removeClass('animate-spin');\r\n\t\t\t\t});\r\n\t\t\t\t\r\n\t\t\t\t\$(\"#cost_cost\").load('" . $this->base . '/calcCost/?NH=1&resel=' . $created_by . "&period='+val);\r\n\t\t\t\t\r\n\t\t\t});\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function doRenewMag()
    {
        global $intro;
        global $error;
        global $array;
        if( $this->admin['level'] == 9 ) 
        {
            $this->qry_admin = '';
        }
        $cost = 0;
        $id = intval($intro->input->post('user_id'));
        $period = intval($intro->input->post('period'));
        $package = intval($intro->input->post('package'));
        $user_id = $id;
        $mac = trim($intro->input->post('mac'));
        $sql = $intro->db->query('SELECT * FROM users where id=' . $id . ' ' . $this->qry_admin . ';');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $exp_date = $row['exp_date'];
        $adminid = intval($row['created_by']);
        if( !isset($array['admins'][$adminid]) ) 
        {
            $adminid = intval($row['member_id']);
        }
        $adm = $intro->auth->adminRow($adminid);
        if( empty($adm) || !is_array($adm) ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Reseller ID (' . $adminid . ') not found!!! ', 'danger');
            exit();
        }
        if( $adm['member_group_id'] > 0 && $package == 0 ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Please choose Package. ', 'danger');
            exit();
        }
        $userid = intval($row['id']);
        if( $username == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: you can\'t Renew this MAG: <strong>' . $mac . "</strong>\r\n\t\t\t\t<li>The MAG may not found.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this MAG.", 'danger');
            exit();
        }
        $date_expire = ($exp_date != '' ? date('Y-m-d', $exp_date) : '-');
        $new_end = $this->getEndDate($date_expire, $period);
        if( $package > 0 ) 
        {
            $pkg = _obf_0D0E122A21280A14271F3B1D1727291E290A0A2A092E11($package, 'calc_expire', $exp_date);
            if( $pkg['new_expire_date'] < time() ) 
            {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Wrong date calculations.', 'danger');
                exit();
            }
            $new_end = $pkg['new_expire_date'];
            $inv = new IntroInvoice();
            $inv->set('isPackage', true);
            $inv->set('adminid', $adminid);
            $inv->set('package', $package);
            $inv->set('period', $package);
            $inv->set('num', 1);
            $inv->set('code_trans', 0);
            $inv->set('all_data', '');
            $inv->set('userid', $userid);
            $inv->set('notes', 'Renew MAG: ' . $mac . ' Days:' . $pkg['inv_notes'] . ' (' . date('Y-m-d', $new_end) . ') ');
            $inv->Save();
            $data['pkg'] = $package;
            $data['exp_date'] = $new_end;
            $data['is_trial'] = $pkg['is_trial'];
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222('mag', 'renew_mag', var_export($data, true) . '<br>' . var_export($pkg, true));
        }
        else
        {
            $inv = new IntroInvoice();
            $inv->set('adminid', $adminid);
            $inv->set('period', $period);
            $inv->set('num', 1);
            $inv->set('userid', $userid);
            $inv->set('notes', 'Renew MAG: ' . $mac . ' Days:' . $array['period'][$period]);
            $inv->Save();
            if( !in_array($period, $array['free']) ) 
            {
                $data['is_trial'] = 0;
            }
            $data['exp_date'] = $new_end = strtotime($new_end . ' ' . date('H:i:s'));
        }
        $data['enabled'] = 1;
        $intro->db->update('users', $data, ' id=' . $userid);
        $af = $intro->db->affected_rows;
        $data2 = [];
        $data2['userid'] = $userid;
        $data2['period'] = $period;
        $intro->db->insert_update('' . PREFIX . '_users_data', $data2, $data2);
        $new_end = date('Y-m-d', $new_end);
        echo "<script>\r\n\t\t\t\r\n\t\t\t\$('#expire_" . $id . '\').html(\'<span class="label label-success label-lg">' . $new_end . "</span>');\r\n\t\t\talert('Success! (" . $af . ")'); \r\n\t\t\t\t\r\n\t\t\t\$('#m3u-modal').modal('hide'); \r\n\t\t\t\r\n\t\t</script>";
    }
    public function calcCost($adminid = 0, $period = 0, $num = 0)
    {
        global $intro;
        global $array;
        if( $adminid == 0 ) 
        {
            $adminid = intval($intro->input->get_post('resel'));
        }
        if( $period == 0 ) 
        {
            $period = intval($intro->input->get_post('period'));
        }
        if( $num == 0 ) 
        {
            $num = intval($intro->input->get_post('num'));
        }
        if( in_array($period, $array['free']) || $period == 0 ) 
        {
            echo '0';
        }
        if( $num == 0 ) 
        {
            $num = 1;
        }
        $adm = $intro->auth->admin_data($adminid);
        $p = new IntroPerms('CheckCost', $adm, $num, $period, $package = $period);
        if( $p->error != '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232($p->error, 'danger');
        }
        echo '<span style=\'color:red\'><strong>' . $num . ' * ' . $p->cost . ' = ' . ($num * $p->cost) . '</strong></span>';
    }
    public function calc()
    {
        global $intro;
        $cur_date = trim($intro->input->get_post('cur_date'));
        $period = $package = trim($intro->input->get_post('period'));
        if( $this->adminRow['member_group_id'] > 0 ) 
        {
            $pkg = _obf_0D0E122A21280A14271F3B1D1727291E290A0A2A092E11($package, 'calc_expire', strtotime($cur_date));
            echo date('Y-m-d', $pkg['new_expire_date']);
        }
        if( in_array($period, $this->free) ) 
        {
            if( $this->admin['level'] != 1 ) 
            {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Sorry: you can\'t renew Free Days. It\'s not allowed.', 'danger');
                exit();
            }
            $days = $period - 100;
            $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($cur_date, 'day', $days, 'Y-m-d');
            echo (string)$new_end;
        }
        else
        {
            $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($cur_date, 'month', $period, 'Y-m-d');
            echo (string)$new_end;
        }
    }
    public function getEndDate($date_expire, $period)
    {
        $rem = _obf_0D24242D0C22102F0715263F3E193B275B1B06383C3401(date('Y-m-d'), $date_expire);
        if( $rem > 0 ) 
        {
            $this->cur_date = $date_expire;
        }
        else
        {
            $this->cur_date = date('Y-m-d');
        }
        if( in_array($period, $this->free) ) 
        {
            $days = $period - 100;
            $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($this->cur_date, 'day', $days, 'Y-m-d');
            return $new_end;
        }
        $new_end = _obf_0D1E0F36162C3B153E080E40155C280D0A052340013701($this->cur_date, 'month', $period, 'Y-m-d');
        return $new_end;
    }
    public function User()
    {
        global $intro;
        global $array;
        $txt_name = 'User';
        $username = $mac = '';
        if( $this->admin['level'] != 1 ) 
        {
            $intro->option['BlockAddFree'] = 1;
        }
        if( $this->admin['level'] == 9 ) 
        {
            $this->qry_admin = '';
        }
        $id = intval($intro->input->get_post('id'));
        $e2 = intval($intro->input->get_post('e2'));
        $user_id = $userid = $id;
        $sql = $intro->db->query('SELECT * FROM users where id=' . $id . ' ' . $this->qry_admin . ';');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        if( $username == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: you cannot change this ' . $txt_name . ".\r\n\t\t\t\t<li>The " . $txt_name . " may not found.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this " . $txt_name . '.', 'danger');
            exit();
        }
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_users_data where userid=' . $user_id . ';'));
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $date_expire = ($exp_date != '' ? date('Y-m-d H:i', $exp_date) : '-');
        $txt_name = 'User';
        $txt_fullname = 'Fullname';
        if( $e2 > 0 ) 
        {
            $txt_name = 'E2 Device';
            $username = $mac;
            $txt_fullname = 'E2 Device';
            $sql = $intro->db->query('SELECT mac FROM enigma2_devices where device_id=' . $e2 . ';');
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            if( $mac == '' ) 
            {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Error: \r\n\t\t\t\t\t<li>The " . $txt_name . " may not found.\r\n\t\t\t\t\t<li>You tried to change the URL!!!. and this incident has been logged.\r\n\t\t\t\t\t<li>Or you don't have the right permisions to edit this " . $txt_name . '.', 'danger');
                exit();
            }
        }
        if( $member_id != $this->adminRow['adminid'] ) 
        {
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Renew ' . $txt_name . ': ' . $username, 'success');
        echo "<table class=\"table table-striped table-bordered\">\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='info'>" . $txt_fullname . ":</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t<td class='info'>Reseller:</td>\r\n\t\t\t\t<td>" . $array['admins'][$member_id] . "</td>\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\r\n\t\t\t\t<td class='info'>Period:</td>\r\n\t\t\t\t<td>" . period($period, $free_days) . ("</td>\r\n\t\t\t\t<td class='info'>Date Expire:</td>\r\n\t\t\t\t<td>" . $date_expire . "</td>\t\r\n\t\t\t</tr>\r\n\t\t\t<tr>\t\t\t\t\r\n\t\t\t\t<td class='info'>Username:</td>\r\n\t\t\t\t<td><strong>" . $username . "</strong></td>\r\n\t\t\t\t<td class='info'> </td>\r\n\t\t\t\t<td></td>\r\n\t\t\t</tr>\r\n\t\t</table>");
        $new_end = $this->getEndDate($date_expire, $period);
        echo "\r\n\t\t<form name=\"renew\" id='frmRenew' method=\"post\" action=\"" . $this->base . "/doRenewUser\">\r\n\t\t<table class=\"table table-striped table-bordered\">";
        if( $this->adminRow['member_group_id'] > 0 ) 
        {
            $pkg = new Packages($this->adminRow);
            $pkg->OfficialOnly = true;
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td>Package: <span style='color:#ff0000'>*</span></td>\r\n\t\t\t\t<td>";
            echo $pkg->FormDropDown();
            echo "\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        else
        {
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class=\"tr_bg2\" width=\"150\"> Period :</td>\r\n\t\t\t\t<td class=\"tr_bg1\">" . _obf_0D25032D2B210E1538102515291B2D08111A1816070622('period', _obf_0D322A5B141A102E2824032B03230A35140306272F2F11(), $period) . (' ' . $this->error('period') . "</td>\r\n\t\t\t</tr>");
        }
        echo "\t\t\r\n\t\t<tr>\r\n\t\t\t<td>New Start Date: </td>\r\n\t\t\t<td><font color=red><b>" . $this->cur_date . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Expire Date: </td>\r\n\t\t\t<td><font color=red><b><span id='calc_div'>" . $new_end . "</span> <span id=\"spin\" class='icon-spin5'></span> </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Cost: </td>\r\n\t\t\t<td><font color=red><b><span id='cost_cost'>";
        $this->calcCost($created_by, $period);
        echo "</span> </td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td> </td>\r\n\t\t\t<td> <input type=\"submit\" value=\" Renew Now\" class=\"btn btn-success\" OnClick=\"return confirm('Are you sure?')\" /> </td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\r\n\t\t<input type=\"hidden\" name=\"user_id\" value=\"" . $user_id . "\" />\r\n\t\t\r\n\t\t</form>";
        echo '<div id=\'result\'>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "<script>\r\n\t\t\$('documnet').ready(function(){\r\n\t\t\t\r\n\t\t\t\$(\"#frmRenew\").submit(function(event){\r\n\t\t\t\tevent.preventDefault();\r\n\r\n\t\t\t\t\$.ajax({\r\n\t\t\t\t\turl:'" . $this->base . "/doRenewUser/?NH=1',\r\n\t\t\t\t\ttype:'POST',\r\n\t\t\t\t\tdata:\$(this).serialize(),\r\n\t\t\t\t\tsuccess:function(result){\r\n\t\t\t\t\t\t\$('#result').html(result);\r\n\t\t\t\t\t}\r\n\r\n\t\t\t\t});\r\n\t\t\t});\r\n\t\t\t\r\n\t\t\t\$(\"select[name=period],select[name=package]\").change(function(){\r\n\t\t\t\tvar val = \$(this).val();\r\n\t\t\t\t\r\n\t\t\t\tif(val == 0){\r\n\t\t\t\t\talert('Error: you can\\'t renew Free.');\r\n\t\t\t\t\treturn false;\r\n\t\t\t\t}\r\n\t\t\t\t\r\n\t\t\t\t\$('#spin').addClass('animate-spin');\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\$.get(\"" . $this->base . '/calc/?cur_date=' . $this->cur_date . "&NH=1&period=\"+val+\"\", function( data ) {\r\n\t\t\t\t\t\$(\"#calc_div\" ).html( data );\r\n\t\t\t\t\t\$('#spin').removeClass('animate-spin');\r\n\t\t\t\t});\r\n\t\t\t\t\r\n\t\t\t\t\$(\"#cost_cost\").load('" . $this->base . '/calcCost/?NH=1&resel=' . $created_by . "&period='+val);\r\n\t\t\t\t\r\n\t\t\t});\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function getBouquets()
    {
        global $intro;
        global $error;
        global $array;
        $id = intval($intro->input->post('package'));
        $sql = $intro->db->query('SELECT * from packages where id=' . $id . ';');
        $r = $intro->db->fetch_assoc($sql);
        $bq = new Bouquets();
        $bq->set('bouquets', json_decode($r['bouquets'], true));
        echo $bq->html();
    }
    public function doRenewUser()
    {
        global $intro;
        global $error;
        global $array;
        $data = [];
        if( $this->admin['level'] == 9 ) 
        {
            $this->qry_admin = '';
        }
        $cost = 0;
        $period = intval($intro->input->post('period'));
        $package = intval($intro->input->post('package'));
        $id = intval($intro->input->post('user_id'));
        $user_id = $id;
        $sql = $intro->db->query('SELECT * FROM users where id=' . $id . ' ' . $this->qry_admin . ';');
        $row = $intro->db->fetch_assoc($sql);
        @extract($row);
        $date_expire = $exp_date;
        $adminid = intval($row['member_id']);
        $userid = intval($row['id']);
        $adm = $intro->auth->adminRow($adminid);
        if( empty($adm) || !is_array($adm) ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Reseller ID (' . $adminid . ') not found!!! ', 'danger');
            exit();
        }
        if( $adm['member_group_id'] > 0 && $package == 0 ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Please choose Package. ', 'danger');
            exit();
        }
        if( $username == '' ) 
        {
            echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: you can not Renew this User: <strong>' . $username . "</strong>\r\n\t\t\t\t<li>The username may not found.\r\n\t\t\t\t<li>Or you don't have the right permisions to edit this user.", 'danger');
            exit();
        }
        if( $package > 0 ) 
        {
            $pkg = _obf_0D0E122A21280A14271F3B1D1727291E290A0A2A092E11($package, 'calc_expire', $date_expire);
            if( $pkg['new_expire_date'] < time() ) 
            {
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232('Error: Wrong date calculations.', 'danger');
                exit();
            }
            $inv = new IntroInvoice();
            $inv->set('isPackage', true);
            $inv->set('adminid', $adminid);
            $inv->set('package', $package);
            $inv->set('period', $package);
            $inv->set('num', 1);
            $inv->set('code_trans', 0);
            $inv->set('all_data', '');
            $inv->set('userid', $userid);
            $inv->set('notes', 'Renew user: ' . $username . ' Days:' . $pkg['inv_notes']);
            $inv->Save();
            $data['pkg'] = $package;
            $data['exp_date'] = $new_end = $pkg['new_expire_date'];
            $data['is_trial'] = $pkg['is_trial'];
        }
        else
        {
            $date_expire = ($date_expire != '' ? date('Y-m-d', $date_expire) : '-');
            $new_end = $this->getEndDate($date_expire, $period);
            $inv = new IntroInvoice();
            $inv->set('adminid', $adminid);
            $inv->set('period', $period);
            $inv->set('num', 1);
            $inv->set('userid', $userid);
            $inv->set('notes', 'Renew user: ' . $username . ' Days:' . $array['period'][$period]);
            $inv->Save();
            if( !in_array($period, $array['free']) ) 
            {
                $data['is_trial'] = 0;
            }
            $data['exp_date'] = strtotime($new_end);
        }
        $data['enabled'] = 1;
        $intro->db->update('users', $data, ' id=' . $userid);
        $af = $intro->db->affected_rows;
        $data2 = [];
        $data2['userid'] = $userid;
        $data2['period'] = $period;
        $intro->db->insert_update('' . PREFIX . '_users_data', $data2, $data2);
        echo "<script>\r\n\t\t\t\r\n\t\t\t\$('#expire_" . $id . '\').html(\'<span class="label label-success label-lg">' . $new_end . "</span>');\r\n\t\t\t\$('#frmRenew').html('Success');\t\r\n\t\t\talert('Success! (" . $af . ")'); \r\n\t\t\t\r\n\t\t\t\$('#m3u-modal').modal('hide'); \r\n\t\t\t\r\n\t\t</script>";
    }
}
