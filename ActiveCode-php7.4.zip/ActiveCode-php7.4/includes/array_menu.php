<?php 
$array['menu']['streams'] = [
    'streams' => [
        'title' => 'Streams', 
        'url' => 'streams/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'streams_add' => [
        'title' => 'Add Streams', 
        'url' => 'streams/Form', 
        'args' => '?t=add', 
        'icon' => 'icon-plus-squared'
    ], 
    'streams_categories' => [
        'title' => 'Categories', 
        'url' => 'categories/index', 
        'args' => '', 
        'icon' => 'icon-folder'
    ], 
    'streams_sort' => [
        'title' => 'Sort Streams', 
        'url' => 'streams/SortOrder', 
        'args' => '', 
        'icon' => 'icon-up-circled2'
    ], 
    'streams_bulk' => [
        'title' => 'Bulk Streams', 
        'url' => 'streams_bulk/index', 
        'args' => '', 
        'icon' => 'icon-code'
    ], 
    'streams_bouquets' => [
        'title' => 'Bouquets', 
        'url' => 'bouquets/index', 
        'args' => '', 
        'icon' => 'icon-gift'
    ], 
    'streams_movies' => [
        'title' => 'Movies', 
        'url' => 'movies/index', 
        'args' => '', 
        'icon' => 'icon-pause'
    ], 
    'streams_series' => [
        'title' => 'Series', 
        'url' => 'series/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'streams_demand' => [
        'title' => 'Users Demands', 
        'url' => 'demand/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'streams_comments' => [
        'title' => 'Comments', 
        'url' => 'comments/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'streams_EPG' => [
        'title' => 'EPG', 
        'url' => 'epg/index', 
        'args' => '', 
        'icon' => 'icon-calendar'
    ], 
    'streams_SAT' => [
        'title' => 'SAT2IPTV', 
        'url' => 'sat2iptv/index', 
        'args' => '', 
        'icon' => 'icon-picture'
    ], 
    'streams_servers' => [
        'title' => 'Servers', 
        'url' => 'servers/index', 
        'args' => '', 
        'icon' => 'icon-building'
    ], 
    'streams_importstr' => [
        'title' => 'Import XML Streams', 
        'url' => 'xml_import/index', 
        'args' => '', 
        'icon' => 'icon-building'
    ], 
    'streams_importvod' => [
        'title' => 'Import XML VODS', 
        'url' => 'xml_import/vod', 
        'args' => '', 
        'icon' => 'icon-building'
    ], 
    'streams_tokenupdat' => [
        'title' => 'Token Update', 
        'url' => 'streams/Token', 
        'args' => '', 
        'icon' => 'icon-exchange'
    ], 
    'streams_Report' => [
        'title' => 'Streams Report', 
        'url' => 'streams/Report', 
        'args' => '', 
        'icon' => 'icon-chart-bar'
    ], 
    'streams_changDNS' => [
        'title' => 'Change DNS', 
        'url' => 'streams/ChangeDNS', 
        'args' => '', 
        'icon' => 'icon-chart-bar'
    ]
];
$array['menu']['codes'] = [
    'codes' => [
        'title' => 'Codes', 
        'url' => 'codes/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'codes_add' => [
        'title' => 'Add Codes', 
        'url' => 'codes/Form', 
        'args' => '?t=add', 
        'icon' => 'icon-plus-squared'
    ], 
    'codes_trans' => [
        'title' => 'Code Trans Records', 
        'url' => 'trans/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'codes_master' => [
        'title' => 'Master Codes', 
        'url' => 'codes_master/index', 
        'args' => '', 
        'icon' => 'icon-bookmark'
    ], 
    'codes_model' => [
        'title' => 'STB Models', 
        'url' => 'model/index', 
        'args' => '', 
        'icon' => 'icon-list-alt'
    ], 
    'codes_free' => [
        'title' => 'Free Codes', 
        'url' => 'free_code/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'codes_import' => [
        'title' => 'Import Codes', 
        'url' => 'codes_import/index', 
        'args' => '', 
        'icon' => 'icon-up'
    ], 
    'codes_mac' => [
        'title' => 'Codes By MACs', 
        'url' => 'codes/FormSerialMac', 
        'args' => '?t=mac', 
        'icon' => 'icon-maxcdn'
    ], 
    'codes_serial' => [
        'title' => 'Codes By Serials', 
        'url' => 'codes/FormSerialMac', 
        'args' => '?t=serial', 
        'icon' => 'icon-barcode'
    ], 
    'codes_online' => [
        'title' => 'Online', 
        'url' => 'online/index', 
        'args' => '', 
        'icon' => 'icon-globe'
    ], 
    'codes_activate' => [
        'title' => 'Activation Count', 
        'url' => 'act_count/index', 
        'args' => '', 
        'icon' => 'icon-list'
    ], 
    'codes_changedcode' => [
        'title' => 'Changed Codes', 
        'url' => 'codes/CodeChange', 
        'args' => '', 
        'icon' => 'icon-exchange'
    ], 
    'codes_report' => [
        'title' => 'Report', 
        'url' => 'codes/Report', 
        'args' => '', 
        'icon' => 'icon-list-alt'
    ]
];
$array['menu']['users'] = [
    'users' => [
        'title' => 'Users', 
        'url' => 'users/index', 
        'args' => '', 
        'icon' => 'icon-user'
    ], 
    'users_add' => [
        'title' => 'Add Users', 
        'url' => 'users/Form', 
        'args' => '?t=add', 
        'icon' => 'icon-plus-squared'
    ]
];
$array['menu']['mag'] = [
    'mag' => [
        'title' => 'MAG', 
        'url' => 'mag/index', 
        'args' => '', 
        'icon' => 'icon-desktop'
    ], 
    'mag_add' => [
        'title' => 'Add MAG', 
        'url' => 'mag/Form', 
        'args' => '?t=add', 
        'icon' => 'icon-plus-squared'
    ]
];
$array['menu']['invoices'] = [
    'invoices' => [
        'title' => 'Invoices', 
        'url' => 'invoices/index', 
        'args' => '', 
        'icon' => 'icon-money'
    ], 
    'invoices_add' => [
        'title' => 'Add Invoices', 
        'url' => 'invoices/Form', 
        'args' => '?t=add', 
        'icon' => 'icon-plus-squared'
    ], 
    'invoices_subres' => [
        'title' => 'Sub-Resellers ', 
        'url' => 'invoices/index_sub', 
        'args' => '', 
        'icon' => 'icon-list'
    ]
];
$array['menu']['payments'] = [
    'payments' => [
        'title' => 'Payments', 
        'url' => 'payments/index', 
        'args' => '', 
        'icon' => 'icon-money'
    ], 
    'payments_add' => [
        'title' => 'Add Payments', 
        'url' => 'payments/Form', 
        'args' => '?t=add', 
        'icon' => 'icon-plus-squared'
    ], 
    'payments_subres' => [
        'title' => 'Sub-Resel ', 
        'url' => 'payments/index_sub', 
        'args' => '', 
        'icon' => 'icon-list'
    ]
];
$array['menu']['logs'] = [
    'logs' => [
        'title' => 'Logs', 
        'url' => 'logs/index', 
        'args' => '', 
        'icon' => 'icon-bug'
    ]
];
$array['menu']['resellers'] = [
    'resellers' => [
        'title' => 'Resellers', 
        'url' => 'admins/index', 
        'args' => '', 
        'icon' => 'icon-users'
    ], 
    'resellers_add' => [
        'title' => 'Add Reseller', 
        'url' => 'admins/Form', 
        'args' => '?t=add', 
        'icon' => 'icon-plus-squared'
    ], 
    'resellers_grp' => [
        'title' => 'Admin Groups', 
        'url' => 'admins/Groups', 
        'args' => '', 
        'icon' => 'icon-plus-squared'
    ], 
    'resellers_import' => [
        'title' => 'Import Registered', 
        'url' => 'admins/ImportRegUsers', 
        'args' => '', 
        'icon' => 'icon-plus-squared'
    ]
];
$array['menu']['tools'] = [
    'tools_options' => [
        'title' => 'Options', 
        'url' => 'options/index', 
        'args' => '', 
        'icon' => 'icon-cog'
    ], 
    'tools_sessions' => [
        'title' => 'Sessions', 
        'url' => 'sessions/index', 
        'args' => '', 
        'icon' => 'icon-login'
    ], 
    'tools_logs' => [
        'title' => 'System Logs', 
        'url' => 'logs_sys/index', 
        'args' => '', 
        'icon' => 'icon-bug'
    ], 
    'tools_Pages' => [
        'title' => 'Pages', 
        'url' => 'pages/index', 
        'args' => '', 
        'icon' => 'icon-doc'
    ], 
    'tools_fix' => [
        'title' => 'Fix Codes with Xtream', 
        'url' => 'fix/index', 
        'args' => '', 
        'icon' => 'icon-wrench'
    ], 
    'tools_bulk' => [
        'title' => 'Bulk Commands (Codes)', 
        'url' => 'commands_users/index', 
        'args' => '', 
        'icon' => 'icon-wrench'
    ], 
    'tools_backup' => [
        'title' => 'Backup', 
        'url' => 'backup/index', 
        'args' => '', 
        'icon' => 'icon-hdd'
    ], 
    'tools_Firewal' => [
        'title' => 'Firewall IPs', 
        'url' => 'firewall/index', 
        'args' => '', 
        'icon' => 'icon-shield'
    ], 
    'tools_StrtoMAC' => [
        'title' => 'String to MAC', 
        'url' => 'String to MAC', 
        'args' => '', 
        'icon' => 'icon-arrows-cw'
    ], 
    'tools_ClrCach' => [
        'title' => 'Clear Cache', 
        'url' => 'tools/ClearCache', 
        'args' => '', 
        'icon' => 'icon-arrows-cw'
    ]
];
