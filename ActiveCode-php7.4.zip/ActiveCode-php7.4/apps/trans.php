<?php 
class Trans_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $admin = [];
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        if( $this->admin['level'] != 1 ) 
        {
            $this->qry_admin = ' and adminid=' . intval($this->admin['adminid']);
            $this->qry_admin_where = ' where adminid=' . intval($this->admin['adminid']);
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\">Code Trans Records</icon></a> \n\t\t\n\t\t</div>");
        if( $this->admin['level'] == 1 ) 
        {
            echo "\n\t\t<div class=center>\n\t\t\t<span class=\"btn btn-danger\">Danger! Danger! Danger!\n\t\t\t<br/>\n\t\t\tWarning: if you delete any record from here, all related codes will be deleted.\n\t\t\t</span>\n\t\t</div><br/>";
        }
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = $queryadmin = $params = $txt = '';
        $page = intval($intro->input->get_post('page'));
        $trans_id = intval($intro->input->get_post('id'));
        $order = trim($intro->input->get_post('order'));
        $trans_name = trim($intro->input->get_post('name'));
        $date1 = trim($intro->input->get_post('date1'));
        $date2 = trim($intro->input->get_post('date2'));
        $admin = intval($intro->input->get_post('admin'));
        $trans_name = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($trans_name, ' ');
        $date1 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date1, '-');
        $date2 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date2, '-');
        $this->nav();
        $rows_per_page = 50;
        if( $trans_name != '' ) 
        {
            $qry .= (' and trans_name  LIKE \'%' . $trans_name . '%\' ');
            $params .= ('&name=' . $trans_name);
            $txt .= (' | Name: ' . $trans_name);
        }
        if( $admin != 0 ) 
        {
            $qry .= (' AND adminid=' . $admin . ' ');
            $params .= ('&admin=' . $admin);
            $rows_per_page = '5000';
            $txt .= (' | Reseller: ' . $array['admins'][$admin]);
        }
        if( $date1 != '' && $date2 != '' ) 
        {
            $qry .= (' AND trans_date BETWEEN UNIX_TIMESTAMP(\'' . $date1 . ' 00:00:00\') AND UNIX_TIMESTAMP(\'' . $date2 . ' 23:59:59\') ');
            $params .= ('&date1=' . $date1 . '&date2=' . $date2);
            $rows_per_page = '5000';
            $txt .= (' | Date: ' . $date1 . ' TO ' . $date2);
        }
        if( $trans_id != 0 ) 
        {
            $qry = ' and trans_id=' . $trans_id . ' ';
        }
        if( $order == '' ) 
        {
            $order = 'trans_id:desc';
        }
        $order = str_replace(':', ' ', $order);
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT *, (select count(id) from ' . PREFIX . '_codes where transid=tr.trans_id) as totCodes ' . ' from ' . PREFIX . ('_codes_trans tr where true ' . $this->qry_admin . ' ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT trans_id from ' . PREFIX . ('_codes_trans where true ' . $this->qry_admin . ' ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<h4 style=\'display:inline\'><i class="icon-list"></i> Code Trans (' . $totalrows . ') ' . $txt . '</h4>');
        if( $this->admin['level'] == 1 ) 
        {
            echo "<form action=\"\" method=\"GET\" class=\"form-inline\">\n\t\t\t<table class='table' style='max-width:700px;'>\n\t\t\t<tr>\n\t\t\t\t<td>Reseller:</td>\n\t\t\t\t<td>" . form_resellers('admin', $admin, 'All Resellers') . ("</td>\n\t\t\t\t<td>Date:</td>\n\t\t\t\t<td>\n\t\t\t\t\t<input type=\"text\" name=\"date1\" value=\"" . $date1 . "\" placeholder='From yyyy-mm-dd' class='form-control form-inline' style='width:150px;'>\n\t\t\t\t\t<input type=\"text\" name=\"date2\" value=\"" . $date2 . "\" placeholder='To yyyy-mm-dd' class='form-control form-inline' style='width:150px;'>\n\t\t\t\t</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td>Trans Name:</td>\n\t\t\t\t<td><input type=\"text\" name=\"name\" value=\"" . $trans_name . "\" placeholder='Trans Name' class='form-control'></td>\n\t\t\t\t<td></td>\n\t\t\t\t<td><input type=\"submit\" value=\" Search! \" class='btn btn-default'></td>\n\t\t\t</tr>\n\t\t\t</table>\n\t\t\t</form>");
        }
        echo "\n\t\t<table class=\"table table-hover table-bordered\" id=\"table_codes\">\n        <thead>\n\t    <tr>\n\t\t\t<th> </th>\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . "</th>\n\t\t\t<th> Reseller </th>\n\t\t\t<th> Name </th>\n\t\t\t<th> Date </th>\n\t\t\t<th> Period </th>\n\t\t\t<th> +Free Days </th>\n\t\t\t<th>Codes</th>\n\t\t\t<th> Length </th>\n\t\t\t<th>" . $intro->lang['options'] . "</th>\n\t    </tr>\n\t\t</thead>\n\t\t\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\n\t\t\t\t<td class=\"center\"><input type=\"checkbox\" value=\"" . $trans_id . "\" name=\"selected_fld[]\"></td>\n\t\t\t\t<td class=\"center\">" . $trans_id . "</td>\n\t\t\t\t<td>") . $array['admins'][$adminid] . ("</td>\n\t\t\t\t<td><span class=\"editable\" data-type=\"text\" data-pk=\"" . $trans_id . '" data-name="trans_name">' . $trans_name . "</span></td>\n\t\t\t\t<td class=\"center\">") . date('Y-m-d H:i:s', $trans_date) . "</td>\n\t\t\t\t<td class=\"center\">" . period($trans_period, $trans_free_days) . ("</td>\n\t\t\t\t<td class=\"center\">" . $trans_free_days . "</td>\n\t\t\t\t<td class=\"center\">") . number_format($totCodes) . ' ' . (($totCodes == 0 ? '<span class="label label-danger">Empty: you can delete it.</span>' : '')) . ("</td>\n\t\t\t\t<td class=\"center\">" . $trans_codes_length . "</td>\n\t\t\t\t\n\t\t\t\t<td class=\"center\">\n\t\t\t\t\t<a class=\"btn btn-success\" href=\"" . $this->base . '/DownloadTXT?tid=' . $trans_id . "\">TXT</a>\n \t\t\t\t\t<a class=\"btn btn-success\" href=\"" . $this->base . '/Download?NH=1&amp;tid=' . $trans_id . '">XLS</a> ');
            if( $this->admin['level'] == 1 ) 
            {
                echo '<a class="btn btn-danger p_del intro_ui_del" href="' . $this->base . '/Del?id=' . $trans_id . '" OnClick="return false;" title="' . $intro->lang['del'] . '">Delete All Codes</a>';
            }
            echo "\n\t\t\t\t</td>\n\t\t\t</tr>";
        }
        echo "</tbody>\n\t\t\t</table>";
        $order = str_replace(' ', ':', $order);
        echo '<center>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?order=' . $order . $params, $totalrows, $rows_per_page, $page) . '</center>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
        echo "\t\t<script>\n\t\t\$('documnet').ready(function(){\n\t\t\n\t\t\t\$.fn.editable.defaults.mode = 'pop';\n\t\t\t\$('.editable').editable({\n\t\t\t\turl: '";
        echo $this->base;
        echo "/EditInPlace?NH=1',\n\t\t\t\tsuccess: function(response) {\n\t\t\t\t}\n\t\t\t});\n\t\t\t\n\t\t});\n\t\t</script>\n\t\t";
    }
    public function EditInPlace()
    {
        global $intro;
        $data = [];
        $id = intval($intro->input->get_post('pk'));
        $name = trim($intro->input->get_post('name'));
        $value = trim($intro->input->get_post('value'));
        $data[$name] = $value;
        $intro->db->update(PREFIX . '_codes_trans', $data, 'trans_id=' . $id);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        if( $this->admin['level'] != 1 ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file. Only First MASTER Admin Can Delete.</h3>' );
        }
        $id = intval($intro->input->get_post('id'));
        $tid = $id;
        $result = $intro->db->query('select userid from ' . PREFIX . ('_codes where transid=\'' . $tid . '\' order by id asc'));
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            $userid = intval($row['userid']);
            $intro->db->query_fast('DELETE FROM users WHERE id=' . $userid . '; ');
        }
        $intro->db->query('DELETE FROM ' . PREFIX . ('_codes WHERE transid=' . $id . '; '));
        $intro->db->query('DELETE FROM ' . PREFIX . ('_codes_trans WHERE trans_id=' . $id . ' '));
        echo 'Delete OK.';
    }
    public function Download()
    {
        global $intro;
        $tid = intval($intro->input->get_post('tid'));
        @header('Content-Description: File Transfer');
        @header('Content-type: text/html; charset=utf-8');
        @header('Content-Type: application/octet-stream');
        @header('Content-Disposition: attachment; filename=codes_' . @date('Y-m-d') . '.xls');
        @header('Expires: 0');
        @header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        @header('Pragma: public');
        echo "<table border=\"1\" align=\"center\" width=\"90%\" cellspacing=\"2\" bordercolor=\"#000000\">\n\t\t<tr>\n\t\t\t<td align=\"center\" bgcolor=\"#c0c0c0\">#</td>\t\t\t\t\n\t\t\t<td align=\"center\" bgcolor=\"#c0c0c0\">Code</td>\t\t\t\t\n\t\t\t<td align=\"center\" bgcolor=\"#c0c0c0\">Days</td>\t\t\t\t\n\t\t\t<td align=\"center\" bgcolor=\"#c0c0c0\">Start Date</td>\t\t\t\t\n\t\t\t<td align=\"center\" bgcolor=\"#c0c0c0\">End Date</td>\t\t\t\t\n\t\t\t\t\t\n\t\t\t<td align=\"center\" bgcolor=\"#c0c0c0\">Activated?</td>\t\t\t\t\n\t\t</tr>";
        $i = 1;
        $result = $intro->db->query('select * from ' . PREFIX . ('_codes where transid=\'' . $tid . '\' ' . $this->qry_admin . ' order by id asc'));
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            extract($row);
            echo "<tr>\n\t\t\t\t<td align=\"center\">" . $i . "</td>\t\t\t\t\n\t\t\t\t<td align=\"center\">" . $code . "</td>\t\t\t\t\t\t\t\n\t\t\t\t<td align=\"center\">" . $days . "</td>\t\t\t\t\n\t\t\t\t<td align=\"center\"> </td>\t\t\t\t\n\t\t\t\t<td align=\"center\"> </td>\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t<td align=\"center\">" . (($status == 1 ? 'Yes' : 'No')) . "</td>\t\t\t\t\n\t\t\t</tr>";
            $i++;
        }
        echo '</table>';
    }
    public function DownloadTXT()
    {
        global $intro;
        $tid = intval($intro->input->get_post('tid'));
        $this->nav();
        $i = 1;
        $all_codes = $all_macs = $all_sn = '';
        $result = $intro->db->query('select * from ' . PREFIX . ('_codes where transid=\'' . $tid . '\' ' . $this->qry_admin . ' order by id asc'));
        while( $row = $intro->db->fetch_assoc($result) ) 
        {
            extract($row);
            $all_codes .= ($code . "\n");
            $all_macs .= ($mac . "\n");
            $all_sn .= ($serial . "\n");
            $i++;
        }
        echo "<fieldset><legend> Text Codes , you can copy them to Word, Excel , Email ....etc</legend>\n\t\t\n\t\t<table class='table'>\n\t\t\t<tr>\n\t\t\t\t<th>Codes</td>\n\t\t\t\t<th>MACs</td>\n\t\t\t\t<th>Serials</td>\n\t\t\t</tr>\n\t\t\t<tr>\n\t\t\t\t<td><textarea class='form-control' style='height:400px' name=\"codes\">" . $all_codes . "</textarea></td>\n\t\t\t\t<td><textarea class='form-control' style='height:400px' name=\"macs\">" . $all_macs . "</textarea></td>\n\t\t\t\t<td><textarea class='form-control' style='height:400px' name=\"sns\">" . $all_sn . "</textarea></td>\n\t\t\t</tr>\n\t\t</table>\n\t\t\n\t\t</fieldset>";
    }
}
