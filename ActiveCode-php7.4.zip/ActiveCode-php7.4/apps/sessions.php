<?php 
class Sessions_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->admin = $intro->auth->sess_admin();
        if( !in_array($this->admin['level'], [
            1, 
            9
        ]) ) 
        {
            exit( '<h3>Error: you don\'t have permisions to access this file.</h3>' );
        }
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function nav()
    {
        global $cur_file;
        echo "<div class=\"app_nav\"> \t\t\n\t\t \n         <a class=\"btn btn-default icon-login\" href=\"" . $this->base . "/index\"> Sessions</a> &nbsp;&nbsp; \t\t \t\t \n         <a class=\"btn btn-danger icon-trash\" href=\"" . $this->base . "/Clear\" OnClick=\"return confirm('This will kick all sessions.');\"> Clear all Sessions</a> &nbsp;&nbsp; \t\t \t\t \n  \n\t\t </div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        global $code;
        $this->DelIdle();
        $intro->db->query('OPTIMIZE TABLE ' . PREFIX . '_session_data;');
        echo "<div dir=ltr>\n";
        $this->nav();
        if( $_POST != null ) 
        {
            @extract($_POST);
        }
        if( $_GET != null ) 
        {
            @extract($_GET);
        }
        if( $code != '' ) 
        {
            $qry .= (' AND the_log  LIKE \'%' . $code . '%\'');
        }
        $result = $intro->db->query('SELECT s.session_id,s.session_expire,s.ip,s.page,s.uagent  ,adm.adminid,adm.admin_name  FROM ' . PREFIX . '_session_data s LEFT JOIN ' . PREFIX . '_admin adm ON s.ip=adm.ipaddress ' . ' ORDER BY session_expire DESC');
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Active Login Sessions (' . $totalrows . ')', 'info');
        echo "\n\t  <!--\n\t  <a href=\"" . $this->base . "/DelIdle\" class=\"btn btn-danger icon-trash\"> Delete Idle more than 2 hours </a>\n\t  -->\n\t  <table class=\"table table-bordered table-hover\">\n            <tr>\n\t\t\t\t<th>#</th>\n\t\t\t\t<th>Reseller</th>\n\t\t\t\t<th>Idle</th>\n\t\t\t\t<th>IP</th>\n\t\t\t\t<th>Page</th>\n\t\t\t\t<th>Useragnet</th>\n\t    </tr>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $session_expire = _obf_0D10361F073B102D294032060E21400727331210083132($session_expire);
            echo "<tr>\n\t\t\t\t<td class=\"center\">" . $i . "</td>\n\t\t\t\t<td class=\"center\">" . $admin_name . "</td>\n\t\t\t\t<td class=\"center\">" . $session_expire . "</td>\n\t\t\t\t<td class=\"center\"><a href='https://www.ip-tracker.org/locator/ip-lookup.php?ip=" . $ip . '\' target=\'_blank\'>' . $ip . "</a></th>\n\t\t\t\t<td class=\"center\">" . $page . "</td>\n\t\t\t\t\n\t\t\t\t<td class=\"center\">" . $uagent . "</th>\n\t\t\t\t\n\t\t\t\t<td> </td>     \n\t\t </tr>";
        }
        echo '</table>';
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function DelIdle()
    {
        global $intro;
        $hours2 = 3600;
        $time = time() - $hours2;
        $intro->db->query('DELETE FROM ' . PREFIX . ('_session_data WHERE session_expire<=\'' . $time . '\';'));
    }
    public function Clear()
    {
        global $intro;
        $intro->db->query('TRUNCATE ' . PREFIX . '_session_data;');
        $intro->redirect($this->appname);
    }
}
