<?php
$_CFG = array();
$_CFG['debug'] = false;
$_CFG['debug_post'] = true;
$_CFG['XOR'] = "yes";
$_CFG['XOR_KEY'] = "98676774";
$_CFG['update_password'] = "Yes";
$_CFG['vod'] = "Yes/No";
$_CFG['portalName'] = "LYNX";