<?php 
class Statement_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $goto = '';
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $qry_admin_father = '';
    public $qryWhereFather = '';
    public $qry_sub = '';
    public $qry_sub_for_dropdown = '';
    public $admin = [];
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $adminid = intval($this->admin['adminid']);
        if( $this->admin['level'] != 1 ) 
        {
            $this->qry_admin = ' and admin=' . $adminid;
            $this->qry_admin_where = ' where admin=' . $adminid;
            $this->qry_sub_for_dropdown = '';
        }
        if( $this->admin['level'] == 6 ) 
        {
            $this->qry_admin_father = ' AND father=\'' . $adminid . '\' ';
            $this->qryWhereFather = ' WHERE father=' . $adminid . ' ';
            $this->qry_sub = ' AND father=\'' . $this->admin['adminid'] . '\' ';
            $this->qry_sub_for_dropdown = ' WHERE father=\'' . $this->admin['adminid'] . '\' ';
        }
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = ' ';
            $this->qry_sub = ' ';
            $this->qryWhereFather = ' ';
        }
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        global $options;
        $addnew = '';
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-calendar\">Statement</icon></a> \r\n\t\t\t" . $addnew . "\t \t\t \r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        global $sess_admin;
        $qry = $queryadmin = $params = $txt = '';
        $get_active = $intro->input->get_post('active');
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $Notes = trim($intro->input->get_post('Notes'));
        $date1 = trim($intro->input->get_post('date1'));
        $date2 = trim($intro->input->get_post('date2'));
        $admin = intval($intro->input->get_post('admin'));
        $depit = $intro->input->get_post('depit');
        $depit = ($depit != '' ? floatval($depit) : '');
        $Notes = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($Notes, ' ');
        $date1 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date1, '-');
        $date2 = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($date2, '-');
        $this->nav();
        $rows_per_page = '100';
        if( $Notes != '' ) 
        {
            $qry .= (' and Notes LIKE \'%' . $Notes . '%\' ');
            $params .= ('&Notes=' . $Notes);
            $txt .= (' | Notes: ' . $Notes);
        }
        if( $admin != 0 && in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            $qry .= (' AND admin=' . $admin . ' ');
            $params .= ('&admin=' . $admin);
            $rows_per_page = '500';
            $txt .= (' | Reseller: ' . $array['admins'][$admin]);
        }
        if( $date1 != '' && $date2 != '' ) 
        {
            $qry .= (' AND dateadded BETWEEN \'' . $date1 . ' 00:00:00\' AND \'' . $date2 . ' 23:59:59\' ');
            $params .= ('&date1=' . $date1 . '&date2=' . $date2);
            $rows_per_page = '5000';
            $txt .= (' | Date: ' . $date1 . '-' . $date2);
        }
        if( $depit > 0 ) 
        {
            $qry .= (' AND depit=\'' . $depit . '\'');
            $params .= ('&depit=' . $depit);
            $rows_per_page = '500';
            $txt .= (' | Amount: ' . $depit);
        }
        $qry_open_bal = '';
        if( $date1 != '' ) 
        {
            $qry_open_bal = ',(SELECT SUM(depit-credit) FROM ' . PREFIX . '_trans where  admin=t.admin) AS prev_bal';
        }
        if( $order == '' ) 
        {
            $order = 'trans_id:desc';
        }
        if( $qry != '' ) 
        {
            $order = 'dateadded:ASC';
        }
        $order = str_replace(':', ' ', $order);
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT *' . $qry_open_bal . ' from ' . PREFIX . ('_trans t where true ' . $qry . ' ' . $this->qry_admin . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT trans_id from ' . PREFIX . ('_trans t where true ' . $qry . ' ' . $this->qry_admin));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Statement  ' . $txt, 'info');
        if( $date1 == '' ) 
        {
            $date1 = date('Y-01-01');
        }
        if( $date2 == '' ) 
        {
            $date2 = date('Y-m-d');
        }
        echo "<form action=\"\" method=\"GET\" class=\"form-inline\">\r\n\t\t<table class='table' style='max-width:800px;'>\r\n\t\t<tr>";
        if( in_array($this->admin['level'], [
            1, 
            6
        ]) ) 
        {
            echo "<td>Reseller:</td>\r\n\t\t\t\t<td>" . form_resellers('admin', $admin, 'All Resellers', $this->qry_sub_for_dropdown) . '</td>';
        }
        echo "\r\n\t\t\t<td>Date:</td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"text\" name=\"date1\" value=\"" . $date1 . "\" class=\"date_picker\" placeholder='From' class='form-control form-inline' style='width:100px;'>\r\n\t\t\t\t<input type=\"text\" name=\"date2\" value=\"" . $date2 . "\" class=\"date_picker\" placeholder='To' class='form-control form-inline' style='width:100px;'>\r\n\t\t\t</td>\r\n\t\t\t<td></td>\r\n\t\t\t<td></td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>Notes:</td>\r\n\t\t\t<td><input type=\"text\" name=\"Notes\" value=\"" . $Notes . "\" placeholder='Notes' class='form-control'></td>\r\n\t\t\t<td></td>\r\n\t\t\t<td><input type=\"submit\" value=\" View \" class='btn btn-default'></td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</form>";
        echo "\t\t\t\r\n\t\t<form action=\"" . $this->base . "/index\" method=\"post\" name=\"fieldsForm\"  id=\"fieldsForm\">\r\n\r\n\t\t<table class=\"table table-hover table-striped table-bordered table-condensed\" id=\"table_trans\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('trans_id', 'index', $params) . "</th>\r\n\t\t\t<th> Type " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('type', 'index', $params) . "</th>\r\n\t\t\t<th>Date " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('dateadded', 'index', $params) . "</th>\r\n\t\t\t<th>Reseller   " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('adminid', 'index', $params) . " </th>\r\n\t\t\t<th>Period   " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('period', 'index', $params) . " </th>\r\n\t\t\t<th>Credit <br/> (Payment) " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('credit', 'index', $params) . " </th>\r\n\t\t\t<th>Debit <br/>(Invoice) " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('depit', 'index', $params) . " </th>\r\n\t\t\t\r\n\t\t\t<th>Notes " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('Notes', 'index', $params) . " </th>\r\n\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        $totCr = $totDr = $totAmount = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $tt = '';
            if( $type == 1 ) 
            {
                $tt = '<span class=\'label label-warning\'>Invoice</span>';
            }
            else
            {
                $tt = $intro->pay_method[$method];
            }
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\">" . $trans_id . "</td>\r\n\t\t\t\t<td class=\"center\">" . $tt . "</td>\r\n\t\t\t\t<td class=\"center\">") . $dateadded . "</td>\r\n\t\t\t\t<td class=\"center\">" . $array['admins'][$admin] . "</td>\r\n\t\t\t\t<td class=\"center\">" . (($pkg > 0 ? $intro->packages[$pkg] : period($period, 0))) . ("</td>\r\n\t\t\t\t<td class=\"center\">" . $credit . "</td>\r\n\t\t\t\t<td class=\"center\">" . $depit . "</td>\r\n\t\t\t\t\r\n\t\t\t\t<td>" . $Notes . "</td>\r\n\t\t\t\t\r\n\t\t\t</tr>");
            $totCr += floatval($credit);
            $totDr += floatval($depit);
        }
        $bal = $totCr - $totDr;
        echo "</tbody>\r\n\t\t\t<tfoot>\r\n\t\t\t<tr style='border-top:2px solid #333'>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\">Page Totals:</td>\r\n\t\t\t\t<td class=\"center\">" . number_format($totCr, 2) . "</td>\r\n\t\t\t\t<td class=\"center\">" . number_format($totDr, 2) . "</td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t\r\n\t\t\t</tr>\r\n\r\n\t\t\t<tr style='border-top:2px solid #333'>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\t<td class=\"center\">Balance:</td>\r\n\t\t\t\t<td class=\"center " . (($bal > 0 ? 'success' : 'danger')) . '"><b>' . number_format($bal, 2) . "</b></td>\r\n\t\t\t\t<td class=\"center\"></td>\r\n\t\t\t\r\n\t\t\t</tr>\r\n\t\t\t</tfoot>\r\n\t\t\t</table>";
        $order = str_replace(' ', ':', $order);
        $page = _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?order=' . $order . $params, $totalrows, $rows_per_page, $page);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411($page);
    }
}
