<?php 
class Act_count_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public $qry_admin = '';
    public $qry_admin_where = '';
    public $admin = [];
    public $adminRow = [];
    public $inputBy = [
        'Code', 
        'MAC', 
        'Serial'
    ];
    public $free = [
        101, 
        103, 
        107, 
        110
    ];
    public $time = null;
    public $PaypassLargeNumber = false;
    public function __construct($appname, $base, $img_path = '')
    {
        global $intro;
        global $array;
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
        $this->admin = $intro->auth->sess_admin();
        $this->adminRow = $intro->auth->admin_data(intval($this->admin['adminid']));
        if( $this->admin['level'] == 1 ) 
        {
            $this->qry_admin = '';
            $this->qry_admin_where = '';
        }
        else
        {
            $this->qry_admin = ' and adminid=' . intval($this->admin['adminid']);
            $this->qry_admin_where = ' where adminid=' . intval($this->admin['adminid']);
        }
        $this->time = time();
        $this->free = $array['free'];
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . "/index\"><icon class=\"icon-list\"> Activation Limits</icon></a>  \r\n\t\t\r\n\t\t</div>");
    }
    public function index()
    {
        global $intro;
        global $array;
        global $options;
        $this->nav();
        $qry = $params = '';
        $status = trim($intro->input->get_post('status'));
        $view = trim($intro->input->get_post('view'));
        $params .= ('&status=' . $status);
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $code = trim($intro->input->get_post('code'));
        if( $order == '' ) 
        {
            $order = 'act_count:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 200;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT SQL_CACHE * from ' . PREFIX . '_codes codes ' . (' where act_count > 2 ' . $this->qry_admin . ' ' . $qry . ' order by ' . $order . ' limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT SQL_CACHE id from ' . PREFIX . '_codes ' . (' where act_count > 2 ' . $this->qry_admin . ' ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Activation limit more than 2 times (' . money($totalrows) . ')', 'primary');
        echo "We calculate Total Devices from Logs, if logs is empty Total Devices will be 0.\r\n\t\t\r\n\t\t<table class=\"DataTable table-striped table-bordered table-condensed\" id=\"table_codes\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . " </th>\r\n\t\t\t<th>Rseller  </th>\r\n\t\t\t<th>" . $intro->lang['codes_fullname'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('fullname', 'index') . " </th>\r\n\t\t\t\r\n\t\t\t<th>" . $intro->lang['codes_code'] . '  </th>';
        echo "\r\n\t\t\t<th>" . $intro->lang['codes_days'] . " </th>\r\n\t\t\t\r\n\t\t\t<th>" . $intro->lang['codes_transid'] . " </th>\r\n\t\t\t<th>" . $intro->lang['codes_status'] . "  </th>\r\n\t\t\t<th>MAC </th>\r\n\t\t\t<th>Serial</th>\r\n\t\t\t<th>Start</th>\r\n\t\t\t<th>Expire</th>\r\n\t\t\t<th>Act Count</th>\r\n\t\t\t<th>Total Devices</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        $mac = $serial = $activity_id = '';
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            $code_replaced = $myrow['code_replaced'];
            if( $status == 0 ) 
            {
                $label = 'default';
            }
            else if( $status == 1 ) 
            {
                $label = 'success';
            }
            else if( $status == 2 ) 
            {
                $label = 'info';
            }
            else if( $status == 3 ) 
            {
                $label = 'danger';
            }
            else if( $status == 4 ) 
            {
                $label = 'warning';
            }
            else if( $status == 5 ) 
            {
                $label = 'danger';
            }
            else
            {
                $label = 'danger';
            }
            $date_expire = ($date_expire != '' ? @date('Y-m-d', $date_expire) : '-');
            $date_start = ($date_start != '' && $date_start != 0 ? @date('Y-m-d', $date_start) : '-');
            if( in_array($period, $array['free']) ) 
            {
                $pp = ($period - 100) . ' Free Day(s)';
            }
            else
            {
                $pp = $period . ' Month(s)';
                if( $free_days > 0 ) 
                {
                    $pp = $period . 'M + ' . $free_days . 'D';
                }
            }
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='c'>" . $id . "</td>\r\n\t\t\t\t<td class='c'>" . $array['admins'][$adminid] . ("</td>\r\n\t\t\t\t<td>" . $fullname . "</td>\r\n\t\t\t\t\r\n\t\t\t\t<td class='c'>" . $code . '</td>');
            echo '<td class=\'c\'>' . $pp . "</td>\r\n\t\t\t\t\r\n\t\t\t\t<td class='c'>" . (($transid > 0 ? '<a href="' . $intro->app_url('trans', 'index') . ('?id=' . $transid . '">' . $transid . '</a>') : '-')) . ("</td>\r\n\t\t\t\t<td  class='c' id=\"status_" . $id . "\">\r\n\t\t\t\t\t<span class='label label-" . $label . "'>\r\n\t\t\t\t\t\t" . $intro->status[$status] . " \r\n\t\t\t\t\t\t") . (($code_replaced != '' ? '<br/>' . $code_replaced : '')) . ("\r\n\t\t\t\t\t</span>\r\n\t\t\t\t</td>\r\n\t\t\t\t<td class='c' id=\"mac_" . $id . "\">\r\n\t\t\t\t\t<a title='Model: " . $model . '\'>' . $mac . '</a>') . (($status != 0 ? $this->array_mac_type_txt[$mac_type] : '')) . "\r\n\t\t\t\t\t" . (($mac2 != '' ? '<br/>' . $mac2 : '')) . ("\r\n\t\t\t\t</td>\r\n\t\t\t\t<td class='c' id=\"sn_" . $id . '">' . $serial . "</td>\r\n\t\t\t\t<td class='c'>" . $date_start . "</td>\r\n\t\t\t\t<td class='c'>" . $date_expire . "</td>\r\n\t\t\t\t<td class='c'>" . $act_count . "</td>\r\n\t\t\t\t<td class='c'><a class='viewDevices' onclick='return false;' href=\"" . $this->base . '/ViewDevices/?NH=1&code=' . $code . '&mac=' . $mac . '&sn=' . $serial . "\">View</a></td>\r\n\t\t\t</tr>");
        }
        echo "</tbody>\r\n\t\t\t</table>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?' . $params, $totalrows, $rows_per_page, $page) . '</div>');
        echo "<script>\r\n\t\tvar spinner = \"<div class='text-center'><i class='fa fa-spinner fa-spin fa-5x fa-fw'></i></div>\";\r\n\t\t\$(document).on('click', '.viewDevices', function(){\r\n\t\t\t\r\n\t\t\t\$(\"#myModal .modal-title\").html('" . $code . "');\r\n\t\t\t\$(\"#myModal .modal-body\").html(spinner);\r\n\t\t\t\$(\"#myModal .modal-body\").load( \$(this).attr('href') + \"&NH=1\" );\r\n\t\t\t\$(\"#myModal\").modal(\"show\");\r\n\t\t\t\r\n\t\t});\r\n\t\t</script>";
    }
    public function ViewDevices()
    {
        global $intro;
        global $array;
        global $options;
        $qry = $params = '';
        $code = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('code'));
        $mac = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('mac'));
        $serial = _obf_0D162C393D0808073D1A062223322C0919102C28242A11($intro->input->get_post('sn'));
        $sql = $intro->db->query('select * from ' . PREFIX . ('_logs where code=' . $code . ' group by uagent'));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('Devices (' . money($totalrows) . (') fro code: ' . $code), 'primary');
        echo "<table class=\"DataTable table-striped table-bordered table-condensed\" id=\"table_codes\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th>#</th>\r\n\t\t\t<th>Useragent</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        $mac = $serial = $activity_id = '';
        while( $myrow = $intro->db->fetch_assoc($sql) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr>\r\n\t\t\t\t<td class='c'>" . $i . "</td>\r\n\r\n\t\t\t\t<td>" . $uagent . "</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t\t</table>";
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
}
