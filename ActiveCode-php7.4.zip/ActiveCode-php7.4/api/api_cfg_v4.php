<?php 
$_CFG = [];
$_CFG['XOR'] = 'yes';
$_CFG['XOR_KEY'] = '735649';
