<?php 
echo '﻿';
class Demand_AppAdmin
{
    public $appname = null;
    public $base = null;
    public $img_path = null;
    public function __construct($appname, $base, $img_path = '')
    {
        $this->appname = $appname;
        $this->base = $base;
        $this->img_path = $img_path;
    }
    public function error($index = '')
    {
        global $error;
        return (isset($error[$index]) ? $error[$index] : '');
    }
    public function nav()
    {
        global $intro;
        global $sess_admin;
        echo policy($sess_admin['adminid'], $this->appname . '.php');
        echo "<div class=\"app_nav\">\r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('index') . ('" href="' . $this->base . '/index"><icon class="icon-list"></icon>') . $intro->lang['demand_appname'] . "</a> \r\n\t\t<a class=\"btn btn-" . _obf_0D112A0B38292C2D10301E34042E37091B2A160D5B2501('Form') . (' p_add" href="' . $this->base . '/Form?t=add"><icon class="icon-plus-squared"></icon>') . $intro->lang['demand_add'] . "</a>  \t\t \t\t \r\n\t\t</div>";
    }
    public function index()
    {
        global $intro;
        global $array;
        $qry = '';
        $page = intval($intro->input->get_post('page'));
        $order = trim($intro->input->get_post('order'));
        $search_txt = trim($intro->input->get_post('search_txt'));
        $this->nav();
        if( $search_txt != '' ) 
        {
            $qry = ' where title  LIKE \'%' . $search_txt . '%\' ';
        }
        if( $order == '' ) 
        {
            $order = 'id:desc';
        }
        $order = str_replace(':', ' ', $order);
        $rows_per_page = 30;
        if( $page == 0 ) 
        {
            $page = 1;
        }
        $nexlimit = $page * $rows_per_page - $rows_per_page;
        $result = $intro->db->query('SELECT * from ' . PREFIX . ('_demand ' . $qry . ' order by ' . $order . '  limit ' . $nexlimit . ',' . $rows_per_page));
        $totrows = $intro->db->returned_rows;
        $sql_all_rows = $intro->db->query('SELECT id from ' . PREFIX . ('_demand ' . $qry . ' '));
        $totalrows = $intro->db->returned_rows;
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="icon-list"></i> ' . $intro->lang['demand_cur'] . (' (' . $totalrows . ')'), 'info');
        echo "\r\n\t\t\r\n\t\t<fieldset>\r\n\t\t\t<form action=\"\" method=\"post\">\r\n\t\t\t\t<input type=\"text\" name=\"search_txt\" value=\"" . $search_txt . '" placeholder="' . $intro->lang['search_form'] . "\" size=\"20\">\r\n\t\t\t\t<input name=\"name\" value=\"" . $intro->lang['search'] . "\" type=\"submit\">\r\n\t\t\t</form>\r\n\t\t</fieldset>\r\n\t\t\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n        <thead>\r\n\t    <tr>\r\n\t\t\t<th> </th>\r\n\t\t\t<th>ID " . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('id', 'index') . "</th>\r\n\t\t\t<th>" . $intro->lang['demand_dtime'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('dtime', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['demand_code'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('code', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['demand_title'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('title', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['demand_ip'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('ip', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['demand_theStatus'] . ' ' . _obf_0D0E3B101F1F141B17071E30192721091B1E0922351901('theStatus', 'index') . " </th>\r\n\t\t\t<th>" . $intro->lang['options'] . "</th>\r\n\t    </tr>\r\n\t\t</thead>\r\n\t\t\r\n\t\t<tbody>";
        $i = 0;
        while( $myrow = $intro->db->fetch_assoc($result) ) 
        {
            @extract($myrow);
            $i++;
            echo "\r\n\t\t\t<tr class=\"" . _obf_0D0E3B292A301E3D17315C402B08361326052C04400E22($i) . ("\">\r\n\t\t\t\t<td class=\"center\"><input type=\"checkbox\" value=\"" . $id . "\" name=\"selected_fld[]\"></td>\r\n\t\t\t\t<td class=\"center\">" . $id . "</td>\r\n\t\t\t\t<td>" . $dtime . "</td>\r\n\t\t\t\t<td>" . $code . "</td>\r\n\t\t\t\t<td>" . $title . "</td>\r\n\t\t\t\t<td>" . $ip . "</td>\r\n\t\t\t\t<td>" . $theStatus . "</td>\r\n\t\t\t\t<td class=\"center\"> \r\n\t\t\t\t\t<a class=\"btn btn-info p_edit\" href=\"" . $this->base . '/Form?t=edit&amp;id=' . $id . '" title="') . $intro->lang['edit'] . ("\"><i class=\"icon-edit\"></i></a>\r\n\t\t\t\t\t<a class=\"btn btn-danger p_del intro_ui_del\" href=\"" . $this->base . '/Del?id=' . $id . '" OnClick="return false;" title="') . $intro->lang['del'] . "\"><i class=\"icon-cancel-circled2\"></i></a>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>";
        }
        echo "</tbody>\r\n\t\t</table>\r\n\t\t</div>";
        $order = str_replace(' ', ':', $order);
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411('<div class=\'text-center\'>' . _obf_0D310332094006251F2A1D300709060C1C245B0E110B32($this->base . '/index?search_txt=' . $search_txt . '&amp;order=' . $order, $totalrows, $rows_per_page, $page) . '</div>');
    }
    public function multiDel()
    {
        global $intro;
        global $error;
        global $sess_admin;
        $selected_fld = $_POST['selected_fld'];
        $count = count($selected_fld);
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        for( $i = 0; $i < $count; $i++ ) 
        {
            $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_demand WHERE id=\'' . $selected_fld[$i] . '\' '));
        }
        $intro->redirect($this->appname);
    }
    public function Form($t = '')
    {
        global $intro;
        global $error;
        global $sess_admin;
        global $array;
        global $dtime;
        global $code;
        global $title;
        global $ip;
        global $theStatus;
        if( $error || $_POST != null ) 
        {
            @extract($_POST);
        }
        $id = intval($intro->input->get_post('id'));
        $t = ($t == '' ? $intro->input->get_post('t') : $t);
        $this->nav();
        if( $t == 'edit' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'edit');
            $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_demand WHERE id=' . $id . ';'));
            $row = $intro->db->fetch_assoc($sql);
            @extract($row);
            $btn['legend_name'] = $intro->lang['demand_edit'] . (' <b>' . $id . '</b>');
            $btn['legend_icon'] = 'icon-edit';
            $btn['name'] = $intro->lang['save_changes'];
            $btn['img_icon'] = 'icon-floppy';
            $btn['action'] = 'doEdit';
        }
        else if( $t == 'add' ) 
        {
            policy($sess_admin['adminid'], $this->appname . '.php', 'add');
            $btn['legend_name'] = $intro->lang['demand_add'];
            $btn['legend_icon'] = 'icon-plus-squared';
            $btn['name'] = $intro->lang['save'];
            $btn['img_icon'] = 'icon-plus-squared';
            $btn['action'] = 'doAdd';
        }
        echo _obf_0D032526222A033D1A2F331C092F2C3636101E15182F22('<i class="' . $btn['legend_icon'] . '"></i> ' . $btn['legend_name'] . ' ', 'info');
        echo "\r\n\t\t<form method=\"POST\" name=\"form_add\"  action=\"" . $this->base . '/' . $btn['action'] . "\" enctype=\"multipart/form-data\">\r\n\t\t<div class=\"table-responsive\">\r\n\t\t<table class=\"table table-bordered table-hover table-striped\">\r\n\t\t<tr>\r\n\t\t\t<td>" . $intro->lang['demand_dtime'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"dtime\" value=\"" . $dtime . '" size="30"> ' . $this->error('dtime') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['demand_code'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"code\" value=\"" . $code . '" size="30"> ' . $this->error('code') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['demand_title'] . (" :  <span style='color:#ff0000'>*</span></td>\r\n\t\t\t<td><input  type=\"text\" name=\"title\" value=\"" . $title . '" size="30"> ' . $this->error('title') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['demand_ip'] . (" : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"ip\" value=\"" . $ip . '" size="30"> ' . $this->error('ip') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td>") . $intro->lang['demand_theStatus'] . (" : </td>\r\n\t\t\t<td><input  type=\"text\" name=\"theStatus\" value=\"" . $theStatus . '" size="30"> ' . $this->error('theStatus') . "</td>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<td></td>\r\n\t\t\t<td>\r\n\t\t\t\t<input type=\"hidden\" name=\"app_name\"  value=\"" . $this->appname . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"t\"  value=\"" . $t . "\">\r\n\t\t\t\t<input type=\"hidden\" name=\"id\"  value=\"" . $id . "\">\r\n\t\t\t\t<button type=\"submit\" name=\"app_action\" value=\"" . $btn['action'] . "\">\r\n\t\t\t\t\t<i class=\"" . $btn['img_icon'] . '"></i> ' . $btn['name'] . " \r\n\t\t\t\t</button>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\t\t</div>\r\n\t\t</form>");
        echo _obf_0D011E16010C0A3322370E3E072C312F130B400C152411();
    }
    public function doAdd()
    {
        global $intro;
        global $error;
        $dtime = trim($intro->input->post('dtime'));
        $code = trim($intro->input->post('code'));
        $title = trim($intro->input->post('title'));
        $ip = trim($intro->input->post('ip'));
        $theStatus = trim($intro->input->post('theStatus'));
        if( $dtime == '' || $code == '' || $title == '' ) 
        {
            if( $dtime == '' ) 
            {
                $error['dtime'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $code == '' ) 
            {
                $error['code'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            if( $title == '' ) 
            {
                $error['title'] = '<span class=error>' . $intro->lang['required'] . '</span>';
            }
            $this->Form('add');
            exit();
        }
        $data['dtime'] = $dtime;
        $data['code'] = $code;
        $data['title'] = $title;
        $data['ip'] = $ip;
        $data['theStatus'] = $theStatus;
        $intro->db->insert(PREFIX . '_demand', $data);
        $id = $intro->db->insert_id();
        $intro->logs($this->appname, $intro->lang['demand_add'] . ' : ' . $id, $_POST);
        $intro->redirect($this->appname);
    }
    public function doEdit()
    {
        global $intro;
        global $array;
        $dtime = trim($intro->input->post('dtime'));
        $code = trim($intro->input->post('code'));
        $title = trim($intro->input->post('title'));
        $ip = trim($intro->input->post('ip'));
        $theStatus = trim($intro->input->post('theStatus'));
        $data['dtime'] = $dtime;
        $data['code'] = $code;
        $data['title'] = $title;
        $data['ip'] = $ip;
        $data['theStatus'] = $theStatus;
        $id = intval($intro->input->post('id'));
        $intro->db->update(PREFIX . '_demand', $data, 'id=' . $id);
        $intro->logs($this->appname, $intro->lang['demand_edit'] . ' : ' . $id, $_POST);
        $intro->redirect($this->appname);
    }
    public function Del()
    {
        global $intro;
        global $sess_admin;
        global $array;
        $id = intval($intro->input->get_post('id'));
        policy($sess_admin['adminid'], $this->appname . '.php', 'del');
        $sql = $intro->db->query('SELECT * FROM ' . PREFIX . ('_demand WHERE id=' . $id . ';'));
        $row = $intro->db->fetch_assoc($sql);
        $sql = $intro->db->query('DELETE FROM ' . PREFIX . ('_demand WHERE id=' . $id . '; '));
        $intro->logs($this->appname, 'delete : ' . $id, $row);
        $intro->redirect($this->appname);
    }
    public function Active()
    {
        global $intro;
        global $id;
        $sql = $intro->db->query('UPDATE ' . PREFIX . ('_demand SET status=\'1\' WHERE id=\'' . $id . '\' '));
        $intro->redirect($this->appname);
    }
}
