<?php
error_reporting(0);
define("_CHECK_X_ME", true);
include "load2.php";
$intro->admin_folder = "";
$intro->auth->flag = "admin";
$login = new Login();
$maa = $intro->input->get_post("maa");
if (isset($maa) != "" && method_exists($login, $maa)) {
    $login->{$maa}();
} else {
    $login->Login();
}
class Login
{
    public $error = NULL;
    public $appname = "login";
    public function __construct()
    {
    }
    public function Login()
    {
        global $intro;
        global $maaking_ver;
        $site_name = "";
        $pagetitle = "";
        $_SESSION["cokl"] = [md5(uniqid() . "gsadjkfGH"), md5(uniqid() . "gsAsxdjkfGH")];
        $name1 = $_SESSION["cokl"][0];
        $name2 = $_SESSION["cokl"][1];
        $username = $intro->input->post("username");
        $password = $intro->input->post("password");
        $goto = $intro->input->get_post("goto");
        include "style/login.php";
    }
    public function do_login()
    {
        global $intro;
        global $remember;
        global $error;
        global $error_msg;
        $intro->db->halt_on_errors = false;
        $this->checkLoginTries();
        if (!isset($_SESSION["cokl"][0]) || !isset($_SESSION["cokl"][1])) {
            $intro->auth->clearCookies(true);
            $intro->sess->stop();
            $location = "login.php?need_to_clear_site_data=" . time();
            echo "<script type=\"text/javascript\">window.location.href=\"" . $location . "\";</script>";
            echo "<noscript><meta http-equiv=\"refresh\" content=\"0;url=" . $location . "\" /></noscript>";
            exit;
        }
        $name1 = $_SESSION["cokl"][0];
        $name2 = $_SESSION["cokl"][1];
        $ip = $intro->input->ip_address();
        $admin_name = strip_tags($intro->input->post($name1));
        $admin_name = preg_replace("/[^a-zA-Z0-9-]/ui", "", $admin_name);
        $password = $intro->input->post($name2);
        $goto = $intro->input->post("goto");
        if (30 < strlen($admin_name) || 30 < strlen($password)) {
            $err_toolong = "(<span class=error>OOPS! You post too long data.</span>)";
            if (30 < strlen($admin_name)) {
                $this->error["user"] = $err_toolong;
            }
            if (30 < strlen($password)) {
                $this->error["pass"] = $err_toolong;
            }
            $this->Login();
            exit;
        }
        if (!$admin_name || !$password) {
            $reqmsg = "(<span class=error>Required!</span>)";
            if (empty($admin_name)) {
                $this->error["user"] = $reqmsg;
            }
            if (empty($password)) {
                $this->error["pass"] = $reqmsg;
            }
            $this->Login();
            exit;
        }
        if ($intro->auth->check_admin_and_login($admin_name, $intro->pwd($password))) {
            $USER_AGENT = $_SERVER["HTTP_USER_AGENT"];
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222($this->appname, "login_success", (string) $USER_AGENT, $admin_name);
            $_SESSION["cokl"] = "";
            unset($_SESSION["cokl"]);
            $intro->redirect("home", "index");
        } else {
            $this->error["msg"] = "<div class=\"error_msg\">Login error. Please check admin name/password.</div>";
            $this->error["pass"] = "";
            $this->error["user"] = $this->error["pass"];
            $this->LoginTries($admin_name);
            _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222($this->appname, "login_fail", "User=" . $admin_name . "<br/>Pass=" . $password, $admin_name);
            unset($password);
            $this->Login();
            exit;
        }
    }
    public function LoginTries($username)
    {
        global $intro;
        $ip = getUserIP();
        $time = time();
        $diff = time() + 1800;
        $intro->db->query_fast("INSERT INTO `" . PREFIX . "_login_ips` (`username`,`ip`,`timeDiff`,`tries`) " . " VALUES ('" . $username . "','" . $ip . "','" . $diff . "',1) ON DUPLICATE KEY UPDATE `timeDiff`='" . $diff . "',`tries`=`tries`+1;");
    }
    public function checkLoginTries()
    {
        global $intro;
        $ip = getUserIP();
        $time = time();
        $diff = time() + 600;
        $sql = $intro->db->query_fast("SELECT timeDiff FROM `" . PREFIX . "_login_ips` WHERE ip='" . $ip . "' AND `tries`>=3;");
        if (0 < $intro->db->returned_rows) {
            $row = $intro->db->fetch_assoc($sql);
            if (time() < $row["timeDiff"]) {
                $this->htmlHeader();
                echo _obf_0D3D40321528110F062A0B0321102712170C15030F2232("Your IP (" . $ip . ") is blocked for 30 minutes. Please contact system admin to unblock your IP.", "danger");
                exit;
            }
        }
    }
    public function htmlHeader()
    {
        echo "<!DOCTYPE html>\n\t\t<html>\n\t\t<head>\n\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n\t\t<meta content=\"text/html; charset=utf-8\" http-equiv=\"Content-Type\" />\n\t\t<meta charset=\"utf-8\" />\n\t\t<title>Login</title>\n\t\t<link rel=\"stylesheet\" href=\"style/css/bootstrap.min.css\">\t\n\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\"style/css/login.css\">\n\t\t</head>\n\t\t<body style='padding:50px;'>";
    }
    public function Logout()
    {
        global $intro;
        $sess_admin = $intro->auth->sess_admin();
        $admin = $sess_admin["admin_name"];
        _obf_0D0D330C0B172A3C08290D16362D1A5C131A1A22091222($this->appname, "logout", "", $admin);
        $sess_admin = $intro->auth->logout();
        $ip = $intro->input->ip_address();
        $intro->sess->stop();
        $location = "login.php";
        if (!headers_sent()) {
            header("Location: " . $location);
        } else {
            echo "<script type=\"text/javascript\">window.location.href=\"" . $location . "\";</script>";
            echo "<noscript><meta http-equiv=\"refresh\" content=\"0;url=" . $location . "\" /></noscript>";
        }
        exit;
    }
    public function ResetCode()
    {
        global $intro;
        $code = trim($intro->input->get_post("code"));
        $code = preg_replace("/[^0-9]/", "", $code);
        $result = $intro->db->query("SELECT * FROM " . PREFIX . "_codes WHERE code='" . $code . "' AND status=1 AND inputBy=0;");
        if (mysqli_num_rows($result) == 0) {
            echo "<div class=\"alert alert-danger\" role=\"alert\">Sorry! code is not found!!! Or code is Suspended/Expired. Or code is not Activated Yet.</div>";
        } else {
            $data = [];
            $data["mac"] = "reset_me";
            $data["serial"] = "reset_me";
            $intro->db->update(PREFIX . "_codes", $data, "code='" . $code . "'");
            echo "<div class=\"alert alert-success\" role=\"alert\">Success! code is now in reset mode, you can Re-activate it now.</div>";
        }
    }
    public function ResetCodeAct()
    {
        global $intro;
        $adminid = $intro->auth->sess_reset()["adminid"];
        if ($adminid == 0) {
            exit("<h3 style='color:red'>Please login.</h3>");
        }
        $code = trim($intro->input->post("code"));
        $code = preg_replace("/[^0-9]/", "", $code);
        if (strlen($code) < 10) {
            exit("<h3 style='color:red'>Code notfound.</h3>");
        }
        $result = $intro->db->query("SELECT * FROM " . PREFIX . "_codes WHERE code='" . $code . "' AND status=1 AND inputBy=0;");
        if (mysqli_num_rows($result) == 0) {
            echo "<div class=\"alert alert-danger\" role=\"alert\">Sorry! code is not found!!!.</div>";
            exit;
        }
        $row = $intro->db->fetch_assoc($result);
        $id = intval($row["id"]);
        $adminid = intval($row["adminid"]);
        $old_code = $row["code"];
        $old_length = strlen($old_code);
        $old_length = $old_length <= 10 ? 12 : $old_length;
        $new_code = random_number($old_length);
        $sql = $intro->db->query("SELECT * FROM " . PREFIX . "_codes where code='" . $new_code . "';");
        if (0 >= $intro->db->returned_rows) {
            $intro->db->insert(PREFIX . "_codes_change", ["code_id" => $id, "old_code" => $old_code, "new_code" => $new_code, "reseller" => $adminid, "dtime" => date("Y-m-d H:i:s")]);
            $intro->db->query("UPDATE " . PREFIX . "_codes set code='" . $new_code . "',act_count=0 where id=" . $id . ";");
            $intro->db->query("UPDATE `users` set username='" . $new_code . "' where id=" . intval($row["userid"]));
            echo "<div class=\"alert alert-success\" role=\"alert\">Success. Activation Limit has been reset. Please remember your new Code.";
            echo "<h3>\n\t\tNew code is: " . $new_code . "\n\t\t</h3>\n\t\tNote: You must do Refresh on Android APP.\n\t\t</div>";
        }
    }
    public function do_Forgot_pwd()
    {
        global $admin;
        global $intro;
        global $db;
        global $email;
        global $admin_name;
        global $error_msg;
        global $site_name;
        global $site_email;
        global $site_url;
        $admin_name = trim($_POST['admin_name']);
        $email = trim($_POST['email']);
        $result = $intro->db->query('SELECT * FROM ' . PREFIX . ('_admin WHERE adm_username=\'' . $admin_name . '\' AND email=\'' . $email . '\''));
        $check = mysqli_num_rows($result);
        if ($check == 1) {
            function new_pwd()
            {
                $chars = 'abchefghjkmnpqrstuvwxyz0123456789';
                srand((double) microtime() * 1000000);
                for ($i = 0; $i <= 7; $i++) {
                    $num = rand() % 33;
                    $tmp = substr($chars, $num, 1);
                    $pwd = $pwd . $tmp;
                }
                return $pwd;
            }
            $new_pwd = new_pwd();
            $md5_password = $intro->pwd($new_pwd);
            $sql = $intro->db->query('UPDATE ' . PREFIX . ('_admin SET adm_password=\'' . $md5_password . '\' WHERE email=\'' . $email . '\''));
            $subject = 'New password';
            $message = "\n\t\tHello " . $admin_name . ",\n\n\t\tYou are receiving this email because you have (or someone pretending to be you has) requested a new password be sent for your account on " . $site_name . ".\n\n\t\tHere it is below.\n\t\t--------------------------\n\t\tadmin name: " . $admin_name . "\n\t\tPassword: " . $new_pwd . "\n\t\t--------------------------\n\t\tYou may login below:\n\t\t" . $site_url . "\n\n\t\tYou can of course change this password yourself via the profile page. If you have any difficulties please contact the webmaster.\n\n\t\t--\n\t\t-Thanks\n\t\t" . $site_name . "\n\n\t\tThis email was automatically generated.\n\t\tPlease do not respond to this email or it will ignored.";
            mail($email, $subject, $message, 'FROM: ' . $site_name . ' <' . $site_email . '>');
            _obf_0D241E331B2535320F331F131F02113E383F0A02163532('تم توليد كلمة مرور جديدة وارسالها الى بريدك الالكتروني .... الرجاء قم بفحص بريدك الالكتروني ', 'login.php', '5');
        } else {
            $this->error['msg'] = '<center><font class="error">خطأ: تأكد من اسم المشرف أو البريد الالكتروني</font></center><br>';
            $this->error['user'] = '';
            $this->error['pass'] = '';
            $this->Login();
        }
    }
}