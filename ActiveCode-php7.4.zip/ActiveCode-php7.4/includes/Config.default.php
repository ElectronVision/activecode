<?php 
$config = [];
$config['base_url'] = '/iptv/';
$config['db']['hostname'] = 'localhost';
$config['db']['username'] = 'root';
$config['db']['password'] = '';
$config['db']['database'] = 'xtream_iptvpro';
$config['db']['port'] = '';
$config['db']['charset'] = 'utf8';
$config['db']['collation'] = 'utf8_general_ci';
$config['production'] = false;
define('PREFIX', 'maa');
